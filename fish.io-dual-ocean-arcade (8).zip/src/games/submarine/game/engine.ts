import { SPECIES, SKINS, FRY, POISON_FISH, POISON_NUDIBRANCH, skinToSpecies, getBotNames } from "./species";
import type { Species, Skin } from "./species";
import { fishSprite, fishMouthOffset, coinSprite, beginSpriteFrame, spriteBudgetLeft } from "./sprites";
import type { EyeExpr, JawState } from "./sprites";
import { Ocean, WORLD_W, WORLD_H, DEEP_START, floorY, glowOrb, zoneAt, depthMeters } from "./ocean";
import type { ReefCave } from "./ocean";
import { fish3d, disposeFish3DShared, isSoftwareWebGL } from "./fish3d";
import type { Fish3DPose } from "./fish3d";
import { disposeReef3DRenderer } from "./reef3d";
import { LautWorld } from "./laut/world";
import { ReefResidents } from "./residents";
import { SHARED } from "./laut/glsl";
import { MedusaGarden, STING_SECONDS } from "./medusae";
import type { AppLang, GraphicsMode, OceanLightingMode, ReefMixMode, ReefRockMode } from "../save";
import { getLocalizedSpeciesName, ZONE_LABELS_I18N } from "../i18n";
import { getMine3DSprites } from "./mine3d";
import { drawSunfish, computeDirectionalSunfishBite } from "./sunfish";
import type { SunfishBonus } from "./sunfish";
import { Decor3DManager } from "./decor3d";
import { drawHarborAndCloudsSky, drawSkyBalloon, getBalloonDanglingItemPos } from "./harborSky";
import type { SkyBalloon, BalloonKind } from "./harborSky";

let bubbleStamp: HTMLCanvasElement | null = null;
/** a real-looking air bubble: clear centre, thin bright rim, refracted light pooling at the bottom, crisp specular */
function getBubbleStamp(): HTMLCanvasElement {
  if (bubbleStamp) return bubbleStamp;
  const S = 64;
  const cv = document.createElement("canvas");
  cv.width = S;
  cv.height = S;
  const c = cv.getContext("2d")!;
  const cx = S * 0.5,
    cy = S * 0.5,
    r = S * 0.44;
  // faint body tint (water seen through the bubble is a touch brighter)
  const body = c.createRadialGradient(cx, cy, r * 0.1, cx, cy, r);
  body.addColorStop(0, "rgba(220, 250, 255, 0.05)");
  body.addColorStop(0.72, "rgba(200, 245, 255, 0.08)");
  body.addColorStop(0.9, "rgba(190, 240, 255, 0.28)");
  body.addColorStop(1, "rgba(180, 235, 255, 0.0)");
  c.fillStyle = body;
  c.beginPath();
  c.arc(cx, cy, r, 0, Math.PI * 2);
  c.fill();
  // refraction: light collects along the lower-right inside edge
  c.save();
  c.beginPath();
  c.arc(cx, cy, r * 0.93, 0, Math.PI * 2);
  c.clip();
  const refr = c.createRadialGradient(cx + r * 0.25, cy + r * 0.3, r * 0.2, cx + r * 0.25, cy + r * 0.3, r * 0.95);
  refr.addColorStop(0, "rgba(255, 255, 255, 0)");
  refr.addColorStop(0.7, "rgba(230, 252, 255, 0.12)");
  refr.addColorStop(1, "rgba(255, 255, 255, 0.55)");
  c.fillStyle = refr;
  c.fillRect(0, 0, S, S);
  c.restore();
  // thin rim, brighter at top-left where the light hits
  const rim = c.createLinearGradient(cx - r, cy - r, cx + r, cy + r);
  rim.addColorStop(0, "rgba(255, 255, 255, 0.95)");
  rim.addColorStop(0.5, "rgba(200, 245, 255, 0.5)");
  rim.addColorStop(1, "rgba(235, 252, 255, 0.85)");
  c.strokeStyle = rim;
  c.lineWidth = S * 0.045;
  c.beginPath();
  c.arc(cx, cy, r * 0.96, 0, Math.PI * 2);
  c.stroke();
  // main specular highlight (elongated) + small secondary glint opposite
  c.save();
  c.translate(cx - r * 0.38, cy - r * 0.4);
  c.rotate(-0.75);
  const hl = c.createRadialGradient(0, 0, 0, 0, 0, r * 0.3);
  hl.addColorStop(0, "rgba(255, 255, 255, 1)");
  hl.addColorStop(0.5, "rgba(255, 255, 255, 0.7)");
  hl.addColorStop(1, "rgba(255, 255, 255, 0)");
  c.fillStyle = hl;
  c.scale(1.6, 1);
  c.beginPath();
  c.arc(0, 0, r * 0.3, 0, Math.PI * 2);
  c.fill();
  c.restore();
  c.fillStyle = "rgba(255, 255, 255, 0.8)";
  c.beginPath();
  c.arc(cx + r * 0.42, cy + r * 0.45, r * 0.07, 0, Math.PI * 2);
  c.fill();
  bubbleStamp = cv;
  return cv;
}

let pearlSprite: HTMLCanvasElement | null = null;
function getPearlSprite(): HTMLCanvasElement {
  if (pearlSprite) return pearlSprite;
  const S = 38; // 2x oversampled for crisp 19x19 draw
  const cv = document.createElement("canvas");
  cv.width = S;
  cv.height = S;
  const c = cv.getContext("2d")!;
  const cx = S * 0.5;
  const cy = S * 0.5;
  const pg = c.createRadialGradient(cx - 5.2, cy - 5.6, 1.6, cx, cy, 16.4);
  pg.addColorStop(0, "#ffffff");
  pg.addColorStop(0.42, "#fff7f2");
  pg.addColorStop(0.75, "#f3d8f4");
  pg.addColorStop(0.92, "#b8d4ec");
  pg.addColorStop(1, "#7c94be");
  c.fillStyle = pg;
  c.beginPath();
  c.arc(cx, cy, 15.6, 0, Math.PI * 2);
  c.fill();
  c.strokeStyle = "rgba(255, 255, 255, 0.92)";
  c.lineWidth = 2.1;
  c.stroke();
  pearlSprite = cv;
  return cv;
}

const mineSpriteCache = new Map<number, { cv: HTMLCanvasElement; span: number }>();
function getMineSprite(r: number): { cv: HTMLCanvasElement; span: number } {
  const key = Math.round(r * 2);
  let e = mineSpriteCache.get(key);
  if (e) return e;
  const qr = key * 0.5;
  const pad = 10;
  const span = (qr + pad) * 2;
  const S = 2; // 2x oversampled
  const cv = document.createElement("canvas");
  cv.width = Math.ceil(span * S);
  cv.height = Math.ceil(span * S);
  const c = cv.getContext("2d")!;
  c.setTransform(S, 0, 0, S, (qr + pad) * S, (qr + pad) * S);

  for (let i = 0; i < 8; i++) {
    const ang = (i * Math.PI) / 4;
    c.save();
    c.rotate(ang);
    c.fillStyle = "#94a3b8";
    c.strokeStyle = "#334155";
    c.lineWidth = 1.25;
    c.beginPath();
    c.moveTo(-2.7, -qr + 1.5);
    c.lineTo(-1.3, -qr - 6.8);
    c.lineTo(1.3, -qr - 6.8);
    c.lineTo(2.7, -qr + 1.5);
    c.closePath();
    c.fill();
    c.stroke();
    c.fillStyle = "#dc2626";
    c.beginPath();
    c.arc(0, -qr - 7.1, 1.55, 0, Math.PI * 2);
    c.fill();
    c.restore();
  }

  const mg = c.createRadialGradient(-qr * 0.34, -qr * 0.36, 1.2, 0, 0, qr * 1.05);
  mg.addColorStop(0, "#f1f5f9");
  mg.addColorStop(0.28, "#cbd5e1");
  mg.addColorStop(0.7, "#94a3b8");
  mg.addColorStop(1, "#475569");
  c.fillStyle = mg;
  c.beginPath();
  c.arc(0, 0, qr, 0, Math.PI * 2);
  c.fill();
  c.strokeStyle = "#334155";
  c.lineWidth = 1.65;
  c.stroke();

  c.strokeStyle = "rgba(226, 232, 240, 0.55)";
  c.lineWidth = 1.1;
  c.beginPath();
  c.ellipse(0, 0, qr * 0.92, qr * 0.34, 0.25, 0, Math.PI * 2);
  c.stroke();

  e = { cv, span };
  mineSpriteCache.set(key, e);
  return e;
}
import { sfx } from "./audio";

export const fishLen = (r: number) => r * 2.55 + 3;

export interface Upgrades {
  suck: number;
  speed: number;
  size: number;
}
export interface StartOpts {
  name: string;
  skin: Skin;
  upgrades: Upgrades;
  speedScale?: number;
  bulkScale?: number;
}
export interface LeaderRow {
  name: string;
  score: number;
  me: boolean;
  color: string;
}
export interface HudState {
  coins: number;
  score: number;
  mass: number;
  energy: number;
  combo: number;
  comboT: number;
  frenzyStage: number;
  level: number;
  growthPct: number;
  stageNum: number;
  zoneName: string;
  rank: number;
  total: number;
  leaderboard: LeaderRow[];
  alive: boolean;
  exhausted: boolean;
  boost: number;
  boostExhausted: boolean;
  sucking: boolean;
  boosting: boolean;
  shieldT: number;
  turboT: number;
  vortexT: number;
  clockT: number;
}
export interface DeathInfo {
  score: number;
  coins: number;
  killer: string;
  killerSpId: string;
  playerSkinId: string;
  playerMode3D: boolean;
  playerName: string;
  maxMass: number;
  eaten: number;
  botsEaten: number;
  maxCombo: number;
  maxDepth: number;
  deepestZone: string;
  stageNum: number;
  bestRank: number;
  schoolSweeps: number;
  time: number;
  reachedRank1: boolean;
  peakLevelTime: number | null;
}
export type GameEvent =
  | { type: "combo"; n: number }
  | { type: "frenzy"; n: number }
  | { type: "levelup"; text: string }
  | { type: "feed"; text: string }
  | { type: "bonus"; title: string; text: string }
  | { type: "coinbump" }
  | { type: "rank1" }
  | { type: "peaklevel"; timeSec: number };

type Kind = "npc" | "bot" | "player";
let NEXT_ID = 1;

class Fish {
  id = NEXT_ID++;
  kind: Kind;
  sp: Species;
  key: string;
  skinRef?: Skin;
  x: number;
  y: number;
  vx = 0;
  vy = 0;
  mass: number;
  r: number;
  face = 1;
  tilt = 0;
  tiltV = 0;
  bend = 0;
  bendV = 0;
  sq = 0;
  sqv = 0;
  tailPh = Math.random() * 6;
  jaw = 0;
  jawV = 0;
  mouthOpenT = 0;
  chompT = 0;
  chompQueue = 0; // queued rapid bite snaps (1 snap per fish eaten outside suction mode!)
  chompPhase = 0; // countdown for active snap in queue
  chompDur = 0.13;
  chompBitFired = false;
  biteLunge = 0; // dynamic visual strike lunge along swim heading
  biteLungeV = 0;
  wantOpen = false;
  wantOpenAmt = 0;
  wantGrab = false;
  sucking = false;
  suckVis = 0; // smooth 0..1 visual fade for suction mist
  turnFlip = 1; // smooth -1..+1 horizontal turn flip (zero instant mirror snap!)
  turnBend = 0; // signed elastic C-curve spine flex during 180-deg 3D turns
  turnBendV = 0;
  exhausted = false;
  energy = 1;
  boosting = false;
  boostVis = 0; // smooth 0..1 boost surge for rear-40% wiggle
  boost = 1;
  boostExhausted = false;
  boostTrail = 0;
  name = "";
  color = "#fff";
  eatenBy: Fish | null = null;
  eatT = 0;
  eatFromX = 0;
  eatFromY = 0;
  dead = false;
  combo = 0;
  comboT = 0;
  score = 0;
  invuln = 0;
  sucked = 0;
  speedMul = 1;
  suckMul = 1;
  maxR = 999;
  fry = false; // tiny schooling snack fish
  school: School | null = null;
  slotA = 0; // slot (angle / radius) inside the school formation
  caught = false;
  slotR = 0;
  gulpT = 0; // 1 -> 0 while a swallowed bite travels down the body as a bulge
  gulpK = 0;
  swallowT = 0; // 1 -> 0 while 3D prey bolus glides past pharynx into esophagus
  eatReachT = 0; // 0 -> 1 while octopus 2 feeding tentacles reach for close prey (not during suction!)
  eatPullT = 0; // 1 -> 0 while octopus 2 feeding tentacles grab & pull prey under head before hap
  eatPullDur = 0.44;
  eatPullSuck = false;
  tentTrail = 0; // spring-smoothed velocity trail for supple trailing tentacles
  tentTrailV = 0;
  tentVertLag = 0; // vertical whip lag when climbing/diving
  tentVertLagV = 0;
  tentTurnLag = 0; // lateral centrifugal whip lag when turning
  tentTurnLagV = 0;
  lastVx = 0;
  lastVy = 0;
  gulpColor = "#ff8fa3";
  gulpTailColor = "#ffd166";
  munch = false; // chewing a big mouthful
  slurpCd = 0; // cooldown between two fry swallows (gives the slurp its rhythm)
  hiddenCave: ReefCave | null = null;
  inCaveId: number | null = null;
  inAir = false;
  divePlungeT = 0;
  airJumpCd = 1 + Math.random() * 6;
  splashCd = 0;
  ai = { tx: 0, ty: 0, timer: 0, target: null as Fish | null, chase: 0, rest: 0, flee: false };

  constructor(kind: Kind, sp: Species, key: string, x: number, y: number, mass: number) {
    this.kind = kind;
    this.sp = sp;
    this.key = key;
    this.x = x;
    this.y = y;
    this.mass = mass;
    this.r = Math.sqrt(mass);
    this.ai.tx = x;
    this.ai.ty = y;
  }

  mouthOff(): [number, number] {
    return fishMouthOffset(this.sp, fishLen(this.r));
  }
  mouthX() {
    const [ox, oy] = this.mouthOff();
    return this.x + this.face * (ox * Math.cos(this.tilt) - oy * Math.sin(this.tilt));
  }
  mouthY() {
    const [ox, oy] = this.mouthOff();
    return this.y + ox * Math.sin(this.tilt) + oy * Math.cos(this.tilt);
  }
}

interface Particle {
  x: number;
  y: number;
  vx: number;
  vy: number;
  life: number;
  max: number;
  type: "bubble" | "bit" | "spark" | "suck" | "ring" | "star" | "streak" | "chomp" | "glint" | "smoke" | "blast" | "splash";
  color: string;
  size: number;
  aspect?: number;
  dir?: number;
  target?: Fish;
}
interface SurfaceWave {
  x: number;
  r: number;
  strength: number;
  age: number;
  maxAge: number;
  entering: boolean;
}
interface Mine {
  x: number;
  y: number;
  baseY: number;
  r: number;
  rot: number;
  rotSp: number;
  ph: number;
  tether: number;
}
interface Txt {
  x: number;
  y: number;
  text: string;
  color: string;
  life: number;
  max: number;
  size: number;
}
interface FlyCoin {
  x: number;
  y: number;
  vx: number;
  vy: number;
  t: number; // < 0 while waiting for its staggered pop
  value: number;
  sx: number; // where the swoop to the HUD starts
  sy: number;
  bend: number; // sideways bulge of the swoop
  trail: number;
}
interface School {
  x: number;
  y: number;
  vx: number;
  vy: number;
  tx: number;
  ty: number;
  timer: number;
  members: Fish[];
  sp: Species;
  pref: "upper" | "any" | "deep";
  panic: number; // 0 calm .. 1 bait-ball
  swirl: number;
  dir: number;
  size0: number;
  byPlayer: number;
  speed: number;
  golden?: boolean;
}
interface WorldCoin {
  x: number;
  y: number;
  vx: number;
  vy: number;
  t: number;
  value: number;
  settled: boolean;
}
type OrbKind = "pearl" | "turbo" | "vortex" | "shield";
interface OrbItem {
  x: number;
  y: number;
  vx: number;
  vy: number;
  kind: OrbKind;
  t: number;
  ph: number;
}

export const EAT_RATIO = 0.88;
export const BOT_EAT_RATIO = 0.74; // rival duels (player vs bot / bot vs bot) require clear ~1.35x radius (~1.83x mass) advantage!
const SCHOOL_COUNT = 21;
const LOAD_BUDGET = 12; // ms of world generation per slice so menu UI stays responsive at 60 FPS
const SPRITE_BUDGET = 2;
const MAX_PIXELS_BY_MODE: Record<GraphicsMode, number> = {
  hd_boost: 2_800_000, // full 1080p+ crisp HiDPI without blur
  super_hd: 4_500_000, // 2K / Retina SSAA ultra sharpness
  ultra_fps: 1_650_000, // high-FPS fill-rate paired with GPU RCAS sharpening
};
const MAX_DPR_BY_MODE: Record<GraphicsMode, number> = {
  hd_boost: 2.0,
  super_hd: 2.25,
  ultra_fps: 1.5,
};
const MENU_MAX_PIXELS = 1_200_000; // crisp full-screen ocean behind main menu
const Q_SCALE = [1, 0.96, 0.9, 0.85]; // preserve razor clarity on submarine, divers & coral
const GRID_CELL = 140;
const GRID_COLS = Math.ceil(WORLD_W / GRID_CELL) + 1;
const GRID_ROWS = Math.ceil(WORLD_H / GRID_CELL) + 1;
const COIN_POP = 0.42; // seconds a coin spends popping out of the mouth
const COIN_FLY = 0.5; // seconds of the swoop to the coin counter
const GAIN = 0.115;
const NPC_TARGET = 600;
const NPC_SPEED = 1.0;
const BOT_COUNT = 79; // 79 rival players + you = 80 players in the 1.6x wider ocean
const MINE_COUNT = 24; // Feeding Frenzy spiked naval sea mines scattered across all depths
const SUNFISH_COUNT = 6; // Non-playable Ocean Sunfish (Mola-mola) 6-bite Food Bonus creatures
const POISON_TARGET = 42; // Poisonous green-brown fish scattered through the ocean
const WORDS_EN = ["CHOMP!", "SNAP!", "GULP!", "CRUNCH!", "YUMMY!", "AWESOME!", "SLURP!"];
const WORDS_ID = ["NYAM!", "HAP!", "GULP!", "CHOMP!", "YUMMY!", "MANTAP!", "SLURP!"];
const SURFACE_Y = 4;
const SKY_TOP_LIMIT = -250;
const MIN_CAM_TOP = -260;
const AIR_GRAVITY = 560;

const clamp = (v: number, a: number, b: number) => (v < a ? a : v > b ? b : v);

export class Game {
  canvas: HTMLCanvasElement;
  ctx: CanvasRenderingContext2D;
  ocean: Ocean;
  fish: Fish[] = [];
  player: Fish | null = null;
  particles: Particle[] = [];
  surfaceWaves: SurfaceWave[] = [];
  texts: Txt[] = [];
  flyCoins: FlyCoin[] = [];
  worldCoins: WorldCoin[] = [];
  orbs: OrbItem[] = [];
  balloons: SkyBalloon[] = [];
  mines: Mine[] = [];
  mineTimers: number[] = [];
  sunfish: SunfishBonus[] = [];
  sunfishTimers: number[] = [];
  sunfishSeq = 0;
  blastFlash = 0;
  orbTimer = 6;
  balloonTimer = 7;
  goldenTimer = 36;
  shieldT = 0;
  stunT = 0; // jellyfish sting: dizzy & paralysed
  stingCd = 0;
  knockT = 0; // bounced off a jellyfish bell: free flight, no steering
  bounceCd = 0;
  poisonDelayQueue: number[] = []; // 2.0s delay before poison dizziness kicks in
  poisonDizzyT = 0; // 2.0s dizziness duration with orbiting 3D yellow stars
  turboT = 0;
  vortexT = 0;
  clockT = 0;
  motes: { x: number; y: number; s: number; col: string; orb: HTMLCanvasElement }[] = [];
  respawnQueue: { t: number; name: string; skin: Skin }[] = [];
  schools: School[] = [];
  schoolTimers: number[] = [];
  schoolSeq = 0;
  streamPts = 0; // running totals of the current slurp chain (shown as one summary pop)
  streamCoins = 0;
  streamN = 0;
  streamT = 0;
  chainPop = 0;
  coinChain = 0;
  lastCoinT = 0;
  cam = { x: WORLD_W / 2, y: 520 };
  camLeft = 0;
  camTop = 0;
  zoom = 2.5;
  dpr = 1;
  pixelMode = false;
  reef3D = true;
  /** "Dunia Laut 3D": live three.js water + coral reef (PENYELAM look) behind the 2D arcade layer */
  lautOn = false;
  laut: LautWorld | null = null;
  medusae = new MedusaGarden();
  residents = new ReefResidents();
  decor3d = new Decor3DManager();
  reefMix: ReefMixMode = "game1";
  rockStyle: ReefRockMode = "g1";
  bgStyle: "game1" | "game2" | "reef_g1" | "shipwreck" | "kelp" | "temple" | "lagoon" = "game1";
  oceanLighting: OceanLightingMode = "after";
  graphicsMode: GraphicsMode = "hd_boost";
  private habitatImg: HTMLImageElement | null = null;
  private shipwreckImg: HTMLImageElement | null = null;
  private kelpImg: HTMLImageElement | null = null;
  private templeImg: HTMLImageElement | null = null;
  private lagoonImg: HTMLImageElement | null = null;
  mode3D = false;
  private live3DBudget = 16;
  private fishLitBudget = 160;
  private fishLitCv: HTMLCanvasElement | null = null;
  private fishLitCtx: CanvasRenderingContext2D | null = null;
  private causticPatCanvas: HTMLCanvasElement | null = null;
  private causticPattern: CanvasPattern | null = null;
  private readonly scratchLight = { sunBeam: 0, caustic: 0, depthK: 0, shallowK: 0, ventWarm: 0, lampCool: 0, subWarm: 0 };
  vw = 320;
  vh = 180;
  mouse = { x: 0, y: 0, sx: 0, sy: 0, active: false };
  camVel = { x: 0, y: 0 };
  suckInput = false;
  boostInput = false;
  t = 0;
  shake = 0;
  freeze = 0;
  sessionCoins = 0;
  arcadeScore = 0;
  eatenCount = 0;
  botsEatenCount = 0;
  maxCombo = 0;
  maxDepthY = 0;
  bestRank = 99;
  reachedRank1 = false;
  peakLevelTime: number | null = null;
  schoolSweeps = 0;
  playerSkinId = "orange";
  playerMode3D = false;
  maxMass = 0;
  startMass = 58;
  startTime = 0;
  level = 0;
  deathTimer = -1;
  killerName = "";
  killerSpId = "";
  coinTimer = 0;
  hudTimer = 0;
  caveMsgCd = 0;
  caveZoom = 0;
  caveVisAlpha = 0;
  caveSightDir = 1;
  lastCave: ReefCave | null = null;
  private caveMaskCv: HTMLCanvasElement | null = null;
  private caveConeCv: HTMLCanvasElement | null = null;
  last = 0;
  raf = 0;
  minimap: HTMLCanvasElement | null = null;
  miniTimer = 0;
  spectate: Fish | null = null;
  leaderId = -1;
  onHud?: (h: HudState) => void;
  onDeath?: (d: DeathInfo) => void;
  onEvent?: (e: GameEvent) => void;
  /** loading progress 0..1; `ready` flips to true when the ocean is generated and populated */
  onLoad?: (pct: number, ready: boolean) => void;
  ready = false;
  loadPct = 0;
  private loadEmit = -1;
  private warm: (() => void)[] | null = null;
  private mc: MessageChannel | null = null;
  private disposed = false;
  private vis: Fish[] = []; // fish near the view this frame
  private grid: Fish[][] = Array.from({ length: GRID_COLS * GRID_ROWS }, () => []);
  private nearBuf: Fish[] = [];
  private predators: Fish[] = [];
  private rankedBuf: Fish[] = [];
  private minimapBg: HTMLCanvasElement | null = null;
  private minimapBgW = 0;
  private minimapBgH = 0;
  private readonly scratchPose3D: Fish3DPose = {
    jaw: 0,
    chompPhase: 0,
    chompDur: 0,
    chompBitFired: false,
    biteLunge: 0,
    tailPh: 0,
    wag2: 0,
    bend: 0,
    turnFlip: 1,
    turnVel: 0,
    boostAmt: 0,
    tilt: 0,
    gulpT: 0,
    gulpK: 0,
    swallowT: 0,
    tentacleReach: 0,
    tentaclePull: 0,
    tentacleTrail: 0,
    tentacleVertLag: 0,
    tentacleTurnLag: 0,
    gulpColor: "",
    gulpTailColor: "",
    sq: 0,
    expr: "normal",
    puff: false,
    sucking: false,
    swimSpeed: 0,
    depthFactor: 0,
    lightingAfter: false,
    sunBeam: 0,
    caustic: 0,
    ventWarm: 0,
    lampCool: 0,
  };
  private orbMineGlow: HTMLCanvasElement | null = null;
  private orbSuction: HTMLCanvasElement | null = null;
  private orbAnglerLure: HTMLCanvasElement | null = null;
  private orbFryLure: HTMLCanvasElement | null = null;
  private orbGoldFry: HTMLCanvasElement | null = null;
  private orbShieldGreen: HTMLCanvasElement | null = null;
  private orbInvulnWhite: HTMLCanvasElement | null = null;
  private orbDorsalRim: HTMLCanvasElement | null = null;
  private orbPlayerSun: HTMLCanvasElement | null = null;
  private orbLampOuter: HTMLCanvasElement | null = null;
  private orbLampCore: HTMLCanvasElement | null = null;
  private orbPartGold: HTMLCanvasElement | null = null;
  private orbPartMist: HTMLCanvasElement | null = null;
  private orbCoinGlow: HTMLCanvasElement | null = null;
  private orbPoisonGlow: HTMLCanvasElement | null = null;
  private orbSunfishGlow: HTMLCanvasElement | null = null;
  private orbDancerGlow: HTMLCanvasElement | null = null;
  private orbCombGlow: HTMLCanvasElement | null = null;
  private labels = new Map<string, { cv: HTMLCanvasElement; w: number; h: number }>();
  private bg: (() => void)[] = []; // sprites still to be rasterised on idle frames
  private dtS = 1 / 60;
  private look = { x: 0, y: 0 }; // smoothed camera look-ahead
  private warmI = 0;
  // adaptive resolution: only engages on devices that cannot hold ~45 fps, and is kept only if it helps
  quality = 0;
  private qAcc = 0;
  private qN = 0;
  private qSlow = 0;
  private qBase = 0;
  private qTrying = false;
  private qLocked = false;
  private qHold = 2;
  menuActive = true;
  menuPaused = false;
  private lastLoadDrawPct = -1;
  private loadTimer: number | null = null;
  speedScale = 1.0;
  bulkScale = 1.7;
  cameraZoomScale = 1.0;
  lang: AppLang = "en";
  coinHudPos = { x: 900, y: 26 };
  private prevZone = -1;
  private prevPlayerY = 999;

  constructor(
    canvas: HTMLCanvasElement,
    init?: {
      pixelMode?: boolean;
      reef3D?: boolean;
      laut?: boolean;
      bgStyle?: "game1" | "game2" | "reef_g1" | "shipwreck" | "kelp" | "temple" | "lagoon";
      reefMix?: ReefMixMode;
      rockStyle?: ReefRockMode;
      oceanLighting?: OceanLightingMode;
      graphicsMode?: GraphicsMode;
      cameraZoom?: number;
      lang?: AppLang;
    }
  ) {
    this.canvas = canvas;
    this.ctx = canvas.getContext("2d", { alpha: false })!;
    if (init?.pixelMode !== undefined) this.pixelMode = init.pixelMode;
    if (init?.reef3D !== undefined) this.reef3D = init.reef3D;
    if (init?.bgStyle !== undefined) this.bgStyle = init.bgStyle;
    if (init?.reefMix !== undefined) this.reefMix = init.reefMix;
    if (init?.rockStyle !== undefined) this.rockStyle = init.rockStyle;
    if (init?.oceanLighting !== undefined) this.oceanLighting = init.oceanLighting;
    if (init?.graphicsMode !== undefined) this.graphicsMode = init.graphicsMode;
    if (init?.cameraZoom !== undefined) this.cameraZoomScale = clamp(init.cameraZoom, 1.0, 1.85);
    if (init?.lang !== undefined) this.lang = init.lang;
    fish3d.setGraphicsMode(this.graphicsMode);
    SHARED.uBgStyle.value =
      this.bgStyle === "game1"
        ? 0
        : this.bgStyle === "shipwreck"
          ? 2
          : this.bgStyle === "kelp"
            ? 3
            : this.bgStyle === "temple"
              ? 4
              : this.bgStyle === "lagoon"
                ? 5
                : 1;
    SHARED.uWaterStyle.value = this.bgStyle === "game2" || this.bgStyle === "kelp" ? 1 : 0;
    SHARED.uLightEnhance.value = this.oceanLighting === "after" ? 1 : 0;
    if (this.bgStyle !== "game1") this.ensureReefBackdropAssets();
    this.lautOn = !!init?.laut && LautWorld.supported();
    // the painted 3D reef bake is skipped while the live 3D sea is active (it is built lazily if the mode is switched off)
    this.ocean = new Ocean({ pixelMode: this.pixelMode, reef3D: this.reef3D && !this.lautOn, bgStyle: this.bgStyle, lang: this.lang });
    this.ocean.laut = this.lautOn;
    this.ocean.oceanLighting = this.oceanLighting;
    // make sure the pixel font used by the depth-level HUD is loaded even if no DOM element uses it yet
    try {
      const fonts = (document as unknown as { fonts?: { load: (f: string) => unknown; addEventListener?: (e: string, cb: () => void) => void } }).fonts;
      fonts?.load("8px 'Press Start 2P'");
      // cached text sprites must be redrawn once the web fonts have arrived
      fonts?.addEventListener?.("loadingdone", () => {
        this.labels.clear();
        this.ocean.clearText();
      });
    } catch {
      /* font loading is best-effort */
    }
    const moteCols = ["#cffafe", "#a5f3fc", "#f5d0fe", "#fde68a"];
    const moteOrbs = moteCols.map((col) => glowOrb(col, true));
    for (let i = 0; i < 150; i++) {
      const ci = i % moteCols.length;
      this.motes.push({
        x: Math.random() * 2000,
        y: Math.random() * 1800,
        s: Math.random(),
        col: moteCols[ci],
        orb: moteOrbs[ci],
      });
    }
    // NOTE: the ocean is NOT generated here. loadStep() builds it a few milliseconds per frame (with a
    // progress bar) and then populates it, so opening the page never locks up the browser.
    this.resize(true);
    this.drawLoading();
    this.last = performance.now();
    this.loop = this.loop.bind(this);
    this.raf = requestAnimationFrame(this.loop);
    this.pumpLoad();
  }

  /**
   * Schedules the next loading slice. When the interactive menu is open, yields briefly between chunks
   * so carousel scrolling & animations keep a locked 60 FPS while the ocean builds in the background.
   */
  private pumpLoad() {
    if (this.ready || this.disposed) return;
    if (this.menuActive) {
      if (this.loadTimer !== null) clearTimeout(this.loadTimer);
      const sliceBudget = isSoftwareWebGL() ? 16 : 24;
      this.loadTimer = window.setTimeout(() => {
        this.loadTimer = null;
        if (this.ready || this.disposed) return;
        this.loadStep(sliceBudget);
        this.pumpLoad();
      }, 0);
      return;
    }
    if (typeof MessageChannel !== "undefined") {
      if (!this.mc) {
        this.mc = new MessageChannel();
        this.mc.port1.onmessage = () => {
          if (this.ready || this.disposed) return;
          this.loadStep();
          this.pumpLoad();
        };
      }
      this.mc.port2.postMessage(0);
    } else {
      setTimeout(() => {
        if (this.ready || this.disposed) return;
        this.loadStep();
        this.pumpLoad();
      }, 0);
    }
  }

  /** One slice of loading: world generation, then a few essential sprites, then the fish population. */
  loadStep(budgetMs = LOAD_BUDGET) {
    if (this.ready) return;
    const t0 = performance.now();
    if (this.ocean.step(budgetMs)) {
      if (this.lautOn && !this.laut) this.laut = new LautWorld(this.ocean, this.bgStyle, this.reefMix, this.rockStyle, this.graphicsMode);
      let lautDone = true;
      if (this.laut && this.lautOn && !this.laut.ready && !this.laut.failed) lautDone = this.laut.step(Math.max(4, budgetMs - (performance.now() - t0)));
      if (this.laut?.failed) this.lautFailed();
      if (lautDone) {
        if (!this.warm) this.warm = this.warmList();
        beginSpriteFrame(1e9);
        while (this.warmI < this.warm.length && performance.now() - t0 < budgetMs) this.warm[this.warmI++]();
        if (this.warmI >= this.warm.length) this.finishInit();
      }
    }
    const lautP = this.laut && this.lautOn ? this.laut.progress : 1;
    const pct = this.ready
      ? 1
      : this.ocean.progress * 0.85 + lautP * (this.ocean.progress >= 1 ? 0.1 : 0) + (this.warm ? (this.warmI / Math.max(1, this.warm.length)) * 0.05 : 0);
    this.loadPct = pct;
    const ip = Math.floor(pct * 50);
    if (ip !== this.loadEmit || this.ready) {
      this.loadEmit = ip;
      this.onLoad?.(pct, this.ready);
    }
  }

  /** minimal essential sprites needed on frame 0; remaining fish rasterise seamlessly in background idle frames */
  private warmList(): (() => void)[] {
    const jobs: (() => void)[] = [];
    const add = (sp: Species, key: string, r: number) => jobs.push(() => void fishSprite(sp, fishLen(r), 0, 0, key, this.pixelMode, "normal", true));
    for (const sp of FRY) add(sp, sp.id, sp.minR);
    for (let i = 0; i < Math.min(6, SPECIES.length); i++) {
      const sp = SPECIES[i];
      add(sp, sp.id, sp.minR);
    }
    const starterSkin = SKINS.find((s) => s.id === this.playerSkinId) || SKINS[0];
    if (starterSkin && !starterSkin.is3D) {
      add(skinToSpecies(starterSkin), "bot-" + starterSkin.id, 8);
    }
    if (SKINS[0] && !SKINS[0].is3D && SKINS[0].id !== starterSkin?.id) {
      add(skinToSpecies(SKINS[0]), "bot-" + SKINS[0].id, 8);
    }
    return jobs;
  }

  private finishInit() {
    while (this.fish.length < NPC_TARGET) this.spawnNPC(true);
    for (let i = 0; i < POISON_TARGET; i++) this.spawnPoisonFish(true);
    for (let i = 0; i < SCHOOL_COUNT; i++) this.spawnSchool(true);
    for (let i = 0; i < MINE_COUNT; i++) this.spawnMine(true);
    for (let i = 0; i < SUNFISH_COUNT; i++) this.spawnSunfish(true);
    const names = [...getBotNames(this.lang)].sort(() => Math.random() - 0.5);
    for (let i = 0; i < BOT_COUNT; i++) {
      const botSkin = SKINS[i % SKINS.length];
      // skewed toward small fry so a 50-player ocean is still fair to a fresh spawn
      this.spawnBot(names[i % names.length], botSkin, 56 + Math.pow(Math.random(), 2.4) * 640);
    }
    // background queue: base poses & swim frames of every fish type, rasterised smoothly on idle frames
    for (const sp of SPECIES) {
      this.bg.push(() => void fishSprite(sp, fishLen(sp.minR), 0, 0, sp.id, this.pixelMode, "normal", true));
      this.bg.push(() => void fishSprite(sp, fishLen(sp.maxR), 0, 0, sp.id, this.pixelMode, "normal", true));
    }
    for (const sk of SKINS) {
      if (sk.is3D) continue;
      const sp = skinToSpecies(sk);
      this.bg.push(() => void fishSprite(sp, fishLen(8), 0, 0, "bot-" + sk.id, this.pixelMode, "normal", true));
      this.bg.push(() => void fishSprite(sp, fishLen(14), 0, 0, "bot-" + sk.id, this.pixelMode, "normal", true));
    }
    const q = (sp: Species, key: string, r: number) => {
      for (let tf = 0; tf < 8; tf++) this.bg.push(() => void fishSprite(sp, fishLen(r), 0, (tf + 0.5) * (Math.PI / 4), key, this.pixelMode, "normal", true));
    };
    for (const sk of SKINS) {
      if (sk.is3D) continue;
      const sp = skinToSpecies(sk);
      q(sp, "bot-" + sk.id, 14);
      q(sp, "bot-" + sk.id, 8);
    }
    for (const sp of SPECIES) {
      q(sp, sp.id, sp.maxR);
      q(sp, sp.id, sp.minR);
    }
    for (const sp of FRY) q(sp, sp.id, sp.minR);
    this.medusae.reset(this.cam.x, this.cam.y, (x, y, r) => this.isInsideRock(x, y, r));
    this.residents.reset(this.cam.x, this.cam.y, (x, y, pad) => this.isInsideRock(x, y, pad));
    this.decor3d.reset(this.ocean, (x, y, pad) => this.isInsideRock(x, y, pad));
    this.resize(true);
    this.ready = true;
    this.last = performance.now();
    this.mc?.port1.close();
    this.mc = null;
  }

  /** Simple loading screen drawn straight on the game canvas while the ocean is being generated. */
  drawLoading() {
    const ctx = this.ctx,
      W = this.canvas.width,
      H = this.canvas.height;
    ctx.setTransform(1, 0, 0, 1, 0, 0);
    const g = ctx.createLinearGradient(0, 0, 0, H);
    g.addColorStop(0, "#49d6f5");
    g.addColorStop(0.45, "#1376cc");
    g.addColorStop(1, "#0b2a7a");
    ctx.fillStyle = g;
    ctx.fillRect(0, 0, W, H);
    const p = this.loadPct;
    const u = Math.max(1, Math.round(H / 240));
    const bw = Math.min(W * 0.6, 150 * u * 2),
      bh = 6 * u,
      bx = Math.round((W - bw) / 2),
      by = Math.round(H * 0.93);
    ctx.fillStyle = "#06143c";
    ctx.fillRect(bx - 2 * u, by - 2 * u, bw + 4 * u, bh + 4 * u);
    ctx.fillStyle = "#123a86";
    ctx.fillRect(bx, by, bw, bh);
    ctx.fillStyle = "#ffe14a";
    ctx.fillRect(bx, by, Math.round(bw * p), bh);
    ctx.fillStyle = "#fff8c0";
    ctx.fillRect(bx, by, Math.round(bw * p), u);
    const isId = this.lang === "id";
    const label =
      p < 0.12
        ? isId ? "Menumbuhkan karang" : "Growing coral"
        : p < 0.43
          ? isId ? "Memahat tebing laut" : "Carving ocean cliffs"
          : p < 0.8
            ? isId ? "Menanam terumbu" : "Planting reefs"
            : p < 0.95
              ? isId ? "Menata dasar laut" : "Shaping sea floor"
              : isId ? "Melepas ikan" : "Releasing fish";
    ctx.font = `700 ${7 * u}px 'Fredoka', system-ui, sans-serif`;
    ctx.textAlign = "center";
    ctx.textBaseline = "alphabetic";
    ctx.fillStyle = "rgba(4, 12, 40, 0.75)";
    ctx.fillText(`${label}… ${Math.floor(p * 100)}%`, W / 2 + u, by - 4 * u + u);
    ctx.fillStyle = "#eaf8ff";
    ctx.fillText(`${label}… ${Math.floor(p * 100)}%`, W / 2, by - 4 * u);
  }

  /**
   * Adaptive resolution that preserves crisp visuals in HD Boost / Super HD while gracefully
   * protecting FPS (prioritizing WebGL scale before ever reducing 2D sharpness).
   */
  trackPerf(rawMs: number) {
    if (this.pixelMode || this.graphicsMode === "super_hd" || rawMs <= 0 || rawMs > 250) return;
    if (this.qHold > 0) {
      this.qHold -= rawMs / 1000;
      return;
    }
    this.qAcc += rawMs;
    this.qN++;
    if (this.qAcc < 1000) return;
    const avg = this.qAcc / this.qN;
    this.qAcc = 0;
    this.qN = 0;
    const maxQ = this.graphicsMode === "hd_boost" ? 1 : Q_SCALE.length - 1;
    if (this.qTrying) {
      this.qTrying = false;
      if (avg > this.qBase * 0.9) {
        this.quality = Math.max(0, this.quality - 1);
        this.laut?.setAdaptiveScale(this.graphicsMode === "hd_boost" ? 0.96 : 0.9);
        this.qLocked = true;
        this.qHold = 0.6;
      }
      return;
    }
    if (this.qLocked || this.quality >= maxQ) return;
    this.qSlow = avg > (this.graphicsMode === "hd_boost" ? 23.0 : 19.5) ? this.qSlow + 1 : 0;
    if (this.qSlow >= 2) {
      this.qSlow = 0;
      this.qBase = avg;
      this.quality++;
      this.laut?.setAdaptiveScale(1 - this.quality * 0.04);
      this.qTrying = true;
      this.qHold = 0.6;
    }
  }

  setPixelMode(pm: boolean) {
    this.pixelMode = pm;
    this.ocean.pixelMode = pm;
    this.ocean.laut = this.lautOn && !pm;
    if (this.ready) this.ocean.ensureMode(this.pixelMode, this.ocean.reef3D);
    const use3D = this.mode3D && !pm;
    this.playerMode3D = use3D || !!(this.player && (this.player.sp.style === "octopus" || this.player.sp.style === "whaleshark"));
    for (const f of this.fish) {
      const pure3D = f.sp.style === "octopus" || f.sp.style === "whaleshark";
      f.sp = { ...f.sp, is3D: pure3D || use3D };
    }
    this.resize(true);
  }

  setReef3D(v: boolean) {
    this.reef3D = v;
    this.applyReefMode();
  }

  /** switch the live 3D "Dunia Laut" sea on/off (the painted reef underneath is kept in sync) */
  setLaut(v: boolean) {
    v = v && LautWorld.supported();
    this.lautOn = v;
    this.ocean.laut = v && !this.pixelMode;
    if (v && !this.laut && this.ready) {
      this.laut = new LautWorld(this.ocean, this.bgStyle, this.reefMix, this.rockStyle, this.graphicsMode);
    }
    this.applyReefMode();
  }

  setReefMix(mode: ReefMixMode) {
    if (this.reefMix === mode) return;
    this.reefMix = mode;
    if (this.laut) {
      this.laut.dispose();
      this.laut = new LautWorld(this.ocean, this.bgStyle, this.reefMix, this.rockStyle, this.graphicsMode);
    }
  }

  setRockStyle(mode: ReefRockMode) {
    if (this.rockStyle === mode) return;
    this.rockStyle = mode;
    if (this.laut && this.reefMix !== "game1") {
      this.laut.dispose();
      this.laut = new LautWorld(this.ocean, this.bgStyle, this.reefMix, this.rockStyle, this.graphicsMode);
    }
  }

  setBgStyle(style: "game1" | "game2" | "reef_g1" | "shipwreck" | "kelp" | "temple" | "lagoon") {
    this.bgStyle = style;
    this.ocean.setBgStyle(style);
    SHARED.uBgStyle.value =
      style === "game1" ? 0 : style === "shipwreck" ? 2 : style === "kelp" ? 3 : style === "temple" ? 4 : style === "lagoon" ? 5 : 1;
    SHARED.uWaterStyle.value = style === "game2" || style === "kelp" ? 1 : 0;
    this.laut?.setBgStyle(style);
    if (style !== "game1") this.ensureReefBackdropAssets();
  }

  setOceanLighting(mode: OceanLightingMode) {
    this.oceanLighting = mode;
    this.ocean.oceanLighting = mode;
    SHARED.uLightEnhance.value = mode === "after" ? 1 : 0;
  }

  setGraphicsMode(mode: GraphicsMode) {
    if (this.graphicsMode === mode) return;
    this.graphicsMode = mode;
    this.quality = 0;
    this.qLocked = false;
    this.qSlow = 0;
    this.qTrying = false;
    this.qHold = 1.0;
    fish3d.setGraphicsMode(mode);
    this.laut?.setGraphicsMode(mode);
    this.resize(true);
  }

  setCameraZoomScale(scale: number) {
    this.cameraZoomScale = clamp(scale, 1.0, 1.85);
    this.resize(false);
  }

  setLang(lang: AppLang) {
    if (this.lang === lang) return;
    this.lang = lang;
    this.ocean.lang = lang;
    this.labels.clear();
    this.ocean.clearText();
    const names = [...getBotNames(lang)].sort(() => Math.random() - 0.5);
    let bi = 0;
    for (const f of this.fish) {
      if (f.kind === "bot" && !f.dead) {
        f.name = names[bi++ % names.length];
      }
    }
    for (const q of this.respawnQueue) {
      q.name = names[bi++ % names.length];
    }
    if (this.ready && !this.menuActive) this.emitHud();
  }

  private getFishLightBuffer(): { cv: HTMLCanvasElement; c: CanvasRenderingContext2D } {
    if (!this.fishLitCv) {
      this.fishLitCv = document.createElement("canvas");
      this.fishLitCv.width = 440;
      this.fishLitCv.height = 440;
      this.fishLitCtx = this.fishLitCv.getContext("2d")!;
    }
    return { cv: this.fishLitCv, c: this.fishLitCtx! };
  }

  private ensureCausticPattern(targetCtx: CanvasRenderingContext2D): CanvasPattern | null {
    if (!this.causticPatCanvas) {
      const S = 128;
      const cv = document.createElement("canvas");
      cv.width = S;
      cv.height = S;
      const c = cv.getContext("2d")!;
      c.clearRect(0, 0, S, S);
      c.lineCap = "round";
      const strokes = [
        { x0: -16, y0: 22, cx: 48, cy: 4, x1: 144, y1: 30 },
        { x0: -16, y0: 68, cx: 64, cy: 88, x1: 144, y1: 62 },
        { x0: -16, y0: 108, cx: 52, cy: 92, x1: 144, y1: 112 },
        { x0: 18, y0: -16, cx: 42, cy: 56, x1: 14, y1: 144 },
        { x0: 84, y0: -16, cx: 68, cy: 62, x1: 92, y1: 144 },
      ];
      for (const s of strokes) {
        c.strokeStyle = "rgba(140, 248, 255, 0.34)";
        c.lineWidth = 7;
        c.beginPath();
        c.moveTo(s.x0, s.y0);
        c.quadraticCurveTo(s.cx, s.cy, s.x1, s.y1);
        c.stroke();

        c.strokeStyle = "rgba(255, 253, 218, 0.72)";
        c.lineWidth = 2.4;
        c.stroke();
      }
      this.causticPatCanvas = cv;
    }
    if (!this.causticPattern) {
      this.causticPattern = targetCtx.createPattern(this.causticPatCanvas, "repeat");
    }
    return this.causticPattern;
  }

  private sampleOceanLight(fx: number, fy: number) {
    const out = this.scratchLight;
    const depthK = clamp((fy - 220) / 1780, 0, 1);
    const shallowK = clamp(1 - fy / 1120, 0, 1);
    const rayA = Math.pow(Math.max(0, Math.sin(fx * 0.0115 + fy * 0.0042 - this.t * 0.48) * 0.5 + 0.5), 2.3);
    const rayB = Math.pow(Math.max(0, Math.sin(fx * 0.019 - fy * 0.006 + this.t * 0.34 + 1.4) * 0.5 + 0.5), 2.8);
    const sunBeam = clamp((rayA * 0.72 + rayB * 0.52) * Math.exp(-Math.max(0, fy) / 960), 0, 1);
    const cWave = 0.5 + 0.5 * Math.sin(fx * 0.032 + fy * 0.024 - this.t * 2.8) * Math.cos(fx * 0.021 - fy * 0.029 + this.t * 2.1);
    const caustic = clamp((0.38 + sunBeam * 0.62) * (0.42 + cWave * 0.58) * shallowK, 0, 1);

    let ventWarm = 0;
    if (fy > DEEP_START + 220) {
      const vents = this.ocean.vents;
      for (let i = 0; i < vents.length; i++) {
        const v = vents[i];
        const dx = fx - v.x;
        const dy = fy - (v.y - 36);
        const d2 = dx * dx + dy * dy;
        if (d2 < 72900) {
          const w = 1 - Math.sqrt(d2) / 270;
          if (w > ventWarm) ventWarm = w;
        }
      }
    }

    let subWarm = 0;
    for (let i = 0; i < this.residents.subs.length; i++) {
      const s = this.residents.subs[i];
      const lx = s.x + s.dir * 86;
      const ly = s.y + 8;
      const dx = fx - lx;
      const dy = fy - ly;
      const d2 = dx * dx + dy * dy;
      if (d2 < 96100) {
        const fwd = dx * s.dir >= -30 ? 1 : 0.45;
        const w = (1 - Math.sqrt(d2) / 310) * fwd;
        if (w > subWarm) subWarm = w;
      }
    }

    let lampCool = 0;
    const p = this.player;
    if (p && !p.dead && !p.eatenBy && p.y > DEEP_START - 160 && fy > DEEP_START - 200) {
      const kDeep = clamp((p.y - (DEEP_START - 160)) / 340, 0, 1);
      const dx = fx - p.x;
      const dy = fy - p.y;
      const d2 = dx * dx + dy * dy;
      if (d2 < 84100) {
        const fwd = dx * p.face >= -24 ? 1 : 0.48;
        lampCool = clamp((1 - Math.sqrt(d2) / 290) * fwd * kDeep, 0, 1);
      }
    }

    out.sunBeam = sunBeam;
    out.caustic = caustic;
    out.depthK = depthK;
    out.shallowK = shallowK;
    out.ventWarm = clamp(ventWarm, 0, 1);
    out.subWarm = clamp(subWarm, 0, 1);
    out.lampCool = clamp(lampCool, 0, 1);
    return out;
  }

  private applyOceanFishLightPass(
    lctx: CanvasRenderingContext2D,
    dim: number,
    halfSpan: number,
    worldX: number,
    worldY: number,
    ol: { sunBeam: number; caustic: number; depthK: number; shallowK: number; ventWarm: number; lampCool: number; subWarm: number }
  ) {
    const cy = dim * 0.5;
    const span = Math.max(10, halfSpan);
    lctx.setTransform(1, 0, 0, 1, 0, 0);
    lctx.globalCompositeOperation = "source-atop";

    // 1. World-space ocean directional light (top-down sun / depth color absorption / bottom sea bounce & vent warmth)
    const g = lctx.createLinearGradient(0, cy - span, 0, cy + span);
    const topSunA = clamp((0.18 + ol.sunBeam * 0.34) * ol.shallowK + ol.subWarm * 0.22 + ol.lampCool * 0.26, 0, 0.56);
    const midTintA = clamp(ol.depthK * 0.34 - (ol.lampCool * 0.18 + ol.subWarm * 0.16), 0, 0.38);
    const bellyShadeA = clamp(0.14 + ol.depthK * 0.38 - ol.ventWarm * 0.12, 0.06, 0.52);

    if (ol.shallowK > 0.25 && ol.depthK < 0.45) {
      g.addColorStop(0, `rgba(255, 249, 208, ${topSunA.toFixed(3)})`);
      g.addColorStop(0.45, `rgba(62, 198, 232, ${(0.06 + ol.sunBeam * 0.08).toFixed(3)})`);
      g.addColorStop(1, `rgba(10, 62, 118, ${bellyShadeA.toFixed(3)})`);
    } else {
      const topR = Math.round(70 + ol.lampCool * 125 + ol.subWarm * 140);
      const topG = Math.round(180 + ol.lampCool * 65 + ol.subWarm * 55);
      const topB = Math.round(235 - ol.subWarm * 45);
      g.addColorStop(0, `rgba(${topR}, ${topG}, ${topB}, ${clamp(0.16 + ol.lampCool * 0.34 + ol.subWarm * 0.28, 0, 0.52).toFixed(3)})`);
      g.addColorStop(0.5, `rgba(12, 46, 108, ${midTintA.toFixed(3)})`);
      if (ol.ventWarm > 0.08) {
        g.addColorStop(1, `rgba(255, 118, 46, ${(ol.ventWarm * 0.42).toFixed(3)})`);
      } else {
        g.addColorStop(1, `rgba(4, 16, 56, ${bellyShadeA.toFixed(3)})`);
      }
    }
    lctx.globalAlpha = 1;
    lctx.fillStyle = g;
    lctx.fillRect(0, 0, dim, dim);

    // 2. Animated water caustic highlights strictly masked inside fish silhouette (skip sub-pixel passes on tiny fish)
    if (ol.caustic > 0.05 && dim >= 56) {
      const pat = this.ensureCausticPattern(lctx);
      if (pat) {
        const ox = Math.floor(-((worldX * 2.1 + this.t * 38) % 128));
        const oy = Math.floor(-((worldY * 2.1 - this.t * 24) % 128));
        lctx.globalAlpha = clamp((0.16 + ol.sunBeam * 0.44) * ol.caustic, 0, 0.56);
        lctx.setTransform(1, 0, 0, 1, ox, oy);
        lctx.fillStyle = pat;
        lctx.fillRect(-ox, -oy, dim + 128, dim + 128);
        lctx.setTransform(1, 0, 0, 1, 0, 0);
      }
    }

    // 3. Soft sunlit / lamp rim sheen on dorsal ridge
    const dorsalA = clamp(ol.sunBeam * ol.shallowK * 0.36 + ol.lampCool * 0.28 + ol.subWarm * 0.24, 0, 0.44);
    if (dorsalA > 0.07 && dim >= 48) {
      const rimG = lctx.createLinearGradient(0, cy - span, 0, cy - span * 0.15);
      rimG.addColorStop(0, `rgba(245, 255, 232, ${dorsalA.toFixed(2)})`);
      rimG.addColorStop(1, "rgba(245, 255, 232, 0)");
      lctx.globalAlpha = 1;
      lctx.fillStyle = rimG;
      lctx.fillRect(0, 0, dim, dim);
    }

    lctx.globalCompositeOperation = "source-over";
    lctx.globalAlpha = 1;
  }

  private ensureReefBackdropAssets() {
    if (typeof Image === "undefined") return;
    if (!this.habitatImg) {
      this.habitatImg = new Image();
      this.habitatImg.src = "/images/reef-habitat.webp";
    }
    if (!this.shipwreckImg) {
      this.shipwreckImg = new Image();
      this.shipwreckImg.src = "/src/assets/images/ancient_shipwreck_bg_1795254425429.jpg";
    }
    if (!this.kelpImg) {
      this.kelpImg = new Image();
      this.kelpImg.src = "/src/assets/images/kelp_cathedral_bg_1795322568135.jpg";
    }
    if (!this.templeImg) {
      this.templeImg = new Image();
      this.templeImg.src = "/src/assets/images/sunken_temple_bg_1795322569079.jpg";
    }
    if (!this.lagoonImg) {
      this.lagoonImg = new Image();
      this.lagoonImg.src = "/src/assets/images/crystal_lagoon_bg_1795322569691.jpg";
    }
  }

  private applyReefMode() {
    const eff = this.reef3D && !this.lautOn;
    this.ocean.reef3D = eff;
    this.ocean.laut = this.lautOn && !this.pixelMode;
    if (this.ready) this.ocean.ensureMode(this.pixelMode, eff);
  }

  /** the 3D sea, once it is fully built and usable for this frame */
  lautActive(): LautWorld | null {
    const l = this.laut;
    if (!this.lautOn || this.pixelMode || !l || !l.ready || l.failed) return null;
    return l;
  }

  setMode3D(on: boolean) {
    this.mode3D = on;
    const use3D = on && !this.pixelMode;
    this.playerMode3D = use3D || !!(this.player && (this.player.sp.style === "octopus" || this.player.sp.style === "whaleshark"));
    for (const f of this.fish) {
      const pure3D = f.sp.style === "octopus" || f.sp.style === "whaleshark";
      f.sp = { ...f.sp, is3D: pure3D || use3D };
    }
  }

  setMenuMode(on: boolean) {
    if (this.menuActive === on) return;
    this.menuActive = on;
    if (!on) {
      this.menuPaused = false;
      this.last = performance.now();
    } else {
      sfx.setSuck(false);
    }
    this.resize(true);
    if (!this.ready && !on) {
      this.pumpLoad();
    }
  }

  setMenuPaused(paused: boolean) {
    this.menuPaused = paused;
  }

  destroy() {
    this.disposed = true;
    if (this.loadTimer !== null) {
      clearTimeout(this.loadTimer);
      this.loadTimer = null;
    }
    this.mc?.port1.close();
    this.mc = null;
    cancelAnimationFrame(this.raf);
    sfx.setSuck(false);
    sfx.updateAmbience({ inPlay: false, playerY: 500, camTop: 200, sucking: false, boosting: false, ventProx: 0 });
    disposeFish3DShared();
    disposeReef3DRenderer();
    this.laut?.dispose();
    this.laut = null;
  }

  isInsideRock(x: number, y: number, pad: number): boolean {
    for (const form of this.ocean.formations) {
      if (
        x < form.x - pad ||
        x > form.x + form.w + pad ||
        y < form.y - pad ||
        y > form.y + form.h + pad
      ) {
        continue;
      }
      if (this.ocean.sampleRockSDF(form, x, y, false).dist < pad) return true;
    }
    return false;
  }

  pickSpecies(): Species {
    const p = this.player;
    if (p && !p.dead && Math.random() < 0.52) {
      const r = p.r;
      const ok = SPECIES.filter((s) => s.maxR > r * 0.35 && s.minR < r * 1.1);
      if (ok.length) return ok[Math.floor(Math.random() * ok.length)];
    }
    const total = SPECIES.reduce((a, s) => a + s.weight, 0);
    let k = Math.random() * total;
    for (const s of SPECIES) {
      k -= s.weight;
      if (k <= 0) return s;
    }
    return SPECIES[0];
  }

  randomSpawnPos(margin: number, offscreen: boolean, pref: "upper" | "any" | "deep" = "any") {
    const near = offscreen && Math.random() < 0.55;
    for (let i = 0; i < 28; i++) {
      const x = near
        ? clamp(this.cam.x + (Math.random() < 0.5 ? -1 : 1) * (this.vw / 2 + 40 + Math.random() * 380), 50, WORLD_W - 50)
        : 50 + Math.random() * (WORLD_W - 100);
      const fy = floorY(x);
      let yMin = 50 + margin;
      let yMax = fy - 45 - margin;
      if (pref === "upper") yMax = Math.min(yMax, DEEP_START + 80);
      else if (pref === "deep") yMin = Math.max(yMin, DEEP_START + 60);
      if (yMax <= yMin) yMax = yMin + 40;
      const y = yMin + Math.random() * (yMax - yMin);

      if (this.isInsideRock(x, y, margin + 12)) continue;
      if (!offscreen) return { x, y };
      if (Math.abs(x - this.cam.x) > this.vw / 2 + 40 || Math.abs(y - this.cam.y) > this.vh / 2 + 40) return { x, y };
    }
    return { x: 180 + Math.random() * (WORLD_W - 360), y: 240 };
  }

  spawnNPC(initial = false) {
    const baseSp = this.pickSpecies();
    const sp = this.mode3D && !this.pixelMode ? { ...baseSp, is3D: true } : baseSp;
    const r = sp.minR + Math.random() * (sp.maxR - sp.minR);
    const pos = this.randomSpawnPos(r, !initial, sp.deepPref || "any");
    const f = new Fish("npc", sp, sp.id, pos.x, pos.y, r * r);
    f.face = Math.random() < 0.5 ? 1 : -1;
    f.maxR = sp.maxR * 1.25;
    this.fish.push(f);

    const school =
      sp.id === "minnow"
        ? 4 + Math.floor(Math.random() * 6)
        : sp.id === "boris_npc" || sp.id === "andy_npc"
          ? Math.random() < 0.5
            ? 2 + Math.floor(Math.random() * 3)
            : 0
          : 0;
    if (school > 0) {
      for (let i = 0; i < school; i++) {
        const gr = r * (0.88 + Math.random() * 0.24);
        const gx = pos.x + (Math.random() - 0.5) * 42;
        const gy = pos.y + (Math.random() - 0.5) * 28;
        if (this.isInsideRock(gx, gy, gr + 6)) continue;
        const g = new Fish("npc", sp, sp.id, gx, gy, gr * gr);
        g.face = f.face;
        this.fish.push(g);
      }
    }
  }

  spawnPoisonFish(initial = false) {
    const isNudi = Math.random() < 0.42;
    const baseSp = isNudi ? POISON_NUDIBRANCH : POISON_FISH;
    const sp = this.mode3D && !this.pixelMode ? { ...baseSp, is3D: true } : baseSp;
    const r = sp.minR + Math.random() * (sp.maxR - sp.minR);
    const pref = isNudi ? "upper" : initial && Math.random() < 0.48 ? "upper" : "any";
    const pos = this.randomSpawnPos(r, !initial, pref);
    const f = new Fish("npc", sp, sp.id, pos.x, pos.y, r * r);
    f.face = Math.random() < 0.5 ? 1 : -1;
    f.maxR = sp.maxR;
    this.fish.push(f);
  }

  // ==========================================================================
  // SNACK SCHOOLS: tight shoals of tiny fish that swirl, flee as a bait-ball and can be vacuumed up
  // ==========================================================================
  spawnSchool(initial = false, golden = false, nearY?: number) {
    const baseSp = FRY[this.schoolSeq++ % FRY.length];
    const sp = this.mode3D && !this.pixelMode ? { ...baseSp, is3D: true } : baseSp;
    const pref = nearY !== undefined ? (nearY > DEEP_START ? "deep" : "upper") : sp.deepPref || "any";
    const pos = this.randomSpawnPos(46, !initial, pref);
    if (nearY !== undefined) {
      pos.y = clamp(nearY + (Math.random() - 0.5) * 140, 65, floorY(pos.x) - 65);
    }
    const n = golden ? 22 : 18 + Math.floor(Math.random() * 13);
    const s: School = {
      x: pos.x,
      y: pos.y,
      vx: (Math.random() < 0.5 ? -1 : 1) * 30,
      vy: 0,
      tx: pos.x,
      ty: pos.y,
      timer: 0,
      members: [],
      sp,
      pref,
      panic: 0,
      swirl: Math.random() * 6.28,
      dir: Math.random() < 0.5 ? 1 : -1,
      size0: n,
      byPlayer: 0,
      speed: sp.speed * (golden ? 0.92 : 0.8),
      golden,
    };
    for (let i = 0; i < n; i++) {
      const r = sp.minR + Math.random() * (sp.maxR - sp.minR);
      const a = i * 2.39996 + Math.random() * 0.4; // golden-angle disc
      const rad = 4 + Math.sqrt((i + 0.5) / n) * 27;
      const f = new Fish("npc", sp, sp.id, pos.x + Math.cos(a) * rad, pos.y + Math.sin(a) * rad * 0.6, r * r);
      f.fry = true;
      f.school = s;
      f.slotA = a;
      f.slotR = rad;
      f.face = s.vx > 0 ? 1 : -1;
      f.maxR = sp.maxR;
      s.members.push(f);
      this.fish.push(f);
    }
    this.schools.push(s);
  }

  spawnOrb(kind?: OrbKind, nearCam = true) {
    const pick: OrbKind =
      kind ?? (Math.random() < 0.4 ? "pearl" : (["turbo", "vortex", "shield"] as const)[Math.floor(Math.random() * 3)]);
    const x = nearCam
      ? clamp(this.cam.x + (Math.random() - 0.5) * this.vw * 1.45, 70, WORLD_W - 70)
      : 70 + Math.random() * (WORLD_W - 140);
    const fy = floorY(x);
    let y =
      pick === "pearl"
        ? clamp(this.cam.y + (Math.random() - 0.25) * this.vh * 0.85, 180, fy - 24)
        : clamp(this.cam.y + (Math.random() - 0.5) * this.vh * 0.9, 85, fy - 75);
    if (this.isInsideRock(x, y, 24)) {
      y = Math.max(85, y - 55);
    }
    this.orbs.push({
      x,
      y,
      vx: (Math.random() - 0.5) * 14,
      vy: (Math.random() - 0.5) * 8,
      kind: pick,
      t: 0,
      ph: Math.random() * Math.PI * 2,
    });
  }

  spawnBalloon(kind?: BalloonKind, nearCam = true) {
    const roll = Math.random();
    const pick: BalloonKind =
      kind ??
      (roll < 0.38
        ? "stopwatch"
        : (["turbo", "vortex", "shield", "pearl"] as const)[Math.floor(Math.random() * 4)]);
    const x = nearCam
      ? clamp(this.cam.x + (Math.random() < 0.5 ? -1 : 1) * (65 + Math.random() * this.vw * 0.48), 90, WORLD_W - 90)
      : 90 + Math.random() * (WORLD_W - 180);
    const baseY = -(76 + Math.random() * 38); // dangling stopwatch/skill sits cleanly at y = -70..-32 for joyful air jumps
    this.balloons.push({
      x,
      y: baseY,
      baseY,
      vx: (Math.random() < 0.5 ? -1 : 1) * (10 + Math.random() * 11),
      kind: pick,
      t: 0,
      ph: Math.random() * Math.PI * 2,
    });
  }

  spawnMine(initial = false) {
    const r = 13.5 + Math.random() * 2.5;
    for (let attempt = 0; attempt < 36; attempt++) {
      const pos = this.randomSpawnPos(r + 22, !initial, "any");
      const fy = floorY(pos.x);
      const y = clamp(pos.y, 130, fy - 75);
      if (this.isInsideRock(pos.x, y, r + 24)) continue;
      if (this.player && !this.player.dead && Math.hypot(pos.x - this.player.x, y - this.player.y) < 380) continue;
      let tooClose = false;
      for (const m of this.mines) {
        if (Math.hypot(pos.x - m.x, y - m.baseY) < 220) {
          tooClose = true;
          break;
        }
      }
      if (tooClose) continue;
      this.mines.push({
        x: pos.x,
        y,
        baseY: y,
        r,
        rot: Math.random() * Math.PI * 2,
        rotSp: (Math.random() < 0.5 ? -1 : 1) * (0.14 + Math.random() * 0.14),
        ph: Math.random() * Math.PI * 2,
        tether: Math.min(240, Math.max(45, fy - y)),
      });
      return;
    }
  }

  spawnSunfish(initial = false) {
    const r = 24 + Math.random() * 4.5;
    for (let attempt = 0; attempt < 32; attempt++) {
      const pref = Math.random() < 0.68 ? "upper" : "any";
      const pos = this.randomSpawnPos(r + 18, !initial, pref);
      const fy = floorY(pos.x);
      const y = clamp(pos.y, 130, Math.min(1480, fy - 72));
      if (this.isInsideRock(pos.x, y, r + 24)) continue;
      if (!initial && this.player && !this.player.dead && Math.hypot(pos.x - this.player.x, y - this.player.y) < 340) continue;
      const face: 1 | -1 = Math.random() < 0.5 ? 1 : -1;
      this.sunfish.push({
        id: ++this.sunfishSeq,
        x: pos.x,
        y,
        vx: face * 26,
        vy: 0,
        r,
        hp: 6,
        maxHp: 6,
        bites: [],
        face,
        turnFlip: face,
        tilt: 0,
        ph: Math.random() * Math.PI * 2,
        tx: clamp(pos.x + face * (220 + Math.random() * 260), 120, WORLD_W - 120),
        ty: clamp(y + (Math.random() - 0.5) * 160, 110, Math.min(1480, fy - 72)),
        timer: 3 + Math.random() * 4,
        biteCd: 0,
        hurtFlash: 0,
        panicT: 0,
        wobbleV: 0,
        dead: false,
      });
      return;
    }
  }

  updateSunfish(dt: number, p: Fish | null) {
    for (let i = this.sunfishTimers.length - 1; i >= 0; i--) {
      this.sunfishTimers[i] -= dt;
      if (this.sunfishTimers[i] <= 0) {
        this.sunfishTimers.splice(i, 1);
        if (this.sunfish.length < SUNFISH_COUNT) this.spawnSunfish(false);
      }
    }

    for (let i = this.sunfish.length - 1; i >= 0; i--) {
      const sf = this.sunfish[i];
      if (sf.dead) {
        this.sunfish.splice(i, 1);
        continue;
      }
      if (sf.biteCd > 0) sf.biteCd = Math.max(0, sf.biteCd - dt);
      if (sf.hurtFlash > 0) sf.hurtFlash = Math.max(0, sf.hurtFlash - dt);
      if (sf.panicT > 0) sf.panicT = Math.max(0, sf.panicT - dt);

      sf.timer -= dt;
      if (sf.timer <= 0 || Math.hypot(sf.tx - sf.x, sf.ty - sf.y) < 34) {
        sf.tx = clamp(sf.x + (Math.random() - 0.5) * 680, 110, WORLD_W - 110);
        const maxY = Math.min(1520, floorY(sf.tx) - 72);
        sf.ty = clamp(sf.y + (Math.random() - 0.5) * 260, 110, Math.max(150, maxY));
        sf.timer = 3.5 + Math.random() * 4.5;
      }

      const dx = sf.tx - sf.x;
      const dy = sf.ty - sf.y;
      const dist = Math.hypot(dx, dy) || 1;
      const spd = sf.panicT > 0 ? 118 : 34;
      const blend = Math.min(1, dt * (sf.panicT > 0 ? 4.2 : 1.6));
      sf.vx += ((dx / dist) * spd - sf.vx) * blend;
      sf.vy += ((dy / dist) * spd * 0.72 + Math.sin(this.t * 1.9 + sf.ph) * 6 - sf.vy) * blend;

      // Gentle suction pull if player vacuums near the Sunfish
      if (p && !p.dead && !p.eatenBy && p.sucking) {
        const mx = p.mouthX();
        const my = p.mouthY();
        const sdx = mx - sf.x;
        const sdy = my - sf.y;
        const sd = Math.hypot(sdx, sdy);
        const suckRange = (105 + p.r * 3.1) * (this.vortexT > 0 ? 1.45 : 1.0);
        if (sd > 1 && sd < suckRange) {
          const pull = (1 - sd / suckRange) * (150 + p.r * 3.2) * dt;
          sf.vx += (sdx / sd) * pull;
          sf.vy += (sdy / sd) * pull;
        }
      }

      sf.x += sf.vx * dt;
      sf.y += sf.vy * dt;

      // Keep clear of seabed rocks and ocean borders
      for (const form of this.ocean.formations) {
        const pad = sf.r + 18;
        if (
          sf.x < form.x - pad ||
          sf.x > form.x + form.w + pad ||
          sf.y < form.y - pad ||
          sf.y > form.y + form.h + pad
        ) {
          continue;
        }
        const hit = this.ocean.sampleRockSDF(form, sf.x, sf.y, false);
        if (hit.dist < pad) {
          const pen = pad - hit.dist;
          sf.x += hit.nx * pen;
          sf.y += hit.ny * pen;
          const vn = sf.vx * hit.nx + sf.vy * hit.ny;
          if (vn < 0) {
            sf.vx -= vn * hit.nx * 1.4;
            sf.vy -= vn * hit.ny * 1.4;
          }
          sf.tx = clamp(sf.x + hit.nx * 180, 110, WORLD_W - 110);
          sf.ty = clamp(sf.y + hit.ny * 140, 110, Math.min(1520, floorY(sf.tx) - 72));
        }
      }

      if (sf.x < 70) {
        sf.x = 70;
        sf.vx = Math.abs(sf.vx);
      } else if (sf.x > WORLD_W - 70) {
        sf.x = WORLD_W - 70;
        sf.vx = -Math.abs(sf.vx);
      }
      const fy = floorY(sf.x);
      sf.y = clamp(sf.y, 90, fy - 62);

      if (Math.abs(sf.vx) > 6) sf.face = sf.vx >= 0 ? 1 : -1;
      sf.turnFlip += (sf.face - sf.turnFlip) * Math.min(1, dt * 4.8);
      const targetTilt = clamp((sf.vy / Math.max(40, Math.abs(sf.vx))) * 0.24 * sf.face, -0.35, 0.35);
      sf.tilt += (targetTilt - sf.tilt) * Math.min(1, dt * 6);

      // 6-Bite Directional Feeding Frenzy Food Bonus interaction with the player
      if (p && !p.dead && !p.eatenBy && sf.biteCd <= 0) {
        const mx = p.mouthX();
        const my = p.mouthY();
        const dm = Math.hypot(sf.x - mx, sf.y - my);
        const db = Math.hypot(sf.x - p.x, sf.y - p.y);
        const reach = p.r * 0.92 + sf.r * 0.88;
        if (dm < reach || db < reach * 0.94) {
          // Compute exact incoming attack vector FROM Sunfish center TOWARD the attacker side
          let worldDirX = p.x * 0.65 + mx * 0.35 - sf.x;
          let worldDirY = p.y * 0.65 + my * 0.35 - sf.y;
          const spdP = Math.hypot(p.vx, p.vy);
          if (Math.hypot(worldDirX, worldDirY) < 8 && spdP > 5) {
            worldDirX = -p.vx;
            worldDirY = -p.vy;
          } else if (spdP > 45) {
            const wLen = Math.hypot(worldDirX, worldDirY) || 1;
            worldDirX = worldDirX / wLen - (p.vx / spdP) * 0.35;
            worldDirY = worldDirY / wLen - (p.vy / spdP) * 0.35;
          }
          const wdLen = Math.hypot(worldDirX, worldDirY) || 1;
          const wnx = worldDirX / wdLen;
          const wny = worldDirY / wdLen;

          const nextHp = sf.hp - 1;
          sf.hp = Math.max(0, nextHp) as 6 | 5 | 4 | 3 | 2 | 1;
          sf.biteCd = 0.30;
          sf.hurtFlash = 0.28;
          sf.panicT = 1.35;

          const biteIdx = sf.bites.length; // 0..4 before final 6th bite
          if (nextHp > 0 && biteIdx < 5) {
            // Convert world incoming unit vector -> Sunfish upright 3D local space (+x = snout, +y = dorsal)
            const dirSign = sf.turnFlip >= 0 ? 1 : -1;
            const rx = wnx * dirSign;
            const ry = -wny; // Canvas +Y down -> 3D +Y up
            const cosT = Math.cos(sf.tilt);
            const sinT = Math.sin(sf.tilt);
            const ux = rx * cosT - ry * sinT;
            const uy = rx * sinT + ry * cosT;
            sf.bites.push(computeDirectionalSunfishBite(sf.bites, ux, uy, biteIdx));
          }

          // Player chomp animation & combo increment
          p.wantOpen = true;
          p.wantOpenAmt = 1.1;
          p.chompQueue = Math.min(12, p.chompQueue + 1);
          p.mouthOpenT = Math.max(p.mouthOpenT, 0.26);
          p.munch = true;
          p.sqv += 11;
          p.gulpColor = "#cfe4f2";
          p.gulpTailColor = "#4b749f";
          p.gulpK = 0.55;
          p.gulpT = 0.85;
          p.combo++;
          this.maxCombo = Math.max(this.maxCombo, p.combo);
          p.comboT = 2.6;
          this.chainPop = 1;

          // Sunfish playfully darts away opposite the bite direction so player gets a crisp 6-bite chase!
          const dart = nextHp > 0 ? 132 : 0;
          sf.vx = -wnx * dart;
          sf.vy = -wny * dart * 0.72 - 18;
          sf.tx = clamp(sf.x - wnx * 290, 110, WORLD_W - 110);
          sf.ty = clamp(sf.y - wny * 170, 110, Math.min(1520, floorY(sf.tx) - 72));
          sf.timer = 1.25;

          // Impact particles spawn right on the bitten perimeter facing the attack!
          const bx = sf.x + wnx * sf.r * 0.64;
          const by = sf.y + wny * sf.r * 0.64;
          const finalBite = nextHp <= 0;

          if (!finalBite) {
            const biteNum = 6 - nextHp; // 1..5
            const ptsTable = [200, 260, 340, 420, 520];
            const coinsTable = [2, 3, 4, 4, 5];
            const massTable = [0.04, 0.045, 0.05, 0.055, 0.06];
            const pts = ptsTable[biteNum - 1] ?? 300;
            const coins = coinsTable[biteNum - 1] ?? 3;
            const massGain = clamp(p.mass * (massTable[biteNum - 1] ?? 0.05), 8, 28);
            p.mass = Math.min(p.maxR * p.maxR, p.mass + massGain);
            this.arcadeScore += pts;
            for (let c = 0; c < coins; c++) {
              this.addFlyCoin(bx, by, 1, c * 0.045, p.face);
            }
            this.texts.push({
              x: sf.x,
              y: sf.y - sf.r - 12,
              text: `${this.lang === "id" ? "NYAM!" : "CHOMP!"} SUNFISH ${biteNum}/6 +${pts}`,
              color: biteNum >= 4 ? "#fde047" : "#7dd3fc",
              life: 1.0,
              max: 1.0,
              size: 10,
            });
            const atkAng = Math.atan2(wny, wnx);
            for (let s = 0; s < 10; s++) {
              const a = atkAng + (Math.random() - 0.5) * 1.65;
              const sp = 32 + Math.random() * 68;
              this.particles.push({
                x: bx,
                y: by,
                vx: Math.cos(a) * sp,
                vy: Math.sin(a) * sp - 10,
                life: 0.45 + Math.random() * 0.35,
                max: 0.8,
                type: "bit",
                color: s % 3 === 0 ? "#fda4af" : s % 3 === 1 ? "#fff1f2" : "#7dd3fc",
                size: 1.6 + Math.random() * 1.4,
              });
            }
            for (let b = 0; b < 4; b++) {
              this.particles.push(this.bubble(bx + (Math.random() - 0.5) * 14, by, 1.1 + Math.random() * 1.6));
            }
            this.spawnRing(bx, by, "#bae6fd", sf.r * 0.72);
            sfx.gulp(2.1, true, p.combo);
            this.shake = Math.min(3.6, this.shake + 1.35);
          } else {
            // Bite 6/6: SUNFISH FEAST!
            const pts = 1500;
            const totalCoins = 16;
            const coinPacks = 8;
            const massGain = clamp(p.mass * 0.16, 26, 72);
            p.mass = Math.min(p.maxR * p.maxR, p.mass + massGain);
            this.arcadeScore += pts;
            this.eatenCount++;
            for (let c = 0; c < coinPacks; c++) {
              const v = Math.floor(totalCoins / coinPacks) + (c < totalCoins % coinPacks ? 1 : 0);
              this.addFlyCoin(bx, by, v, c * 0.04, p.face);
            }
            this.texts.push({
              x: sf.x,
              y: sf.y - sf.r - 16,
              text: `SUNFISH FEAST! +${pts}`,
              color: "#ffe14a",
              life: 1.5,
              max: 1.5,
              size: 13,
            });
            this.spawnSparks(bx, by, "#ffe14a", 20);
            this.spawnSparks(bx, by, "#fda4af", 12);
            this.spawnSparks(bx, by, "#67e8f9", 10);
            this.spawnRing(bx, by, "#fde047", sf.r * 1.65);
            this.spawnRing(bx, by, "#ffffff", sf.r * 1.1);
            for (let b = 0; b < 7; b++) {
              this.particles.push(this.bubble(bx + (Math.random() - 0.5) * 18, by, 1.3 + Math.random() * 2.1));
            }
            sfx.bonus();
            this.shake = Math.min(5.2, this.shake + 3.2);
            this.freeze = 0.04;
            this.onEvent?.({
              type: "bonus",
              title: "SUNFISH FEAST!",
              text:
                this.lang === "id"
                  ? `6× Gigitan Mola-Mola tuntas · +${totalCoins} Koin & ukuran melonjak!`
                  : `6× Mola-Mola bites complete · +${totalCoins} Coins & huge growth!`,
            });
            sf.dead = true;
            this.sunfishTimers.push(6 + Math.random() * 4);
            this.emitHud();
          }
        }
      }
    }
  }

  spawnExplosion(x: number, y: number, rad: number) {
    // 1. Expanding white-gold & orange concussive shockwave rings
    this.spawnRing(x, y, "#ffffff", rad * 1.45);
    this.spawnRing(x, y, "#ff8c2e", rad * 1.05);
    this.spawnRing(x, y, "#ef4444", rad * 0.72);

    // 2. Fiery core explosion puffs (orange -> yellow -> crimson)
    const fireCols = ["#fff7c2", "#fde047", "#fb923c", "#ef4444"];
    for (let i = 0; i < 24; i++) {
      const a = Math.random() * Math.PI * 2;
      const sp = 24 + Math.random() * (rad * 2.6);
      const life = 0.28 + Math.random() * 0.28;
      this.particles.push({
        x: x + (Math.random() - 0.5) * 8,
        y: y + (Math.random() - 0.5) * 8,
        vx: Math.cos(a) * sp,
        vy: Math.sin(a) * sp,
        life,
        max: life,
        type: "blast",
        color: fireCols[i % fireCols.length],
        size: 8 + Math.random() * 14,
      });
    }

    // 3. Dark smoky soot clouds billowing underwater
    for (let i = 0; i < 16; i++) {
      const a = Math.random() * Math.PI * 2;
      const sp = 18 + Math.random() * 88;
      const life = 0.65 + Math.random() * 0.55;
      this.particles.push({
        x: x + (Math.random() - 0.5) * 10,
        y: y + (Math.random() - 0.5) * 10,
        vx: Math.cos(a) * sp,
        vy: Math.sin(a) * sp - 16,
        life,
        max: life,
        type: "smoke",
        color: i % 3 === 0 ? "#475569" : "#1e293b",
        size: 10 + Math.random() * 14,
      });
    }

    // 4. Shrapnel sparks & rapid blast bubbles
    this.spawnSparks(x, y, "#fde047", 24);
    this.spawnSparks(x, y, "#f97316", 18);
    for (let i = 0; i < 18; i++) {
      const bb = this.bubble(x + (Math.random() - 0.5) * 18, y + (Math.random() - 0.5) * 18, 1.5 + Math.random() * 2.8);
      bb.vx = (Math.random() - 0.5) * 110;
      bb.vy = -40 - Math.random() * 80;
      this.particles.push(bb);
    }
  }

  updateSchools(dt: number, threats: Fish[], attract = false) {
    const nearX = this.vw * 0.85 + 160;
    const nearY = this.vh * 0.85 + 160;
    for (const s of this.schools) {
      let mw = 0;
      for (let i = 0; i < s.members.length; i++) {
        const m = s.members[i];
        if (!m.dead) s.members[mw++] = m;
      }
      s.members.length = mw;
      if (!mw) continue;
      if (attract && (Math.abs(s.x - this.cam.x) > nearX || Math.abs(s.y - this.cam.y) > nearY)) continue;
      // anything big enough to eat them makes the whole school bolt and ball up
      let fx = 0,
        fy = 0,
        danger = 0;
      for (const o of threats) {
        if (o.fry || o.r < 3.6) continue;
        const dx = s.x - o.x,
          dy = s.y - o.y;
        const R = 62 + o.r * 2.2;
        if (Math.abs(dx) > R || Math.abs(dy) > R) continue;
        const d = Math.hypot(dx, dy);
        if (d < R) {
          const k = 1 - d / R;
          fx += (dx / (d || 1)) * k;
          fy += (dy / (d || 1)) * k;
          if (k > danger) danger = k;
        }
      }
      const scared = danger > 0.05;
      s.panic += ((scared ? 1 : 0) - s.panic) * Math.min(1, dt * (scared ? 5 : 1.1));
      s.timer -= dt;
      if (scared) {
        const d = Math.hypot(fx, fy) || 1;
        s.tx = clamp(s.x + (fx / d) * 170, 60, WORLD_W - 60);
        s.ty = s.y + (fy / d) * 120;
        s.timer = 0.8;
      } else if (s.timer <= 0 || Math.hypot(s.tx - s.x, s.ty - s.y) < 26) {
        s.tx = clamp(s.x + (Math.random() - 0.5) * 560, 80, WORLD_W - 80);
        const yMin = s.pref === "deep" ? DEEP_START + 80 : 28;
        const yMax = s.pref === "upper" ? DEEP_START + 40 : floorY(s.tx) - 80;
        s.ty = clamp(s.y + (Math.random() - 0.5) * 240, yMin, Math.max(yMin + 10, Math.min(yMax, floorY(s.tx) - 80)));
        s.timer = 3.5 + Math.random() * 4;
      }
      // Playful surface breach wave for shallow schools so fry schools leap out of the ocean!
      if (!scared && s.pref !== "deep" && s.y < 72 && Math.random() < dt * 0.24 && !this.isInsideRock(s.x, SURFACE_Y - 12, 34)) {
        s.vy = -195 - Math.random() * 65;
        s.vx = (s.vx >= 0 ? 1 : -1) * Math.max(85, Math.abs(s.vx) * 1.15);
        s.ty = -36;
        s.timer = 0.55;
      }
      const dx = s.tx - s.x,
        dy = s.ty - s.y,
        d = Math.hypot(dx, dy) || 1;
      const sp = s.speed * (1 + s.panic * 0.55);
      const k = Math.min(1, dt * 1.7);
      s.vx += ((dx / d) * sp - s.vx) * k;
      const wasAbove = s.y < SURFACE_Y;
      if (wasAbove) {
        s.vy += AIR_GRAVITY * dt;
      } else {
        s.vy += ((dy / d) * sp * 0.75 - s.vy) * k;
      }
      s.x += s.vx * dt;
      s.y += s.vy * dt;
      if (wasAbove && s.y >= SURFACE_Y) {
        s.y = SURFACE_Y + 6;
        s.vy = Math.max(95, s.vy * 0.72);
        s.ty = Math.max(s.ty, 96);
        if (Math.abs(s.x - this.cam.x) < this.vw * 0.8 && this.camTop < 180) {
          this.spawnWaterSplash(s.x, Math.max(8, (s.members[0]?.r ?? 6) * 1.45), clamp(s.vy / 210, 0.55, 1.1), true, false);
        }
      }
      for (const form of this.ocean.formations) {
        const pad = 34;
        if (
          s.x < form.x - pad ||
          s.x > form.x + form.w + pad ||
          s.y < form.y - pad ||
          s.y > form.y + form.h + pad
        ) {
          continue;
        }
        const hit = this.ocean.sampleRockSDF(form, s.x, s.y, false);
        if (hit.dist < pad) {
          const pen = pad - hit.dist;
          s.x += hit.nx * pen;
          s.y += hit.ny * pen;
        }
      }
      s.x = clamp(s.x, 50, WORLD_W - 50);
      const minSchoolY = s.vy < -35 || s.y < SURFACE_Y + 6 ? -80 : 28;
      s.y = clamp(s.y, minSchoolY, floorY(s.x) - 56);
      s.swirl += dt * (0.45 + s.panic * 2.4) * s.dir;
    }
    // emptied (or nearly emptied & far away) schools are replaced somewhere off-screen
    for (let i = this.schools.length - 1; i >= 0; i--) {
      const s = this.schools[i];
      const far = Math.abs(s.x - this.cam.x) > this.vw * 0.9 || Math.abs(s.y - this.cam.y) > this.vh * 0.9;
      if (s.members.length === 0 || (s.members.length < 5 && far)) {
        for (const m of s.members) m.dead = true;
        this.schools.splice(i, 1);
        this.schoolTimers.push(3 + Math.random() * 5);
      }
    }
    for (let i = this.schoolTimers.length - 1; i >= 0; i--) {
      this.schoolTimers[i] -= dt;
      if (this.schoolTimers[i] <= 0) {
        this.schoolTimers.splice(i, 1);
        this.spawnSchool();
      }
    }
  }

  /** Each fry holds a slot on a slowly swirling ellipse (stretched along the heading) around the school centre. */
  fryAI(f: Fish, dt: number) {
    const s = f.school;
    if (!s || f.sucked > 0 || f.inAir || f.y < SURFACE_Y) return; // being vacuumed or airborne: pure physics
    const hs = Math.hypot(s.vx, s.vy) || 1,
      ux = s.vx / hs,
      uy = s.vy / hs;
    const ang = f.slotA + s.swirl,
      spread = 1 + s.panic * 0.3;
    const lx = Math.cos(ang) * f.slotR * 1.45 * spread,
      ly = Math.sin(ang) * f.slotR * 0.72 * spread;
    const tx = s.x + ux * lx - uy * ly + s.vx * 0.25,
      ty = s.y + uy * lx + ux * ly + s.vy * 0.25 + Math.sin(this.t * 2.6 + f.id) * 1.5;
    const ax = tx - f.x,
      ay = ty - f.y,
      d = Math.hypot(ax, ay) || 1;
    const ms = s.speed * (1.05 + s.panic * 0.6) * Math.min(1.35, 0.45 + d / 22);
    const near = clamp(1 - d / 14, 0, 1);
    let vx = (ax / d) * ms * (1 - near) + s.vx * near,
      vy = (ay / d) * ms * (1 - near) + s.vy * near;
    // cheap stochastic separation so the shoal never clumps into one blob
    for (let k = 0; k < 2; k++) {
      const o = s.members[(Math.random() * s.members.length) | 0];
      if (!o || o === f) continue;
      const ex = f.x - o.x,
        ey = f.y - o.y,
        dd = ex * ex + ey * ey;
      if (dd < 30 && dd > 0.01) {
        const q = Math.sqrt(dd);
        vx += (ex / q) * (5.5 - q) * 10;
        vy += (ey / q) * (5.5 - q) * 10;
      }
    }
    const k2 = Math.min(1, dt * 4);
    f.vx += (vx - f.vx) * k2;
    f.vy += (vy - f.vy) * k2;
  }

  /** Clean sweep: the player vacuumed (almost) a whole school -> coin shower + banner */
  schoolBonus(s: School, x: number, y: number) {
    this.schoolSweeps++;
    const bonus = 5 + Math.round(s.size0 * 0.3);
    const n = Math.min(bonus, 14);
    for (let i = 0; i < n; i++) this.addFlyCoin(x, y, Math.floor(bonus / n) + (i < bonus % n ? 1 : 0), 0.15 + i * 0.05, 0);
    this.arcadeScore += s.size0 * 60;
    const isId = this.lang === "id";
    const spName = getLocalizedSpeciesName(s.sp.id, s.sp.name, this.lang);
    this.texts.push({ x, y: y - 30, text: isId ? "SAPU BERSIH!" : "CLEAN SWEEP!", color: "#7dffb0", life: 1.6, max: 1.6, size: 13 });
    this.texts.push({ x, y: y - 16, text: `+${bonus} ${isId ? "koin" : "coins"}`, color: "#ffe14a", life: 1.6, max: 1.6, size: 9 });
    this.spawnSparks(x, y, "#7dffb0", 20);
    this.spawnSparks(x, y, "#ffe14a", 14);
    this.spawnRing(x, y, "#ffffff", 26);
    this.shake = Math.min(3.5, this.shake + 2);
    sfx.bonus();
    this.onEvent?.({
      type: "bonus",
      title: isId ? "SAPU BERSIH!" : "CLEAN SWEEP!",
      text: isId ? `Segerombolan ${spName} habis disedot · +${bonus} koin` : `Entire ${spName} school vacuumed · +${bonus} coins`,
    });
  }

  spawnBot(name: string, skin: Skin, mass: number) {
    const sp = skinToSpecies(skin, this.mode3D && !this.pixelMode);
    const pos = this.randomSpawnPos(24, true, "any");
    const f = new Fish("bot", sp, "bot-" + skin.id, pos.x, pos.y, mass);
    f.skinRef = skin;
    f.name = name;
    f.color = skin.pal.body;
    f.speedMul = 0.9;
    f.maxR = 62;
    f.invuln = 2;
    this.fish.push(f);
  }

  start(opts: StartOpts) {
    if (!this.ready) return; // still generating the ocean
    if (this.player) this.player.dead = true;
    const baseSkin = SKINS.find((s) => s.id === opts.skin.id);
    if (!baseSkin?.is3D) {
      const want3D = opts.skin.is3D !== undefined ? !!opts.skin.is3D : this.mode3D;
      if (want3D !== this.mode3D) this.setMode3D(want3D);
    }
    const sp = skinToSpecies(opts.skin, !!(baseSkin?.is3D || (this.mode3D && !this.pixelMode)));
    const pos = this.randomSpawnPos(65, false, "upper");
    const shelves = this.ocean.formations.filter((f) => f.zone === 0 && f.rx > 155);
    if (shelves.length) {
      const f = shelves[(Math.random() * shelves.length) | 0];
      const at = Math.round(f.cxl - f.rx * (0.48 + Math.random() * 0.28));
      const sx = f.x + at,
        sy = f.y + Math.max(0, f.top[at]) - 99;
      if (!this.isInsideRock(sx, sy, 60)) {
        pos.x = sx;
        pos.y = sy;
      }
    }
    pos.y = clamp(pos.y, 180, 660);
    if (this.isInsideRock(pos.x, pos.y, 65)) {
      pos.x = WORLD_W * 0.5;
      pos.y = 320;
    }
    const mass = 58 + opts.upgrades.size * 14;
    const p = new Fish("player", sp, "player-" + opts.skin.id, pos.x, pos.y, mass);
    p.skinRef = opts.skin;
    p.name = opts.name || (this.lang === "id" ? "Kamu" : "You");
    p.color = "#ffffff";
    this.speedScale = clamp(opts.speedScale ?? this.speedScale ?? 1.0, 0.7, 1.8);
    this.bulkScale = clamp(opts.bulkScale ?? this.bulkScale ?? 1.7, 0.7, 2.5);
    p.speedMul = (1 + opts.upgrades.speed * 0.07) * this.speedScale;
    p.suckMul = 1 + opts.upgrades.suck * 0.16;
    p.invuln = 3.5;
    p.maxR = 68;
    this.player = p;
    p.turnFlip = p.face;
    this.fish.push(p);
    this.resize(true);
    this.camVel.x = 0;
    this.camVel.y = 0;
    if (this.mouse.active) {
      this.mouse.sx = this.mouse.x;
      this.mouse.sy = this.mouse.y;
      const W = Math.max(1, window.innerWidth);
      const H = Math.max(1, window.innerHeight);
      const initOffX = clamp((this.mouse.sx / W - 0.5) * this.vw, -this.vw * 0.35, this.vw * 0.35);
      const initOffY = clamp((this.mouse.sy / H - 0.5) * this.vh, -this.vh * 0.35, this.vh * 0.35);
      const minCamX = this.vw >= WORLD_W ? WORLD_W / 2 : this.vw / 2;
      const maxCamX = this.vw >= WORLD_W ? WORLD_W / 2 : WORLD_W - this.vw / 2;
      this.cam.x = clamp(p.x - initOffX, minCamX, maxCamX);
      this.cam.y = clamp(p.y - initOffY, MIN_CAM_TOP + this.vh / 2, WORLD_H + 35 - this.vh / 2);
    } else {
      this.cam.x = p.x;
      this.cam.y = p.y;
    }
    this.look.x = this.look.y = 0;
    this.sessionCoins = 0;
    this.arcadeScore = 0;
    this.eatenCount = 0;
    this.botsEatenCount = 0;
    this.maxCombo = 0;
    this.maxDepthY = p.y;
    this.bestRank = BOT_COUNT + 1;
    this.reachedRank1 = false;
    this.peakLevelTime = null;
    this.schoolSweeps = 0;
    this.playerSkinId = opts.skin.id;
    this.playerMode3D = !!opts.skin.is3D;
    this.killerName = "";
    this.killerSpId = "";
    this.stunT = 0;
    this.stingCd = 0;
    this.knockT = 0;
    this.bounceCd = 0;
    this.poisonDelayQueue = [];
    this.poisonDizzyT = 0;
    this.medusae.reset(p.x, p.y, (x, y, r) => this.isInsideRock(x, y, r));
    this.decor3d.reset(this.ocean, (x, y, pad) => this.isInsideRock(x, y, pad));
    this.residents.reset(p.x, p.y, (x, y, pad) => this.isInsideRock(x, y, pad));
    this.startMass = mass;
    this.maxMass = mass;
    this.startTime = this.t;
    this.deathTimer = -1;
    this.level = this.calcLevel(p.r);
    this.prevZone = zoneAt(p.y);
    this.prevPlayerY = p.y;
    this.flyCoins = [];
    this.surfaceWaves = [];
    this.orbs = [];
    this.balloons = [];
    this.mines = [];
    this.mineTimers = [];
    this.sunfish = [];
    this.sunfishTimers = [];
    this.blastFlash = 0;
    this.orbTimer = 5;
    this.balloonTimer = 6;
    this.goldenTimer = 36;
    this.shieldT = 0;
    this.turboT = 0;
    this.vortexT = 0;
    this.clockT = 0;
    this.caveZoom = 0;
    this.caveVisAlpha = 0;
    this.caveSightDir = 1;
    this.lastCave = null;
    this.streamPts = this.streamCoins = this.streamN = 0;
    this.coinChain = 0;
    for (let i = 0; i < MINE_COUNT; i++) this.spawnMine(true);
    for (let i = 0; i < SUNFISH_COUNT; i++) this.spawnSunfish(true);
    for (const f of this.fish) {
      if (f !== p && f.r > p.r && Math.hypot(f.x - p.x, f.y - p.y) < 480) {
        const np = this.randomSpawnPos(f.r, true);
        f.x = np.x;
        f.y = np.y;
      }
    }
    this.spawnOrb("pearl", true);
    this.spawnOrb("shield", true);
    this.spawnBalloon("stopwatch", true);
    this.spawnBalloon(undefined, true);
    for (let i = 0; i < 3; i++) this.spawnBalloon(undefined, false);
    this.spawnRing(p.x, p.y, "#a5f3fc", 16);
    this.emitHud();
    sfx.spawn();
  }

  calcLevel(r: number) {
    return SPECIES.filter((s) => s.minR < r * EAT_RATIO).length;
  }

  calcGrowthPct(r: number): number {
    let prevR = 6.5;
    for (let i = 0; i < SPECIES.length; i++) {
      const needR = SPECIES[i].minR / EAT_RATIO;
      if (r < needR) {
        const prevMass = prevR * prevR;
        const needMass = needR * needR;
        const curMass = r * r;
        return clamp((curMass - prevMass) / Math.max(1, needMass - prevMass), 0, 1);
      }
      prevR = needR;
    }
    return 1;
  }

  setSuck(on: boolean) {
    this.suckInput = on;
  }

  setBoost(on: boolean) {
    this.boostInput = on;
  }

  setSpeedScale(s: number, upgradeLv = 0) {
    this.speedScale = clamp(s, 0.7, 1.8);
    if (this.player && !this.player.dead) {
      this.player.speedMul = (1 + upgradeLv * 0.07) * this.speedScale;
    }
  }

  setBulkScale(s: number) {
    this.bulkScale = clamp(s, 0.7, 2.5);
  }

  applyBoost(f: Fish, want: boolean, dt: number) {
    const wasBoost = f.boosting;
    const freeTurbo = f === this.player && this.turboT > 0;
    if (freeTurbo) {
      f.boost = 1;
      f.boostExhausted = false;
    }
    if (want && !f.boostExhausted && f.boost > 0) {
      f.boosting = true;
      if (!freeTurbo) f.boost -= dt * 0.55;
      if (f.boost <= 0) {
        f.boost = 0;
        f.boostExhausted = true;
        f.boosting = false;
      }
    } else {
      f.boosting = false;
      f.boost = Math.min(1, f.boost + dt * 0.24);
      if (f.boostExhausted && f.boost > 0.35) f.boostExhausted = false;
    }
    if (f.boosting && !wasBoost) {
      f.sqv -= 6;
      const onScreen = !this.menuActive && Math.abs(f.x - this.cam.x) < this.vw / 2 + 20 && Math.abs(f.y - this.cam.y) < this.vh / 2 + 20;
      if (onScreen) {
        sfx.whoosh(f === this.player);
        const bx = f.x - f.face * f.r;
        for (let i = 0; i < 8; i++) {
          this.particles.push(this.bubble(bx + (Math.random() - 0.5) * f.r, f.y + (Math.random() - 0.5) * f.r, 1 + Math.random() * 2));
        }
        this.spawnRing(bx, f.y, "#bff8ff", f.r * 0.65);
      }
    }
  }

  /** WebGL refused to build the live 3D sea: fall back to the painted reef */
  private lautFailed() {
    this.lautOn = false;
    this.ocean.laut = false;
    this.laut = null;
    this.applyReefMode();
    this.onLautFailed?.();
  }
  onLautFailed?: () => void;

  loop(now: number) {
    const ts = Number.isFinite(now) ? now : performance.now();
    const raw = ts - this.last;
    if (!this.ready) {
      this.last = ts;
      if (!this.menuActive || Math.abs(this.loadPct - this.lastLoadDrawPct) >= 0.06 || this.lastLoadDrawPct < 0) {
        this.lastLoadDrawPct = this.loadPct;
        this.drawLoading();
      }
      this.raf = requestAnimationFrame(this.loop);
      return;
    }
    if (this.lautOn && this.laut && !this.laut.ready && !this.laut.failed) {
      // finish (or lazily build) the 3D sea in small slices while the painted reef keeps the game alive
      this.laut.step(12);
      if (this.laut.failed) this.lautFailed();
    }
    if (this.menuActive) {
      if (this.menuPaused || document.hidden) {
        this.last = ts;
        this.raf = requestAnimationFrame(this.loop);
        return;
      }
      // Smooth ~28 FPS live ocean attract mode behind the wooden menu so fish & reefs stay alive without starving 60 FPS UI
      if (raw < 36) {
        this.raf = requestAnimationFrame(this.loop);
        return;
      }
      const dtMenu = clamp(raw / 1000, 0.008, 0.05);
      this.last = ts;
      this.update(dtMenu);
      this.render();
      this.raf = requestAnimationFrame(this.loop);
      return;
    }
    let dt = Number.isFinite(raw) ? raw / 1000 : 1 / 60;
    this.last = ts;
    this.trackPerf(raw);
    if (dt < 0) dt = 0;
    else if (dt > 0.05) dt = 0.05;
    // frame-time smoothing: responsive yet smooth against timer jitter
    if (!Number.isFinite(this.dtS) || this.dtS < 0) this.dtS = dt;
    else this.dtS += (dt - this.dtS) * 0.48;
    dt = Math.max(0, this.dtS);
    if (this.freeze > 0) {
      this.freeze -= dt;
    } else {
      this.update(dt);
    }
    this.render();
    // idle-time sprite warming during gameplay
    if (this.bg.length && raw < 22 && performance.now() - ts < 10 && spriteBudgetLeft() > 0) this.bg.pop()!();
    this.raf = requestAnimationFrame(this.loop);
  }

  resize(instant = false) {
    const focus = this.player && !this.player.dead ? this.player : this.spectate;
    const r = focus ? focus.r : 9;
    const zoomBoost = this.cameraZoomScale * (1 + this.caveZoom * 0.44);
    const viewH = clamp(345 + (r - 7.6) * 4.5, 345, 720) / zoomBoost;
    const W = Math.max(1, window.innerWidth);
    const H = Math.max(1, window.innerHeight);
    const targetZoom = Math.max(1, Math.min(H / viewH, W / (viewH * 1.25)));
    this.zoom = instant ? targetZoom : this.zoom + (targetZoom - this.zoom) * 0.14;

    this.coinHudPos = { x: Math.min(W - 38, W / 2 + 465), y: 26 };

    if (this.pixelMode) {
      const qps = Math.max(1, Math.round(this.zoom * 20) / 20);
      const cw = Math.ceil(W / qps);
      const ch = Math.ceil(H / qps);
      if (this.canvas.width !== cw || this.canvas.height !== ch) {
        this.canvas.width = cw;
        this.canvas.height = ch;
      }
      this.dpr = 1;
      this.vw = cw;
      this.vh = ch;
    } else {
      const modeCap = MAX_PIXELS_BY_MODE[this.graphicsMode];
      const capPx = this.menuActive ? MENU_MAX_PIXELS : isSoftwareWebGL() ? Math.min(modeCap, 1_850_000) : modeCap;
      const dprCap = MAX_DPR_BY_MODE[this.graphicsMode];
      const qScale = this.graphicsMode === "super_hd" ? 1 : this.graphicsMode === "hd_boost" ? Math.max(0.95, Q_SCALE[this.quality]) : Q_SCALE[this.quality];
      const dpr = Math.min(window.devicePixelRatio || 1, dprCap, Math.sqrt(capPx / (W * H))) * qScale;
      const cw = Math.round(W * dpr);
      const ch = Math.round(H * dpr);
      if (this.canvas.width !== cw || this.canvas.height !== ch) {
        this.canvas.width = cw;
        this.canvas.height = ch;
      }
      this.dpr = dpr;
      this.vw = W / this.zoom;
      this.vh = H / this.zoom;
    }
  }

  // Exact gap-free SDF collision against every rock formation & cave ceiling/floor/walls
  resolveRockCollisions(f: Fish) {
    const fr = Math.max(4, f.r * 0.72);
    for (const form of this.ocean.formations) {
      const margin = fr + 46;
      if (
        f.x < form.x - margin ||
        f.x > form.x + form.w + margin ||
        f.y < form.y - margin ||
        f.y > form.y + form.h + margin
      ) {
        continue;
      }
      const cave = form.cave;
      // Keep cave passable if fish fits maxR OR is already inside this cave (growing inside never traps!)
      const useCave = !!cave && (f.r <= cave.maxR || f.inCaveId === cave.id);
      for (let pass = 0; pass < 3; pass++) {
        const hit = this.ocean.sampleRockSDF(form, f.x, f.y, useCave);
        if (hit.dist < fr) {
          const pen = fr - hit.dist;
          f.x += hit.nx * pen;
          f.y += hit.ny * pen;
          const vn = f.vx * hit.nx + f.vy * hit.ny;
          if (vn < 0) {
            f.vx -= hit.nx * vn * 1.08;
            f.vy -= hit.ny * vn * 1.08;
          }
        } else {
          break;
        }
      }
    }
  }

  update(dt: number) {
    this.t += dt;
    this.caveMsgCd = Math.max(0, this.caveMsgCd - dt);
    this.resize();
    const p = this.player;

    if (this.poisonDizzyT > 0) this.poisonDizzyT = Math.max(0, this.poisonDizzyT - dt);
    if (p && !p.dead && !p.eatenBy && this.poisonDelayQueue.length > 0) {
      let triggered = false;
      let qw = 0;
      for (let i = 0; i < this.poisonDelayQueue.length; i++) {
        const rem = this.poisonDelayQueue[i] - dt;
        if (rem <= 0) triggered = true;
        else this.poisonDelayQueue[qw++] = rem;
      }
      this.poisonDelayQueue.length = qw;
      if (triggered) {
        this.poisonDizzyT = 2.0;
        sfx.dizzy();
        this.shake = Math.max(this.shake, 4.5);
        this.spawnSparks(p.x, p.y, "#a3e635", 14);
        this.spawnSparks(p.x, p.y, "#fde047", 12);
        this.spawnRing(p.x, p.y, "#a3e635", p.r * 2.2);
        this.texts.push({ x: p.x, y: p.y - p.r - 16, text: this.lang === "id" ? "PUSING!" : "DIZZY!", color: "#fde047", life: 1.5, max: 1.5, size: 13 });
      } else if (Math.random() < dt * 7) {
        this.particles.push({
          x: p.mouthX() + (Math.random() - 0.5) * p.r * 0.5,
          y: p.mouthY() + (Math.random() - 0.5) * p.r * 0.5,
          vx: (Math.random() - 0.5) * 14,
          vy: -18 - Math.random() * 14,
          life: 0.45,
          max: 0.45,
          type: "bit",
          color: Math.random() < 0.65 ? "#a3e635" : "#854d0e",
          size: 1.5,
        });
      }
    } else if (!p || p.dead) {
      this.poisonDelayQueue.length = 0;
      this.poisonDizzyT = 0;
    }

    if (!p || p.dead) {
      if (!this.spectate || this.spectate.dead || (!p && this.spectate.y > 560)) {
        const bots = this.fish.filter((f) => f.kind === "bot" && !f.dead && (!p ? f.y < 500 : true));
        const pool = bots.length ? bots : this.fish.filter((f) => f.kind === "bot" && !f.dead);
        pool.sort((a, b) => b.mass - a.mass);
        this.spectate = pool[Math.floor(Math.random() * Math.min(4, pool.length))] || null;
      }
    }

    if (p && !p.dead && !p.eatenBy) {
      this.applyBoost(p, this.boostInput, dt);
      const W = Math.max(1, window.innerWidth);
      const H = Math.max(1, window.innerHeight);

      // Direct zero-latency mouse coordinates so cursor tracking never lags behind fast flicks
      if (this.mouse.active) {
        this.mouse.sx = this.mouse.x;
        this.mouse.sy = this.mouse.y;
      }

      const ms = this.maxSpeed(p);
      const minCamX = this.vw >= WORLD_W ? WORLD_W / 2 : this.vw / 2;
      const maxCamX = this.vw >= WORLD_W ? WORLD_W / 2 : WORLD_W - this.vw / 2;
      const minCamY = MIN_CAM_TOP + this.vh / 2;
      const maxCamY = WORLD_H + 35 - this.vh / 2;

      // 0. STUNG BY A JELLYFISH / BOUNCED OFF BELL / POISON DIZZINESS: no control, dizzy drift
      if (p.divePlungeT > 0) p.divePlungeT = Math.max(0, p.divePlungeT - dt);
      const lost = this.stunT > 0 || this.knockT > 0 || this.poisonDizzyT > 0;
      if (lost) {
        if (p.inAir || p.y < SURFACE_Y) {
          p.inAir = true;
          p.vy += AIR_GRAVITY * dt;
          p.vx *= Math.exp(-0.35 * dt);
          p.x = clamp(p.x + p.vx * dt, p.r, WORLD_W - p.r);
          p.y += p.vy * dt;
          if (p.y < SKY_TOP_LIMIT) {
            p.y = SKY_TOP_LIMIT;
            p.vy = Math.max(0, p.vy);
          }
          if (p.y >= SURFACE_Y) {
            const impactVy = Math.max(135, p.vy * 0.78);
            p.inAir = false;
            p.y = SURFACE_Y + 4 + Math.min(10, p.r * 0.16);
            p.vy = clamp(impactVy, 135, 420);
            p.divePlungeT = clamp(0.32 + p.vy / 850, 0.34, 0.65);
            if (p.splashCd <= 0) {
              p.splashCd = 0.24;
              this.spawnWaterSplash(p.x, p.r, clamp(impactVy / 190, 0.72, 1.75), true, true);
            }
          }
        } else if (this.knockT > 0 && this.stunT <= 0) {
          // ballistic bounce: keep flying, slow water drag, spin the face with the motion
          p.vx *= Math.exp(-1.1 * dt);
          p.vy *= Math.exp(-1.1 * dt);
          p.vy += 30 * dt;
          if (Math.abs(p.vx) > 20) p.face = p.vx > 0 ? 1 : -1;
        } else if (this.poisonDizzyT > 0 && this.stunT <= 0) {
          // Wobbly drunken spin from eating poisonous fish
          const wob = this.t * 9.5;
          p.vx += (Math.cos(wob) * 58 - p.vx) * Math.min(1, dt * 5.2);
          p.vy += (Math.sin(wob * 1.35) * 44 + 8 - p.vy) * Math.min(1, dt * 5.2);
          p.face = Math.sin(this.t * 4.2) >= 0 ? 1 : -1;
        } else {
          p.vx += (Math.sin(this.t * 37) * 26 - p.vx) * Math.min(1, dt * 4);
          p.vy += (Math.cos(this.t * 29) * 20 + 14 - p.vy) * Math.min(1, dt * 4);
          p.face = Math.sin(this.t * 2.3) > 0 ? 1 : -1;
        }
        p.sucking = false;
        p.boosting = false;
      } else if (this.mouse.active) {
        const baseCamLeft = this.vw >= WORLD_W ? (WORLD_W - this.vw) / 2 : clamp(this.cam.x - this.vw / 2, 0, WORLD_W - this.vw);
        const baseCamTop = clamp(this.cam.y - this.vh / 2, MIN_CAM_TOP, WORLD_H + 35 - this.vh);
        const tx = clamp(baseCamLeft + (this.mouse.sx / W) * this.vw, p.r, WORLD_W - p.r);
        const ty = clamp(baseCamTop + (this.mouse.sy / H) * this.vh, -175, floorY(tx) - p.r * 0.6);
        const dx = tx - p.x;
        const steerTy = p.divePlungeT > 0 ? Math.max(ty, SURFACE_Y + 26 + p.r * 0.9) : ty;
        const dy = steerTy - p.y;

        if (p.inAir || p.y < SURFACE_Y) {
          // Airborne ballistic arc: real gravity pulls fish down to dive cleanly back into the ocean!
          p.inAir = true;
          p.sucking = false;
          p.boosting = false;
          p.vy += AIR_GRAVITY * dt;
          p.vx *= Math.exp(-0.28 * dt);
          p.vx += clamp((tx - p.x) * 2.1, -155, 155) * dt;
          if (ty - p.y > 24 && p.vy > -45) p.vy += 165 * dt;
          p.x = clamp(p.x + p.vx * dt, p.r, WORLD_W - p.r);
          p.y += p.vy * dt;
          if (p.y < SKY_TOP_LIMIT) {
            p.y = SKY_TOP_LIMIT;
            p.vy = Math.max(0, p.vy);
          }
          if (Math.abs(p.vx) > 14) p.face = p.vx > 0 ? 1 : -1;
          else if (Math.abs(dx) > 4) p.face = dx > 0 ? 1 : -1;
          if (p.y >= SURFACE_Y) {
            // Plunge ("nyemplung") deeply underwater with real downward momentum — never skip/bounce on surface!
            const impactVy = Math.max(145, p.vy * 0.8);
            p.inAir = false;
            p.y = SURFACE_Y + 4 + Math.min(10, p.r * 0.16);
            p.vy = clamp(impactVy, 145, 430);
            p.divePlungeT = clamp(0.34 + p.vy / 820, 0.36, 0.68);
            if (p.splashCd <= 0) {
              p.splashCd = 0.24;
              this.spawnWaterSplash(p.x, p.r, clamp(impactVy / 190, 0.75, 1.8), true, true);
            }
          }
        } else {
          const dist = Math.hypot(dx, dy);
          const dead = 1.2;
          const full = this.vw * 0.05;
          // High-response spring velocity + smooth cruise curve: moves as fast & crisp as the mouse!
          const catchUp = Math.min(ms * 3.1, Math.max(0, dist - dead) * 11.5);
          const cruise = ms * Math.pow(Math.min(1, Math.max(0, dist - dead) / full), 0.52);
          const want = dist <= dead ? 0 : Math.max(cruise, catchUp);
          const tvx = dist > 0.01 ? (dx / dist) * want : 0;
          const tvy = dist > 0.01 ? (dy / dist) * want : 0;
          const vMag = Math.hypot(p.vx, p.vy);
          const turning = want > 1 && vMag > 6 && (tvx * p.vx + tvy * p.vy) / (want * vMag) < 0.5;
          const baseRate = want === 0 ? 24 : turning ? (p.boosting ? 50 : 44) : p.boosting ? 38 : 34;
          const rate = p.divePlungeT > 0 ? Math.min(baseRate, 11) : baseRate;
          const acc = 1 - Math.exp(-rate * dt);
          p.vx += (tvx - p.vx) * acc;
          p.vy += (tvy - p.vy) * acc;

          const stepX = p.vx * dt,
            stepY = p.vy * dt;
          const steps = Math.min(10, Math.max(1, Math.ceil(Math.hypot(stepX, stepY) / 4.5)));
          for (let k = 0; k < steps; k++) {
            p.x += stepX / steps;
            p.y += stepY / steps;
            this.resolveRockCollisions(p);
            const fy = floorY(p.x) - p.r * 0.6;
            if (p.y > fy) p.y = fy;
            if (p.y < SURFACE_Y) {
              if (p.divePlungeT <= 0 && (p.vy < -48 || ty < SURFACE_Y - 10)) {
                // Breach! Launch smoothly into the sky!
                p.inAir = true;
                const minLaunch = -(210 + Math.min(120, p.r * 1.9)) * (p.boosting ? 1.24 : 1.0);
                p.vy = Math.min(p.vy * 1.16, minLaunch);
                if (Math.abs(p.vx) < 28) p.vx = p.face * 36;
                if (p.splashCd <= 0) {
                  p.splashCd = 0.24;
                  this.spawnWaterSplash(p.x, p.r, clamp(Math.abs(p.vy) / 210, 0.72, 1.5), false, true);
                }
                break;
              } else {
                p.y = SURFACE_Y + Math.max(4, p.r * 0.25);
                p.vy = Math.max(24, p.vy);
              }
            }
            p.x = clamp(p.x, p.r, WORLD_W - p.r);
          }

          const flipDeadX = Math.max(1.2, Math.abs(dy) * 0.045);
          if (dx > flipDeadX || (Math.abs(dx) > 0.6 && p.vx > 12)) p.face = 1;
          else if (dx < -flipDeadX || (Math.abs(dx) > 0.6 && p.vx < -12)) p.face = -1;
        }
      } else if (p.inAir || p.y < SURFACE_Y) {
        p.inAir = true;
        p.vy += AIR_GRAVITY * dt;
        p.vx *= Math.exp(-0.28 * dt);
        p.x = clamp(p.x + p.vx * dt, p.r, WORLD_W - p.r);
        p.y += p.vy * dt;
        if (p.y >= SURFACE_Y) {
          const impactVy = Math.max(135, p.vy * 0.78);
          p.inAir = false;
          p.y = SURFACE_Y + 4 + Math.min(10, p.r * 0.16);
          p.vy = clamp(impactVy, 135, 420);
          p.divePlungeT = clamp(0.32 + p.vy / 850, 0.34, 0.65);
          if (p.splashCd <= 0) {
            p.splashCd = 0.24;
            this.spawnWaterSplash(p.x, p.r, clamp(impactVy / 190, 0.72, 1.75), true, true);
          }
        }
      } else if (p.boosting) {
        p.vx = p.face * ms;
        p.vy = 0;
        p.x = clamp(p.x + p.vx * dt, p.r, WORLD_W - p.r);
        this.resolveRockCollisions(p);
      } else {
        p.vx *= Math.exp(-8 * dt);
        p.vy *= Math.exp(-8 * dt);
      }

      const prevCave = p.hiddenCave;
      p.hiddenCave = this.getCaveAt(p.x, p.y, p.r, p.inCaveId);
      if (p.hiddenCave) {
        p.inCaveId = p.hiddenCave.id;
        this.lastCave = p.hiddenCave;
        p.energy = Math.min(1, p.energy + dt * 0.22);
        p.boost = Math.min(1, p.boost + dt * 0.2);
        if (!prevCave && this.caveMsgCd <= 0) {
          this.caveMsgCd = 2.4;
          this.texts.push({ x: p.x, y: p.y - p.r - 14, text: this.lang === "id" ? "TERSEMBUNYI!" : "HIDDEN!", color: "#5eead4", life: 1.1, max: 1.1, size: 9.5 });
        }
      } else if (p.inCaveId !== null) {
        const fm = this.ocean.formations.find((form) => form.cave?.id === p.inCaveId);
        if (!fm || this.ocean.sampleRockSDF(fm, p.x, p.y, false).dist > p.r * 0.85) {
          p.inCaveId = null;
        }
      }

      const hiding = !!p.hiddenCave;
      const zRate = 1 - Math.exp(-(hiding ? 4.8 : 3.4) * dt);
      this.caveZoom += ((hiding ? 1 : 0) - this.caveZoom) * zRate;
      if (!hiding && this.caveZoom < 0.002) this.caveZoom = 0;
      const vRate = 1 - Math.exp(-(hiding ? 6.5 : 4.2) * dt);
      this.caveVisAlpha += ((hiding ? 1 : 0) - this.caveVisAlpha) * vRate;
      if (!hiding && this.caveVisAlpha < 0.002) {
        this.caveVisAlpha = 0;
        this.lastCave = null;
      }
      if (this.lastCave) {
        const targetDir =
          this.lastCave.kind === "alcove"
            ? this.lastCave.dir >= 0
              ? 1
              : -1
            : Math.abs(p.x - this.lastCave.x) > 12
              ? p.x >= this.lastCave.x
                ? 1
                : -1
              : p.face;
        this.caveSightDir += (targetDir - this.caveSightDir) * (1 - Math.exp(-8.5 * dt));
      }

      // 2. CAMERA: silky locked-on follow + subtle framing toward cave entrance while hiding
      const lk = 1 - Math.exp(-10 * dt);
      this.look.x += (p.vx * 0.09 - this.look.x) * lk;
      this.look.y += (p.vy * 0.07 - this.look.y) * lk;
      const mouthBiasX = this.lastCave ? this.caveSightDir * Math.min(46, this.vw * 0.14) * this.caveZoom : 0;
      const follow = 1 - Math.exp(-16 * dt);
      this.cam.x += (clamp(p.x + this.look.x + mouthBiasX, minCamX, maxCamX) - this.cam.x) * follow;
      this.cam.y += (clamp(p.y + this.look.y, minCamY, maxCamY) - this.cam.y) * follow;

      this.applySuckState(p, this.suckInput && !p.inAir, dt);
      sfx.setSuck(p.sucking);
    } else {
      if (p) {
        p.hiddenCave = null;
        p.inCaveId = null;
      }
      this.caveZoom += (0 - this.caveZoom) * Math.min(1, dt * 4);
      this.caveVisAlpha += (0 - this.caveVisAlpha) * Math.min(1, dt * 5);
      if (this.caveVisAlpha < 0.002) {
        this.caveVisAlpha = 0;
        this.lastCave = null;
      }
      sfx.setSuck(false);
    }

    const attract = this.menuActive;
    const nearX = this.vw * 0.8 + 140;
    const nearY = this.vh * 0.8 + 140;

    this.rebuildGrid(attract, nearX, nearY);
    const predators = this.predators;
    predators.length = 0;
    for (let i = 0; i < this.fish.length; i++) {
      const f = this.fish[i];
      if (!f.dead && !f.eatenBy && (f.kind !== "npc" || f.sp.predator)) {
        if (attract && (Math.abs(f.x - this.cam.x) > nearX || Math.abs(f.y - this.cam.y) > nearY)) continue;
        predators.push(f);
      }
    }
    this.updateSchools(dt, predators, attract);
    for (const f of this.fish) {
      if (f.dead || f.caught || f.eatenBy || f.kind === "player") continue;
      if (attract && (Math.abs(f.x - this.cam.x) > nearX || Math.abs(f.y - this.cam.y) > nearY)) continue;
      f.ai.timer -= dt;
      if (f.kind === "bot") this.botAI(f, dt);
      else if (f.fry) this.fryAI(f, dt);
      else this.npcAI(f, dt, predators);
    }

    for (const f of this.fish) {
      if (f.sucking && !f.dead && !f.eatenBy) {
        if (attract && (Math.abs(f.x - this.cam.x) > nearX || Math.abs(f.y - this.cam.y) > nearY)) continue;
        this.doSuck(f, dt);
      }
    }

    for (const f of this.fish) {
      if (f.dead) continue;
      if (attract && !f.eatenBy && (Math.abs(f.x - this.cam.x) > nearX || Math.abs(f.y - this.cam.y) > nearY)) continue;
      if (f.eatenBy) {
        const isOctoEat = f.eatenBy.sp.style === "octopus";
        const eatDur = isOctoEat
          ? f.eatenBy.sucking
            ? f.fry
              ? 0.24
              : 0.34
            : f.fry
              ? 0.32
              : 0.44
          : f.fry
            ? 0.105
            : 0.165;
        f.eatT += dt / eatDur;
        if (f.eatT >= 1) this.finishEat(f.eatenBy, f);
        continue;
      }
      if (f.caught) {
        f.vx = 0;
        f.vy = 0;
        f.tailPh += dt * 6;
        continue;
      }
      if (f.splashCd > 0) f.splashCd = Math.max(0, f.splashCd - dt);
      if (f.airJumpCd > 0) f.airJumpCd = Math.max(0, f.airJumpCd - dt);
      if (f !== p && f.divePlungeT > 0) f.divePlungeT = Math.max(0, f.divePlungeT - dt);
      const isDirectPlayer = f === p && this.mouse.active && this.stunT <= 0 && this.knockT <= 0 && this.poisonDizzyT <= 0;
      if (!isDirectPlayer) {
        if (f.inAir || f.y < SURFACE_Y) {
          f.inAir = true;
          f.sucking = false;
          f.boosting = false;
          f.vy += AIR_GRAVITY * dt;
          f.vx *= Math.exp(-0.28 * dt);
        }
        f.x += f.vx * dt;
        f.y += f.vy * dt;
        if (f.y >= SURFACE_Y) {
          this.resolveRockCollisions(f);
        }

        const fy = floorY(f.x) - f.r * 0.6;
        if (f.y > fy) {
          f.y = fy;
          f.vy = Math.min(0, f.vy);
        }
        if (!f.inAir && f.y < SURFACE_Y) {
          if (f.divePlungeT <= 0 && f.vy < -50 && f.sucked <= 0) {
            f.inAir = true;
            f.vy = Math.min(f.vy * 1.14, -(175 + Math.min(115, f.r * 1.8)));
            if (Math.abs(f.vx) < 40) f.vx = f.face * (54 + Math.random() * 44);
            if (f.splashCd <= 0 && Math.abs(f.x - this.cam.x) < this.vw * 0.8 && this.camTop < 180) {
              f.splashCd = 0.26;
              const playSfx = !this.menuActive && Math.abs(f.x - this.cam.x) < this.vw * 0.5 && f.r > 9.5;
              this.spawnWaterSplash(f.x, f.r, clamp(Math.abs(f.vy) / 225, 0.55, 1.4), false, playSfx);
            }
          } else {
            f.y = SURFACE_Y + Math.max(4, f.r * 0.28);
            f.vy = Math.max(24, f.vy);
          }
        } else if (f.inAir && f.y >= SURFACE_Y) {
          const impactVy = Math.max(125, f.vy * 0.78);
          f.inAir = false;
          f.y = SURFACE_Y + 4 + Math.min(10, f.r * 0.16);
          f.vy = clamp(impactVy, 125, 410);
          f.divePlungeT = clamp(0.32 + f.vy / 850, 0.34, 0.65);
          f.airJumpCd = Math.max(f.airJumpCd, 2.0 + Math.random() * 1.5);
          if (f.splashCd <= 0 && Math.abs(f.x - this.cam.x) < this.vw * 0.8 && this.camTop < 180) {
            f.splashCd = 0.26;
            const playSfx = !this.menuActive && Math.abs(f.x - this.cam.x) < this.vw * 0.5 && f.r > 9.5;
            this.spawnWaterSplash(f.x, f.r, clamp(impactVy / 195, 0.65, 1.75), true, playSfx);
          }
        }
        if (f.y < SKY_TOP_LIMIT) {
          f.y = SKY_TOP_LIMIT;
          f.vy = Math.max(0, f.vy);
        }
        if (f.x < f.r) {
          f.x = f.r;
          f.vx = Math.abs(f.vx);
        }
        if (f.x > WORLD_W - f.r) {
          f.x = WORLD_W - f.r;
          f.vx = -Math.abs(f.vx);
        }
      }
      const sp = Math.hypot(f.vx, f.vy);
      if (!isDirectPlayer && Math.abs(f.vx) > 6 && !(f.kind === "npc" && f.sucked > 0)) f.face = f.vx > 0 ? 1 : -1;

      // Smooth 3D-like turn flip (-1 .. +1), C1-smooth spring pitch angle, and ragdoll spine curvature
      const flipSpeed = f.sp.is3D
        ? (f.kind === "player" ? 7.8 : 7.0) + (f.boosting ? 2.2 : 0)
        : f.kind === "player"
          ? 20
          : 10;
      const flipRate = 1 - Math.exp(-flipSpeed * dt);
      f.turnFlip += (f.face - f.turnFlip) * flipRate;

      const boostTarget = f.boosting ? 1 : 0;
      f.boostVis += (boostTarget - f.boostVis) * (1 - Math.exp(-(f.boosting ? 14 : 9) * dt));

      const uSp = clamp((sp - 3) / 36, 0, 1);
      const speedFactor = uSp * uSp * (3 - 2 * uSp);
      const horiz = Math.hypot(f.vx, 12);
      const rawSlope = Math.atan2(f.vy, horiz) * (f.inAir ? 0.96 : 0.92);
      const turnLevel = 0.78 + 0.22 * Math.abs(f.turnFlip);
      const idlePitch = f.inAir ? 0 : (1 - speedFactor) * Math.sin(this.t * 1.35 + f.id * 1.37) * 0.055;
      const tiltCap = f.inAir ? 1.24 : 1.02;
      const targTilt = clamp(rawSlope, -tiltCap, tiltCap) * speedFactor * turnLevel + idlePitch;

      const wTilt = f.inAir ? 14.5 : f.kind === "player" ? 13.5 : f.kind === "bot" ? 9.0 : f.fry ? 11.5 : 7.8;
      const tiltAcc = wTilt * wTilt * (targTilt - f.tilt) - 1.78 * wTilt * f.tiltV;
      f.tiltV = clamp(f.tiltV + tiltAcc * dt, -10, 10);
      f.tilt = clamp(f.tilt + f.tiltV * dt, -1.26, 1.26);

      // Elastic ragdoll spine bend + signed C-curve whip on 3D turns
      const turnGap = Math.abs(f.face - f.turnFlip);
      const turnMid = Math.sqrt(Math.max(0, 1 - f.turnFlip * f.turnFlip));
      const signedTurnTarget = clamp(-(f.face - f.turnFlip) * (0.65 + turnMid * 0.85), -1.15, 1.15);
      const wTB = f.kind === "player" ? 13.0 : 11.0;
      const tbAcc = wTB * wTB * (signedTurnTarget - f.turnBend) - 1.38 * wTB * f.turnBendV;
      f.turnBendV = clamp(f.turnBendV + tbAcc * dt, -10, 10);
      f.turnBend = clamp(f.turnBend + f.turnBendV * dt, -1.25, 1.25);

      const turnSway = turnGap > 0.04 ? Math.sin(this.t * 13 + f.id) * 0.052 * Math.min(1, turnGap) : 0;
      const targBend = clamp(-f.tiltV * 0.1 - f.tilt * 0.042 * speedFactor + turnSway, -0.42, 0.42);
      const wBend = f.kind === "player" ? 11.5 : 9.2;
      const bendAcc = wBend * wBend * (targBend - f.bend) - 1.42 * wBend * f.bendV;
      f.bendV = clamp(f.bendV + bendAcc * dt, -6.5, 6.5);
      f.bend = clamp(f.bend + f.bendV * dt, -0.48, 0.48);

      const speedNorm = Math.min(1.4, sp / 170);
      const turnWhip = Math.min(1.3, turnGap * 1.1) + Math.min(0.6, Math.abs(f.tiltV) * 0.11);
      f.tailPh += dt * (3.2 + speedNorm * 8.6 + f.boostVis * 13.5 + turnWhip * 4.8);
      if (f.sucked > 0) f.tailPh += dt * 9; // faster tail beats while being vacuumed
      if (f.gulpT > 0) f.gulpT = Math.max(0, f.gulpT - dt / 0.62);
      if (f.swallowT > 0) f.swallowT = Math.max(0, f.swallowT - dt / 0.34);
      if (f.eatPullT > 0) f.eatPullT = Math.max(0, f.eatPullT - dt / Math.max(0.18, f.eatPullDur));
      if (f.sp.style === "octopus") {
        const grabTarget = !f.sucking && f.wantGrab && f.eatPullT <= 0.05 ? 1 : 0;
        const grabRate = 1 - Math.exp(-(grabTarget > f.eatReachT ? 18 : 11) * dt);
        f.eatReachT += (grabTarget - f.eatReachT) * grabRate;

        const safeDt = Math.max(0.001, dt);
        const ay = clamp((f.vy - f.lastVy) / safeDt, -550, 550);
        const trailTarget = clamp(sp / 128, 0, 1.18) + f.boostVis * 0.42;
        const trailAcc = 46 * (trailTarget - f.tentTrail) - 9.2 * f.tentTrailV;
        f.tentTrailV = clamp(f.tentTrailV + trailAcc * dt, -6, 6);
        f.tentTrail = clamp(f.tentTrail + f.tentTrailV * dt, 0, 1.45);

        const vertTarget = clamp(f.vy / 175 + ay / 820 + f.tiltV * 0.12, -1.05, 1.05);
        const vertAcc = 52 * (vertTarget - f.tentVertLag) - 8.4 * f.tentVertLagV;
        f.tentVertLagV = clamp(f.tentVertLagV + vertAcc * dt, -7, 7);
        f.tentVertLag = clamp(f.tentVertLag + f.tentVertLagV * dt, -1.15, 1.15);

        const turnTarget = clamp(f.turnBend * 1.15 + f.turnBendV * 0.08, -1.25, 1.25);
        const turnAcc = 48 * (turnTarget - f.tentTurnLag) - 8.2 * f.tentTurnLagV;
        f.tentTurnLagV = clamp(f.tentTurnLagV + turnAcc * dt, -7, 7);
        f.tentTurnLag = clamp(f.tentTurnLag + f.tentTurnLagV * dt, -1.35, 1.35);

        f.lastVx = f.vx;
        f.lastVy = f.vy;
      } else {
        f.eatReachT = 0;
      }
      f.wantGrab = false;
      if (f.slurpCd > 0) f.slurpCd -= dt;

      // Gentle breathing suction squash + eager anticipation stretch when opening wide
      const isOcto = f.sp.style === "octopus";
      const targetSq = f.sucking
        ? (isOcto ? 0.16 : 0.12) + Math.sin(this.t * (isOcto ? 7.5 : 9)) * (isOcto ? 0.045 : 0.025)
        : f.wantOpen && f.chompPhase <= 0
          ? -(isOcto ? 0.09 : 0.06) * Math.min(1, f.wantOpenAmt)
          : isOcto
            ? Math.sin(this.t * 3.8 + f.id) * 0.045
            : 0;
      // Bouncy underdamped cartoon jelly spring (extra soft & squishy for octopus!)
      const sqStiff = isOcto ? 185 : 260;
      const sqDamp = isOcto ? 7.2 : 11.5;
      f.sqv += (-sqStiff * (f.sq - targetSq) - sqDamp * f.sqv) * dt;
      f.sq = clamp(f.sq + f.sqv * dt, -0.35, 0.55);
      const suckFade = 1 - Math.exp(-(f.sucking ? 14 : 10) * dt);
      f.suckVis += ((f.sucking ? 1 : 0) - f.suckVis) * suckFade;

      f.mouthOpenT -= dt;
      f.chompT -= dt;
      f.invuln -= dt;
      f.sucked -= dt;
      f.comboT -= f === p && this.clockT > 0 ? dt * 0.35 : dt;
      if (f.comboT <= 0) f.combo = 0;

      // Pop next queued chomp snap when eating multiple fish rapidly without suction!
      if (f.chompPhase <= 0 && f.chompQueue > 0) {
        f.chompQueue--;
        f.chompDur = f.chompQueue >= 5 ? 0.095 : f.chompQueue >= 2 ? 0.115 : 0.14;
        f.chompPhase = f.chompDur;
        f.chompBitFired = false;
        // Quick anticipatory jaw flare & slight elastic recoil stretch before slamming shut
        f.jawV = Math.max(f.jawV, 24);
        f.biteLungeV -= f.r * 2.6;
        f.tiltV -= 2.0;
        f.sqv -= 8.5;
      }

      let jawTarget = 0;
      let jawK = 320;
      let jawDamp = 20;

      if (f.chompPhase > 0) {
        f.chompPhase -= dt;
        const u = clamp(1 - f.chompPhase / Math.max(0.04, f.chompDur), 0, 1);
        if (u < 0.38) {
          // Anticipatory Mangap! Snaps mouth extra wide open
          jawTarget = 1.38;
          jawK = 920;
          jawDamp = 20;
        } else {
          // Explosive Ngehap! Slams jaw shut with juicy cartoon squash & lunge
          jawTarget = -0.44;
          jawK = 1080;
          jawDamp = 16;
          if (!f.chompBitFired) {
            f.chompBitFired = true;
            f.jawV = -26;
            f.biteLungeV += Math.min(310, Math.max(64, f.r * 11.8));
            f.sqv += f.chompQueue > 0 ? 15.5 : 19.5;
            f.tiltV += 3.2;
            f.vx += f.face * Math.cos(f.tilt) * 20;
            f.vy += Math.sin(f.tilt) * 20;
            const bmx = f.mouthX(),
              bmy = f.mouthY();
            if (
              (f.chompQueue > 0 || f.kind === "player") &&
              Math.abs(bmx - this.cam.x) < this.vw &&
              Math.abs(bmy - this.cam.y) < this.vh
            ) {
              this.particles.push({
                x: bmx + f.face * f.r * 0.16,
                y: bmy,
                vx: f.face * 12,
                vy: 0,
                life: 0.16,
                max: 0.16,
                type: "chomp",
                color: "#e0f7ff",
                size: Math.max(5, f.r * 0.56),
                dir: f.face,
              });
              this.particles.push(this.bubble(bmx, bmy, 0.9 + Math.random() * 1.1));
            }
          }
        }
      } else if (f.chompT > 0.04 && f.munch) {
        // Lively rhythmic cartoon chew on big mouthfuls while gulp bulge travels down body
        jawTarget = 0.08 + Math.sin((f.chompT / 0.15) * Math.PI * 2) * 0.52;
        jawK = 520;
        jawDamp = 18;
      } else if (f.sucking) {
        jawTarget = 1.08 + Math.sin(this.t * 18 + f.id) * 0.14;
        jawK = 400;
        jawDamp = 20;
      } else if (f.mouthOpenT > 0 || f.wantOpen) {
        // Dynamic Mangap anticipation: scales extra wide with prey proximity + hungry jaw quiver
        const eager = Math.max(f.wantOpenAmt, f.mouthOpenT > 0 ? 1.08 : 0.84);
        jawTarget = 0.96 + eager * 0.38 + Math.sin(this.t * 24 + f.id) * 0.08;
        jawK = 520;
        jawDamp = 18;
        if (f.wantOpen) f.tailPh += dt * 4.8 * eager;
      } else if (Math.sin(this.t * 2.1 + f.id) > 0.88) {
        jawTarget = 0.24;
      } else {
        jawK = 360;
        jawDamp = 22;
      }
      f.jawV += (jawK * (jawTarget - f.jaw) - jawDamp * f.jawV) * dt;
      f.jaw = clamp(f.jaw + f.jawV * dt, -0.48, 1.42);

      // Spring-integrate forward bite strike lunge
      f.biteLungeV += (-260 * f.biteLunge - 18 * f.biteLungeV) * dt;
      f.biteLunge = clamp(f.biteLunge + f.biteLungeV * dt, -f.r * 0.38, f.r * 0.62);

      const tr = Math.sqrt(f.mass);
      f.r += (tr - f.r) * Math.min(1, dt * 3.2);
      f.wantOpen = false;
      f.wantOpenAmt = 0;
      if (f.kind !== "player" && !f.sucking) {
        f.energy = Math.min(1, f.energy + dt * 0.3);
      }
      if (f.boosting) {
        f.boostTrail -= dt;
        if (f.boostTrail <= 0 && Math.abs(f.x - this.cam.x) < this.vw && Math.abs(f.y - this.cam.y) < this.vh) {
          f.boostTrail = 0.032;
          const bx = f.x - f.face * f.r * 1.15,
            by = f.y + (Math.random() - 0.5) * f.r * 0.75;
          this.particles.push(this.bubble(bx, by, 0.9 + Math.random() * 1.4));
          // Juicy hydrodynamic wake streak behind boosting fish
          this.particles.push({
            x: bx,
            y: by,
            vx: -f.vx * 0.35 + (Math.random() - 0.5) * 18,
            vy: -f.vy * 0.35 + (Math.random() - 0.5) * 18,
            life: 0.22,
            max: 0.22,
            type: "streak",
            color: "#d2fcff",
            size: 1.4,
          });
        }
      }
      if (f.kind === "npc" && Math.random() < dt * (attract ? 0.04 : 0.15)) this.particles.push(this.bubble(f.mouthX(), f.mouthY(), 1));
      if (f.kind === "npc" && f.sp.poisonous && !f.eatenBy && Math.random() < dt * (attract ? 0.6 : 2.2) && Math.abs(f.x - this.cam.x) < this.vw * 0.7 && Math.abs(f.y - this.cam.y) < this.vh * 0.7) {
        this.particles.push({
          x: f.x + (Math.random() - 0.5) * f.r * 1.4,
          y: f.y + (Math.random() - 0.5) * f.r * 0.9,
          vx: (Math.random() - 0.5) * 10,
          vy: -12 - Math.random() * 14,
          life: 0.55,
          max: 0.55,
          type: "bit",
          color: Math.random() < 0.7 ? "#a3e635" : "#78350f",
          size: 1.3,
        });
      }
      if (f !== p) {
        f.hiddenCave = this.getCaveAt(f.x, f.y, f.r, f.inCaveId);
        if (f.hiddenCave) {
          f.inCaveId = f.hiddenCave.id;
        } else if (f.inCaveId !== null) {
          const fm = this.ocean.formations.find((form) => form.cave?.id === f.inCaveId);
          if (!fm || this.ocean.sampleRockSDF(fm, f.x, f.y, false).dist > f.r * 0.85) {
            f.inCaveId = null;
          }
        }
      }
    }

    if (p && !p.dead && !p.eatenBy && !this.menuActive) {
      const cached = !this.lautActive();
      for (const d of this.residents.divers) d.cached = cached;
      this.residents.update(
        dt,
        p,
        this.fish,
        (x, y, pad) => this.isInsideRock(x, y, pad),
        (f) => {
          this.spawnRing(f.x, f.y, "#b8f7df", 7);
          if (f.kind === "player") {
            if (this.shieldT > 0) return;
            p.boost = Math.max(0, p.boost - 0.32);
            p.energy = Math.max(0.1, p.energy - 0.25);
            p.invuln = 2.2;
            this.onEvent?.({ type: "feed", text: this.lang === "id" ? "Tersenggol tombak! Berlindung di balik karang." : "Grazed by a spear! Take cover behind coral." });
          } else {
            f.dead = true;
            for (const n of this.fish) {
              const dx = n.x - f.x,
                dy = n.y - f.y,
                dist = Math.hypot(dx, dy);
              if (n.kind === "npc" && !n.dead && dist < 75 && dist > 0.1) {
                n.vx += (dx / dist) * 47;
                n.vy += (dy / dist) * 47;
                n.ai.tx = n.x + dx * 2;
                n.ai.ty = n.y + dy * 2;
                n.ai.timer = 0.7;
                n.ai.flee = true;
              }
            }
          }
        },
        (text) => this.onEvent?.({ type: "feed", text: this.lang === "id" ? "Penyelam membidik! Jauhi garis kuning." : text }),
      );
    }
    this.checkEating(attract, nearX, nearY);

    {
      let w = 0;
      for (let i = 0; i < this.fish.length; i++) {
        const f = this.fish[i];
        if (!f.dead) this.fish[w++] = f;
      }
      this.fish.length = w;
    }
    let npcCount = 0;
    let poisonCount = 0;
    for (const f of this.fish) {
      if (f.kind === "npc" && !f.fry) {
        if (f.sp.poisonous) poisonCount++;
        else npcCount++;
      }
    }
    if (npcCount < NPC_TARGET) for (let i = 0; i < Math.min(8, NPC_TARGET - npcCount); i++) this.spawnNPC();
    if (poisonCount < POISON_TARGET) for (let i = 0; i < Math.min(4, POISON_TARGET - poisonCount); i++) this.spawnPoisonFish();
    if (p && !p.dead && Math.random() < dt * 2) {
      const cand = this.fish[Math.floor(Math.random() * this.fish.length)];
      if (cand && cand.kind === "npc" && !cand.fry && !cand.sp.poisonous && cand.r < p.r * 0.25 && Math.abs(cand.x - p.x) > this.vw) cand.dead = true;
    }
    {
      let rw = 0;
      for (let i = 0; i < this.respawnQueue.length; i++) {
        const q = this.respawnQueue[i];
        q.t -= dt;
        if (q.t <= 0) this.spawnBot(q.name, q.skin, 58 + Math.random() * 140);
        else this.respawnQueue[rw++] = q;
      }
      this.respawnQueue.length = rw;
    }

    // Spawn coins both from surface and inside glowing deep crevices!
    if (!attract) {
      this.coinTimer -= dt;
      if (this.coinTimer <= 0) {
      this.coinTimer = 1.1 + Math.random() * 1.3;
      const x = this.cam.x + (Math.random() - 0.5) * this.vw * 1.4;
      this.worldCoins.push({
        x: clamp(x, 20, WORLD_W - 20),
        y: Math.random() < 0.35 ? DEEP_START + 120 + Math.random() * 550 : -4,
        vx: 0,
        vy: 16 + Math.random() * 14,
        t: 0,
        value: Math.random() < 0.35 ? 3 : 1 + Math.floor(Math.random() * 2),
        settled: false,
      });
      if (Math.random() < 0.35) {
        const c = this.ocean.chestPos;
        this.worldCoins.push({
          x: c.x,
          y: c.y - 6,
          vx: (Math.random() - 0.5) * 45,
          vy: -45 - Math.random() * 30,
          t: 0,
          value: 3,
          settled: false,
        });
      }
    }
    for (const c of this.worldCoins) {
      c.t += dt;
      if (!c.settled) {
        c.vy += (24 - c.vy) * dt * 0.8;
        c.vx *= 1 - dt * 1.5;
        c.x += c.vx * dt + Math.sin(c.t * 3) * 0.3;
        c.y += c.vy * dt;
        if (c.y > floorY(c.x) - 3) {
          c.y = floorY(c.x) - 3;
          c.settled = true;
        }
      }
      if (p && !p.dead && !p.eatenBy) {
        const mx = p.mouthX(),
          my = p.mouthY();
        const d = Math.hypot(c.x - mx, c.y - my);
        const magnet = (p.r * 2.4 + 26) * 1.4;
        if (d < magnet && d > 0.5) {
          // coin magnet: nearby coins curve into the mouth on their own (1.4x stronger)
          const pull = (70 + 260 * (1 - d / magnet)) * 1.4 * dt;
          c.settled = false;
          c.vx = 0;
          c.vy = 0;
          c.x += ((mx - c.x) / d) * Math.min(d, pull);
          c.y += ((my - c.y) / d) * Math.min(d, pull);
        }
        if (d < p.r * 0.9 + 6) {
          c.t = 999;
          for (let i = 0; i < c.value; i++) this.addFlyCoin(c.x, c.y, 1, i * 0.05, 0);
          this.arcadeScore += c.value * 50;
          this.texts.push({ x: c.x, y: c.y - 6, text: "+" + c.value, color: "#ffe14a", life: 0.8, max: 0.8, size: 9 });
          this.spawnSparks(c.x, c.y, "#ffe14a", 8);
          this.spawnRing(c.x, c.y, "#fff3a1", 7);
          p.sqv += 2.5;
        }
      }
    }
      let cw = 0;
      for (let i = 0; i < this.worldCoins.length; i++) {
        const c = this.worldCoins[i];
        if (c.t < 24 && c.y < WORLD_H + 10) this.worldCoins[cw++] = c;
      }
      this.worldCoins.length = cw;
    } else {
      this.coinTimer = 0;
    }

    // Active power-up timers + Pearls / Power-Up Orbs + Golden Sardine Frenzy
    if (this.shieldT > 0) this.shieldT = Math.max(0, this.shieldT - dt);
    if (this.stingCd > 0) this.stingCd = Math.max(0, this.stingCd - dt);
    if (this.turboT > 0) this.turboT = Math.max(0, this.turboT - dt);
    if (this.knockT > 0) this.knockT = Math.max(0, this.knockT - dt);
    if (this.bounceCd > 0) this.bounceCd = Math.max(0, this.bounceCd - dt);
    // Game 2 medusae in Game 1: the bell is a springy trampoline, the tentacles sting (4 s stun)
    if (!this.menuActive && p && !p.dead && !p.eatenBy) {
      const res = this.medusae.update(
        dt,
        p,
        (x, y, r) => this.isInsideRock(x, y, r),
        this.shieldT > 0,
      );
      this.stunT = this.medusae.stun;
      if (res === "bounce" && this.medusae.lastBounce) {
        const b = this.medusae.lastBounce;
        const nx = b.nx,
          ny = b.ny;
        const vin = p.vx * nx + p.vy * ny;
        const speed = Math.hypot(p.vx, p.vy);
        const kick = 175 + Math.min(255, speed * 0.72);
        const rvx = p.vx - 2 * Math.min(0, vin) * nx;
        const rvy = p.vy - 2 * Math.min(0, vin) * ny;
        p.vx = rvx * 0.55 + nx * kick;
        p.vy = rvy * 0.55 + ny * kick - 36;
        p.x += nx * 4;
        p.y += ny * 4;
        p.sqv += 9;
        p.tiltV += (nx > 0 ? -1 : 1) * 6;
        this.knockT = 0.42 + Math.min(0.3, speed / 900);
        this.bounceCd = 0.35;
        this.shake = Math.max(this.shake, 3 + Math.min(5, speed / 80));
        sfx.pop(2);
        sfx.whoosh(true);
        this.spawnRing(p.x, p.y, "#dff9ff", p.r * 1.6);
        this.spawnSparks(p.x - nx * p.r * 0.5, p.y - ny * p.r * 0.5, "#c7f0ff", 8);
        for (let k = 0; k < 5; k++) {
          this.particles.push(
            this.bubble(p.x + (Math.random() - 0.5) * p.r, p.y + (Math.random() - 0.5) * p.r, 0.8 + Math.random() * 1.6),
          );
        }
        const words = this.lang === "id" ? ["BOING!", "DUK!", "MENTAL!", "PLOK!"] : ["BOING!", "BOUNCE!", "SPRING!", "POP!"];
        this.texts.push({ x: p.x, y: p.y - p.r - 12, text: words[(Math.random() * words.length) | 0], color: "#fde68a", life: 0.9, max: 0.9, size: 14 });
      } else if (res === "shield") {
        this.shieldT = 0;
        this.stingCd = 2.5;
        sfx.shieldBreak();
        this.spawnSparks(p.x, p.y, "#7dd3fc", 16);
        this.texts.push({ x: p.x, y: p.y - p.r - 14, text: this.lang === "id" ? "PERISAI PECAH!" : "SHIELD BROKEN!", color: "#7dd3fc", life: 1.3, max: 1.3, size: 13 });
        this.emitHud();
      } else if (res === "sting") {
        this.stunT = STING_SECONDS;
        this.stingCd = 6.5;
        this.knockT = 0;
        this.shake = 7;
        this.blastFlash = Math.max(this.blastFlash, 0.35);
        sfx.explode();
        this.spawnSparks(p.x, p.y, "#a5f3fc", 22);
        this.spawnSparks(p.x, p.y, "#fef08a", 10);
        this.texts.push({
          x: p.x,
          y: p.y - p.r - 16,
          text: this.lang === "id" ? "KESETRUM UBUR-UBUR! PUSING 4 DETIK" : "STUNG BY JELLYFISH! STUNNED 4s",
          color: "#a5f3fc",
          life: 1.8,
          max: 1.8,
          size: 12,
        });
        this.onEvent?.({
          type: "feed",
          text: this.lang === "id" ? `${p.name} tersengat ubur-ubur!` : `${p.name} was stung by a jellyfish!`,
        });
        this.emitHud();
      }
    } else {
      this.medusae.tickVisual(dt);
      if (this.stunT > 0) this.stunT = Math.max(0, this.stunT - dt);
    }
    if (this.vortexT > 0) this.vortexT = Math.max(0, this.vortexT - dt);
    if (this.clockT > 0) this.clockT = Math.max(0, this.clockT - dt);

    if (p && !p.dead && !p.eatenBy) {
      this.orbTimer -= dt;
      if (this.orbTimer <= 0) {
        this.orbTimer = 9 + Math.random() * 5;
        if (this.orbs.length < 5) this.spawnOrb(undefined, true);
      }
      this.balloonTimer -= dt;
      if (this.balloonTimer <= 0) {
        this.balloonTimer = 8 + Math.random() * 5;
        if (this.balloons.length < 6) {
          this.spawnBalloon(undefined, this.camTop < 420);
        }
      }
      this.goldenTimer -= dt;
      if (this.goldenTimer <= 0) {
        this.goldenTimer = 42 + Math.random() * 14;
        this.spawnSchool(false, true, p.y);
        sfx.bonus();
        this.onEvent?.({
          type: "bonus",
          title: this.lang === "id" ? "GEROMBOLAN EMAS!" : "GOLDEN SCHOOL!",
          text: this.lang === "id" ? "Kejar ikan sarden emas di dekatmu untuk 2× Koin!" : "Chase the golden sardines nearby for 2× Coins!",
        });
      }
    }

    // Floating sky balloons carrying pocket stopwatches & bonus skill charms
    for (const b of this.balloons) {
      b.t += dt;
      b.x += b.vx * dt;
      if (b.x < 75) {
        b.x = 75;
        b.vx = Math.abs(b.vx);
      } else if (b.x > WORLD_W - 75) {
        b.x = WORLD_W - 75;
        b.vx = -Math.abs(b.vx);
      }
      b.y = b.baseY + Math.sin(this.t * 1.9 + b.ph) * 6.5;
      if (Math.random() < dt * 2.4 && Math.abs(b.x - this.cam.x) < this.vw && this.camTop < 180) {
        const itPos = getBalloonDanglingItemPos(b, this.t);
        const gcol =
          b.kind === "stopwatch"
            ? "#fde047"
            : b.kind === "turbo"
              ? "#67e8f9"
              : b.kind === "vortex"
                ? "#fdba74"
                : b.kind === "shield"
                  ? "#6ee7b7"
                  : "#f9a8d4";
        this.particles.push({
          x: itPos.x + (Math.random() - 0.5) * 14,
          y: itPos.y + (Math.random() - 0.5) * 14,
          vx: 0,
          vy: -12,
          life: 0.45,
          max: 0.45,
          type: "glint",
          color: gcol,
          size: 1.15,
        });
      }
      if (p && !p.dead && !p.eatenBy && p.y < 14) {
        const mx = p.mouthX();
        const my = p.mouthY();
        const itPos = getBalloonDanglingItemPos(b, this.t);
        const dItem = Math.min(Math.hypot(itPos.x - mx, itPos.y - my), Math.hypot(itPos.x - p.x, itPos.y - p.y));
        const dBalloon = Math.min(Math.hypot(b.x - mx, b.y - my), Math.hypot(b.x - p.x, b.y - p.y));
        if (dItem < p.r * 1.18 + 16 || dBalloon < p.r * 1.05 + 17) {
          b.t = 999;
          sfx.powerup();
          sfx.bonus();
          p.sqv += 7;
          const popX = dItem <= dBalloon ? itPos.x : b.x;
          const popY = dItem <= dBalloon ? itPos.y : b.y;
          const isId = this.lang === "id";
          if (b.kind === "stopwatch") {
            this.clockT = 10;
            if (this.shieldT > 0) this.shieldT += 3.5;
            if (this.turboT > 0) this.turboT += 3.5;
            if (this.vortexT > 0) this.vortexT += 3.5;
            this.arcadeScore += 500;
            for (let i = 0; i < 5; i++) this.addFlyCoin(popX, popY, 1, i * 0.04, p.face);
            this.texts.push({ x: popX, y: popY - 10, text: isId ? "JAM WAKTU! +500" : "TIME STOP! +500", color: "#fde047", life: 1.4, max: 1.4, size: 11 });
            this.spawnSparks(popX, popY, "#ff5c7a", 18);
            this.spawnSparks(popX, popY, "#fde047", 14);
            this.spawnRing(popX, popY, "#fef08a", 22);
            this.onEvent?.({
              type: "bonus",
              title: isId ? "JAM WAKTU BALON!" : "BALLOON TIME STOP!",
              text: isId
                ? "Predator melambat, kombo lebih awet & semua skill aktif bertambah selama 10 detik!"
                : "Predators slow down, combos last longer & all active skills extend for 10s!",
            });
          } else if (b.kind === "turbo") {
            this.turboT = Math.max(this.turboT, 9);
            p.boost = 1;
            p.boostExhausted = false;
            this.arcadeScore += 300;
            for (let i = 0; i < 3; i++) this.addFlyCoin(popX, popY, 1, i * 0.04, p.face);
            this.texts.push({ x: popX, y: popY - 10, text: isId ? "BALON TURBO!" : "TURBO BALLOON!", color: "#67e8f9", life: 1.3, max: 1.3, size: 11 });
            this.spawnSparks(popX, popY, "#67e8f9", 20);
            this.spawnRing(popX, popY, "#a5f3fc", 20);
            this.onEvent?.({
              type: "bonus",
              title: isId ? "BALON SIRIP TURBO!" : "BALLOON TURBO FINS!",
              text: isId ? "Kecepatan +35% & Boost tak terbatas selama 9 detik!" : "+35% Speed & unlimited Boost for 9s!",
            });
          } else if (b.kind === "vortex") {
            this.vortexT = Math.max(this.vortexT, 9);
            p.energy = 1;
            p.exhausted = false;
            this.arcadeScore += 300;
            for (let i = 0; i < 3; i++) this.addFlyCoin(popX, popY, 1, i * 0.04, p.face);
            this.texts.push({ x: popX, y: popY - 10, text: isId ? "BALON PUSARAN!" : "VORTEX BALLOON!", color: "#fdba74", life: 1.3, max: 1.3, size: 11 });
            this.spawnSparks(popX, popY, "#fdba74", 20);
            this.spawnRing(popX, popY, "#fed7aa", 20);
            this.onEvent?.({
              type: "bonus",
              title: isId ? "BALON PUSARAN MEGA!" : "BALLOON MEGA VORTEX!",
              text: isId ? "Jangkauan hisap 55% lebih luas selama 9 detik!" : "55% wider suction range for 9s!",
            });
          } else if (b.kind === "shield") {
            this.shieldT = Math.max(this.shieldT, 15);
            this.arcadeScore += 300;
            for (let i = 0; i < 3; i++) this.addFlyCoin(popX, popY, 1, i * 0.04, p.face);
            this.texts.push({ x: popX, y: popY - 10, text: isId ? "BALON PERISAI!" : "SHIELD BALLOON!", color: "#6ee7b7", life: 1.3, max: 1.3, size: 11 });
            this.spawnSparks(popX, popY, "#6ee7b7", 20);
            this.spawnRing(popX, popY, "#a7f3d0", 20);
            this.onEvent?.({
              type: "bonus",
              title: isId ? "BALON PERISAI!" : "BALLOON SHIELD!",
              text: isId ? "Melindungi dari 1 serangan predator selama 15 detik!" : "Protects from 1 predator attack for 15s!",
            });
          } else {
            this.arcadeScore += 600;
            for (let i = 0; i < 10; i++) this.addFlyCoin(popX, popY, i < 2 ? 2 : 1, i * 0.035, p.face);
            this.texts.push({
              x: popX,
              y: popY - 10,
              text: isId ? "BALON HARTA! +12 Koin" : "TREASURE BALLOON! +12 Coins",
              color: "#f9a8d4",
              life: 1.35,
              max: 1.35,
              size: 11,
            });
            this.spawnSparks(popX, popY, "#fde047", 22);
            this.spawnRing(popX, popY, "#fbcfe8", 22);
            this.onEvent?.({
              type: "bonus",
              title: isId ? "BALON MUTIARA!" : "PEARL BALLOON!",
              text: isId ? "Bonus +600 Skor & Hujan Koin Emas!" : "Bonus +600 Score & Golden Coin Shower!",
            });
          }
          this.emitHud();
        }
      }
    }
    {
      let bw = 0;
      for (let i = 0; i < this.balloons.length; i++) {
        const b = this.balloons[i];
        if (b.t < 75) this.balloons[bw++] = b;
      }
      this.balloons.length = bw;
    }

    for (const o of this.orbs) {
      o.t += dt;
      o.x = clamp(o.x + o.vx * dt, 40, WORLD_W - 40);
      o.y = clamp(o.y + (o.vy + Math.sin(this.t * 2.2 + o.ph) * 8) * dt, 50, floorY(o.x) - 18);
      if (Math.random() < dt * 2.2 && Math.abs(o.x - this.cam.x) < this.vw) {
        const gcol = o.kind === "pearl" ? "#fff3a1" : o.kind === "turbo" ? "#67e8f9" : o.kind === "vortex" ? "#fdba74" : "#6ee7b7";
        this.particles.push({ x: o.x + (Math.random() - 0.5) * 14, y: o.y + (Math.random() - 0.5) * 14, vx: 0, vy: -8, life: 0.45, max: 0.45, type: "glint", color: gcol, size: 1 });
      }
      if (p && !p.dead && !p.eatenBy) {
        const mx = p.mouthX(),
          my = p.mouthY();
        const d = Math.hypot(o.x - mx, o.y - my);
        if (d < p.r * 1.15 + 14) {
          o.t = 999;
          sfx.powerup();
          p.sqv += 6;
          const isId = this.lang === "id";
          if (o.kind === "pearl") {
            for (let i = 0; i < 8; i++) this.addFlyCoin(o.x, o.y, i < 2 ? 2 : 1, i * 0.04, p.face);
            this.arcadeScore += 400;
            if (p.combo > 0) p.comboT = Math.min(2.6, p.comboT + 1.5);
            this.texts.push({ x: o.x, y: o.y - 10, text: isId ? "MUTIARA! +10 Koin" : "PEARL! +10 Coins", color: "#fff3a1", life: 1.25, max: 1.25, size: 10 });
            this.spawnSparks(o.x, o.y, "#ffe14a", 18);
            this.spawnRing(o.x, o.y, "#fff7c2", 18);
          } else if (o.kind === "turbo") {
            this.turboT = 8;
            p.boost = 1;
            p.boostExhausted = false;
            this.texts.push({ x: o.x, y: o.y - 10, text: isId ? "SIRIP TURBO!" : "TURBO FINS!", color: "#67e8f9", life: 1.2, max: 1.2, size: 10 });
            this.spawnSparks(o.x, o.y, "#67e8f9", 16);
            this.spawnRing(o.x, o.y, "#a5f3fc", 16);
            this.onEvent?.({
              type: "bonus",
              title: isId ? "SIRIP TURBO!" : "TURBO FINS!",
              text: isId ? "Kecepatan +35% & Boost tak terbatas selama 8 detik!" : "+35% Speed & unlimited Boost for 8s!",
            });
          } else if (o.kind === "vortex") {
            this.vortexT = 8;
            p.energy = 1;
            p.exhausted = false;
            this.texts.push({ x: o.x, y: o.y - 10, text: isId ? "PUSARAN MEGA!" : "MEGA VORTEX!", color: "#fdba74", life: 1.2, max: 1.2, size: 10 });
            this.spawnSparks(o.x, o.y, "#fdba74", 16);
            this.spawnRing(o.x, o.y, "#fed7aa", 16);
            this.onEvent?.({
              type: "bonus",
              title: isId ? "PUSARAN MEGA!" : "MEGA VORTEX!",
              text: isId ? "Jangkauan hisap 55% lebih luas selama 8 detik!" : "55% wider suction range for 8s!",
            });
          } else {
            this.shieldT = 14;
            this.texts.push({ x: o.x, y: o.y - 10, text: isId ? "PERISAI GELEMBUNG!" : "BUBBLE SHIELD!", color: "#6ee7b7", life: 1.2, max: 1.2, size: 10 });
            this.spawnSparks(o.x, o.y, "#6ee7b7", 16);
            this.spawnRing(o.x, o.y, "#a7f3d0", 16);
            this.onEvent?.({
              type: "bonus",
              title: isId ? "PERISAI AKTIF!" : "SHIELD ACTIVE!",
              text: isId ? "Melindungi dari 1 serangan predator selama 14 detik!" : "Protects from 1 predator attack for 14s!",
            });
          }
        }
      }
    }
    {
      let ow = 0;
      for (let i = 0; i < this.orbs.length; i++) {
        const o = this.orbs[i];
        if (o.t < 42) this.orbs[ow++] = o;
      }
      this.orbs.length = ow;
    }

    // Naval Sea Mine bombs (Feeding Frenzy style): bobbing in current, lethal on single contact with player!
    if (this.blastFlash > 0) this.blastFlash = Math.max(0, this.blastFlash - dt * 2.2);
    for (let i = this.mineTimers.length - 1; i >= 0; i--) {
      this.mineTimers[i] -= dt;
      if (this.mineTimers[i] <= 0) {
        this.mineTimers.splice(i, 1);
        this.spawnMine(false);
      }
    }
    for (let i = this.mines.length - 1; i >= 0; i--) {
      const m = this.mines[i];
      m.y = m.baseY + Math.sin(this.t * 1.45 + m.ph) * 8.5;
      m.rot += m.rotSp * dt;
      if (p && !p.dead && !p.eatenBy && this.t - this.startTime > 0.5) {
        const d = Math.hypot(p.x - m.x, p.y - m.y);
        if (d < p.r * 0.78 + m.r * 0.84) {
          // Single-hit lethal detonation!
          this.mines.splice(i, 1);
          this.mineTimers.push(7 + Math.random() * 5);
          this.shieldT = 0;
          this.turboT = 0;
          this.vortexT = 0;
          this.clockT = 0;
          p.dead = true;
          p.vx = 0;
          p.vy = 0;
          sfx.setSuck(false);
          sfx.explode();
          this.shake = 18;
          this.blastFlash = 1.0;
          this.freeze = 0.06;
          this.spawnExplosion(m.x, m.y, Math.max(30, p.r * 2.2 + 16));
          const isId = this.lang === "id";
          this.texts.push({ x: m.x, y: m.y - 18, text: isId ? "DUAR!!" : "BOOM!!", color: "#ff5a36", life: 1.5, max: 1.5, size: 15 });
          this.killerName = isId ? "Bom Ranjau Laut" : "Naval Sea Mine";
          this.killerSpId = "bomb";
          this.deathTimer = 1.75;
          this.spectate = null;
          this.emitHud();
          break;
        }
      }
    }

    this.updateSunfish(dt, this.menuActive ? null : p);
    this.decor3d.update(dt, this.t, this.ocean);

    const hx = this.camLeft + (this.coinHudPos.x / Math.max(1, window.innerWidth)) * this.vw;
    const hy = this.camTop + (this.coinHudPos.y / Math.max(1, window.innerHeight)) * this.vh;
    for (const c of this.flyCoins) {
      c.t += dt;
      if (c.t < 0) continue; // staggered: this coin has not popped out yet
      if (c.t < COIN_POP) {
        // 1) pop out of the mouth in a little fountain arc
        c.vy += 260 * dt;
        c.vx *= 1 - dt * 3.2;
        c.x += c.vx * dt;
        c.y += c.vy * dt;
        c.sx = c.x;
        c.sy = c.y;
      } else {
        // 2) swoop to the coin counter along a curved, accelerating path, shedding gold glints
        const u = Math.min(1, (c.t - COIN_POP) / COIN_FLY),
          e = u * u * (1.6 - 0.6 * u);
        const ex = hx - c.sx,
          ey = hy - c.sy,
          L = Math.hypot(ex, ey) || 1;
        const arc = Math.sin(e * Math.PI) * c.bend;
        c.x = c.sx + ex * e + (-ey / L) * arc;
        c.y = c.sy + ey * e + (ex / L) * arc;
        c.trail -= dt;
        if (c.trail <= 0) {
          c.trail = 0.03;
          this.particles.push({ x: c.x, y: c.y, vx: (Math.random() - 0.5) * 10, vy: 6 + Math.random() * 8, life: 0.3, max: 0.3, type: "glint", color: "#ffe14a", size: 1 });
        }
        if (u >= 1) {
          c.t = 999;
          this.sessionCoins += c.value;
          if (this.t - this.lastCoinT > 0.7) this.coinChain = 0;
          this.lastCoinT = this.t;
          sfx.coin(this.coinChain++);
          this.onEvent?.({ type: "coinbump" });
        }
      }
    }
    {
      let fw = 0;
      for (let i = 0; i < this.flyCoins.length; i++) {
        const c = this.flyCoins[i];
        if (c.t < 999) this.flyCoins[fw++] = c;
      }
      this.flyCoins.length = fw;
    }

    if (Math.random() < dt * (attract ? 4.5 : 11)) {
      const v = this.ocean.vents[Math.floor(Math.random() * this.ocean.vents.length)];
      if (v && Math.abs(v.x - this.cam.x) < this.vw) {
        const count = 1 + (Math.random() < 0.45 ? 1 : 0);
        for (let b = 0; b < count; b++) {
          const bb = this.bubble(v.x + (Math.random() - 0.5) * 11, v.y - Math.random() * 4, 1.1 + Math.random() * 2.5);
          bb.vy -= 18 + Math.random() * 16;
          this.particles.push(bb);
        }
        if (Math.random() < 0.28) {
          this.particles.push({
            x: v.x + (Math.random() - 0.5) * 10,
            y: v.y - 2,
            vx: (Math.random() - 0.5) * 10,
            vy: -26 - Math.random() * 14,
            life: 0.55,
            max: 0.55,
            type: "glint",
            color: Math.random() < 0.35 ? "#ffd480" : "#aef4ff",
            size: 1.1,
          });
        }
      }
    }

    for (const pt of this.particles) {
      pt.life -= dt;
      if (pt.type === "bubble") {
        // bigger bubbles rise faster and wobble more; small ones zig-zag quickly
        const term = 22 + pt.size * 16;
        pt.vy += (-term - pt.vy) * Math.min(1, dt * 1.6);
        const age = pt.max - pt.life;
        pt.vx = Math.sin(age * (7.5 - Math.min(4, pt.size)) + pt.size * 7) * (3 + pt.size * 3) + Math.sin(age * 1.3 + pt.size) * 2;
        pt.size += dt * 0.08; // expands slightly as pressure drops
        if (pt.y < 6) {
          // pops at the surface: tiny ring of droplets
          pt.life = 0;
          if (Math.random() < 0.5) this.particles.push({ x: pt.x, y: 4, vx: 0, vy: 0, life: 0.3, max: 0.3, type: "ring", color: "#e8feff", size: pt.size * 1.6 });
        }
      } else if (pt.type === "bit") {
        pt.vy += 45 * dt;
        pt.vx *= 1 - dt * 2.2;
        pt.vy *= 1 - dt * 1.2;
      } else if (pt.type === "splash") {
        pt.vy += 490 * dt;
        pt.vx *= Math.exp(-0.9 * dt);
        if (pt.y > SURFACE_Y + 6 && pt.vy > 0) pt.life = Math.min(pt.life, 0.03);
      } else if (pt.type === "suck" && pt.target) {
        const tx = pt.target.mouthX(),
          ty = pt.target.mouthY();
        const dx = tx - pt.x,
          dy = ty - pt.y;
        const d = Math.hypot(dx, dy) || 1;
        // Soft curved inward spiral converging directly into mouth center
        const tangX = -dy / d,
          tangY = dx / d;
        const s = (145 + (pt.max - pt.life) * 290) * 1.4;
        const swirl = 26 * Math.sin(pt.size * 5) * Math.min(1, d / 34);
        pt.vx = (dx / d) * s + tangX * swirl;
        pt.vy = (dy / d) * s + tangY * swirl;
        if (d < 4 || pt.target.suckVis < 0.05) pt.life = 0;
      } else if (pt.type === "spark" || pt.type === "star") {
        pt.vx *= 1 - dt * 4;
        pt.vy *= 1 - dt * 4;
      } else if (pt.type === "blast") {
        pt.vx *= 1 - dt * 4.5;
        pt.vy *= 1 - dt * 4.5;
      } else if (pt.type === "smoke") {
        pt.vx *= 1 - dt * 2.4;
        pt.vy = pt.vy * (1 - dt * 2.2) - 18 * dt;
      }
      pt.x += pt.vx * dt;
      pt.y += pt.vy * dt;
    }
    {
      let w = 0;
      for (let i = 0; i < this.particles.length; i++) {
        const pt = this.particles[i];
        if (pt.life > 0) this.particles[w++] = pt;
      }
      this.particles.length = w;
      if (w > 550) this.particles.splice(0, w - 550);
    }
    if (this.surfaceWaves.length > 0) {
      let wv = 0;
      for (let i = 0; i < this.surfaceWaves.length; i++) {
        const sw = this.surfaceWaves[i];
        sw.age += dt;
        if (sw.age < sw.maxAge) this.surfaceWaves[wv++] = sw;
      }
      this.surfaceWaves.length = wv;
    }
    {
      let w = 0;
      for (let i = 0; i < this.texts.length; i++) {
        const tx = this.texts[i];
        tx.life -= dt;
        tx.y -= dt * 18;
        if (tx.life > 0) this.texts[w++] = tx;
      }
      this.texts.length = w;
    }

    // one juicy summary pop when a slurp chain ends
    this.chainPop = Math.max(0, this.chainPop - dt * 5);
    if (this.streamN > 0) {
      this.streamT -= dt;
      if (this.streamT <= 0) {
        if (p && !p.dead) {
          const isId = this.lang === "id";
          this.texts.push({ x: p.x, y: p.y - p.r * 1.15 - 44, text: "+" + this.streamPts, color: "#fff3a1", life: 1.1, max: 1.1, size: 9 + Math.min(6, this.streamN * 0.35) });
          this.texts.push({
            x: p.x,
            y: p.y - p.r * 1.15 - 33,
            text: `${this.streamN} ${isId ? "ikan" : "fish"}  +${this.streamCoins} ${isId ? "koin" : "coins"}`,
            color: "#ffe14a",
            life: 1.1,
            max: 1.1,
            size: 7,
          });
        }
        this.streamPts = this.streamCoins = this.streamN = 0;
      }
    }

    // Camera smooth-follow only when spectating or during death animation (live player camera is driven above!)
    if (!p || p.dead || p.eatenBy) {
      const focus = p && !p.dead ? p.eatenBy || p : this.deathTimer >= 0 ? null : this.spectate;
      if (focus) {
        const lead = focus.vx * 0.22;
        const targetCamY = attract ? clamp(focus.y + focus.vy * 0.14, 195, 420) : focus.y + focus.vy * 0.14;
        this.cam.x += (focus.x + lead - this.cam.x) * Math.min(1, dt * (attract ? 2.6 : 4.5));
        this.cam.y += (targetCamY - this.cam.y) * Math.min(1, dt * (attract ? 2.6 : 4.5));
      }
    }
    this.shake *= Math.exp(-9 * dt);
    if (this.shake < 0.05) this.shake = 0;

    if (this.deathTimer >= 0) {
      this.deathTimer -= dt;
      if (this.deathTimer < 0) {
        this.deathTimer = -1;
        for (const c of this.flyCoins) this.sessionCoins += c.value;
        this.flyCoins = [];
        this.onDeath?.({
          score: this.arcadeScore,
          coins: this.sessionCoins,
          killer: this.killerName,
          killerSpId: this.killerSpId,
          playerSkinId: this.playerSkinId,
          playerMode3D: this.playerMode3D,
          playerName: this.player?.name || (this.lang === "id" ? "Kamu" : "You"),
          maxMass: Math.round(this.maxMass),
          eaten: this.eatenCount,
          botsEaten: this.botsEatenCount,
          maxCombo: this.maxCombo,
          maxDepth: depthMeters(this.maxDepthY),
          deepestZone: ZONE_LABELS_I18N[this.lang][zoneAt(this.maxDepthY)],
          stageNum: Math.max(1, this.level - 1),
          bestRank: Math.max(1, this.bestRank),
          schoolSweeps: this.schoolSweeps,
          time: Math.max(1, Math.round(this.t - this.startTime)),
          reachedRank1: this.reachedRank1,
          peakLevelTime: this.peakLevelTime,
        });
      }
    }

    if (p && !p.dead) {
      this.maxMass = Math.max(this.maxMass, p.mass);
      this.maxDepthY = Math.max(this.maxDepthY, p.y);
      const lv = this.calcLevel(p.r);
      if (lv > this.level) {
        this.level = lv;
        const sp = SPECIES[Math.min(lv - 1, SPECIES.length - 1)];
        const spName = getLocalizedSpeciesName(sp.id, sp.name, this.lang);
        this.onEvent?.({
          type: "levelup",
          text: this.lang === "id" ? `Ukuran naik! Bisa makan ${spName}!` : `Level up! You can now eat ${spName}!`,
        });
        if (lv >= SPECIES.length) {
          sfx.stageClear(0.8);
          if (this.peakLevelTime === null) {
            this.peakLevelTime = Math.max(1, Math.round(this.t - this.startTime));
            this.onEvent?.({ type: "peaklevel", timeSec: this.peakLevelTime });
          }
        } else {
          sfx.levelUp();
        }
        this.spawnRing(p.x, p.y, "#fff6a0", p.r * 2.1);
        this.spawnSparks(p.x, p.y, "#ffffff", 18);
      }
    }

    const inPlay = !!(p && !p.dead && !p.eatenBy && this.deathTimer < 0);
    const ambY = p && !p.dead ? p.y : this.cam.y;
    if (inPlay) {
      const z = zoneAt(ambY);
      if (this.prevZone >= 0 && z !== this.prevZone) {
        sfx.onZoneChange(z > this.prevZone);
      }
      this.prevZone = z;
      if (this.prevPlayerY >= 34 && ambY < 34 && !p?.inAir) {
        sfx.surfaceSplash(0.32);
      }
      this.prevPlayerY = ambY;
    }
    if (!attract) {
      let ventProx = 0;
      for (let i = 0; i < this.ocean.vents.length; i++) {
        const v = this.ocean.vents[i];
        const d = Math.hypot(v.x - this.cam.x, v.y - this.cam.y);
        if (d < 260) {
          const prox = 1 - d / 260;
          if (prox > ventProx) ventProx = prox;
        }
      }
      sfx.updateAmbience({
        inPlay,
        playerY: ambY,
        camTop: this.camTop,
        sucking: Boolean(inPlay && p?.sucking),
        boosting: Boolean(inPlay && p?.boosting),
        ventProx,
      });

      this.hudTimer -= dt;
      if (this.hudTimer <= 0) {
        this.hudTimer = 0.12;
        this.emitHud();
      }
      this.miniTimer -= dt;
      if (this.miniTimer <= 0) {
        this.miniTimer = 0.3;
        this.drawMinimap();
      }
    }
  }

  getCaveAt(x: number, y: number, r: number, prevCaveId: number | null = null): ReefCave | null {
    for (const form of this.ocean.formations) {
      const c = form.cave;
      if (!c) continue;
      if (r > c.maxR && prevCaveId !== c.id) continue;
      if (x < form.x || x > form.x + form.w || y < form.y || y > form.y + form.h) continue;
      const solidD = this.ocean.sampleRockSDF(form, x, y, false).dist;
      const caveD = this.ocean.sampleRockSDF(form, x, y, true).dist;
      if (solidD < 3 && caveD >= -1) return c;
    }
    return null;
  }

  /** Fish tucked inside a reef cave are shielded & hidden from outside or larger predators. */
  isProtectedInCave(predator: Fish, prey: Fish): boolean {
    const c = prey.hiddenCave;
    if (!c) return false;
    if (predator.r > c.maxR) return true;
    if (prey.kind === "player") return true;
    return predator.hiddenCave !== c;
  }

  /** Fair size check: player<->bot and bot<->bot duels require a clear size difference (BOT_EAT_RATIO = 0.74) */
  canEat(e: Fish, o: Fish): boolean {
    if (e.caught || o.caught) return false;
    const ratio = e.kind !== "npc" && o.kind !== "npc" ? BOT_EAT_RATIO : EAT_RATIO;
    return o.r < e.r * ratio;
  }

  rebuildGrid(attract = false, nearX = 0, nearY = 0) {
    const g = this.grid;
    for (let i = 0; i < g.length; i++) g[i].length = 0;
    for (const f of this.fish) {
      if (f.dead || f.eatenBy) continue;
      if (attract && (Math.abs(f.x - this.cam.x) > nearX || Math.abs(f.y - this.cam.y) > nearY)) continue;
      const cx = Math.max(0, Math.min(GRID_COLS - 1, (f.x / GRID_CELL) | 0));
      const cy = Math.max(0, Math.min(GRID_ROWS - 1, (f.y / GRID_CELL) | 0));
      g[cy * GRID_COLS + cx].push(f);
    }
  }

  queryNear(x: number, y: number, rad: number): Fish[] {
    const out = this.nearBuf;
    out.length = 0;
    const x0 = Math.max(0, ((x - rad) / GRID_CELL) | 0);
    const x1 = Math.min(GRID_COLS - 1, ((x + rad) / GRID_CELL) | 0);
    const y0 = Math.max(0, ((y - rad) / GRID_CELL) | 0);
    const y1 = Math.min(GRID_ROWS - 1, ((y + rad) / GRID_CELL) | 0);
    const g = this.grid;
    for (let cy = y0; cy <= y1; cy++) {
      const row = cy * GRID_COLS;
      for (let cx = x0; cx <= x1; cx++) {
        const cell = g[row + cx];
        for (let k = 0; k < cell.length; k++) out.push(cell[k]);
      }
    }
    return out;
  }

  maxSpeed(f: Fish) {
    const slowMul =
      this.clockT > 0 && f !== this.player && this.player && !this.player.dead && (this.canEat(f, this.player) || f.sp.predator)
        ? 0.58
        : 1;
    if (f.kind === "npc") return f.sp.speed * NPC_SPEED * slowMul;
    const base = f.kind === "player" ? 190 : 126;
    const turboMul = f === this.player && this.turboT > 0 ? 1.35 : 1;
    return base * Math.pow(8 / Math.max(8, f.r), 0.14) * f.speedMul * turboMul * slowMul * (f.boosting ? 1.6 : 1);
  }

  applySuckState(f: Fish, want: boolean, dt: number) {
    const freeVortex = f === this.player && this.vortexT > 0;
    if (freeVortex) {
      f.energy = 1;
      f.exhausted = false;
    }
    if (want && !f.exhausted && f.energy > 0) {
      f.sucking = true;
      if (!freeVortex) f.energy -= (dt * 0.42) / (0.85 + f.suckMul * 0.15);
      if (f.energy <= 0) {
        f.energy = 0;
        f.exhausted = true;
        f.sucking = false;
      }
    } else {
      f.sucking = false;
      f.energy = Math.min(1, f.energy + dt * 0.28);
      if (f.exhausted && f.energy > 0.3) f.exhausted = false;
    }
  }

  suckRange(f: Fish) {
    const megaMul = f === this.player && this.vortexT > 0 ? 1.55 : 1;
    return (f.r * 3.2 + 28) * f.suckMul * 1.4 * megaMul;
  }

  doSuck(f: Fish, dt: number) {
    const mx = f.mouthX(),
      my = f.mouthY();
    const dirx = f.face * Math.cos(f.tilt),
      diry = Math.sin(f.tilt);
    const range = this.suckRange(f);
    const near = this.queryNear(mx, my, range + 54);
    for (const o of near) {
      if (o === f || o.dead || o.eatenBy || o.invuln > 0) continue;
      if (!this.canEat(f, o) || this.isProtectedInCave(f, o)) continue;
      const dx = o.x - mx,
        dy = o.y - my;
      if (Math.abs(dx) > range + o.r || Math.abs(dy) > range + o.r) continue;
      const d = Math.hypot(dx, dy);
      if (d > range + o.r || d < 0.1) continue;
      const cos = (dx * dirx + dy * diry) / d;
      const smallPrey = o.fry || o.r < f.r * 0.48;
      // Already-captured or close small fish stay locked inside the intake flow instead of slipping out
      const minCos = o.sucked > 0 || d < f.r * 1.5 + 16 ? -0.08 : smallPrey ? 0.12 : 0.26;
      if (cos < minCos) continue;

      const rx = -dx / d,
        ry = -dy / d;
      // Uniform intake floor across the whole cone so outer shoal members pull in just as evenly as center fish
      const distFactor = Math.max(0.45, 1.14 - (d / (range + o.r)) * 0.68);
      const sizeFactor = clamp((f.r / o.r) * 0.45, 0.42, 1.5);
      const strength = 370 * 1.4 * f.suckMul * distFactor * sizeFactor;

      // Centering force guides off-axis small fish smoothly onto the mouth streamline
      const cross = dx * diry - dy * dirx;
      const tx = -ry,
        ty = rx;
      const centerPull = -Math.sign(cross) * Math.min(1, Math.abs(cross) / Math.max(12, range * 0.35)) * strength * 0.36;
      // Subtle fading spiral only at outer distance so fish never orbit past the lips
      const swirlAmp = (o.id & 1 ? 1 : -1) * strength * 0.28 * clamp((d - f.r * 0.8) / (range * 0.55), 0, 1);

      const pull = strength * 3.15 * dt;
      o.vx += rx * pull + tx * (centerPull + swirlAmp) * dt;
      o.vy += ry * pull + ty * (centerPull + swirlAmp) * dt;

      // Dampen lateral slip and partially match eater swim velocity so moving while sucking pulls shoals evenly
      const vDotR = o.vx * rx + o.vy * ry;
      const latX = o.vx - rx * vDotR;
      const latY = o.vy - ry * vDotR;
      const latDamp = Math.exp(-5.5 * dt);
      o.vx = rx * vDotR + latX * latDamp + (f.vx * 0.28 - o.vx * 0.08) * Math.min(1, dt * 4);
      o.vy = ry * vDotR + latY * latDamp + (f.vy * 0.28 - o.vy * 0.08) * Math.min(1, dt * 4);

      o.sucked = 0.24;
      if (o.kind === "npc") {
        o.face = dx >= 0 ? 1 : -1;
        const targetTilt = clamp(Math.atan2(ry, Math.abs(rx) + 0.35) * 0.5, -0.45, 0.45);
        o.tilt += (targetTilt - o.tilt) * Math.min(1, dt * 7);
      }
      f.wantOpen = true;
    }
    if (f.kind === "player") {
      for (const c of this.worldCoins) {
        const dx = c.x - mx,
          dy = c.y - my;
        const d = Math.hypot(dx, dy);
        if (d < range * 1.25 && (dx * dirx + dy * diry) / (d || 1) > 0.14) {
          c.settled = false;
          c.vx = (-dx / d) * (165 * 1.45);
          c.vy = (-dy / d) * (165 * 1.45);
        }
      }
    }
    const onScreen = Math.abs(mx - this.cam.x) < this.vw && Math.abs(my - this.cam.y) < this.vh;
    if (onScreen && Math.random() < 0.65) {
      const a = Math.atan2(diry, dirx) + (Math.random() - 0.5) * 1.05;
      const dd = range * (0.34 + Math.random() * 0.58);
      this.particles.push({
        x: mx + Math.cos(a) * dd,
        y: my + Math.sin(a) * dd,
        vx: 0,
        vy: 0,
        life: 0.58,
        max: 0.58,
        type: "suck",
        color: Math.random() < 0.35 ? "#ffffff" : "#bae6fd",
        size: 0.65 + Math.random() * 0.65,
        target: f,
      });
    }
  }

  botAI(f: Fish, dt: number) {
    if (f.inAir || f.y < SURFACE_Y) return;
    if (f.ai.timer <= 0) {
      f.ai.timer = 0.2 + Math.random() * 0.15;
      let threat: Fish | null = null,
        td = 1e9;
      let best: Fish | null = null,
        bv = 0;
      const near = this.queryNear(f.x, f.y, 300);
      for (const o of near) {
        if (o === f || o.dead || o.eatenBy) continue;
        const dx = o.x - f.x,
          dy = o.y - f.y;
        if (Math.abs(dx) > 300 || Math.abs(dy) > 300) continue;
        const d2 = dx * dx + dy * dy;
        if (d2 > 90000) continue;
        const d = Math.sqrt(d2);
        if (this.canEat(o, f) && (o.kind !== "npc" || o.sp.predator)) {
          const thr = 80 + o.r * 2.2;
          if (d < thr && d < td) {
            td = d;
            threat = o;
          }
        } else if (this.canEat(f, o) && !o.sp.poisonous && !this.isProtectedInCave(f, o) && o.invuln <= 0 && d < 260) {
          const pw = o.kind === "player" ? (this.t - this.startTime < 12 ? 0.25 : o.mass < 160 ? 0.6 : 1.1) : 1;
          const v = (o.mass * pw) / (d + 40);
          if (v > bv) {
            bv = v;
            best = o;
          }
        }
      }
      f.ai.flee = !!threat;
      if (threat) {
        const dx = f.x - threat.x,
          dy = f.y - threat.y;
        const d = Math.hypot(dx, dy) || 1;
        f.ai.tx = f.x + (dx / d) * 200;
        f.ai.ty = f.y + (dy / d) * 200;
        f.ai.target = null;
      } else if (best) {
        f.ai.target = best;
      } else {
        f.ai.target = null;
        if (Math.hypot(f.ai.tx - f.x, f.ai.ty - f.y) < 30 || Math.random() < 0.05) {
          const p = this.randomSpawnPos(f.r, false);
          f.ai.tx = clamp(f.x + (Math.random() - 0.5) * 600, 40, WORLD_W - 40);
          f.ai.ty = p.y;
        }
      }
    }
    let tx = f.ai.tx,
      ty = f.ai.ty;
    const tgt = f.ai.target;
    if (tgt && !tgt.dead && !tgt.eatenBy && !this.isProtectedInCave(f, tgt)) {
      tx = tgt.x + tgt.vx * 0.3;
      ty = tgt.y + tgt.vy * 0.3;
    } else if (tgt && this.isProtectedInCave(f, tgt)) {
      f.ai.target = null;
    }
    const dx = tx - f.x,
      dy = ty - f.y;
    const d = Math.hypot(dx, dy) || 1;
    let wantBoost = false;
    if (f.ai.flee && f.boost > 0.25) wantBoost = true;
    if (tgt && !tgt.dead && d < 90 && d > this.suckRange(f) * 0.5 && f.boost > 0.5 && Math.random() < 0.6) wantBoost = true;
    this.applyBoost(f, wantBoost, dt);
    // Gentle mine avoidance so bots steer smoothly around sea mines
    let avx = 0,
      avy = 0;
    for (const m of this.mines) {
      const mdx = f.x - m.x,
        mdy = f.y - m.y;
      const safe = m.r + f.r + 48;
      if (Math.abs(mdx) > safe || Math.abs(mdy) > safe) continue;
      const d = Math.hypot(mdx, mdy) || 1;
      if (d < safe) {
        const push = (1 - d / safe) * 1.45;
        avx += (mdx / d) * push;
        avy += (mdy / d) * push;
      }
    }
    const ms = this.maxSpeed(f) * (f.ai.flee || f.boosting ? 1 : 0.85);
    const steerX = dx / d + avx,
      steerY = dy / d + avy;
    const steerL = Math.hypot(steerX, steerY) || 1;
    // softer steering: rivals turn in arcs instead of snapping onto a new heading
    f.vx += ((steerX / steerL) * ms - f.vx) * Math.min(1, dt * 3.4);
    f.vy += ((steerY / steerL) * ms - f.vy) * Math.min(1, dt * 3.4);
    // Occasional playful ocean jump when swimming near the surface
    if (f.y < 92 && f.airJumpCd <= 0 && !this.isInsideRock(f.x, SURFACE_Y - 12, f.r) && Math.random() < dt * 0.55) {
      f.airJumpCd = 6 + Math.random() * 10;
      const dir = Math.abs(f.vx) > 20 ? (f.vx > 0 ? 1 : -1) : f.face;
      f.vx = dir * (105 + Math.random() * 90);
      f.vy = -(225 + Math.random() * 115 + Math.min(80, f.r * 1.4));
    }
    if (tgt && !tgt.dead && !tgt.eatenBy && d < f.r * 5 + tgt.r * 2) f.wantOpen = true;
    const wantSuck = !!tgt && !tgt.dead && d < this.suckRange(f) * 0.9 && Math.sign(dx) === f.face && f.energy > 0.2;
    this.applySuckState(f, wantSuck, dt);
    if (f.mass > 3200) f.mass -= dt * 14;
  }

  npcAI(f: Fish, dt: number, predators: Fish[]) {
    if (f.inAir || f.y < SURFACE_Y) return;
    if (f.ai.timer <= 0) {
      f.ai.timer = 0.25 + Math.random() * 0.25;
      f.ai.flee = false;
      let threat: Fish | null = null,
        td = 1e9;
      for (const o of predators) {
        if (o === f || o.r * EAT_RATIO <= f.r) continue;
        const dx = o.x - f.x,
          dy = o.y - f.y;
        const thr = 50 + o.r * 1.6;
        if (Math.abs(dx) > thr || Math.abs(dy) > thr) continue;
        const d2 = dx * dx + dy * dy;
        if (d2 < thr * thr) {
          const d = Math.sqrt(d2);
          if (d < td) {
            td = d;
            threat = o;
          }
        }
      }
      if (threat && Math.random() < 0.85) {
        const dx = f.x - threat.x,
          dy = f.y - threat.y;
        const d = Math.hypot(dx, dy) || 1;
        f.ai.tx = f.x + (dx / d) * 120;
        f.ai.ty = f.y + (dy / d) * 120;
        f.ai.flee = true;
      } else if (f.sp.predator) {
        f.ai.rest -= 0.3;
        if (f.ai.chase > 0) f.ai.chase -= 0.3;
        if (f.ai.target && (f.ai.target.dead || f.ai.target.eatenBy || f.ai.chase <= 0 || this.isProtectedInCave(f, f.ai.target))) {
          f.ai.target = null;
          f.ai.rest = 2.6;
        }
        if (!f.ai.target && f.ai.rest <= 0) {
          let best: Fish | null = null,
            bd = 170;
          const near = this.queryNear(f.x, f.y, 175);
          for (const o of near) {
            if (o === f || o.dead || o.sp.poisonous || !this.canEat(f, o) || this.isProtectedInCave(f, o) || o.invuln > 0) continue;
            if (o.kind === "npc" && o.r < f.r * 0.25) continue;
            const d = Math.hypot(o.x - f.x, o.y - f.y);
            const w = o.kind === "npc" ? d * 1.5 : d;
            if (w < bd) {
              bd = w;
              best = o;
            }
          }
          if (best) {
            f.ai.target = best;
            f.ai.chase = 3.5;
          }
        }
        if (!f.ai.target && (Math.hypot(f.ai.tx - f.x, f.ai.ty - f.y) < 20 || Math.random() < 0.04)) {
          f.ai.tx = clamp(f.x + (Math.random() - 0.5) * 500, 40, WORLD_W - 40);
          f.ai.ty = clamp(f.y + (Math.random() - 0.5) * 240, 34, floorY(f.x) - 50);
        }
      } else if (Math.hypot(f.ai.tx - f.x, f.ai.ty - f.y) < 15 || Math.random() < 0.06) {
        f.ai.tx = clamp(f.x + (Math.random() - 0.5) * 260, 20, WORLD_W - 20);
        f.ai.ty = clamp(f.y + (Math.random() - 0.5) * 140, 22, floorY(f.x) - 25);
      }
    }
    if (f.sucked > 0) return;
    let tx = f.ai.tx,
      ty = f.ai.ty;
    const tgt = f.ai.target;
    let boost = f.ai.flee ? 1.3 : 0.55;
    if (tgt && !tgt.dead) {
      tx = tgt.x;
      ty = tgt.y;
      boost = 1.2;
    }
    const dx = tx - f.x,
      dy = ty - f.y;
    const d = Math.hypot(dx, dy) || 1;
    if (tgt && !tgt.dead && !tgt.eatenBy && d < f.r * 5 + tgt.r * 2) f.wantOpen = true;
    // glide: never brake to a dead stop at a waypoint, and steer in wide, soft arcs
    const ms = f.sp.speed * NPC_SPEED * boost * (d < 14 ? 0.4 + (d / 14) * 0.6 : 1);
    const steer = Math.min(1, dt * (f.ai.flee ? 3.6 : 2.3));
    f.vx += ((dx / d) * ms - f.vx) * steer;
    f.vy += ((dy / d) * ms - f.vy) * steer;
    // Shallow-water NPCs occasionally leap above the ocean surface and dive back in
    if (f.y < 82 && f.airJumpCd <= 0 && !this.isInsideRock(f.x, SURFACE_Y - 10, f.r) && Math.random() < dt * 0.42) {
      f.airJumpCd = 6.5 + Math.random() * 12;
      const dir = Math.abs(f.vx) > 15 ? (f.vx > 0 ? 1 : -1) : f.face;
      f.vx = dir * (80 + Math.random() * 75);
      f.vy = -(190 + Math.random() * 105 + Math.min(70, f.r * 1.4));
    }
  }

  checkEating(attract = false, nearX = 0, nearY = 0) {
    const list = this.fish;
    for (const e of list) {
      if (e.dead || e.eatenBy) continue;
      if (e.kind === "npc" && !e.sp.predator) continue;
      if (attract && (Math.abs(e.x - this.cam.x) > nearX || Math.abs(e.y - this.cam.y) > nearY)) continue;
      const busy = e.chompT > (e.munch ? 0.26 : 0.1);
      const mx = e.mouthX(),
        my = e.mouthY();
      const scanR = e.r * 3.1 + 58;
      const near = this.queryNear(e.x, e.y, scanR);
      const maxBatch = e.sucking ? 4 : e.kind === "player" || e.kind === "bot" ? 8 : 3;
      let eatenNow = 0;
      for (const o of near) {
        if (o === e || o.dead || o.eatenBy || o.invuln > 0 || (e.kind !== "player" && o.sp.poisonous)) continue;
        const duel = e.kind !== "npc" && o.kind !== "npc";
        if (!this.canEat(e, o) || this.isProtectedInCave(e, o)) {
          // Similar-size rival fish gently bump/deflect off each other instead of overlapping or unfairly eating!
          if (duel && e.id < o.id && !this.canEat(o, e) && !this.isProtectedInCave(o, e)) {
            const bdx = o.x - e.x,
              bdy = o.y - e.y;
            const minD = (e.r + o.r) * 0.68;
            if (Math.abs(bdx) < minD && Math.abs(bdy) < minD) {
              const bd = Math.hypot(bdx, bdy) || 0.01;
              if (bd < minD) {
                const nx = bdx / bd,
                  ny = bdy / bd;
                const push = (minD - bd) * 0.5;
                e.x -= nx * push;
                e.y -= ny * push;
                o.x += nx * push;
                o.y += ny * push;
                e.vx -= nx * 24;
                e.vy -= ny * 24;
                o.vx += nx * 24;
                o.vy += ny * 24;
              }
            }
          }
          continue;
        }
        if (e.kind === "npc" && o.kind === "npc" && o.r < e.r * 0.25) continue;
        const streamGulp = o.fry || (e.sucking && o.r < e.r * 0.48);
        const multiBite = !e.sucking && (o.fry || o.r < e.r * 0.68);
        if (e.sucking) {
          if (streamGulp ? e.slurpCd > 0 : busy) continue;
        } else if (!multiBite && busy) {
          continue;
        }
        const dx = o.x - mx,
          dy = o.y - my;
        const isOctoEater = e.sp.style === "octopus";
        const reach = duel ? o.r * 0.84 + e.r * 0.42 : o.r + e.r * (isOctoEater ? 0.72 : 0.56);
        const reachOuter = reach * 5.2;
        if (Math.abs(dx) > reachOuter || Math.abs(dy) > reachOuter) continue;
        const d2 = dx * dx + dy * dy;
        if (d2 >= reachOuter * reachOuter) continue;
        const d = Math.sqrt(d2);
        e.wantOpen = true;
        e.wantOpenAmt = Math.max(e.wantOpenAmt, clamp(1.08 - (d - reach) / Math.max(1, reach * 4.2), 0.35, 1.15));
        if (isOctoEater && !e.sucking && d < reach * 2.15 && dx * e.face >= -o.r * 0.35) {
          e.wantGrab = true;
        }
        if (d < reach || (!duel && (o.x - e.x) * (o.x - e.x) + (o.y - e.y) * (o.y - e.y) < e.r * e.r * 0.3364)) {
          this.startEat(e, o);
          eatenNow++;
          if (e.sucking) {
            if (!streamGulp || eatenNow >= maxBatch) break;
            e.slurpCd = 0.014;
          } else {
            if (!multiBite || eatenNow >= maxBatch) break;
          }
        }
      }
    }
  }

  startEat(e: Fish, o: Fish) {
    if (o === this.player && this.shieldT > 0) {
      this.shieldT = 0;
      o.invuln = 2.4;
      const dx = e.x - o.x;
      const dy = e.y - o.y;
      const d = Math.hypot(dx, dy) || 1;
      e.vx = (dx / d) * 165;
      e.vy = (dy / d) * 165;
      e.ai.target = null;
      e.ai.rest = 1.4;
      this.shake = Math.min(5, this.shake + 3.5);
      sfx.shieldBreak();
      this.spawnRing(o.x, o.y, "#5eead4", o.r * 2.6);
      this.spawnSparks(o.x, o.y, "#a7f3d0", 18);
      const isId = this.lang === "id";
      this.texts.push({ x: o.x, y: o.y - o.r - 14, text: isId ? "PERISAI MENAHAN!" : "SHIELD BLOCKED!", color: "#6ee7b7", life: 1.25, max: 1.25, size: 10 });
      this.onEvent?.({
        type: "feed",
        text: isId
          ? `Perisai gelembung menahan gigitan ${e.name || e.sp.name}!`
          : `Bubble shield blocked ${e.name || e.sp.name}'s bite!`,
      });
      return;
    }
    o.eatenBy = e;
    o.eatT = 0;
    o.eatFromX = o.x;
    o.eatFromY = o.y;
    o.sucking = false;
    o.boosting = false;
    e.gulpColor = o.sp.pal.body;
    e.gulpTailColor = o.sp.pal.fin || o.sp.pal.tail || o.sp.pal.belly;
    if (e.sp.style === "octopus") {
      const pullDur = e.sucking ? (o.fry ? 0.24 : 0.34) : o.fry ? 0.32 : 0.44;
      e.eatPullT = 1.0;
      e.eatPullDur = pullDur;
      e.eatPullSuck = e.sucking;
      // Tentacles reach out first to grab prey; actual "HAP!" bite impact happens once pulled under head
      if (!e.sucking) {
        e.biteLungeV += Math.min(26, Math.max(8, e.r * 0.8));
        e.sqv -= 2.2;
      }
    } else if (e.sucking) {
      e.chompT = 0;
      e.jawV = Math.max(e.jawV, 16);
      e.mouthOpenT = Math.max(e.mouthOpenT, 0.28);
    } else if (e.chompPhase <= 0 && e.chompQueue === 0) {
      e.chompT = 0;
      e.jawV = Math.max(e.jawV, 24);
      e.mouthOpenT = Math.max(e.mouthOpenT, o.fry ? 0.24 : 0.28);
      e.biteLungeV -= Math.min(62, Math.max(16, e.r * 2.1));
      e.sqv -= 4.5;
    }
    if (o === this.player) {
      sfx.setSuck(false);
    }
  }

  finishEat(e: Fish, o: Fish) {
    o.dead = true;
    o.eatenBy = null;
    const isOctoEat = e.sp.style === "octopus";
    const mx = isOctoEat ? e.x + e.face * e.r * 0.14 : e.mouthX(),
      my = isOctoEat ? e.y + e.r * 0.32 : e.mouthY();
    const tiny = o.fry;
    const big = o.r > e.r * 0.4;

    if (e.kind === "npc") {
      e.mass += o.mass * 0.025;
    } else {
      const taper = 1 / (1 + Math.max(0, e.r - 8) * 0.04);
      const rawGain = o.mass * GAIN * taper;
      const maxStep = e.mass * 0.055 + 2.0;
      e.mass += Math.min(rawGain, maxStep);
    }
    if (e.r > e.maxR) e.mass = e.maxR * e.maxR;

    e.swallowT = 1;
    e.gulpColor = o.sp.pal.body;
    e.gulpTailColor = o.sp.pal.fin || o.sp.pal.tail || o.sp.pal.belly;
    const biteGain = tiny ? 0.34 : 0.42 + Math.min(0.36, (o.r / e.r) * 0.58);
    e.gulpK = Math.min(0.88, (e.gulpT > 0 ? e.gulpK * 0.80 : 0) + biteGain * (e.gulpT > 0 ? 0.34 : 1.0));
    e.gulpT = 1;
    if (isOctoEat) {
      // Prey just reached beak underneath head -> trigger the "HAP!" gulp snap & squishy recoil!
      e.chompDur = big ? 0.24 : 0.16;
      e.chompPhase = e.chompDur * 0.72;
      e.chompBitFired = false;
      e.munch = e.munch || big;
      e.chompT = big ? 0.52 : 0.34;
      e.sqv += tiny ? 3.8 : 5.6;
      e.biteLungeV -= Math.min(34, Math.max(10, e.r * 1.1));
    } else if (e.sucking && (tiny || o.r < e.r * 0.48)) {
      // Rapid suction slurp: mouth stays lively wide open while prey enters throat
      e.sqv += tiny ? 2.5 : 4.2;
    } else {
      // Non-suction bite mode: brief wide-open throat entry window, then crisp snap-chomp while throat-to-belly swells
      if (e.chompPhase <= 0 && e.chompQueue === 0) {
        e.chompDur = big ? 0.24 : 0.16;
        // Start Bite #1 just before SLAM (u=0.28) so jaw stays wide open as food enters pharynx, then slams!
        e.chompPhase = e.chompDur * 0.72;
        e.chompBitFired = false;
      } else {
        // Additional fish eaten in the same cluster/school queue 1 extra rapid snap each!
        e.chompQueue = Math.min(12, e.chompQueue + 1);
      }
      e.munch = e.munch || big;
      e.chompT = big ? 0.58 : 0.32;
    }
    e.score += Math.round(o.mass * 12);

    const onScreen = Math.abs(mx - this.cam.x) < this.vw && Math.abs(my - this.cam.y) < this.vh;
    if (onScreen) {
      const gx = e.x + e.face * e.r * 0.16,
        gy = e.y + e.r * 0.08;
      const gCnt = tiny ? 1 : 2;
      for (let i = 0; i < gCnt; i++) {
        const b = this.bubble(gx + (Math.random() - 0.5) * e.r * 0.18, gy + (Math.random() - 0.5) * e.r * 0.18, 0.8 + Math.random() * 1.1);
        b.vx -= e.face * (12 + Math.random() * 14);
        this.particles.push(b);
      }
      const cols = [o.sp.pal.body, o.sp.pal.belly, o.sp.pal.fin];
      if (tiny) {
        this.spawnRing(mx, my, o.sp.pal.fin, 3.4);
        for (let i = 0; i < 3; i++) {
          const a = Math.random() * Math.PI * 2;
          const s = 16 + Math.random() * 34;
          this.particles.push({
            x: mx,
            y: my,
            vx: Math.cos(a) * s + e.face * 12,
            vy: Math.sin(a) * s - 10,
            life: 0.3 + Math.random() * 0.25,
            max: 0.55,
            type: "bit",
            color: cols[i],
            size: 1.1 + Math.random() * 0.8,
          });
        }
        if (Math.random() < 0.5) this.particles.push(this.bubble(mx, my, 0.9 + Math.random() * 1.2));
      } else {
        this.particles.push({
          x: mx + e.face * e.r * 0.15,
          y: my,
          vx: e.face * 10,
          vy: 0,
          life: 0.22,
          max: 0.22,
          type: "chomp",
          color: "#e0f7ff",
          size: Math.max(6, e.r * 0.65),
          dir: e.face,
        });
        const n = 7 + Math.min(12, Math.round(o.r));
        for (let i = 0; i < n; i++) {
          const a = Math.random() * Math.PI * 2;
          const s = 20 + Math.random() * 58;
          this.particles.push({
            x: mx,
            y: my,
            vx: Math.cos(a) * s + e.face * 18,
            vy: Math.sin(a) * s - 16,
            life: 0.5 + Math.random() * 0.4,
            max: 0.9,
            type: "bit",
            color: cols[i % 3],
            size: 1.6 + Math.random() * 1.6,
          });
        }
        for (let i = 0; i < 4; i++) this.particles.push(this.bubble(mx + (Math.random() - 0.5) * 8, my, 1.2 + Math.random() * 2.2));
        this.spawnRing(mx, my, "#bae6fd", Math.max(5, o.r));
        // impact speed-lines + a second, wider shock ring
        for (let i = 0; i < 8; i++) {
          const a = (i / 8) * Math.PI * 2 + Math.random() * 0.5;
          const s = 95 + Math.random() * 75;
          this.particles.push({ x: mx + Math.cos(a) * 3, y: my + Math.sin(a) * 3, vx: Math.cos(a) * s, vy: Math.sin(a) * s, life: 0.2, max: 0.2, type: "streak", color: "#ffffff", size: 1 });
        }
        this.spawnRing(mx, my, "#ffffff", Math.max(8, o.r * 1.7));
      }
    }

    if (e === this.player) {
      if (o.sp.poisonous) {
        this.poisonDelayQueue.push(2.0);
        this.spawnSparks(mx, my, "#a3e635", 10);
        this.spawnSparks(mx, my, "#78350f", 6);
        this.spawnRing(mx, my, "#84cc16", Math.max(8, o.r * 1.9));
        this.texts.push({ x: mx, y: my - e.r * 1.3 - 10, text: this.lang === "id" ? "BERACUN!" : "POISON!", color: "#a3e635", life: 1.2, max: 1.2, size: 11 });
      }
      e.combo++;
      this.maxCombo = Math.max(this.maxCombo, e.combo);
      e.comboT = 2.6;
      this.chainPop = 1;
      const mult = e.combo >= 10 ? 3 : e.combo >= 5 ? 2 : 1;
      const pts = Math.round((45 + o.mass * 3.5 + (o.kind === "bot" ? 500 : 0)) * mult);
      this.arcadeScore += pts;

      let coins = tiny ? (o.school?.golden ? 2 : 1) : Math.max(1, Math.round(o.r / 2.6)) * mult;
      if (o.kind === "bot") {
        coins += 15;
        this.botsEatenCount++;
      }
      const n = Math.min(coins, 10);
      for (let i = 0; i < n; i++) {
        const v = Math.floor(coins / n) + (i < coins % n ? 1 : 0);
        this.addFlyCoin(mx, my, v, i * 0.045, e.face);
      }
      this.eatenCount++;
      if (tiny) {
        // no text spam per fry: pops climb in pitch and the chain is summed up when it ends
        this.streamPts += pts;
        this.streamCoins += coins;
        this.streamN++;
        this.streamT = 0.5;
        sfx.pop(e.combo);
        this.shake = Math.min(1.2, this.shake + 0.18);
        const s = o.school;
        if (s) {
          s.byPlayer++;
          if (!s.members.some((m) => !m.dead) && s.byPlayer >= s.size0 * 0.7) this.schoolBonus(s, mx, my);
        }
      } else {
        this.texts.push({ x: mx, y: my - e.r * 0.8, text: "+" + pts, color: "#fff3a1", life: 0.85, max: 0.85, size: 8 });
        if (Math.random() < 0.55 || o.r > e.r * 0.5) {
          const wordsList = this.lang === "id" ? WORDS_ID : WORDS_EN;
          this.texts.push({
            x: mx + (Math.random() - 0.5) * 10,
            y: my - e.r * 1.4 - 8,
            text: wordsList[Math.floor(Math.random() * wordsList.length)],
            color: "#ffffff",
            life: 0.7,
            max: 0.7,
            size: 9,
          });
        }
        this.spawnSparks(mx, my - e.r * 0.3, "#fff7c2", 5);
        sfx.gulp(o.r / 6, true, e.combo);
        this.shake = Math.min(3, this.shake + 0.5 + o.r / 10);
        // hit-stop: a few frozen frames sell the weight of a big bite
        // hit-stop only for genuinely big bites (it used to fire on almost every bite of a small fish,
        // which read as stutter rather than impact)
        this.freeze = o.kind === "bot" ? 0.045 : 0;
      }
      if (e.combo === 7 || e.combo === 14 || e.combo === 22) {
        this.onEvent?.({ type: "frenzy", n: e.combo });
        sfx.frenzy();
        this.spawnSparks(e.x, e.y, "#ffe14a", 22);
      } else if (e.combo >= 3) {
        this.onEvent?.({ type: "combo", n: e.combo });
        if (!tiny) sfx.combo(e.combo);
      }
      if (o.kind === "bot") {
        this.onEvent?.({ type: "feed", text: this.lang === "id" ? `${e.name} memakan ${o.name}!` : `${e.name} ate ${o.name}!` });
      }
    } else if (!this.menuActive && onScreen && !tiny && Math.abs(mx - this.cam.x) < this.vw / 2) {
      sfx.gulp(o.r / 6, false);
    }

    if (o.kind === "bot") {
      this.respawnQueue.push({ t: 1.5 + Math.random() * 2.5, name: o.name, skin: o.skinRef || SKINS[0] });
      if (!this.menuActive && e.kind === "bot") {
        this.onEvent?.({ type: "feed", text: this.lang === "id" ? `${e.name} memakan ${o.name}!` : `${e.name} ate ${o.name}!` });
      }
    }
    if (o === this.player) {
      this.killerName = e.name || e.sp.name;
      this.killerSpId = e.skinRef?.id || e.sp.id;
      this.deathTimer = 1.6;
      this.shake = 6;
      sfx.die();
      sfx.setSuck(false);
      this.texts.push({ x: mx, y: my - e.r - 10, text: this.lang === "id" ? "DIMAKAN!" : "EATEN!", color: "#ff5a6a", life: 1.5, max: 1.5, size: 16 });
      this.onEvent?.({ type: "feed", text: this.lang === "id" ? `${this.killerName} memakan ${o.name}!` : `${this.killerName} ate ${o.name}!` });
      this.spectate = e;
    }
  }

  /** A coin pops out of the mouth (staggered by `delay`), then swoops to the coin counter. */
  addFlyCoin(x: number, y: number, value: number, delay = 0, dir = 0) {
    const a = -Math.PI / 2 + (Math.random() - 0.5) * 1.9 + dir * 0.3;
    const s = 70 + Math.random() * 90;
    this.flyCoins.push({ x, y, vx: Math.cos(a) * s, vy: Math.sin(a) * s, t: -delay, value, sx: x, sy: y, bend: (Math.random() < 0.5 ? -1 : 1) * (16 + Math.random() * 30), trail: 0 });
  }

  bubble(x: number, y: number, size: number): Particle {
    return { x, y, vx: 0, vy: -10 - Math.random() * 10, life: 2.2 + Math.random() * 2, max: 4.2, type: "bubble", color: "#e8ffff", size };
  }

  spawnRing(x: number, y: number, color: string, size: number, aspect = 1) {
    this.particles.push({ x, y, vx: 0, vy: 0, life: 0.38, max: 0.38, type: "ring", color, size, aspect });
  }

  spawnWaterSplash(x: number, r: number, strength: number, entering: boolean, playSound = false) {
    const s = clamp(strength, 0.55, 1.8);
    const sizeK = clamp(r / 14, 0.42, 3.8);

    // 1) Physical propagating ocean surface wave scaled cleanly to fish size `r`
    this.surfaceWaves.push({
      x,
      r,
      strength: s,
      age: 0,
      maxAge: clamp(0.9 + Math.sqrt(r) * 0.16, 0.95, 1.95),
      entering,
    });
    if (this.surfaceWaves.length > 36) this.surfaceWaves.shift();

    // 2) Wide elliptical perspective water-surface ripple rings scaled directly with fish size
    const ringLife = clamp(0.46 + sizeK * 0.14, 0.44, 1.05);
    this.particles.push({
      x,
      y: SURFACE_Y + 1,
      vx: 0,
      vy: 0,
      life: ringLife,
      max: ringLife,
      type: "ring",
      color: entering ? "#ffffff" : "#cffafe",
      size: clamp(r * (entering ? 1.85 : 1.3) * s, 9, 120),
      aspect: 0.25,
    });
    if (entering) {
      this.particles.push({
        x,
        y: SURFACE_Y + 2,
        vx: 0,
        vy: 0,
        life: ringLife * 0.85,
        max: ringLife * 0.85,
        type: "ring",
        color: "#bae6fd",
        size: clamp(r * 1.15 * s, 6, 78),
        aspect: 0.22,
      });
      if (r >= 16) {
        this.particles.push({
          x,
          y: SURFACE_Y + 2,
          vx: 0,
          vy: 0,
          life: ringLife * 1.18,
          max: ringLife * 1.18,
          type: "ring",
          color: "#7dd3fc",
          size: clamp(r * 2.45 * s, 26, 155),
          aspect: 0.2,
        });
      }
    }

    // 3) Arched splash droplets erupting proportionally to fish size `r`
    const dropCount = clamp(Math.round((entering ? 13 : 9) * (0.62 + sizeK * 0.56) * s), 5, 36);
    const vScale = (0.68 + Math.min(1.45, sizeK * 0.38)) * s;
    for (let i = 0; i < dropCount; i++) {
      const spread = (Math.random() - 0.5) * 2;
      const life = clamp(0.42 + sizeK * 0.08 + Math.random() * 0.34, 0.4, 0.96);
      this.particles.push({
        x: x + (Math.random() - 0.5) * r * 1.1,
        y: SURFACE_Y - 1,
        vx: spread * (66 + Math.random() * 78) * vScale,
        vy: -(82 + Math.random() * 145) * vScale,
        life,
        max: life,
        type: "splash",
        color: i % 3 === 0 ? "#ffffff" : i % 3 === 1 ? "#dcfbff" : "#7dd3fc",
        size: clamp(1.1 + r * 0.088 + Math.random() * 1.25, 1.2, 6.2),
      });
    }

    // 4) Plunge bubble plume swirling down under the waterline
    if (entering) {
      const bubN = clamp(Math.round(4 + r * 0.48), 3, 18);
      for (let i = 0; i < bubN; i++) {
        const bb = this.bubble(
          x + (Math.random() - 0.5) * r * 1.35,
          SURFACE_Y + 5 + Math.random() * (12 + r * 1.35),
          clamp(0.9 + r * 0.04 + Math.random() * 1.8, 0.9, 4.2),
        );
        bb.vy = 26 + Math.random() * (30 + r * 0.85);
        this.particles.push(bb);
      }
    }
    if (playSound && !this.menuActive) {
      sfx.surfaceSplash(clamp(0.24 + Math.min(0.45, r * 0.011) + s * 0.14, 0.26, 0.68));
    }
  }

  spawnSparks(x: number, y: number, color: string, n: number) {
    for (let i = 0; i < n; i++) {
      const a = Math.random() * Math.PI * 2;
      const s = 38 + Math.random() * 85;
      this.particles.push({
        x,
        y,
        vx: Math.cos(a) * s,
        vy: Math.sin(a) * s,
        life: 0.55 + Math.random() * 0.4,
        max: 0.95,
        type: Math.random() < 0.5 ? "star" : "spark",
        color,
        size: 1.8,
      });
    }
  }

  emitHud() {
    const p = this.player;
    const ranked = this.rankedBuf;
    ranked.length = 0;
    for (let i = 0; i < this.fish.length; i++) {
      const f = this.fish[i];
      if ((f.kind === "bot" || f.kind === "player") && !f.dead) ranked.push(f);
    }
    ranked.sort((a, b) => b.mass - a.mass);
    this.leaderId = ranked[0]?.id ?? -1;
    const rank = p && !p.dead ? ranked.indexOf(p) + 1 : 0;
    if (rank > 0) {
      this.bestRank = Math.min(this.bestRank, rank);
      if (rank === 1 && !this.reachedRank1) {
        this.reachedRank1 = true;
        this.onEvent?.({ type: "rank1" });
      }
    }
    const leaderCount = Math.min(6, ranked.length);
    const leaderboard: LeaderRow[] = new Array(leaderCount);
    for (let i = 0; i < leaderCount; i++) {
      const f = ranked[i];
      leaderboard[i] = { name: f.name, score: Math.round(f.mass), me: f === p, color: f.sp.pal.body };
    }
    const frenzyStage = p ? Math.min(7, p.combo) : 0;
    const py = p ? p.y : this.cam.y;
    const zoneName = `${ZONE_LABELS_I18N[this.lang][zoneAt(py)]} (${depthMeters(py)} m)`;
    this.onHud?.({
      coins: this.sessionCoins,
      score: this.arcadeScore,
      mass: p ? Math.round(p.mass) : 0,
      energy: p ? p.energy : 0,
      combo: p ? p.combo : 0,
      comboT: p ? p.comboT : 0,
      frenzyStage,
      level: this.level,
      growthPct: p ? this.calcGrowthPct(p.r) : 0,
      stageNum: Math.max(1, this.level - 1),
      zoneName,
      rank,
      total: ranked.length + this.respawnQueue.length, // rivals waiting to respawn still count: always 50 players
      leaderboard,
      alive: !!p && !p.dead && this.deathTimer < 0,
      exhausted: p ? p.exhausted : false,
      boost: p ? p.boost : 0,
      boostExhausted: p ? p.boostExhausted : false,
      sucking: p ? p.sucking : false,
      boosting: p ? p.boosting : false,
      shieldT: this.shieldT,
      turboT: this.turboT,
      vortexT: this.vortexT,
      clockT: this.clockT,
    });
  }

  drawMinimap() {
    const m = this.minimap;
    if (!m) return;
    const c = m.getContext("2d")!;
    const w = m.width,
      h = m.height;
    const sx = w / WORLD_W,
      sy = h / WORLD_H;

    if (!this.minimapBg || this.minimapBgW !== w || this.minimapBgH !== h) {
      const bg = (this.minimapBg ??= document.createElement("canvas"));
      bg.width = w;
      bg.height = h;
      this.minimapBgW = w;
      this.minimapBgH = h;
      const bc = bg.getContext("2d")!;
      const mg = bc.createLinearGradient(0, 0, 0, h);
      mg.addColorStop(0, "#155e8a");
      mg.addColorStop(0.45, "#0c2d5e");
      mg.addColorStop(1, "#050d28");
      bc.fillStyle = mg;
      bc.fillRect(0, 0, w, h);

      bc.fillStyle = "rgba(38, 95, 145, 0.7)";
      for (const col of this.ocean.colliders) {
        if (col.maxPassR !== undefined) continue;
        bc.beginPath();
        bc.arc(col.x * sx, col.y * sy, Math.max(1.5, col.r * sx * 1.2), 0, Math.PI * 2);
        bc.fill();
      }
      for (const cv of this.ocean.caves) {
        bc.fillStyle = "rgba(4, 12, 34, 0.92)";
        bc.beginPath();
        bc.ellipse(cv.x * sx, cv.y * sy, Math.max(2, cv.rx * sx * 0.72), Math.max(1.6, cv.ry * sy * 0.75), 0, 0, Math.PI * 2);
        bc.fill();
        bc.fillStyle = "#5eead4";
        bc.beginPath();
        bc.arc(cv.x * sx, cv.y * sy, 1.35, 0, Math.PI * 2);
        bc.fill();
      }
      bc.fillStyle = "#4c2882";
      for (let x = 0; x < w; x++) {
        const fy = (floorY((x / w) * WORLD_W) / WORLD_H) * h;
        bc.fillRect(x, fy, 1, h - fy);
      }
    }
    c.drawImage(this.minimapBg, 0, 0);

    c.strokeStyle = "rgba(255,245,190,0.75)";
    c.lineWidth = 1;
    c.strokeRect(this.camLeft * sx + 0.5, this.camTop * sy + 0.5, this.vw * sx, this.vh * sy);
    const p = this.player;
    for (const f of this.fish) {
      if (f.dead) continue;
      if (f.kind === "bot") {
        c.fillStyle = p && !p.dead && this.canEat(f, p) ? "#ff4a5a" : f.sp.pal.body;
        c.beginPath();
        c.arc(f.x * sx, f.y * sy, 1.9, 0, Math.PI * 2);
        c.fill();
      } else if (f.kind === "npc" && f.sp.predator) {
        c.fillStyle = "#ff8a8a";
        c.fillRect(f.x * sx - 1, f.y * sy - 1, 2, 2);
      }
    }
    // pearls & power-up orbs show as twinkling beacons on minimap
    for (const o of this.orbs) {
      c.fillStyle = o.kind === "pearl" ? "#ffe96b" : o.kind === "turbo" ? "#67e8f9" : o.kind === "vortex" ? "#fdba74" : "#6ee7b7";
      c.beginPath();
      c.arc(o.x * sx, o.y * sy, 2.1, 0, Math.PI * 2);
      c.fill();
    }
    // snack schools show up as little shimmering clusters
    c.fillStyle = "rgba(200, 245, 255, 0.95)";
    for (const s of this.schools) {
      if (s.members.length < 4) continue;
      c.fillStyle = s.golden ? "rgba(255, 226, 90, 0.98)" : "rgba(200, 245, 255, 0.95)";
      const qx = s.x * sx,
        qy = s.y * sy;
      c.fillRect(qx - 2, qy - 0.5, 1, 1);
      c.fillRect(qx, qy - 1.5, 1, 1);
      c.fillRect(qx + 1.5, qy + 0.5, 1, 1);
      c.fillRect(qx - 0.5, qy + 1, 1, 1);
    }
    // sea mine bombs blink crimson on minimap
    c.fillStyle = Math.floor(this.t * 4) % 2 === 0 ? "#ff3b4e" : "#fca5a5";
    for (const mn of this.mines) {
      c.beginPath();
      c.arc(mn.x * sx, mn.y * sy, 1.9, 0, Math.PI * 2);
      c.fill();
    }
    // Sunfish Food Bonus blips gleam aqua-gold on minimap
    for (const sf of this.sunfish) {
      if (sf.dead) continue;
      c.fillStyle = sf.hp === 1 ? "#fde047" : "#38bdf8";
      c.beginPath();
      c.arc(sf.x * sx, sf.y * sy, 2.4, 0, Math.PI * 2);
      c.fill();
      c.strokeStyle = "#ffffff";
      c.lineWidth = 0.7;
      c.stroke();
    }
    if (p && !p.dead) {
      c.fillStyle = "#ffffff";
      c.beginPath();
      c.arc(p.x * sx, p.y * sy, 3.2, 0, Math.PI * 2);
      c.fill();
      c.fillStyle = "#ffa22a";
      c.beginPath();
      c.arc(p.x * sx, p.y * sy, 2, 0, Math.PI * 2);
      c.fill();
    }
  }

  // Draws 100% Seamless, Line-Free, Velvety Water Suction Mist (zero lines, zero triangle cone borders!)
  drawSoftSuctionVortex(f: Fish, camLeft: number, camTop: number, vw: number, vh: number) {
    if (f.suckVis < 0.02) return;
    const mx = f.mouthX() - camLeft,
      my = f.mouthY() - camTop;
    if (mx < -180 || mx > vw + 180 || my < -180 || my > vh + 180) return;
    const ctx = this.ctx;
    const range = this.suckRange(f);
    const ang = Math.atan2(Math.sin(f.tilt), f.face * Math.cos(f.tilt));
    const vis = f.suckVis;
    const S = this.pixelMode ? 1 : this.zoom * this.dpr;
    const cs = Math.cos(ang) * S,
      sn = Math.sin(ang) * S;
    const orb = (this.orbSuction ??= glowOrb("rgba(170, 240, 255, 0.5)", false));
    ctx.globalCompositeOperation = "lighter";
    ctx.setTransform(cs, sn, -sn, cs, mx * S, my * S);
    // Soft air/water suction vortex field + silky converging hydro-ribbons
    const rc = range * 0.48;
    ctx.globalAlpha = 0.22 * vis;
    ctx.drawImage(orb, range * 0.4 - rc, -rc * 0.46, rc * 2, rc * 0.92);
    // Subtle intake mouth glow
    ctx.globalAlpha = 0.28 * vis;
    ctx.drawImage(orb, -f.r * 0.35, -f.r * 0.5, f.r * 1.1, f.r);

    // Subtle inward-moving crescent intake ripples
    ctx.strokeStyle = "rgb(215, 248, 255)";
    ctx.lineWidth = Math.max(1.0, f.r * 0.08);
    for (let w = 0; w < 2; w++) {
      const wp = (this.t * 1.65 + w * 0.5) % 1;
      const wAlpha = Math.sin(wp * Math.PI) * 0.24 * vis;
      const wx = range * (0.86 - wp * 0.72);
      const wy = Math.max(4, wx * 0.48);
      ctx.globalAlpha = wAlpha;
      ctx.beginPath();
      ctx.arc(wx * 0.25, 0, Math.hypot(wx * 0.75, wy), -0.42, 0.42);
      ctx.stroke();
    }

    // 6 smooth translucent airflow ribbons curving evenly into the mouth (zero per-frame gradient or string allocations)
    ctx.lineCap = "round";
    const tracks = [-0.36, 0.36, -0.21, 0.21, -0.08, 0.08];
    for (let i = 0; i < tracks.length; i++) {
      const prog = (this.t * 1.55 + i * 0.17) % 1;
      const fade = Math.sin(prog * Math.PI) * vis;
      if (fade <= 0.01) continue;
      const side = tracks[i];
      const x1 = range * (0.98 - prog * 0.68);
      const x0 = Math.max(range * 0.04, x1 - range * 0.36);
      const y1 = side * range * (1 - prog * 0.58);
      const y0 = side * range * 0.16 * (1 - prog * 0.55);
      const xm = (x0 + x1) * 0.48;
      const ym = y1 * 0.48;
      const baseW = Math.max(1.05, f.r * (Math.abs(side) < 0.15 ? 0.11 : 0.085));
      ctx.strokeStyle = "rgb(215, 248, 255)";
      ctx.globalAlpha = 0.14 * fade;
      ctx.lineWidth = baseW * 1.35;
      ctx.beginPath();
      ctx.moveTo(x1, y1);
      ctx.quadraticCurveTo(xm, ym, x0, y0);
      ctx.stroke();

      ctx.strokeStyle = "rgb(232, 253, 255)";
      ctx.globalAlpha = 0.28 * fade;
      ctx.lineWidth = baseW * 0.72;
      ctx.beginPath();
      ctx.moveTo(x1 * 0.92 + x0 * 0.08, y1 * 0.92 + y0 * 0.08);
      ctx.quadraticCurveTo(xm, ym, x0 * 0.88 + x1 * 0.12, y0 * 0.88 + y1 * 0.12);
      ctx.stroke();
    }
    ctx.setTransform(S, 0, 0, S, 0, 0);
    ctx.globalAlpha = 1;
    ctx.globalCompositeOperation = "source-over";
  }

  /** Feeding Frenzy iconic spiked iron naval sea mine with anchor chain & pulsing red danger light */
  drawMines(camLeft: number, camTop: number, vw: number, vh: number, t: number) {
    // When Dunia Laut 3D is active, live 3D instanced sea mines, interlocking 3D chains,
    // seabed anchors & volumetric beacons are rendered in-world by LautWorld pass 1.
    if (this.lautActive()) return;

    const ctx = this.ctx;
    const redGlow = (this.orbMineGlow ??= glowOrb("rgba(255, 62, 62, 0.72)", false));
    const s3d = this.pixelMode ? null : getMine3DSprites();

    for (const m of this.mines) {
      const x = m.x - camLeft;
      const y = m.y - camTop;
      if (x < -56 || x > vw + 56 || y < -275 || y > vh + 80) continue;

      const fy = floorY(m.x);
      const anchoredOnFloor = m.baseY + m.tether >= fy - 24;
      const botWorldY = anchoredOnFloor ? fy - 4 : m.baseY + m.tether;
      const botScreenY = botWorldY - camTop;
      const botY = Math.min(vh + 16, botScreenY);
      const blink = 0.5 + 0.5 * Math.sin(t * 7.5 + m.ph);

      if (s3d) {
        // 1. 3D PBR interlocking stud-link anchor chain (alternating 0° / 90° links)
        const startY = y + m.r * 1.06;
        const linkH = m.r * 0.54;
        const linkW = linkH * 0.714;
        const pitch = linkH * 0.64;
        const span = Math.max(8, botScreenY - startY);
        const count = Math.max(2, Math.round(span / pitch));

        if (anchoredOnFloor && botScreenY >= -24 && botScreenY <= vh + 28) {
          const aw = m.r * 2.1;
          const ah = aw * (60 / 72);
          ctx.drawImage(s3d.anchor, x - aw * 0.5, fy - camTop - ah * 0.88, aw, ah);
        }

        for (let k = 0; k < count; k++) {
          const u = (k + 0.5) / count;
          const cy = startY + (botScreenY - startY) * u;
          if (cy < -20) continue;
          if (cy > vh + 20) break;
          const cx = x + Math.sin(t * 1.35 + m.ph + u * 3.8) * Math.sin(u * Math.PI) * 3.1;
          const uNext = Math.min(1, (k + 1.5) / count);
          const nx = x + Math.sin(t * 1.35 + m.ph + uNext * 3.8) * Math.sin(uNext * Math.PI) * 3.1;
          const ny = startY + (botScreenY - startY) * uNext;
          const tilt = Math.atan2(nx - cx, Math.max(1e-3, ny - cy));
          const fade = anchoredOnFloor ? 1 : Math.min(1, (1 - u) * 3.5 + 0.16);

          ctx.save();
          if (fade < 0.99) ctx.globalAlpha = fade;
          ctx.translate(cx, cy);
          ctx.rotate(-tilt);
          ctx.drawImage((k & 1) === 0 ? s3d.chainFlat : s3d.chainEdge, -linkW * 0.5, -linkH * 0.5, linkW, linkH);
          ctx.restore();
        }

        // 2. Pulsing red danger halo
        ctx.save();
        ctx.globalCompositeOperation = "lighter";
        ctx.globalAlpha = 0.24 + blink * 0.44;
        const gR = m.r * (2.4 + blink * 0.48);
        ctx.drawImage(redGlow, x - gR, y - gR, gR * 2, gR * 2);
        ctx.restore();

        // 3. 3D PBR Naval Sea Mine sprite frame + animated ruby core flare
        const frames = s3d.mineFrames;
        const normRot = ((m.rot / (Math.PI * 2)) % 1 + 1) % 1;
        const exact = normRot * frames.length;
        const idx = Math.floor(exact) % frames.length;
        const remAng = ((exact - Math.floor(exact)) * (Math.PI * 2)) / frames.length;
        const drawSpan = m.r * 3.24;

        ctx.save();
        ctx.translate(x, y);
        ctx.rotate(-remAng);
        ctx.drawImage(frames[idx], -drawSpan * 0.5, -drawSpan * 0.5, drawSpan, drawSpan);
        ctx.restore();

        // Additive pulsing beacon sparkle on top of ruby dome
        if (blink > 0.35) {
          ctx.save();
          ctx.globalCompositeOperation = "lighter";
          ctx.globalAlpha = (blink - 0.35) * 0.72;
          const coreR = m.r * 0.52;
          ctx.drawImage(redGlow, x - coreR, y - coreR, coreR * 2, coreR * 2);
          ctx.restore();
        }
        continue;
      }

      // Crisp pixel-mode / fallback mine
      ctx.strokeStyle = "rgba(148, 163, 184, 0.85)";
      ctx.lineWidth = 2.2;
      ctx.lineCap = "round";
      ctx.beginPath();
      let cy = y + m.r * 0.95;
      while (cy < botY) {
        const sway = Math.sin(t * 1.3 + m.ph + (cy - y) * 0.04) * 2.2;
        const cx = x + sway;
        const ey = cy + 3;
        ctx.moveTo(cx + 1.9, ey);
        ctx.ellipse(cx, ey, 1.9, 3.3, 0, 0, Math.PI * 2);
        cy += 6.2;
      }
      ctx.stroke();

      ctx.save();
      ctx.globalCompositeOperation = "lighter";
      ctx.globalAlpha = 0.25 + blink * 0.45;
      const gR = m.r * (2.35 + blink * 0.45);
      ctx.drawImage(redGlow, x - gR, y - gR, gR * 2, gR * 2);
      ctx.restore();

      const spr = getMineSprite(m.r);
      ctx.save();
      ctx.translate(x, y);
      ctx.rotate(m.rot);
      ctx.drawImage(spr.cv, -spr.span * 0.5, -spr.span * 0.5, spr.span, spr.span);

      ctx.fillStyle = blink > 0.45 ? "#ff3b30" : "#7f1d1d";
      ctx.beginPath();
      ctx.arc(0, 0, m.r * 0.28, 0, Math.PI * 2);
      ctx.fill();
      ctx.strokeStyle = "#334155";
      ctx.lineWidth = 1;
      ctx.stroke();
      if (blink > 0.45) {
        ctx.fillStyle = "#fef08a";
        ctx.beginPath();
        ctx.arc(-0.8, -0.8, m.r * 0.11, 0, Math.PI * 2);
        ctx.fill();
      }
      ctx.restore();
    }
  }

  /** Outlined text drawn once into a small canvas and then reused as a sprite (stroking glyphs per frame is slow). */
  label(text: string, col: string, size: number): { cv: HTMLCanvasElement; w: number; h: number } {
    const q = Math.min(4, Math.max(1, Math.ceil(this.pxs() * 2) / 2)); // device px per world unit, in half steps
    const key = text + "|" + col + "|" + size + "|" + q + (this.pixelMode ? "p" : "");
    let e = this.labels.get(key);
    if (!e) {
      const font = this.pixelMode ? `${Math.max(5, size - 2)}px 'Press Start 2P', monospace` : `700 ${size}px 'Fredoka', system-ui, sans-serif`;
      const cv = document.createElement("canvas");
      const c = cv.getContext("2d")!;
      c.font = font;
      const w = c.measureText(text).width + 6.4,
        h = size * 1.5 + 6.4;
      cv.width = Math.max(2, Math.ceil(w * q));
      cv.height = Math.max(2, Math.ceil(h * q));
      c.setTransform(q, 0, 0, q, 0, 0);
      c.font = font;
      c.textAlign = "center";
      c.textBaseline = "middle";
      c.lineJoin = "round";
      c.miterLimit = 2;
      c.strokeStyle = "rgba(8, 22, 52, 0.9)";
      c.lineWidth = 2.6;
      c.strokeText(text, w / 2, h / 2);
      c.fillStyle = col;
      c.fillText(text, w / 2, h / 2);
      e = { cv, w: cv.width / q, h: cv.height / q };
      if (this.labels.size > 260) this.labels.clear();
      this.labels.set(key, e);
    }
    return e;
  }

  private pxs() {
    return this.pixelMode ? 1 : this.zoom * this.dpr;
  }

  render() {
    if (!this.ocean.ready) return;
    beginSpriteFrame(SPRITE_BUDGET);
    const soft = isSoftwareWebGL();
    this.live3DBudget = this.menuActive ? 0 : soft ? 2 : this.graphicsMode === "super_hd" ? 6 : this.graphicsMode === "ultra_fps" ? 3 : 5;
    this.fishLitBudget = this.graphicsMode === "super_hd" ? 40 : this.graphicsMode === "ultra_fps" ? 14 : 26;
    if (!this.menuActive) fish3d.beginFrame(soft || this.graphicsMode === "ultra_fps" ? 1 : 2);
    const ctx = this.ctx;
    const scale = this.pixelMode ? 1 : this.zoom * this.dpr;
    ctx.setTransform(scale, 0, 0, scale, 0, 0);
    ctx.imageSmoothingEnabled = !this.pixelMode;
    if (!this.pixelMode) {
      ctx.imageSmoothingQuality = this.graphicsMode === "super_hd" ? "high" : this.graphicsMode === "ultra_fps" ? "low" : "medium";
    }

    const vw = this.vw,
      vh = this.vh;
    let camLeft = this.cam.x - vw / 2;
    let camTop = this.cam.y - vh / 2;
    camLeft = vw >= WORLD_W ? (WORLD_W - vw) / 2 : clamp(camLeft, 0, WORLD_W - vw);
    camTop = clamp(camTop, MIN_CAM_TOP, WORLD_H + 35 - vh);
    if (this.shake > 0) {
      // a smooth decaying wobble instead of random per-frame jitter
      camLeft += Math.sin(this.t * 58) * this.shake * 0.45;
      camTop += Math.cos(this.t * 47) * this.shake * 0.45;
    }
    // one camera, snapped to the device-pixel grid, for EVERYTHING drawn this frame: sprites and pixel-art
    // backgrounds then move in lockstep (no 1px wobble of fish against the reef)
    camLeft = Math.round(camLeft * scale) / scale;
    camTop = Math.round(camTop * scale) / scale;
    this.camLeft = camLeft;
    this.camTop = camTop;
    const t = this.t;
    const oc = this.ocean;
    oc.time = t;
    oc.pxs = scale;
    const focus = this.player && !this.player.dead ? this.player : null;
    oc.focusX = focus ? focus.x : -9999;
    oc.focusY = focus ? focus.y : -9999;

    const laut = this.lautActive();
    if (laut) {
      // "Dunia Laut 3D": live water volume, god-rays and far canyon walls, then the painted sea life
      laut.update(this.canvas, camLeft, camTop, vw, vh, t, this.residents, this.medusae.animals, this.mines);
      oc.tickLaut();
      laut.drawPass(0, ctx);
      if (!this.pixelMode && camTop < 24) {
        drawHarborAndCloudsSky(ctx, camLeft, camTop, vw, vh, t, false);
      }
      oc.drawLautLife(ctx, camLeft, camTop, vw, vh);
    } else if (this.bgStyle !== "game1") {
      this.ensureReefBackdropAssets();
      const isCustom169 =
        this.bgStyle === "shipwreck" || this.bgStyle === "kelp" || this.bgStyle === "temple" || this.bgStyle === "lagoon";
      const brightWater = this.bgStyle !== "game2" && this.bgStyle !== "kelp";
      const img =
        this.bgStyle === "shipwreck"
          ? this.shipwreckImg
          : this.bgStyle === "kelp"
            ? this.kelpImg
            : this.bgStyle === "temple"
              ? this.templeImg
              : this.bgStyle === "lagoon"
                ? this.lagoonImg
                : this.habitatImg;
      const maxTop = isCustom169 ? 1150 : 900;
      const matte = !!img?.complete && !!img.naturalWidth && camTop < maxTop;
      if (brightWater || !matte || camTop > 480 || camTop < 0) oc.drawWater(ctx, camLeft, camTop, vw, vh);
      if (matte && img) {
        const aspect = img.naturalWidth / img.naturalHeight;
        const width = Math.max(vw * 1.14, vh * aspect * (isCustom169 ? 1.12 : 1.22));
        const height = width / aspect;
        const dx = -(width - vw) * (0.5 + 0.35 * Math.sin(camLeft * 0.0008));
        const dy = -(height - vh) * clamp(0.25 + Math.max(0, camTop) / 1150, 0, 1);
        const fade = isCustom169 ? clamp(1 - (camTop - 620) / 560, 0, 1) : clamp(1 - (camTop - 480) / 490, 0, 1);
        ctx.save();
        if (camTop < 0) {
          ctx.beginPath();
          ctx.rect(0, Math.max(0, -camTop), vw + 2, vh + 2);
          ctx.clip();
        }
        if (isCustom169) {
          ctx.globalAlpha = fade * 0.9;
          ctx.drawImage(img, dx, dy, width, height);
        } else if (brightWater) {
          ctx.globalAlpha = fade * 0.48;
          ctx.drawImage(img, dx, dy, width, height);
          ctx.globalCompositeOperation = "screen";
          ctx.globalAlpha = fade * 0.56;
          ctx.drawImage(img, dx, dy, width, height);
        } else {
          ctx.globalAlpha = fade;
          ctx.drawImage(img, dx, dy, width, height);
        }
        ctx.restore();
        if (brightWater) oc.drawLight(ctx, 0, camLeft, camTop, vw, vh, t);
        if (camTop <= 480) oc.tickLaut();
        oc.drawHabitatLife(ctx, camLeft, camTop, vw, vh);
      } else {
        oc.drawLight(ctx, 0, camLeft, camTop, vw, vh, t);
        oc.drawLayers(ctx, camLeft, camTop, vw, vh, true);
      }
      if (this.player) this.residents.drawFallback(ctx, camLeft, camTop, vw, vh);
    } else {
      oc.drawWater(ctx, camLeft, camTop, vw, vh);
      oc.drawLight(ctx, 0, camLeft, camTop, vw, vh, t); // sun bloom, far shafts, caustics
      oc.drawLayers(ctx, camLeft, camTop, vw, vh, true);
      if (this.player) this.residents.drawFallback(ctx, camLeft, camTop, vw, vh);
    }

    // Soft glowing floating plankton & bioluminescent deep-sea dust (pre-cached orbs!)
    ctx.save();
    ctx.globalCompositeOperation = "lighter";
    const deepAmt = clamp((camTop - 680) / 720, 0, 1);
    ctx.globalAlpha = 0.38 + deepAmt * 0.36;
    for (const m of this.motes) {
      const p = 0.6 + m.s * 0.5;
      const x = ((((m.x - camLeft * p + t * 3.5 * m.s) % 2000) + 2000) % 2000) - 100;
      const y = ((((m.y - camTop * p + Math.sin(t + m.x) * 6) % 1800) + 1800) % 1800) - 100;
      if (y + camTop < 6 || x < -10 || x > vw + 10 || y < -10 || y > vh + 10) continue;
      const rad = (m.s > 0.7 ? 2.6 : 1.6) * (1 + deepAmt * 0.45);
      ctx.drawImage(m.orb, x - rad, y - rad, rad * 2, rad * 2);
    }
    ctx.restore();

    // Scenic Rock Overhangs, Stalactite Arches & Glowing Bioluminescent Crevices!
    if (laut) {
      laut.drawPass(1, ctx); // rock pinnacles, coral reef, sea floor, vents, treasure, residents
      oc.drawLautDecor(ctx, camLeft, camTop, vw, vh, t);
    } else {
      this.medusae.drawCached(ctx, camLeft, camTop, vw, vh, false);
      oc.drawRockFormations(ctx, camLeft, camTop, vw, vh, t);
      oc.drawFloor(ctx, camLeft, camTop, vw, vh);
      oc.drawBackDecor(ctx, camLeft, camTop, vw, vh, t);
    }

    if (this.worldCoins.length > 0) {
      const coinGlow = (this.orbCoinGlow ??= glowOrb("rgba(255, 214, 80, 0.55)", false));
      ctx.save();
      ctx.globalCompositeOperation = "lighter";
      for (const c of this.worldCoins) {
        const x = c.x - camLeft,
          y = c.y - camTop;
        if (x < -12 || x > vw + 12 || y < -12 || y > vh + 12) continue;
        if (c.t > 20 && Math.floor(c.t * 8) % 2 === 0) continue;
        ctx.globalAlpha = 0.45 + Math.sin(t * 5 + c.x) * 0.18;
        ctx.drawImage(coinGlow, x - 11, y - 11, 22, 22);
      }
      ctx.restore();
      for (const c of this.worldCoins) {
        const x = c.x - camLeft,
          y = c.y - camTop;
        if (x < -12 || x > vw + 12 || y < -12 || y > vh + 12) continue;
        if (c.t > 20 && Math.floor(c.t * 8) % 2 === 0) continue;
        ctx.drawImage(coinSprite(Math.floor(c.t * 10 + c.x)), x - 5.5, y - 5.5, 11, 11);
      }
    }

    this.residents.drawLines(ctx, camLeft, camTop);

    // Giant Clam Pearls & Glowing Power-Up Bubbles
    for (const o of this.orbs) {
      const x = o.x - camLeft;
      const y = o.y - camTop;
      if (x < -24 || x > vw + 24 || y < -24 || y > vh + 24) continue;
      const pulse = 1 + Math.sin(t * 4.5 + o.ph) * 0.08;
      const glowCol =
        o.kind === "pearl"
          ? "rgba(255, 232, 130, 0.7)"
          : o.kind === "turbo"
            ? "rgba(80, 232, 255, 0.72)"
            : o.kind === "vortex"
              ? "rgba(255, 175, 80, 0.72)"
              : "rgba(95, 242, 185, 0.72)";
      ctx.save();
      ctx.globalCompositeOperation = "lighter";
      ctx.globalAlpha = 0.55 + Math.sin(t * 3.5 + o.ph) * 0.16;
      ctx.drawImage(glowOrb(glowCol, false), x - 18 * pulse, y - 18 * pulse, 36 * pulse, 36 * pulse);
      ctx.restore();

      ctx.save();
      ctx.translate(x, y);
      ctx.scale(pulse, pulse);
      if (o.kind === "pearl") {
        // Cached iridescent mother-of-pearl sprite + dynamic specular star glint
        ctx.drawImage(getPearlSprite(), -9.5, -9.5, 19, 19);
        ctx.fillStyle = "#ffffff";
        ctx.beginPath();
        ctx.arc(-2.5, -2.5, 1.9, 0, Math.PI * 2);
        ctx.fill();
        const gl = 3.2 + Math.sin(t * 6 + o.ph) * 0.8;
        ctx.strokeStyle = "rgba(255, 255, 255, 0.92)";
        ctx.lineWidth = 0.9;
        ctx.beginPath();
        ctx.moveTo(-2.5 - gl, -2.5);
        ctx.lineTo(-2.5 + gl, -2.5);
        ctx.moveTo(-2.5, -2.5 - gl);
        ctx.lineTo(-2.5, -2.5 + gl);
        ctx.stroke();
      } else {
        const coreCol = o.kind === "turbo" ? "#22d3ee" : o.kind === "vortex" ? "#fb923c" : "#34d399";
        ctx.fillStyle = "rgba(10, 32, 68, 0.55)";
        ctx.beginPath();
        ctx.arc(0, 0, 8.6, 0, Math.PI * 2);
        ctx.fill();
        ctx.strokeStyle = coreCol;
        ctx.lineWidth = 1.7;
        ctx.stroke();
        ctx.fillStyle = coreCol;
        if (o.kind === "turbo") {
          ctx.beginPath();
          ctx.moveTo(1.5, -5.2);
          ctx.lineTo(-3.5, 0.5);
          ctx.lineTo(0, 0.5);
          ctx.lineTo(-1.5, 5.2);
          ctx.lineTo(3.8, -0.5);
          ctx.lineTo(0.2, -0.5);
          ctx.closePath();
          ctx.fill();
        } else if (o.kind === "vortex") {
          ctx.lineWidth = 1.8;
          ctx.beginPath();
          ctx.arc(0, 0, 4.4, 0, Math.PI * 1.55);
          ctx.stroke();
          ctx.beginPath();
          ctx.arc(0, 0, 1.8, 0, Math.PI * 2);
          ctx.fill();
        } else {
          ctx.beginPath();
          ctx.moveTo(0, -5);
          ctx.lineTo(4.4, -2.5);
          ctx.quadraticCurveTo(4.2, 2.8, 0, 5.4);
          ctx.quadraticCurveTo(-4.2, 2.8, -4.4, -2.5);
          ctx.closePath();
          ctx.fill();
        }
        ctx.fillStyle = "rgba(255, 255, 255, 0.85)";
        ctx.beginPath();
        ctx.arc(-3.5, -3.5, 1.6, 0, Math.PI * 2);
        ctx.fill();
      }
      ctx.restore();
    }

    // Spiked Feeding Frenzy Naval Sea Mines
    this.drawMines(camLeft, camTop, vw, vh, t);

    const litAfter = this.oceanLighting === "after" && !this.pixelMode;

    // Pure-3D Ambient Marine Decor: Spanish Dancer & RGB Comb Jelly
    if (!this.menuActive && this.decor3d.items.length) {
      const dancerGlow = (this.orbDancerGlow ??= glowOrb("rgba(255, 110, 72, 0.56)", false));
      const combGlow = (this.orbCombGlow ??= glowOrb("rgba(103, 232, 249, 0.62)", false));
      this.decor3d.draw(
        ctx,
        camLeft,
        camTop,
        vw,
        vh,
        t,
        scale,
        dancerGlow,
        combGlow,
        litAfter,
        (wx, wy) => this.sampleOceanLight(wx, wy)
      );
      ctx.setTransform(scale, 0, 0, scale, 0, 0);
    }

    // Non-playable Pure-3D Ocean Sunfish (Mola-mola) 6-bite Food Bonus creatures
    if (this.sunfish.length) {
      const sfGlow = (this.orbSunfishGlow ??= glowOrb("rgba(125, 228, 255, 0.58)", false));
      for (const sf of this.sunfish) {
        if (sf.dead) continue;
        const m = sf.r * 2.4 + 32;
        if (sf.x < camLeft - m || sf.x > camLeft + vw + m || sf.y < camTop - m || sf.y > camTop + vh + m) continue;
        const olSf = litAfter ? this.sampleOceanLight(sf.x, sf.y) : null;
        drawSunfish(ctx, sf, camLeft, camTop, t, scale, sfGlow, litAfter, olSf);
      }
      ctx.setTransform(scale, 0, 0, scale, 0, 0);
    }

    // only fish near the view are sorted & drawn (the ocean holds ~650)
    const sorted = this.vis;
    sorted.length = 0;
    for (const f of this.fish) {
      if (f.dead) continue;
      const m = f.r * 3 + 70;
      const fx = f.eatenBy ? f.eatFromX : f.x,
        fy = f.eatenBy ? f.eatFromY : f.y;
      if (fx < camLeft - m || fx > camLeft + vw + m || fy < camTop - m || fy > camTop + vh + m) continue;
      sorted.push(f);
    }
    sorted.sort((a, b) => (a.eatenBy ? 1 : 0) - (b.eatenBy ? 1 : 0) || a.r - b.r);

    // 3D Stage-Aware Player Lighting: sunlit caustic shimmer up high -> multi-cone volumetric headlamp in deep zones
    const p = this.player;
    if (p && !p.dead && !p.eatenBy) {
      if (p.y < 520 && !this.pixelMode) {
        const sunK = clamp(1 - p.y / 520, 0, 1);
        const haloR = p.r * 3.8 + 26;
        ctx.globalCompositeOperation = "lighter";
        ctx.globalAlpha = 0.22 * sunK;
        ctx.drawImage((this.orbPlayerSun ??= glowOrb("rgba(195, 252, 255, 0.58)", false)), p.x - camLeft - haloR, p.y - camTop - haloR, haloR * 2, haloR * 2);
        ctx.globalAlpha = 1;
        ctx.globalCompositeOperation = "source-over";
      }
      if (p.y > DEEP_START - 160) {
        const kDeep = clamp((p.y - (DEEP_START - 160)) / 340, 0, 1);
        const outerOrb = (this.orbLampOuter ??= glowOrb("rgba(65, 195, 255, 0.48)", false));
        const coreOrb = (this.orbLampCore ??= glowOrb("rgba(205, 252, 255, 0.65)", false));
        const haloR = p.r * 5.8 + 52;
        ctx.globalCompositeOperation = "lighter";
        ctx.globalAlpha = 0.44 * kDeep;
        ctx.drawImage(outerOrb, p.x - camLeft - haloR, p.y - camTop - haloR, haloR * 2, haloR * 2);
        const ang = Math.atan2(Math.sin(p.tilt), p.face * Math.cos(p.tilt));
        const cs = Math.cos(ang) * scale,
          sn = Math.sin(ang) * scale;
        ctx.setTransform(cs, sn, -sn, cs, (p.mouthX() - camLeft) * scale, (p.mouthY() - camTop) * scale);
        // Wide volumetric outer cone
        const wideRx = p.r * 4.4 + 62,
          wideRy = wideRx * 0.46;
        ctx.globalAlpha = 0.34 * kDeep;
        ctx.drawImage(outerOrb, -wideRx * 0.22, -wideRy, wideRx * 2, wideRy * 2);
        // Bright focused inner volumetric cone
        const innerRx = p.r * 3.0 + 40,
          innerRy = innerRx * 0.28;
        ctx.globalAlpha = 0.48 * kDeep;
        ctx.drawImage(coreOrb, -innerRx * 0.14, -innerRy, innerRx * 2, innerRy * 2);
        ctx.setTransform(scale, 0, 0, scale, 0, 0);
        ctx.globalAlpha = 1;
        ctx.globalCompositeOperation = "source-over";
      }
    }

    // Soft Suction Vortex Cones & Gossamer Ribbons
    for (const f of sorted) {
      if (f.sucking && !f.eatenBy) {
        this.drawSoftSuctionVortex(f, camLeft, camTop, vw, vh);
      }
    }

    // Near Game 2 medusae in 2D mode
    if (!laut) this.medusae.drawCached(ctx, camLeft, camTop, vw, vh, true);

    // Draw Fish
    for (const f of sorted) this.drawFish(f, camLeft, camTop);

    // Foreground cave upper arch lips & stalactites drawn over fish tucked inside caves
    if (laut) laut.drawPass(2, ctx); // 3D cave lips over fish tucked inside the caves
    oc.drawCaveForeground(ctx, camLeft, camTop, vw, vh, t, p && !p.dead && !p.eatenBy && p.hiddenCave ? p.hiddenCave.id : null, !!laut);

    // ---------- particles in two passes (normal, then additive): the blend mode is switched twice per
    // frame instead of save/restore around every single particle ----------
    const parts = this.particles;
    const bub = getBubbleStamp();
    const gold = (this.orbPartGold ??= glowOrb("rgba(255, 196, 40, 0.98)", false));
    ctx.lineCap = "round";
    for (const pt of parts) {
      const ty = pt.type;
      if (ty !== "bubble" && ty !== "bit" && ty !== "splash" && ty !== "streak" && ty !== "glint" && ty !== "smoke") continue;
      const x = pt.x - camLeft,
        y = pt.y - camTop;
      if (x < -45 || x > vw + 45 || y < -45 || y > vh + 45) continue;
      const k = clamp(pt.life / pt.max, 0, 1);
      if (ty === "bubble") {
        const r = Math.max(1.4, pt.size * 1.35);
        const age = pt.max - pt.life;
        const sq = 1 + Math.sin(age * 9 + pt.size * 5) * Math.min(0.18, 0.05 + pt.size * 0.03); // oblate wobble
        ctx.globalAlpha = Math.min(1, age * 6) * Math.min(1, k * 8);
        ctx.drawImage(bub, x - r * sq, y - r / sq, r * 2 * sq, (r * 2) / sq);
        ctx.globalAlpha = 1;
      } else if (ty === "splash") {
        const r = pt.size * (0.55 + k * 0.65);
        ctx.globalAlpha = Math.min(1, k * 1.4);
        ctx.fillStyle = pt.color;
        ctx.beginPath();
        ctx.arc(x, y, r, 0, Math.PI * 2);
        ctx.fill();
        ctx.globalAlpha = 1;
      } else if (ty === "smoke") {
        const r = pt.size * (0.75 + (1 - k) * 1.45);
        ctx.globalAlpha = k * 0.62;
        ctx.fillStyle = pt.color;
        ctx.beginPath();
        ctx.arc(x, y, r, 0, Math.PI * 2);
        ctx.fill();
        ctx.globalAlpha = 1;
      } else if (ty === "bit") {
        const rad = pt.size * (0.8 + k * 0.8);
        ctx.globalAlpha = k;
        ctx.drawImage(glowOrb(pt.color, true), x - rad, y - rad, rad * 2, rad * 2);
        ctx.globalAlpha = 1;
      } else if (ty === "glint") {
        const rad = 2.4 * k + 0.4;
        ctx.drawImage(gold, x - rad, y - rad, rad * 2, rad * 2);
      } else {
        const d = Math.hypot(pt.vx, pt.vy) || 1;
        const len = 6 + k * 10;
        ctx.globalAlpha = k * 0.5;
        ctx.strokeStyle = "#d2fcff";
        ctx.lineWidth = 1.8 * k;
        ctx.beginPath();
        ctx.moveTo(x, y);
        ctx.lineTo(x + (pt.vx / d) * len, y + (pt.vy / d) * len);
        ctx.stroke();
        ctx.globalAlpha = 1;
      }
    }
    ctx.globalCompositeOperation = "lighter";
    const mistOrb = (this.orbPartMist ??= glowOrb("#7dd3fc", true));
    for (const pt of parts) {
      const ty = pt.type;
      if (ty === "bubble" || ty === "bit" || ty === "splash" || ty === "streak" || ty === "glint" || ty === "smoke") continue;
      const x = pt.x - camLeft,
        y = pt.y - camTop;
      if (x < -45 || x > vw + 45 || y < -45 || y > vh + 45) continue;
      const k = clamp(pt.life / pt.max, 0, 1);
      if (ty === "chomp") {
        // silky bite ripple: two crescents closing on each other
        const r = pt.size * (0.65 + (1 - k) * 0.48);
        const oy = r * (0.42 - (1 - k) * 0.45);
        const a0 = (pt.dir || 1) > 0 ? -0.5 : Math.PI - 0.5;
        ctx.globalAlpha = k * 0.75;
        ctx.strokeStyle = "rgba(224, 248, 255, 0.9)";
        ctx.lineWidth = 2.0 * k + 0.6;
        ctx.beginPath();
        ctx.arc(x, y - oy, r, a0, a0 + 1);
        ctx.moveTo(x + Math.cos(a0) * r, y + oy + Math.sin(a0) * r);
        ctx.arc(x, y + oy, r, a0, a0 + 1);
        ctx.stroke();
      } else if (ty === "suck") {
        const rad = pt.size * 1.45;
        ctx.globalAlpha = Math.sin(k * Math.PI) * 0.36;
        ctx.drawImage(mistOrb, x - rad, y - rad, rad * 2, rad * 2);
      } else if (ty === "blast") {
        const rad = pt.size * (0.65 + (1 - k) * 1.35);
        ctx.globalAlpha = k * 0.9;
        ctx.drawImage(glowOrb(pt.color, true), x - rad, y - rad, rad * 2, rad * 2);
      } else if (ty === "ring") {
        const r = pt.size * (0.88 + (1 - k) * 1.65);
        const asp = pt.aspect ?? 1;
        ctx.globalAlpha = k * (asp < 1 ? 0.65 : 0.52);
        ctx.strokeStyle = pt.color;
        ctx.lineWidth = (asp < 1 ? 2.6 : 2.2) * k;
        ctx.beginPath();
        if (asp < 0.99) ctx.ellipse(x, y, r, r * asp, 0, 0, Math.PI * 2);
        else ctx.arc(x, y, r, 0, Math.PI * 2);
        ctx.stroke();
      } else {
        const rad = 3.8 * k + 1.2;
        ctx.globalAlpha = 1;
        ctx.drawImage(glowOrb(pt.color, true), x - rad, y - rad, rad * 2, rad * 2);
      }
    }

    // coins flying to the counter: all glows (still additive), then the coins themselves
    const coinGlow = (this.orbCoinGlow ??= glowOrb("rgba(255, 214, 80, 0.55)", false));
    const coinSc = (c: FlyCoin) => {
      // elastic pop-in, then the coin shrinks a little while it swoops into the counter
      const k = c.t / COIN_POP;
      return k < 0.45 ? 0.3 + k * 2.3 : k < 1 ? 1.34 - (k - 0.45) * 0.62 : 1 - Math.min(1, (c.t - COIN_POP) / COIN_FLY) * 0.3;
    };
    ctx.globalAlpha = 0.6;
    for (const c of this.flyCoins) {
      if (c.t < 0) continue;
      const sc = coinSc(c);
      ctx.drawImage(coinGlow, c.x - camLeft - 10 * sc, c.y - camTop - 10 * sc, 20 * sc, 20 * sc);
    }
    ctx.globalAlpha = 1;
    ctx.globalCompositeOperation = "source-over";
    for (const c of this.flyCoins) {
      if (c.t < 0) continue;
      const sc = coinSc(c);
      ctx.drawImage(coinSprite(Math.floor(c.t * 22)), c.x - camLeft - 5.5 * sc, c.y - camTop - 5.5 * sc, 11 * sc, 11 * sc);
    }

    // Dynamic propagating ocean surface waves (gelombang air) scaled to entering/exiting fish size
    if (this.surfaceWaves.length > 0 && camTop < 140) {
      const sy = SURFACE_Y - camTop;
      ctx.save();
      for (const sw of this.surfaceWaves) {
        const sx = sw.x - camLeft;
        const reach = clamp(sw.r * (sw.entering ? 7.6 : 5.2) * sw.strength, 36, 340);
        if (sx < -reach - 40 || sx > vw + reach + 40) continue;
        const u = clamp(sw.age / sw.maxAge, 0, 1);
        const fade = Math.pow(1 - u, 1.3);
        const curSpan = reach * (0.16 + 0.84 * Math.pow(u, 0.68));
        const peakH = clamp(sw.r * (sw.entering ? 0.68 : 0.42) * sw.strength, 4.5, 36) * fade;
        const steps = 28;
        const frontDist = curSpan * 0.72;
        const waveK = (Math.PI * 2.4) / Math.max(22, reach * 0.38);

        // Filled translucent aqua wave swell
        ctx.beginPath();
        for (let i = 0; i <= steps; i++) {
          const f = (i / steps) * 2 - 1;
          const dx = f * curSpan;
          const ad = Math.abs(dx);
          const env = Math.exp(-Math.pow((ad - frontDist) / Math.max(14, curSpan * 0.34), 2)) + 0.45 * Math.exp(-Math.pow(ad / Math.max(10, reach * 0.18), 2));
          const osc = Math.cos((ad - frontDist) * waveK);
          const wy = sy - (0.55 + 0.45 * osc) * peakH * env;
          if (i === 0) ctx.moveTo(sx + dx, sy + 3);
          ctx.lineTo(sx + dx, wy);
        }
        ctx.lineTo(sx + curSpan, sy + 3);
        ctx.closePath();
        ctx.fillStyle = `rgba(125, 232, 250, ${(0.44 * fade).toFixed(3)})`;
        ctx.fill();

        // Crisp foaming white crest line along top of traveling wave
        ctx.beginPath();
        for (let i = 0; i <= steps; i++) {
          const f = (i / steps) * 2 - 1;
          const dx = f * curSpan;
          const ad = Math.abs(dx);
          const env = Math.exp(-Math.pow((ad - frontDist) / Math.max(14, curSpan * 0.34), 2)) + 0.45 * Math.exp(-Math.pow(ad / Math.max(10, reach * 0.18), 2));
          const osc = Math.cos((ad - frontDist) * waveK);
          const wy = sy - (0.55 + 0.45 * osc) * peakH * env;
          if (i === 0) ctx.moveTo(sx + dx, wy);
          else ctx.lineTo(sx + dx, wy);
        }
        ctx.strokeStyle = `rgba(255, 255, 255, ${(0.95 * fade).toFixed(3)})`;
        ctx.lineWidth = clamp(1.6 + sw.r * 0.068, 1.6, 4.5) * (0.45 + 0.55 * fade);
        ctx.stroke();

        // Central splash crown plume during the early plunge/breach burst
        if (sw.entering && u < 0.48) {
          const crK = Math.sin((u / 0.48) * Math.PI);
          const crW = clamp(sw.r * 1.45 * sw.strength, 10, 88) * (0.55 + u * 1.2);
          const crH = peakH * 1.55 * crK;
          ctx.strokeStyle = `rgba(255, 255, 255, ${(0.92 * crK).toFixed(3)})`;
          ctx.lineWidth = clamp(1.9 + sw.r * 0.06, 1.6, 4.4);
          ctx.beginPath();
          ctx.moveTo(sx - crW, sy);
          ctx.quadraticCurveTo(sx - crW * 0.45, sy - crH * 1.2, sx - crW * 0.12, sy - crH * 0.42);
          ctx.moveTo(sx + crW, sy);
          ctx.quadraticCurveTo(sx + crW * 0.45, sy - crH * 1.2, sx + crW * 0.12, sy - crH * 0.42);
          ctx.stroke();
        }
      }
      ctx.restore();
    }

    // Floating glossy balloons carrying stopwatches ("jam") & bonus skill medallions above water
    if (this.balloons.length > 0 && camTop < 140) {
      for (const b of this.balloons) {
        const bx = b.x - camLeft;
        const by = b.y - camTop;
        if (bx < -42 || bx > vw + 42 || by < -55 || by > vh + 24) continue;
        drawSkyBalloon(ctx, b, camLeft, camTop, t);
      }
    }

    // ---------- names, warnings & floating numbers: cached text sprites ----------
    if (!this.menuActive) {
      for (const f of sorted) {
        if (f.eatenBy) continue;
        const x = f.x - camLeft,
          y = f.y - camTop - f.r * 1.15 - 8;
        if (x < -60 || x > vw + 60 || y < -25 || y > vh + 40) continue;
        if (f.kind !== "npc") {
          if (f === p && this.caveVisAlpha > 0.01) continue;
          const col =
            f.kind === "player"
              ? "#ffffff"
              : p && !p.dead && this.canEat(f, p)
                ? "#ff9494"
                : p && !p.dead && this.canEat(p, f)
                  ? "#a8ffbe"
                  : "#e8f4ff";
          const L = this.label(f.name, col, 9);
          ctx.drawImage(L.cv, x - L.w / 2, y - L.h / 2, L.w, L.h);
          if (f.id === this.leaderId) this.drawCrown(x, y - 9);
        }
        if (p && !p.dead && !p.hiddenCave && f !== p && this.canEat(f, p) && p.invuln <= 0) {
          const dx = f.x - p.x,
            dy = f.y - p.y;
          const d2 = dx * dx + dy * dy;
          if (d2 < 40000) {
            const hunting = f.ai.target === p || (f.kind === "bot" && d2 < 25600);
            if (hunting && Math.floor(t * 6) % 2 === 0) {
              const L = this.label("!", "#ff3b4e", 11);
              ctx.drawImage(L.cv, x - L.w / 2, y - (f.kind === "npc" ? 0 : 11) - L.h / 2, L.w, L.h);
            }
          }
        }
      }
    }

    // slurp-chain counter riding next to the player: pops on every bite, with a draining combo timer
    if (p && !p.dead && !p.eatenBy && p.combo >= 2 && p.comboT > 0) {
      const kT = clamp(p.comboT / 2.6, 0, 1);
      const col = p.combo >= 10 ? "#ff7ad9" : p.combo >= 5 ? "#ffb347" : "#fff066";
      const L = this.label("x" + p.combo, col, 10 + Math.min(5, Math.round(p.combo * 0.22)));
      const sc = 1 + this.chainPop * 0.55;
      const cx = p.x - camLeft - p.face * (p.r * 0.9 + 13),
        cy = p.y - camTop - p.r * 1.15 - 22;
      ctx.globalAlpha = Math.min(1, kT * 5);
      ctx.drawImage(L.cv, cx - (L.w * sc) / 2, cy - (L.h * sc) / 2, L.w * sc, L.h * sc);
      ctx.fillStyle = "rgba(8, 22, 52, 0.75)";
      ctx.fillRect(cx - 8, cy + 7, 16, 2);
      ctx.fillStyle = col;
      ctx.fillRect(cx - 8, cy + 7, 16 * kT, 2);
      ctx.globalAlpha = 1;
    }

    for (const tx of this.texts) {
      const k = tx.life / tx.max;
      // squash-in pop: starts small, overshoots, settles
      const pop = k > 0.86 ? 0.5 + ((1 - k) / 0.14) * 0.78 : k > 0.72 ? 1.28 - ((0.86 - k) / 0.14) * 0.28 : 1;
      const L = this.label(tx.text, tx.color, tx.size + 2);
      ctx.globalAlpha = k < 0.3 ? k / 0.3 : 1;
      ctx.drawImage(L.cv, tx.x - camLeft - (L.w * pop) / 2, tx.y - camTop - (L.h * pop) / 2, L.w * pop, L.h * pop);
    }
    ctx.globalAlpha = 1;

    if (laut) {
      laut.drawPass(3, ctx); // crisp light shafts + foreground coral & kelp silhouettes
    } else {
      oc.drawLight(ctx, 1, camLeft, camTop, vw, vh, t); // light shafts falling in front of the reef and the fish
      // Layer 6 (1.24x): Foreground Parallax Coral, Crystal & Giant Kelp Silhouettes!
      oc.drawForegroundParallax(ctx, camLeft, camTop, vw, vh, t);
    }
    oc.drawSurface(ctx, camLeft, camTop, vw, t);
    oc.drawVignette(ctx, camTop, vw, vh);

    // Directional cave darkness & sight-cone mask (limits sight strictly to cave interior + outside of entrance!)
    this.drawCaveSightMask(ctx, camLeft, camTop, vw, vh);

    // Keep player name, TERSEMBUNYI indicator, and crown sharp & legible above the cave visibility veil
    if (p && !p.dead && !p.eatenBy && this.caveVisAlpha > 0.01) {
      const px = p.x - camLeft;
      const py = p.y - camTop - p.r * 1.15 - 8;
      if (px >= -60 && px <= vw + 60 && py >= -25 && py <= vh + 40) {
        const L = this.label(p.name, "#ffffff", 9);
        ctx.drawImage(L.cv, px - L.w / 2, py - L.h / 2, L.w, L.h);
        if (p.hiddenCave) {
          const S = this.label(this.lang === "id" ? "TERSEMBUNYI" : "HIDDEN", "#7efce8", 7.5);
          ctx.drawImage(S.cv, px - S.w / 2, py - L.h * 0.5 - S.h * 0.65 - 2, S.w, S.h);
        }
        if (p.id === this.leaderId) this.drawCrown(px, py - (p.hiddenCave ? 19 : 9));
      }
    }

    // Depth-level gauge + zone title card
    if (focus && !focus.eatenBy) oc.drawHud(ctx, vw, vh, focus.y, t);

    // Off-screen predator edge-of-screen warning chevrons
    if (p && !p.dead && !p.eatenBy && !p.hiddenCave && p.invuln <= 0) {
      for (const f of this.predators) {
        if (f === p || f.dead || f.eatenBy || !this.canEat(f, p)) continue;
        const sx = f.x - camLeft;
        const sy = f.y - camTop;
        if (sx >= -12 && sx <= vw + 12 && sy >= -12 && sy <= vh + 12) continue;
        const dx = f.x - p.x,
          dy = f.y - p.y;
        const d2 = dx * dx + dy * dy;
        if (d2 > 108900) continue;
        const d = Math.sqrt(d2);
        const ang = Math.atan2(sy - vh * 0.5, sx - vw * 0.5);
        const pad = 16;
        const edgeX = clamp(sx, pad, vw - pad);
        const edgeY = clamp(sy, pad + 26, vh - pad);
        const pulse = 0.65 + 0.35 * Math.sin(t * 11);
        ctx.save();
        ctx.translate(edgeX, edgeY);
        ctx.rotate(ang);
        ctx.globalAlpha = pulse * clamp(1 - (d - 110) / 220, 0.35, 1);
        ctx.fillStyle = "#ff4757";
        ctx.strokeStyle = "#fff5f5";
        ctx.lineWidth = 1.2;
        ctx.beginPath();
        ctx.moveTo(6, 0);
        ctx.lineTo(-4.5, -4.5);
        ctx.lineTo(-2.2, 0);
        ctx.lineTo(-4.5, 4.5);
        ctx.closePath();
        ctx.fill();
        ctx.stroke();
        ctx.restore();
      }
    }

    // Jellyfish shock arcs + 3D cartoon orbiting yellow stars above head (jellyfish stun OR poison dizziness)
    if (p && !p.dead && !p.eatenBy && (this.stunT > 0 || this.poisonDizzyT > 0)) {
      if (this.stunT > 0) {
        this.medusae.drawShock(ctx, p.x - camLeft, p.y - camTop, p.r);
      }
      const starSpan = Math.max(26, p.r * 3.0);
      const heightMult = Math.max(1.32, p.sp.hRatio * 1.12);
      const sx = p.x - camLeft - starSpan * 0.5;
      const sy = p.y - camTop - p.r * heightMult - starSpan * 0.5;
      ctx.setTransform(scale, 0, 0, scale, 0, 0);
      const drewStars = fish3d.renderDizzyStars(ctx, sx, sy, starSpan, starSpan, t, starSpan * scale * 1.25);
      if (!drewStars) {
        ctx.save();
        for (let k = 0; k < 5; k++) {
          const a = t * 4.8 + (k / 5) * Math.PI * 2;
          const kx = p.x - camLeft + Math.cos(a) * p.r * 1.05;
          const ky = p.y - camTop - p.r * 1.25 + Math.sin(a) * p.r * 0.34;
          ctx.fillStyle = k % 2 ? "#fde047" : "#fef08a";
          ctx.strokeStyle = "#5c2d00";
          ctx.lineWidth = 0.9;
          ctx.beginPath();
          for (let i = 0; i < 10; i++) {
            const rr = i % 2 ? 1.5 : 3.4;
            const aa = (i / 10) * Math.PI * 2 + t * 5;
            if (i === 0) ctx.moveTo(kx + Math.cos(aa) * rr, ky + Math.sin(aa) * rr);
            else ctx.lineTo(kx + Math.cos(aa) * rr, ky + Math.sin(aa) * rr);
          }
          ctx.closePath();
          ctx.fill();
          ctx.stroke();
        }
        ctx.restore();
      }
    }

    // Fiery blast screen flash on mine detonation
    if (this.blastFlash > 0.01) {
      ctx.save();
      ctx.globalCompositeOperation = "lighter";
      ctx.globalAlpha = this.blastFlash * 0.55;
      ctx.fillStyle = "rgb(255, 165, 65)";
      ctx.fillRect(0, 0, vw + 2, vh + 2);
      ctx.restore();
    }
  }

  drawCrown(x: number, y: number) {
    const ctx = this.ctx;
    ctx.save();
    ctx.translate(x, y);
    ctx.beginPath();
    ctx.moveTo(-4.5, 2.5);
    ctx.lineTo(-5.2, -2.5);
    ctx.lineTo(-2, 0.2);
    ctx.lineTo(0, -3.5);
    ctx.lineTo(2, 0.2);
    ctx.lineTo(5.2, -2.5);
    ctx.lineTo(4.5, 2.5);
    ctx.closePath();
    ctx.fillStyle = "#ffd43b";
    ctx.fill();
    ctx.strokeStyle = "#4a2500";
    ctx.lineWidth = 1.2;
    ctx.lineJoin = "round";
    ctx.stroke();
    ctx.restore();
  }

  outlinedText(s: string, x: number, y: number, col: string, strokeW = 2.5) {
    const ctx = this.ctx;
    ctx.lineJoin = "round";
    ctx.miterLimit = 2;
    ctx.strokeStyle = "rgba(8, 22, 52, 0.88)";
    ctx.lineWidth = strokeW;
    ctx.strokeText(s, x, y);
    ctx.fillStyle = col;
    ctx.fillText(s, x, y);
  }

  drawFish(f: Fish, camLeft: number, camTop: number) {
    const ctx = this.ctx;
    let x = f.x,
      y = f.y,
      sc = 1;
    let rot = f.tilt;
    let face = f.face;
    if (!f.eatenBy && f.biteLunge !== 0) {
      const wr = (f.turnFlip >= 0 ? 1 : -1) * rot;
      x += Math.cos(wr) * f.turnFlip * f.biteLunge;
      y += Math.sin(wr) * f.turnFlip * f.biteLunge;
    }
    const spd = Math.hypot(f.vx, f.vy);
    let sx = 1 - f.sq * 0.56 + Math.min(0.08, spd * 0.0005) + (f.boosting ? 0.12 : 0);
    let sy = 1 + f.sq * 0.82 - Math.min(0.05, spd * 0.00035) - (f.boosting ? 0.06 : 0);

    if (f.jaw > 0.18 && !f.eatenBy) {
      sy += (f.jaw - 0.18) * 0.18;
      sx -= (f.jaw - 0.18) * 0.07;
    }

    if (f.sp.style === "puffer" && !f.eatenBy) {
      // the pufferfish balloons up while it vacuums and right after a gulp
      const pf = f.suckVis * 0.16 + Math.max(0, f.gulpT) * 0.06;
      sx *= 1 + pf * 0.5;
      sy *= 1 + pf;
    }

    if (f.eatenBy) {
      const e = f.eatenBy;
      if (e.sp.style === "octopus") {
        // Stage 1 (0..0.34): 2 front tentacles reach & clasp prey at (grabX, grabY)
        // Stage 2 (0.34..0.82): clasped tentacles sweep & pull prey underneath head to (underX, underY)
        // Stage 3 (0.82..1.00): prey slips into beak under head & gets HAP!-swallowed
        const cosT = Math.cos(e.tilt);
        const sinT = Math.sin(e.tilt);
        const gxOff = e.r * 1.28;
        const gyOff = e.r * 0.18;
        const grabX = e.x + e.face * (gxOff * cosT - gyOff * sinT);
        const grabY = e.y + (gxOff * sinT + gyOff * cosT);
        const uxOff = e.r * 0.14;
        const uyOff = e.r * 0.34;
        const underX = e.x + e.face * (uxOff * cosT - uyOff * sinT);
        const underY = e.y + (uxOff * sinT + uyOff * cosT);
        if (f.eatT < 0.34) {
          const k0 = f.eatT / 0.34;
          const s0 = k0 * k0 * (3 - 2 * k0);
          x = f.eatFromX + (grabX - f.eatFromX) * s0;
          y = f.eatFromY + (grabY - f.eatFromY) * s0;
          sc = 1 - s0 * 0.04;
        } else {
          const k1 = (f.eatT - 0.34) / 0.66;
          const s1 = k1 * k1 * (3 - 2 * k1);
          x = grabX + (underX - grabX) * s1;
          y = grabY + (underY - grabY) * s1 + Math.sin(k1 * Math.PI) * e.r * 0.24;
          const hapPhase = k1 < 0.64 ? 0 : (k1 - 0.64) / 0.36;
          sc = Math.max(0.06, 0.96 - Math.pow(hapPhase, 1.35) * 0.90);
        }
        sx *= 1 + Math.max(0, f.eatT - 0.55) * 0.55;
        sy *= 1 - Math.max(0, f.eatT - 0.55) * 0.42;
        const dx = underX - f.eatFromX;
        const dy = underY - f.eatFromY;
        face = dx >= 0 ? -1 : 1;
        rot = Math.atan2(dy, Math.abs(dx) + 8) * (dx >= 0 ? -0.7 : 0.7);
      } else {
        const mx = e.mouthX() - e.face * e.r * 0.14 * f.eatT,
          my = e.mouthY();
        const k = Math.pow(f.eatT, 1.45);
        x = f.eatFromX + (mx - f.eatFromX) * k;
        y = f.eatFromY + (my - f.eatFromY) * k - Math.sin(f.eatT * Math.PI) * Math.min(8, e.r * 0.22);
        const lateShrink = f.eatT < 0.42 ? 0 : (f.eatT - 0.42) / 0.58;
        sc = Math.max(0.08, 1 - Math.pow(lateShrink, 1.35) * 0.86);
        sx *= 1 + f.eatT * 0.64;
        sy *= 1 - f.eatT * 0.4;
        const dx = mx - f.eatFromX,
          dy = my - f.eatFromY;
        face = dx >= 0 ? -1 : 1;
        rot = Math.atan2(dy, Math.abs(dx) + 8) * (dx >= 0 ? -0.85 : 0.85);
      }
    }

    const scrX = x - camLeft,
      scrY = y - camTop;
    const reach = f.r * 2.6;
    if (scrX < -reach || scrX > this.vw + reach || scrY < -reach || scrY > this.vh + reach) return;

    // Soft bioluminescent lure light pool for the anglerfish in deep water (pre-rendered glow)
    if (f.sp.lure && !f.eatenBy && f.y > DEEP_START - 200) {
      const lr = f.r * 2.6 + 18;
      ctx.globalCompositeOperation = "lighter";
      ctx.globalAlpha = 0.7;
      ctx.drawImage((this.orbAnglerLure ??= glowOrb("rgba(40, 215, 255, 0.58)", false)), scrX + face * f.r * 1.15 - lr, scrY - f.r * 0.95 - lr, lr * 2, lr * 2);
      ctx.globalAlpha = 1;
      ctx.globalCompositeOperation = "source-over";
    }

    // lanternfish fry carry their own little light
    if (f.fry && f.sp.pal.lure && !f.eatenBy && f.id % 3 === 0) {
      // one shared glow for every third fish of the shoal (same look, a third of the blending)
      const gr = f.r * 5.2;
      ctx.globalCompositeOperation = "lighter";
      ctx.globalAlpha = 0.55;
      ctx.drawImage((this.orbFryLure ??= glowOrb("rgba(111, 240, 255, 0.5)", false)), scrX - gr, scrY - gr, gr * 2, gr * 2);
      ctx.globalAlpha = 1;
      ctx.globalCompositeOperation = "source-over";
    }

    if (f.sucked > 0 && !f.eatenBy) {
      y += Math.sin(this.t * 28 + f.id * 1.7) * 0.55;
      sx *= 1.14;
      sy *= 0.88;
    }

    let jawState: JawState = 0;
    if (f.eatenBy) jawState = 6;
    else if (f.jaw <= -0.12) jawState = -1;
    else if (f.jaw >= 0.08) jawState = Math.min(6, Math.max(1, Math.round(f.jaw * 6))) as JawState;

    let expr: EyeExpr = "normal";
    if (f.eatenBy || f.sucked > 0) expr = "panic";
    else if ((f.chompPhase > 0 && f.chompBitFired) || (f.chompPhase <= 0 && f.chompT > 0.02)) expr = "happy";

    const isPure3D = f.sp.style === "octopus" || f.sp.style === "whaleshark";
    const spr = isPure3D ? null : fishSprite(f.sp, fishLen(f.r), jawState, f.tailPh, f.key, this.pixelMode, expr, f.kind === "player");

    // Golden Sardine Frenzy aura on shimmering golden schools
    if (f.fry && f.school?.golden && !f.eatenBy) {
      const gr = f.r * 3.8;
      ctx.globalCompositeOperation = "lighter";
      ctx.globalAlpha = 0.55 + Math.sin(this.t * 8 + f.id) * 0.2;
      ctx.drawImage((this.orbGoldFry ??= glowOrb("rgba(255, 224, 80, 0.72)", false)), scrX - gr, scrY - gr, gr * 2, gr * 2);
      ctx.globalAlpha = 1;
      ctx.globalCompositeOperation = "source-over";
    }

    // Soft dreamy shield / cave-shelter aura when invulnerable, Bubble Shield active, or hidden in cave
    if ((f.invuln > 0 || (f === this.player && (this.shieldT > 0 || f.hiddenCave))) && !f.eatenBy) {
      const hasBubble = f === this.player && this.shieldT > 0;
      const inCave = f === this.player && !!f.hiddenCave;
      ctx.save();
      ctx.globalCompositeOperation = "lighter";
      ctx.globalAlpha = hasBubble ? 0.45 + Math.sin(this.t * 6) * 0.14 : inCave ? 0.28 + Math.sin(this.t * 4.5) * 0.08 : 0.35 + Math.sin(this.t * 8) * 0.15;
      const hr = f.r * (hasBubble ? 2.35 : 2.1);
      ctx.drawImage(
        hasBubble || inCave ? (this.orbShieldGreen ??= glowOrb("rgba(80, 248, 195, 0.56)", false)) : (this.orbInvulnWhite ??= glowOrb("rgba(190, 248, 255, 0.5)", false)),
        x - camLeft - hr,
        y - camTop - hr,
        hr * 2,
        hr * 2
      );
      if (hasBubble) {
        ctx.globalCompositeOperation = "source-over";
        ctx.globalAlpha = this.shieldT < 3 && Math.floor(this.t * 8) % 2 === 0 ? 0.35 : 0.75;
        ctx.strokeStyle = "#6ee7b7";
        ctx.lineWidth = 1.4;
        ctx.beginPath();
        ctx.arc(x - camLeft, y - camTop, f.r * 1.48, 0, Math.PI * 2);
        ctx.stroke();
      }
      ctx.restore();
    }

    const flipX = f.eatenBy ? face : Math.abs(f.turnFlip) < 0.24 ? (f.turnFlip >= 0 ? 0.24 : -0.24) : f.turnFlip;
    const yaw = f.eatenBy ? 0 : 1 - Math.abs(flipX); // 0 = full side profile, ~0.76 = 3D front-angle turn!
    ctx.globalAlpha = 1;
    // idle fish hover gently instead of hanging frozen in the water
    const swim = Math.min(1, spd / 110);
    const hover = f.eatenBy ? 0 : (1 - swim) * Math.sin(this.t * 1.7 + f.id * 1.3) * Math.min(1.2, f.r * 0.06);
    const S0 = this.pxs(),
      worldRot = (flipX >= 0 ? 1 : -1) * rot,
      co = Math.cos(worldRot),
      si = Math.sin(worldRot),
      kx = sx * sc,
      ky = sy * sc;

    // Toxic eerie green-brown halo around poisonous fish
    if (f.sp.poisonous && !f.eatenBy && !this.pixelMode) {
      const pr = f.r * 2.35;
      ctx.globalCompositeOperation = "lighter";
      ctx.globalAlpha = 0.36 + Math.sin(this.t * 6.5 + f.id) * 0.14;
      ctx.drawImage((this.orbPoisonGlow ??= glowOrb("rgba(132, 232, 38, 0.62)", false)), x - camLeft - pr, y - camTop + hover - pr, pr * 2, pr * 2);
      ctx.globalAlpha = 1;
      ctx.globalCompositeOperation = "source-over";
    }

    // Subtle 3D bioluminescent rim aura for rare luminous fish or deep-sea hunters
    if (
      !f.eatenBy &&
      !this.pixelMode &&
      (f.sp.style === "aurora" ||
        f.sp.style === "mandarin" ||
        f.sp.style === "narwhal" ||
        f.sp.style === "seadragon" ||
        f.sp.style === "axolotl" ||
        f.sp.style === "nudibranch" ||
        f.sp.style === "cuttlefish" ||
        f.sp.style === "octopus" ||
        f.sp.style === "whaleshark" ||
        f.sp.id === "skin-lumba_pink" ||
        f.sp.id === "skin-snapturtle_albino")
    ) {
      const rCol =
        f.sp.id === "skin-snapturtle_albino"
          ? "rgba(255, 224, 232, 0.5)"
          : f.sp.id === "skin-lumba_pink"
          ? "rgba(255, 165, 220, 0.48)"
          : f.sp.style === "octopus"
            ? f.sucking || f.jaw > 0.25
              ? "rgba(0, 250, 255, 0.72)"
              : "rgba(34, 211, 238, 0.44)"
            : f.sp.style === "whaleshark"
              ? "rgba(125, 211, 252, 0.44)"
              : f.sp.style === "aurora"
                ? "rgba(110, 245, 255, 0.48)"
                : f.sp.style === "narwhal"
                  ? "rgba(185, 228, 255, 0.44)"
                  : f.sp.style === "seadragon"
                    ? "rgba(158, 255, 198, 0.48)"
                    : f.sp.style === "axolotl"
                      ? "rgba(255, 150, 215, 0.46)"
                      : f.sp.style === "cuttlefish"
                        ? "rgba(56, 225, 255, 0.46)"
                        : f.sp.style === "nudibranch"
                          ? "rgba(168, 120, 255, 0.46)"
                          : "rgba(255, 168, 92, 0.42)";
      const rr = f.r * (f.sp.style === "octopus" && (f.sucking || f.jaw > 0.25) ? 2.55 : 2.15);
      ctx.globalCompositeOperation = "lighter";
      ctx.globalAlpha =
        f.sp.style === "octopus" && (f.sucking || f.jaw > 0.25)
          ? 0.62 + Math.sin(this.t * 9 + f.id) * 0.14
          : (f.y > DEEP_START - 120 ? 0.55 : 0.26) + Math.sin(this.t * 3.4 + f.id) * 0.08;
      ctx.drawImage(glowOrb(rCol, false), x - camLeft - rr, y - camTop + hover - rr, rr * 2, rr * 2);
      ctx.globalAlpha = 1;
      ctx.globalCompositeOperation = "source-over";
    }

    const sprW = fishLen(f.r) * 1.4;
    const sprH = sprW * 0.82;
    const px = S0 * (x - camLeft);
    const py = S0 * (y - camTop + hover);
    const litAfter = this.oceanLighting === "after" && !this.pixelMode;
    const ol = litAfter ? this.sampleOceanLight(x, y) : null;

    let drew3D = false;
    if (!this.menuActive && (isPure3D || (f.sp.is3D && !this.pixelMode))) {
      const worldSpan = sprW * (f.sp.style === "octopus" ? 1.76 : 1.14);
      const pose = this.scratchPose3D;
      pose.jaw = f.eatenBy ? 1 : f.jaw;
      pose.chompPhase = f.chompPhase;
      pose.chompDur = f.chompDur;
      pose.chompBitFired = f.chompBitFired;
      pose.biteLunge = 0;
      pose.tailPh = f.tailPh;
      pose.wag2 = this.t * 6.0 + f.id;
      pose.bend = f.bend;
      pose.turnFlip = f.eatenBy ? face : f.turnFlip;
      pose.turnVel = f.eatenBy ? 0 : f.turnBend;
      pose.boostAmt = f.eatenBy ? 0 : f.boostVis;
      pose.tilt = rot;
      pose.gulpT = f.gulpT;
      pose.gulpK = f.gulpK * this.bulkScale;
      pose.swallowT = f.swallowT;
      if (f.sp.style === "octopus") {
        let eatClasp = 0;
        let eatPull = 0;
        if (f.eatPullT > 0.001) {
          const u = 1 - f.eatPullT;
          // 0..0.34: reach forward & clasp prey | 0.34..0.80: pull prey underneath head | 0.80..1.0: hold for HAP & relax
          eatClasp = u < 0.26 ? Math.sin((u / 0.26) * Math.PI * 0.5) : u < 0.50 ? 1 - (u - 0.26) / 0.24 : 0;
          eatPull =
            u < 0.22
              ? 0
              : u < 0.68
                ? Math.sin(((u - 0.22) / 0.46) * Math.PI * 0.5)
                : Math.sin(((1 - u) / 0.32) * Math.PI * 0.5);
        }
        const suckScale = f.eatPullSuck && f.sucking ? 0.78 : 1;
        pose.tentacleReach = Math.max(f.sucking ? 0 : f.eatReachT, eatClasp * suckScale);
        pose.tentaclePull = eatPull * suckScale;
        pose.tentacleTrail = f.eatenBy ? 0 : f.tentTrail;
        pose.tentacleVertLag = f.eatenBy ? 0 : f.tentVertLag;
        pose.tentacleTurnLag = f.eatenBy ? 0 : f.tentTurnLag;
      } else {
        pose.tentacleReach = 0;
        pose.tentaclePull = 0;
        pose.tentacleTrail = 0;
        pose.tentacleVertLag = 0;
        pose.tentacleTurnLag = 0;
      }
      pose.gulpColor = f.gulpColor;
      pose.gulpTailColor = f.gulpTailColor;
      pose.sq = f.sq;
      pose.expr = expr;
      pose.puff = f.munch || jawState === -1;
      pose.sucking = f.sucking;
      pose.swimSpeed = swim;
      pose.depthFactor = clamp((f.y - 350) / 1400, 0, 1);
      pose.lightingAfter = litAfter;
      pose.sunBeam = ol ? ol.sunBeam : 0;
      pose.caustic = ol ? ol.caustic : 0;
      pose.ventWarm = ol ? clamp(ol.ventWarm + ol.subWarm * 0.72, 0, 1) : 0;
      pose.lampCool = ol ? ol.lampCool : 0;

      const useLive3D = f === this.player || isPure3D || (!f.fry && (f.r >= 17.5 || f.gulpT > 0.02 || f.swallowT > 0.02 || f.jaw > 0.4) && this.live3DBudget > 0);
      if (useLive3D) {
        if (f !== this.player && !isPure3D) this.live3DBudget--;
        ctx.setTransform(S0 * sc, 0, 0, S0 * sc, px, py);
        drew3D = fish3d.renderToCanvas(
          f.sp,
          ctx,
          -worldSpan * 0.5,
          -worldSpan * 0.5,
          worldSpan,
          worldSpan,
          pose,
          worldSpan * S0 * 1.15
        );
        if (drew3D && !f.eatenBy && f.y < 680 && (f.kind !== "npc" || f.r > 8)) {
          const sunVis = clamp(1 - f.y / 680, 0, 1);
          const beamBoost = ol ? 1 + ol.sunBeam * 0.75 + ol.caustic * 0.35 : 1;
          const shimmer = 0.58 + 0.42 * Math.sin(this.t * 3.2 + f.x * 0.035 + f.id);
          ctx.globalCompositeOperation = "lighter";
          ctx.globalAlpha = clamp(0.24 * sunVis * shimmer * beamBoost, 0, 0.65);
          ctx.drawImage((this.orbDorsalRim ??= glowOrb("rgba(220, 253, 255, 0.78)", false)), -sprW * 0.28, -sprH * 0.42, sprW * 0.56, sprH * 0.34);
          ctx.globalAlpha = 1;
          ctx.globalCompositeOperation = "source-over";
        }
      } else {
        const minLitR = this.graphicsMode === "ultra_fps" ? 13.5 : 9.5;
        const useLitBuf = litAfter && ol !== null && (f === this.player || (!f.fry && f.r >= minLitR)) && this.fishLitBudget > 0;
        const devSpan = worldSpan * sc * S0;
        const dim = useLitBuf ? Math.min(440, Math.max(36, Math.ceil(devSpan * 1.16) + 12)) : 0;
        if (useLitBuf && dim <= 440) {
          this.fishLitBudget--;
          const { cv: lcv, c: lctx } = this.getFishLightBuffer();
          const cx0 = dim * 0.5;
          const cy0 = dim * 0.5;
          lctx.setTransform(1, 0, 0, 1, 0, 0);
          lctx.globalCompositeOperation = "source-over";
          lctx.globalAlpha = 1;
          lctx.clearRect(0, 0, dim, dim);
          lctx.setTransform(S0 * sc, 0, 0, S0 * sc, cx0, cy0);
          drew3D = fish3d.renderCached3D(f.sp, lctx, worldSpan, pose, devSpan * 1.15, false);
          if (drew3D) {
            this.applyOceanFishLightPass(lctx, dim, devSpan * 0.48, x, y, ol);
            ctx.setTransform(1, 0, 0, 1, 0, 0);
            ctx.drawImage(lcv, 0, 0, dim, dim, px - cx0, py - cy0, dim, dim);
          }
        } else {
          ctx.setTransform(S0 * sc, 0, 0, S0 * sc, px, py);
          drew3D = fish3d.renderCached3D(f.sp, ctx, worldSpan, pose, devSpan * 1.15, false);
        }
      }
    }

    if (!drew3D && spr) {
      // Smooth articulated multi-segment ragdoll spine + traveling swim S-wave + localized gulp bulge
      const gulpProg = 1 - clamp(f.gulpT, 0, 1);
      const gulpAmp = f.gulpT > 0 && !f.eatenBy ? f.gulpK * this.bulkScale * Math.sin(Math.pow(gulpProg, 0.72) * Math.PI) * Math.pow(1 - gulpProg * 0.42, 0.8) * 0.38 : 0;
      const gulpPos = 0.20 + (1 - Math.pow(1 - gulpProg, 2.2)) * 0.44;
      const roll = f.eatenBy ? 0 : si * yaw * 0.14;
      const gKx = kx * Math.max(0.74, 1 - gulpAmp * 0.14);
      const a0 = S0 * flipX * co * gKx;
      const b0 = S0 * flipX * (si + roll) * gKx;
      const c0 = -S0 * si * ky;
      const d0 = S0 * co * ky;

      const devLen = spr.w * S0 * Math.max(kx, ky, 1);
      const segs = f.eatenBy || devLen < 16 ? 1 : devLen >= 86 ? 9 : devLen >= 34 ? 6 : 4;
      const minLitR2 = this.graphicsMode === "ultra_fps" ? 13.5 : 9.5;
      const useLitBuf = litAfter && ol !== null && !f.eatenBy && (f === this.player || (!f.fry && f.r >= minLitR2)) && this.fishLitBudget > 0;
      const dim = useLitBuf ? Math.min(440, Math.max(36, Math.ceil(Math.max(spr.w, spr.h) * S0 * Math.max(kx, ky, 1) * 1.46) + 12)) : 0;

      let targetCtx = ctx;
      let ox = px;
      let oy = py;
      let litBufCv: HTMLCanvasElement | null = null;
      if (useLitBuf && dim <= 440) {
        this.fishLitBudget--;
        const buf = this.getFishLightBuffer();
        litBufCv = buf.cv;
        targetCtx = buf.c;
        ox = dim * 0.5;
        oy = dim * 0.5;
        targetCtx.setTransform(1, 0, 0, 1, 0, 0);
        targetCtx.globalCompositeOperation = "source-over";
        targetCtx.globalAlpha = 1;
        targetCtx.clearRect(0, 0, dim, dim);
      }

      if (segs === 1) {
        const gKy = ky * (1 + gulpAmp * 0.55);
        targetCtx.setTransform(a0, b0, -S0 * si * gKy, S0 * co * gKy, ox, oy);
        targetCtx.drawImage(spr.canvas, -spr.w / 2, -spr.h / 2, spr.w, spr.h);
      } else {
        const cw = spr.canvas.width;
        const ch = spr.canvas.height;
        const turnWhip = Math.min(1, yaw * 1.15);
        const waveAmp = spr.h * (0.036 + swim * 0.056 + (f.boosting ? 0.034 : 0) + turnWhip * 0.042);
        const bendAmp = f.bend * spr.w * 0.34;
        const spineAt = (s: number) => {
          const t = clamp((s - 0.12) / 0.88, 0, 1);
          if (t <= 0) return 0;
          const w = Math.pow(t, 1.55) * waveAmp * Math.sin(f.tailPh - s * 3.85);
          const b = Math.pow(t, 1.65) * bendAmp;
          return w + b;
        };

        const segW = spr.w / segs;
        const devSeg = Math.hypot(a0, b0) * segW;
        const ovLocal = Math.min(segW * 0.45, 1.25 / Math.max(0.45, devSeg / segW));
        const ovU = ovLocal / spr.w;

        let prevDy = spineAt(1);
        for (let i = 0; i < segs; i++) {
          const u0 = i / segs;
          const u1 = (i + 1) / segs;
          const s1 = 1 - u1;
          const dy0 = prevDy;
          const dy1 = spineAt(s1);
          prevDy = dy1;

          const lx0 = (u0 - 0.5) * spr.w;
          const slope = (dy1 - dy0) / segW;
          let gy = 1;
          if (gulpAmp > 0.005) {
            const dG = (1 - 0.5 * (u0 + u1) - gulpPos) / 0.16;
            gy += gulpAmp * Math.exp(-dG * dG);
          }

          const uDrawEnd = i < segs - 1 ? Math.min(1, u1 + ovU) : 1;
          const srcX = u0 * cw;
          const srcW = Math.min(cw - srcX, (uDrawEnd - u0) * cw);
          const dstW = (uDrawEnd - u0) * spr.w;

          targetCtx.setTransform(
            a0 + c0 * slope,
            b0 + d0 * slope,
            c0 * gy,
            d0 * gy,
            ox + a0 * lx0 + c0 * dy0,
            oy + b0 * lx0 + d0 * dy0
          );
          targetCtx.drawImage(spr.canvas, srcX, 0, srcW, ch, 0, -spr.h / 2, dstW, spr.h);
        }

        const midDy = spineAt(0.5);
        targetCtx.setTransform(a0, b0, c0, d0, ox + c0 * midDy, oy + d0 * midDy);
      }

      if (litBufCv && ol) {
        this.applyOceanFishLightPass(targetCtx, dim, Math.max(12, spr.h * S0 * ky * 0.52), x, y, ol);
        ctx.setTransform(1, 0, 0, 1, 0, 0);
        ctx.drawImage(litBufCv, 0, 0, dim, dim, px - ox, py - oy, dim, dim);
      } else if (!f.eatenBy && !this.pixelMode && f.y < 680 && (f.kind !== "npc" || f.r > 8)) {
        const sunVis = clamp(1 - f.y / 680, 0, 1);
        const shimmer = 0.58 + 0.42 * Math.sin(this.t * 3.2 + f.x * 0.035 + f.id);
        ctx.globalCompositeOperation = "lighter";
        ctx.globalAlpha = 0.28 * sunVis * shimmer;
        ctx.drawImage((this.orbDorsalRim ??= glowOrb("rgba(220, 253, 255, 0.72)", false)), -spr.w * 0.28, -spr.h * 0.42, spr.w * 0.56, spr.h * 0.34);
        ctx.globalAlpha = 1;
        ctx.globalCompositeOperation = "source-over";
      }
    }
    ctx.setTransform(S0, 0, 0, S0, 0, 0);

    if (f.kind === "player" && !f.eatenBy && f.r < 14) {
      const yy = y - camTop - f.r * 1.18 - 16 + Math.sin(this.t * 6) * 2;
      const xx = x - camLeft;
      ctx.save();
      ctx.fillStyle = "#ffe14a";
      ctx.strokeStyle = "rgba(8, 22, 52, 0.8)";
      ctx.lineWidth = 1.1;
      ctx.beginPath();
      ctx.moveTo(xx - 3.2, yy - 2);
      ctx.lineTo(xx + 3.2, yy - 2);
      ctx.lineTo(xx, yy + 2.5);
      ctx.closePath();
      ctx.fill();
      ctx.stroke();
      ctx.restore();
    }
  }

  private getCaveConeMask(): HTMLCanvasElement {
    if (this.caveConeCv) return this.caveConeCv;
    const size = 256;
    const cv = document.createElement("canvas");
    cv.width = size;
    cv.height = size;
    const c = cv.getContext("2d")!;
    const img = c.createImageData(size, size);
    const d = img.data;
    const ax = 32;
    const ay = 128;
    const maxR = 224;
    const qStep = (a: number, b: number, v: number) => {
      const t = clamp((v - a) / (b - a), 0, 1);
      return t * t * t * (t * (t * 6 - 15) + 10);
    };
    for (let y = 0; y < size; y++) {
      const dy = y - ay;
      for (let x = 0; x < size; x++) {
        const dx = x - ax;
        const dist = Math.hypot(dx, dy);
        const u = dist / maxR;
        if (u >= 1) continue;
        const ang = Math.abs(Math.atan2(dy, dx));
        const maxAng = 0.54 + 0.38 * (1 - qStep(0.06, 0.42, u));
        const innerAng = maxAng * 0.2;
        const angFade = 1 - qStep(innerAng, maxAng, ang);
        if (angFade <= 0) continue;
        const radFade = 1 - qStep(0.32, 0.98, u);
        const backFade = qStep(-24, 14, dx);
        const alpha = Math.round(255 * angFade * radFade * backFade);
        if (alpha > 0) {
          const i = (y * size + x) * 4;
          d[i + 3] = alpha;
        }
      }
    }
    c.putImageData(img, 0, 0);
    this.caveConeCv = cv;
    return cv;
  }

  /**
   * When hiding inside a cave, shrouds everything behind/above/below the solid rock walls in darkness,
   * revealing ONLY the cave interior and a silky-smooth directional visibility cone facing out the entrance.
   */
  drawCaveSightMask(ctx: CanvasRenderingContext2D, camLeft: number, camTop: number, vw: number, vh: number) {
    if (this.caveVisAlpha <= 0.01 || !this.lastCave) return;
    const cave = this.lastCave;
    const mw = Math.max(4, Math.ceil(vw));
    const mh = Math.max(4, Math.ceil(vh));
    if (!this.caveMaskCv) {
      this.caveMaskCv = document.createElement("canvas");
    }
    const cv = this.caveMaskCv;
    if (cv.width !== mw || cv.height !== mh) {
      cv.width = mw;
      cv.height = mh;
    }
    const mc = cv.getContext("2d")!;
    mc.setTransform(1, 0, 0, 1, 0, 0);
    mc.globalCompositeOperation = "source-over";
    mc.globalAlpha = 1;
    mc.imageSmoothingEnabled = true;
    mc.clearRect(0, 0, mw, mh);

    // Deep atmospheric cavern rock darkness outside visible sight cone
    mc.fillStyle = "rgba(2, 6, 18, 0.90)";
    mc.fillRect(0, 0, mw, mh);

    mc.globalCompositeOperation = "destination-out";

    const dirSign = cave.kind === "alcove" ? (cave.dir >= 0 ? 1 : -1) : this.caveSightDir >= 0 ? 1 : -1;
    const coneFade = cave.kind === "tunnel" ? clamp(Math.abs(this.caveSightDir) * 1.35, 0.1, 1) : 1;

    // 1. Cut out the cave chamber interior with an ultra-gradual quintic radial feather (no hard oval rim)
    const cx = cave.x - camLeft;
    const cy = cave.y - camTop;
    const chamRx = cave.rx * 1.18;
    const chamRy = cave.ry * 1.36;
    mc.save();
    mc.translate(cx - dirSign * cave.rx * 0.04, cy);
    mc.scale(chamRx, chamRy);
    const cg = mc.createRadialGradient(0, 0, 0.05, 0, 0, 1);
    cg.addColorStop(0, "rgba(0, 0, 0, 1)");
    cg.addColorStop(0.28, "rgba(0, 0, 0, 0.98)");
    cg.addColorStop(0.48, "rgba(0, 0, 0, 0.88)");
    cg.addColorStop(0.64, "rgba(0, 0, 0, 0.66)");
    cg.addColorStop(0.78, "rgba(0, 0, 0, 0.38)");
    cg.addColorStop(0.9, "rgba(0, 0, 0, 0.14)");
    cg.addColorStop(1, "rgba(0, 0, 0, 0)");
    mc.fillStyle = cg;
    mc.beginPath();
    mc.arc(0, 0, 1, 0, Math.PI * 2);
    mc.fill();
    mc.restore();

    // 2. Soft local clarity pool around player fish inside the cave
    const p = this.player;
    if (p && !p.dead && !p.eatenBy) {
      const px = p.x - camLeft;
      const py = p.y - camTop - p.r * 0.25;
      const pr = Math.max(44, p.r * 2.35 + 24);
      const pg = mc.createRadialGradient(px, py, pr * 0.1, px, py, pr);
      pg.addColorStop(0, "rgba(0, 0, 0, 1)");
      pg.addColorStop(0.35, "rgba(0, 0, 0, 0.9)");
      pg.addColorStop(0.6, "rgba(0, 0, 0, 0.56)");
      pg.addColorStop(0.82, "rgba(0, 0, 0, 0.2)");
      pg.addColorStop(1, "rgba(0, 0, 0, 0)");
      mc.fillStyle = pg;
      mc.beginPath();
      mc.arc(px, py, pr, 0, Math.PI * 2);
      mc.fill();
    }

    // 3. Silky-smooth directional visibility cone radiating outward from the cave entrance
    const apexX = (cave.kind === "alcove" ? cave.x - dirSign * cave.rx * 0.16 : cave.x) - camLeft;
    const apexY = cy;
    const halfAng = Math.atan2(cave.ry * 1.05, cave.rx * 0.78);
    const sightLen = Math.hypot(mw, mh) * 0.98;
    const scaleX = sightLen / 224;
    const scaleY = scaleX * clamp(Math.tan(halfAng) / 0.6, 0.72, 1.35);
    const coneMask = this.getCaveConeMask();

    mc.save();
    mc.globalAlpha = coneFade;
    mc.translate(apexX, apexY);
    if (dirSign < 0) mc.scale(-1, 1);
    mc.scale(scaleX, scaleY);
    mc.drawImage(coneMask, -32, -128);
    mc.restore();

    // 4. Soft diffused threshold pool right at the cave doorway
    const mouthX = cave.x + dirSign * cave.rx * 0.88 - camLeft;
    mc.save();
    mc.globalAlpha = coneFade * 0.78;
    mc.translate(mouthX, cy);
    mc.scale(cave.rx * 0.65, cave.ry * 1.35);
    const mg = mc.createRadialGradient(0, 0, 0.08, 0, 0, 1);
    mg.addColorStop(0, "rgba(0, 0, 0, 1)");
    mg.addColorStop(0.38, "rgba(0, 0, 0, 0.76)");
    mg.addColorStop(0.68, "rgba(0, 0, 0, 0.36)");
    mg.addColorStop(0.88, "rgba(0, 0, 0, 0.1)");
    mg.addColorStop(1, "rgba(0, 0, 0, 0)");
    mc.fillStyle = mg;
    mc.beginPath();
    mc.arc(0, 0, 1, 0, Math.PI * 2);
    mc.fill();
    mc.restore();

    ctx.save();
    const prevSm = ctx.imageSmoothingEnabled;
    ctx.imageSmoothingEnabled = true;
    ctx.globalAlpha = this.caveVisAlpha;
    ctx.drawImage(cv, 0, 0, mw, mh);
    ctx.imageSmoothingEnabled = prevSm;
    ctx.restore();
  }
}
