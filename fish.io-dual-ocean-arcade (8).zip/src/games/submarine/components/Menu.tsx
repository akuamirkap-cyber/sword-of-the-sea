import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { NEMO_VARIANT_IDS, SKINS, isNemoSkinId, skinToSpecies } from "../game/species";
import { spritePreviewFrameSingle, coinSprite } from "../game/sprites";
import type { JawState } from "../game/sprites";
import { fish3d, isSoftwareWebGL } from "../game/fish3d";
import Fish3DViewport from "./Fish3DViewport";
import type { BgStyle, GraphicsMode, OceanLightingMode, ReefMixMode, ReefRockMode, SaveData, SoundPack } from "../save";
import { UPGRADE_COSTS, MAX_UPGRADE } from "../save";
import type { Upgrades } from "../game/engine";
import { sfx } from "../game/audio";
import { TROPHIES, formatSecShort, isTrophyMet, localizeTitleReward } from "../trophies";
import {
  NEMO_VARIANT_META,
  UI_TEXT,
  getLocalizedSkinName,
  getLocalizedSkinSubtitle,
} from "../i18n";

interface Props {
  save: SaveData;
  setSave: (s: SaveData) => void;
  onPlay: (skinIdOverride?: string) => void;
  onOpenTrophies: () => void;
  loading?: boolean;
  loadPct?: number;
  paused?: boolean;
  muted?: boolean;
  onToggleMute?: () => void;
}

type ModalTab = "hub" | "theme" | "setting" | "nemo" | null;
type HubTab = "records" | "upgrades" | "skins";
type SkinFilter = "all" | "predator" | "reef" | "rare";

const UPGRADE_META: {
  id: keyof Upgrades;
  icon: string;
  en: { name: string; desc: string };
  idText: { name: string; desc: string };
}[] = [
  {
    id: "suck",
    icon: "🌀",
    en: { name: "Super Suction", desc: "Wider & stronger water suction current." },
    idText: { name: "Sedotan Super", desc: "Jangkauan & tarikan arus sedot lebih luas." },
  },
  {
    id: "speed",
    icon: "💨",
    en: { name: "Turbo Fins", desc: "Swim & maneuver much faster in the ocean." },
    idText: { name: "Sirip Turbo", desc: "Berenang & bermanuver jauh lebih lincah." },
  },
  {
    id: "size",
    icon: "🍔",
    en: { name: "Big Catch", desc: "Enter the ocean with a larger starting size." },
    idText: { name: "Ikan Bongsor", desc: "Masuk lautan dengan ukuran awal lebih besar." },
  },
];

export function coinURL() {
  return coinSprite(0).toDataURL();
}

type OpaqueBox = { minX: number; minY: number; maxX: number; maxY: number };

const TILE_CANVASES_2D: Record<string, (HTMLCanvasElement | undefined)[]> = {};
const TILE_BOX_2D: Record<string, OpaqueBox> = {};
const TILE_CANVASES_3D: Record<string, (HTMLCanvasElement | undefined)[]> = {};
const CTX_CACHE = new WeakMap<HTMLCanvasElement, CanvasRenderingContext2D>();

const TILE_CYCLE: JawState[] = [0, 3, 6, -1];

const TILE_SCALE: Record<string, number> = {
  orange: 0.78,
  nemo_panda: 0.78,
  nemo_yellow: 0.78,
  nemo_blue: 0.78,
  nemo_storm: 0.78,
  nemo_black: 0.78,
  buntal: 0.86,
  dori: 0.92,
  pierre: 0.92,
  layla: 0.94,
  andy: 0.95,
  andy_blue: 0.95,
  boris: 0.95,
  kakatua: 0.96,
  peter: 0.96,
  eddy: 0.98,
  leon: 1.02,
  idol: 1.0,
  layaran: 1.04,
  pari: 1.06,
  hiu: 1.06,
  hiu_elegan: 1.06,
  hiu_totol: 1.06,
  orca: 1.06,
  mandarin: 1.02,
  aurora: 1.04,
  narwhal: 1.06,
  seadragon: 1.06,
  axolotl: 1.02,
  tuna: 1.04,
  hammerhead: 1.04,
  butterfly: 0.96,
  snapper: 1.0,
  lumba: 1.04,
  lumba_pink: 1.04,
  snapturtle: 1.06,
  snapturtle_albino: 1.06,
  boxfish: 0.94,
  seahorse: 1.0,
  nudibranch: 1.02,
  sotong: 1.02,
  manta: 1.06,
  penyu: 1.04,
  gurita_cincin_biru: 1.02,
  hiu_paus: 1.06,
};

const PREDATOR_SKIN_IDS = new Set([
  "orca",
  "hiu",
  "hiu_elegan",
  "hiu_totol",
  "hammerhead",
  "eddy",
  "snapturtle",
  "snapturtle_albino",
  "layaran",
  "pari",
  "manta",
  "hiu_paus",
]);

function drawFishCanvas(
  cv: HTMLCanvasElement | null,
  frame: HTMLCanvasElement | undefined,
  cssW: number,
  cssH: number,
  scaleMult: number,
  maxDpr = 1.4
) {
  if (!cv || !frame) return;
  const dpr = Math.min(window.devicePixelRatio || 1, maxDpr);
  const pw = Math.round(cssW * dpr);
  const ph = Math.round(cssH * dpr);
  if (cv.width !== pw || cv.height !== ph) {
    cv.width = pw;
    cv.height = ph;
  }
  let ctx = CTX_CACHE.get(cv);
  if (!ctx) {
    const got = cv.getContext("2d");
    if (!got) return;
    CTX_CACHE.set(cv, got);
    ctx = got;
  }
  ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
  ctx.clearRect(0, 0, cssW, cssH);

  const pad = 6;
  const fit = Math.min((cssW - pad * 2) / frame.width, (cssH - pad * 2) / frame.height) * scaleMult;
  const dw = frame.width * fit;
  const dh = frame.height * fit;

  ctx.drawImage(frame, cssW * 0.5 - dw * 0.5, cssH * 0.5 - dh * 0.5, dw, dh);
}

function CornerRivets() {
  return (
    <>
      <div className="pointer-events-none absolute top-2 left-2 w-2.5 h-2.5 rounded-full bg-[#e3ab4b] border border-[#3b1d06] shadow-sm flex items-center justify-center text-[6px] text-[#4d2808] z-20">
        ✕
      </div>
      <div className="pointer-events-none absolute top-2 right-2 w-2.5 h-2.5 rounded-full bg-[#e3ab4b] border border-[#3b1d06] shadow-sm flex items-center justify-center text-[6px] text-[#4d2808] z-20">
        ✕
      </div>
      <div className="pointer-events-none absolute bottom-2 left-2 w-2.5 h-2.5 rounded-full bg-[#e3ab4b] border border-[#3b1d06] shadow-sm flex items-center justify-center text-[6px] text-[#4d2808] z-20">
        ✕
      </div>
      <div className="pointer-events-none absolute bottom-2 right-2 w-2.5 h-2.5 rounded-full bg-[#e3ab4b] border border-[#3b1d06] shadow-sm flex items-center justify-center text-[6px] text-[#4d2808] z-20">
        ✕
      </div>
    </>
  );
}

/* ============ REFERENCE MOCKUP VECTOR ICONS & SPLASHES ============ */

function GoldenCrownIcon({ className = "" }: { className?: string }) {
  return (
    <svg viewBox="0 0 88 64" className={className} fill="none" aria-hidden="true">
      <defs>
        <linearGradient id="crownGold" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%" stopColor="#FFF7AE" />
          <stop offset="45%" stopColor="#FFD22B" />
          <stop offset="100%" stopColor="#D97706" />
        </linearGradient>
      </defs>
      <path
        d="M15 49 L9 21 L28 33 L44 13 L60 33 L79 21 L73 49 Z"
        fill="url(#crownGold)"
        stroke="#5C2802"
        strokeWidth="3.5"
        strokeLinejoin="round"
      />
      <rect x="14" y="47" width="60" height="9" rx="4.5" fill="#F59E0B" stroke="#5C2802" strokeWidth="3.2" />
      <circle cx="9" cy="18" r="4.8" fill="#FFE869" stroke="#5C2802" strokeWidth="2.6" />
      <circle cx="44" cy="10" r="5.5" fill="#FFF3A1" stroke="#5C2802" strokeWidth="2.6" />
      <circle cx="79" cy="18" r="4.8" fill="#FFE869" stroke="#5C2802" strokeWidth="2.6" />
      <circle cx="44" cy="36" r="3.6" fill="#EF4444" stroke="#5C2802" strokeWidth="1.8" />
      <circle cx="28" cy="40" r="2.7" fill="#38BDF8" stroke="#5C2802" strokeWidth="1.5" />
      <circle cx="60" cy="40" r="2.7" fill="#38BDF8" stroke="#5C2802" strokeWidth="1.5" />
    </svg>
  );
}

function GoldenArrowIcon({ dir }: { dir: "left" | "right" }) {
  return (
    <svg
      viewBox="0 0 64 76"
      className={`w-11 h-14 sm:w-14 sm:h-16 ${dir === "right" ? "scale-x-[-1]" : ""}`}
      fill="none"
      aria-hidden="true"
    >
      <defs>
        <linearGradient id={`arrG-${dir}`} x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%" stopColor="#FFF7AE" />
          <stop offset="48%" stopColor="#FFCA1A" />
          <stop offset="100%" stopColor="#EA580C" />
        </linearGradient>
      </defs>
      {/* Crisp white glow rim + deep amber outline rounded triangle */}
      <path
        d="M11 38 C11 33 14 29 19 25 L43 9 C50 5 57 9 57 17 V59 C57 67 50 71 43 67 L19 51 C14 47 11 43 11 38 Z"
        fill={`url(#arrG-${dir})`}
        stroke="#FFFFFF"
        strokeWidth="5.5"
        strokeLinejoin="round"
      />
      <path
        d="M11 38 C11 33 14 29 19 25 L43 9 C50 5 57 9 57 17 V59 C57 67 50 71 43 67 L19 51 C14 47 11 43 11 38 Z"
        fill="none"
        stroke="#782C04"
        strokeWidth="2.5"
        strokeLinejoin="round"
      />
      <path
        d="M49 16 L24 33 C21 35 20 37 20 38"
        stroke="#FFFBEB"
        strokeWidth="3"
        strokeLinecap="round"
        opacity="0.7"
      />
    </svg>
  );
}

function TitleSplashSvg() {
  return (
    <svg
      viewBox="0 0 560 190"
      className="pointer-events-none absolute -inset-x-10 -inset-y-4 w-[calc(100%+5rem)] h-[calc(100%+2rem)] drop-shadow-[0_10px_22px_rgba(2,20,54,0.6)]"
      fill="none"
      aria-hidden="true"
    >
      <defs>
        <linearGradient id="splashMain" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%" stopColor="#7AE7FF" />
          <stop offset="45%" stopColor="#1B9DFF" />
          <stop offset="100%" stopColor="#0952B8" />
        </linearGradient>
      </defs>
      {/* Dynamic splash body wrapping behind Fish.io */}
      <path
        d="M72 104 C44 96 30 74 44 58 C56 44 82 54 96 68 C88 46 96 22 122 24 C144 26 154 48 164 62 C188 30 236 18 280 24 C324 18 372 30 396 62 C406 48 416 26 438 24 C464 22 472 46 464 68 C478 54 504 44 516 58 C530 74 516 96 488 104 C494 128 470 150 434 148 C406 146 392 134 366 138 C328 144 306 152 280 152 C254 152 232 144 194 138 C168 134 154 146 126 148 C90 150 66 128 72 104 Z"
        fill="url(#splashMain)"
        stroke="#053276"
        strokeWidth="5"
        strokeLinejoin="round"
      />
      {/* Lower wave crest highlight */}
      <path
        d="M114 142 C164 126 218 118 280 120 C342 118 396 126 446 142 C412 162 346 168 280 164 C214 168 148 162 114 142 Z"
        fill="#38C6FF"
        stroke="#053276"
        strokeWidth="4"
      />
      {/* Glossy splash highlights & droplets */}
      <path d="M54 68 C64 60 80 66 88 76" stroke="#D9F7FF" strokeWidth="3.5" strokeLinecap="round" opacity="0.85" />
      <path d="M506 68 C496 60 480 66 472 76" stroke="#D9F7FF" strokeWidth="3.5" strokeLinecap="round" opacity="0.85" />
      <circle cx="34" cy="40" r="8" fill="#5CE1FF" stroke="#053276" strokeWidth="3" />
      <circle cx="24" cy="94" r="6" fill="#5CE1FF" stroke="#053276" strokeWidth="2.5" />
      <circle cx="526" cy="40" r="8" fill="#5CE1FF" stroke="#053276" strokeWidth="3" />
      <circle cx="536" cy="94" r="6" fill="#5CE1FF" stroke="#053276" strokeWidth="2.5" />
      <circle cx="96" cy="166" r="5" fill="#99F1FF" stroke="#053276" strokeWidth="2" />
      <circle cx="464" cy="166" r="5" fill="#99F1FF" stroke="#053276" strokeWidth="2" />
    </svg>
  );
}

function PlaySplashWingsSvg() {
  return (
    <svg
      viewBox="0 0 460 150"
      className="pointer-events-none absolute -inset-x-9 -inset-y-5 w-[calc(100%+4.5rem)] h-[calc(100%+2.5rem)] drop-shadow-[0_10px_20px_rgba(2,22,56,0.5)]"
      fill="none"
      aria-hidden="true"
    >
      <defs>
        <linearGradient id="playWingGrad" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%" stopColor="#86EEFF" />
          <stop offset="50%" stopColor="#1B9DFF" />
          <stop offset="100%" stopColor="#0853BA" />
        </linearGradient>
      </defs>
      <path
        d="M52 74 C24 62 16 42 32 32 C48 22 68 38 82 52 C74 28 96 14 118 28 C134 38 148 44 176 42 H284 C312 44 326 38 342 28 C364 14 386 28 378 52 C392 38 412 22 428 32 C444 42 436 62 408 74 C432 88 430 112 408 118 C390 124 370 112 354 114 C324 126 296 128 230 128 C164 128 136 126 106 114 C90 112 70 124 52 118 C30 112 28 88 52 74 Z"
        fill="url(#playWingGrad)"
        stroke="#04306E"
        strokeWidth="4.5"
        strokeLinejoin="round"
      />
      <circle cx="18" cy="76" r="7" fill="#6EE7FF" stroke="#04306E" strokeWidth="2.5" />
      <circle cx="442" cy="76" r="7" fill="#6EE7FF" stroke="#04306E" strokeWidth="2.5" />
      <circle cx="62" cy="18" r="5" fill="#9FF2FF" stroke="#04306E" strokeWidth="2" />
      <circle cx="398" cy="18" r="5" fill="#9FF2FF" stroke="#04306E" strokeWidth="2" />
    </svg>
  );
}

function TrophyCupIcon() {
  return (
    <svg viewBox="0 0 48 48" className="w-7 h-7 sm:w-8 sm:h-8 shrink-0 drop-shadow-[0_2px_4px_rgba(0,0,0,0.5)]" fill="none" aria-hidden="true">
      <defs>
        <linearGradient id="cupGold" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%" stopColor="#FFF7AE" />
          <stop offset="50%" stopColor="#FFCA1A" />
          <stop offset="100%" stopColor="#D97706" />
        </linearGradient>
      </defs>
      <path d="M13 12 H7 C7 20 10 24 15 24" stroke="#F59E0B" strokeWidth="4" strokeLinecap="round" />
      <path d="M35 12 H41 C41 20 38 24 33 24" stroke="#F59E0B" strokeWidth="4" strokeLinecap="round" />
      <path
        d="M13 8 H35 V20 C35 27 30 32 24 32 C18 32 13 27 13 20 Z"
        fill="url(#cupGold)"
        stroke="#5C2802"
        strokeWidth="2.6"
        strokeLinejoin="round"
      />
      <rect x="21" y="31" width="6" height="7" fill="#F59E0B" stroke="#5C2802" strokeWidth="2.2" />
      <rect x="15" y="37" width="18" height="6" rx="2.5" fill="#D97706" stroke="#5C2802" strokeWidth="2.4" />
      <path d="M18 13 V21" stroke="#FFFBEB" strokeWidth="2.4" strokeLinecap="round" opacity="0.75" />
    </svg>
  );
}

function GoldStarIcon() {
  return (
    <svg viewBox="0 0 48 48" className="w-7 h-7 sm:w-8 sm:h-8 shrink-0 drop-shadow-[0_2px_4px_rgba(0,0,0,0.5)]" fill="none" aria-hidden="true">
      <defs>
        <linearGradient id="starGold" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%" stopColor="#FFF7AE" />
          <stop offset="50%" stopColor="#FFD22B" />
          <stop offset="100%" stopColor="#EA580C" />
        </linearGradient>
      </defs>
      <path
        d="M24 5 L29.7 16.6 L42.5 18.4 L33.2 27.4 L35.4 40.2 L24 34.1 L12.6 40.2 L14.8 27.4 L5.5 18.4 L18.3 16.6 Z"
        fill="url(#starGold)"
        stroke="#5C2802"
        strokeWidth="2.8"
        strokeLinejoin="round"
      />
      <path d="M24 10 L20.5 17.5" stroke="#FFFBEB" strokeWidth="2.2" strokeLinecap="round" opacity="0.75" />
    </svg>
  );
}

function TropicalIslandIcon() {
  return (
    <svg viewBox="0 0 64 56" className="w-10 h-9 sm:w-12 sm:h-10 shrink-0 drop-shadow-[0_3px_4px_rgba(0,0,0,0.5)]" fill="none" aria-hidden="true">
      {/* Water splash ring around island */}
      <ellipse cx="32" cy="44" rx="24" ry="7" fill="#38BDF8" stroke="#083366" strokeWidth="2" opacity="0.85" />
      {/* Sandy mound */}
      <path d="M12 43 C15 33 49 33 52 43 C44 47 20 47 12 43 Z" fill="#FCD34D" stroke="#78350F" strokeWidth="2.3" />
      {/* Curved palm trunk */}
      <path d="M31 37 C29 29 30 22 33 17" stroke="#78350F" strokeWidth="5.5" strokeLinecap="round" />
      <path d="M31 37 C29 29 30 22 33 17" stroke="#D97706" strokeWidth="3.2" strokeLinecap="round" />
      {/* Palm fronds */}
      <path d="M33 17 C24 10 14 14 12 22 C20 19 26 19 33 17 Z" fill="#22C55E" stroke="#14532D" strokeWidth="2" strokeLinejoin="round" />
      <path d="M33 17 C27 7 35 4 41 9 C38 13 35 15 33 17 Z" fill="#4ADE80" stroke="#14532D" strokeWidth="2" strokeLinejoin="round" />
      <path d="M33 17 C42 10 52 14 54 22 C46 19 40 19 33 17 Z" fill="#16A34A" stroke="#14532D" strokeWidth="2" strokeLinejoin="round" />
      <path d="M33 17 C23 18 18 25 21 30 C25 25 29 21 33 17 Z" fill="#15803D" stroke="#14532D" strokeWidth="1.8" strokeLinejoin="round" />
      <path d="M33 17 C43 18 48 25 45 30 C41 25 37 21 33 17 Z" fill="#22C55E" stroke="#14532D" strokeWidth="1.8" strokeLinejoin="round" />
    </svg>
  );
}

/** Wooden Ship's Steering Wheel (Setir Kapal Kayu) requested by user for Setting button */
function WoodenShipWheelIcon() {
  const angles = [0, 45, 90, 135, 180, 225, 270, 315];
  return (
    <svg viewBox="0 0 64 64" className="w-10 h-10 sm:w-11 sm:h-11 shrink-0 drop-shadow-[0_3px_5px_rgba(0,0,0,0.55)]" fill="none" aria-hidden="true">
      <defs>
        <linearGradient id="woodWheelRim" x1="0" y1="0" x2="1" y2="1">
          <stop offset="0%" stopColor="#DDA15E" />
          <stop offset="50%" stopColor="#A96228" />
          <stop offset="100%" stopColor="#6D3812" />
        </linearGradient>
        <linearGradient id="brassHub" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%" stopColor="#FFF3A1" />
          <stop offset="55%" stopColor="#F59E0B" />
          <stop offset="100%" stopColor="#92400E" />
        </linearGradient>
      </defs>

      {/* 8 Wooden Spokes & Turned Handles */}
      {angles.map((deg) => (
        <g key={deg} transform={`rotate(${deg} 32 32)`}>
          {/* Spoke shaft */}
          <rect x="30" y="7" width="4" height="22" rx="1.5" fill="#9A5622" stroke="#2D1304" strokeWidth="1.8" />
          {/* Turned wooden handle grip sticking outside rim */}
          <rect x="28.6" y="3.5" width="6.8" height="8" rx="3" fill="#C97A39" stroke="#2D1304" strokeWidth="2" />
          {/* Handle cap highlight */}
          <circle cx="32" cy="5.5" r="1.4" fill="#FDE68A" opacity="0.85" />
        </g>
      ))}

      {/* Main Wooden Wheel Ring */}
      <circle cx="32" cy="32" r="18.5" stroke="#2D1304" strokeWidth="10" />
      <circle cx="32" cy="32" r="18.5" stroke="url(#woodWheelRim)" strokeWidth="6.2" />
      {/* Wood rim highlight */}
      <path d="M18 20 A18 18 0 0 1 44 19" stroke="#F6C88C" strokeWidth="1.6" strokeLinecap="round" opacity="0.65" />

      {/* Center Brass & Wood Hub */}
      <circle cx="32" cy="32" r="7.2" fill="url(#brassHub)" stroke="#2D1304" strokeWidth="2.4" />
      <circle cx="32" cy="32" r="2.8" fill="#451A03" />
      <circle cx="31" cy="31" r="1" fill="#FFFBEB" opacity="0.8" />
    </svg>
  );
}

export default function Menu({
  save,
  setSave,
  onPlay,
  onOpenTrophies,
  loading = false,
  loadPct = 0,
  paused = false,
  muted = false,
  onToggleMute,
}: Props) {
  const lang = save.lang;
  const t = UI_TEXT[lang];
  const softWebGL = useMemo(() => isSoftwareWebGL(), []);

  const [modal, setModal] = useState<ModalTab>(null);
  const [hubTab, setHubTab] = useState<HubTab>("records");
  const [skinFilter, setSkinFilter] = useState<SkinFilter>("all");
  const [skinQuery, setSkinQuery] = useState("");
  const [biteTrig, setBiteTrig] = useState(0);
  const [toast, setToast] = useState<{ icon: string; msg: string } | null>(null);

  const cur = useMemo(() => SKINS.find((s) => s.id === save.skin) || SKINS[0], [save.skin]);
  const activeIdx = useMemo(() => Math.max(0, SKINS.findIndex((s) => s.id === cur.id)), [cur.id]);

  const nemoSkins = useMemo(
    () =>
      NEMO_VARIANT_IDS.map((id) => {
        const origIdx = SKINS.findIndex((s) => s.id === id);
        return { skin: SKINS[origIdx], origIdx };
      }).filter((x) => x.origIdx >= 0 && !!x.skin),
    []
  );

  // 5-fish horizontal carousel indices wrapping SKINS array: [-2, -1, 0, +1, +2]
  const carouselSlots = useMemo(() => {
    const total = SKINS.length;
    return [-2, -1, 0, 1, 2].map((offset) => {
      const idx = (activeIdx + offset + total) % total;
      return { offset, idx, skin: SKINS[idx] };
    });
  }, [activeIdx]);

  const activeIdxRef = useRef(activeIdx);
  activeIdxRef.current = activeIdx;
  const carouselIndicesRef = useRef<number[]>(carouselSlots.map((s) => s.idx));
  carouselIndicesRef.current = carouselSlots.map((s) => s.idx);
  const mode3DRef = useRef(save.mode3D);
  mode3DRef.current = save.mode3D;
  const pausedRef = useRef(paused);
  pausedRef.current = paused;
  const modalRef = useRef<ModalTab>(modal);
  modalRef.current = modal;
  const hubTabRef = useRef<HubTab>(hubTab);
  hubTabRef.current = hubTab;
  const nemoIndicesRef = useRef<number[]>([]);
  nemoIndicesRef.current = nemoSkins.map((x) => x.origIdx);
  const lastNemoSkinRef = useRef<string>(isNemoSkinId(save.skin) ? save.skin : "orange");
  if (isNemoSkinId(save.skin)) {
    lastNemoSkinRef.current = save.skin;
  }
  const loadingRef = useRef(loading);
  loadingRef.current = loading;
  const softWebGLRef = useRef(softWebGL);
  softWebGLRef.current = softWebGL;

  // Refs for canvases
  const carouselCanvasRefs = useRef<(HTMLCanvasElement | null)[]>([null, null, null, null, null]);
  const carouselDrawnKeysRef = useRef<(string | undefined)[]>([undefined, undefined, undefined, undefined, undefined]);
  const heroCanvasRef = useRef<HTMLCanvasElement | null>(null);
  const lastHeroCanvasElRef = useRef<HTMLCanvasElement | null>(null);
  const heroDrawnKeyRef = useRef<string | undefined>(undefined);

  const gridScrollRef = useRef<HTMLDivElement | null>(null);
  const tileRefs = useRef<(HTMLButtonElement | null)[]>([]);
  const tileCanvasRefs = useRef<(HTMLCanvasElement | null)[]>([]);
  const drawnKeysRef = useRef<(string | undefined)[]>([]);
  const nemoPickerCanvasRefs = useRef<(HTMLCanvasElement | null)[]>([]);
  const nemoDrawnKeysRef = useRef<(string | undefined)[]>([]);

  const softBiteUntilRef = useRef(0);
  const toastTimerRef = useRef<number | undefined>(undefined);
  const isScrollingRef = useRef(false);
  const scrollIdleTimerRef = useRef<number | undefined>(undefined);
  const scrollTopRef = useRef(0);
  const scrollerHRef = useRef(440);
  const tileBoundsRef = useRef<{ top: number; bottom: number }[]>([]);
  const lastDrawStepRef = useRef(-1);
  const dragStartXRef = useRef<number | null>(null);

  const unlockedTrophyCount = useMemo(
    () => TROPHIES.filter((tItem) => !!save.unlockedTrophies[tItem.id] || isTrophyMet(tItem, save)).length,
    [
      save.unlockedTrophies,
      save.best,
      save.rank1Count,
      save.peakLevelCount,
      save.bestPeakTimeSec,
      save.bestCombo,
      save.bestDepth,
      save.totalRuns,
    ]
  );

  const coin = useMemo(() => coinURL(), []);
  const heroIs3D = !!(cur.is3D || (save.mode3D && cur.supports3D));
  const heroSpecies = useMemo(() => skinToSpecies(cur, heroIs3D), [cur, heroIs3D]);
  const showLiveHero3D = !loading && !softWebGL && heroIs3D && !paused && modal === null;

  const localizedEquippedTitle = useMemo(
    () => localizeTitleReward(save.equippedTitle, lang),
    [save.equippedTitle, lang]
  );

  const showToastMsg = useCallback((icon: string, msg: string) => {
    setToast({ icon, msg });
    clearTimeout(toastTimerRef.current);
    toastTimerRef.current = window.setTimeout(() => setToast(null), 2000);
  }, []);

  const triggerTestBite = useCallback(() => {
    sfx.init();
    if (sfx.pack === "wav") {
      void sfx.whenReady(["bite1", "bite2", "eat"]).then(() => {
        if (sfx.pack === "wav") sfx.gulp(1.0, true, 0);
      });
    } else {
      sfx.gulp(1.0, true, 0);
    }
    const activeSkin = SKINS[activeIdxRef.current];
    const usesLive3D =
      !loadingRef.current &&
      !softWebGLRef.current &&
      !!(activeSkin?.is3D || (mode3DRef.current && activeSkin?.supports3D));
    if (!usesLive3D) {
      softBiteUntilRef.current = performance.now() + 900;
    } else {
      setBiteTrig((c) => c + 1);
    }
  }, []);

  const stepCarousel = useCallback(
    (delta: number) => {
      const total = SKINS.length;
      const nextIdx = (activeIdx + delta + total) % total;
      const nextSkin = SKINS[nextIdx];
      if (!nextSkin) return;
      if (isNemoSkinId(nextSkin.id)) lastNemoSkinRef.current = nextSkin.id;
      setSave({ ...save, skin: nextSkin.id });
    },
    [activeIdx, save, setSave]
  );

  const selectSkin = useCallback(
    (skinId: string, openNemoIfAlreadySelected = true) => {
      if (isNemoSkinId(skinId)) {
        lastNemoSkinRef.current = skinId;
        if (save.skin === skinId) {
          if (openNemoIfAlreadySelected) setModal("nemo");
          else triggerTestBite();
        } else {
          setSave({ ...save, skin: skinId });
        }
        return;
      }
      if (save.skin === skinId) {
        triggerTestBite();
        return;
      }
      setSave({ ...save, skin: skinId });
    },
    [save, setSave, triggerTestBite]
  );

  const pickNemoVariant = useCallback(
    (skinId: string) => {
      lastNemoSkinRef.current = skinId;
      if (save.skin === skinId) {
        triggerTestBite();
      } else {
        setSave({ ...save, skin: skinId });
        const chosen = SKINS.find((s) => s.id === skinId);
        if (chosen) {
          showToastMsg("🐠", `${t.nemoActiveToast} ${getLocalizedSkinName(chosen.id, chosen.name, lang)}!`);
        }
      }
    },
    [lang, save, setSave, showToastMsg, t.nemoActiveToast, triggerTestBite]
  );

  const pickRandomSkin = useCallback(() => {
    const total = SKINS.length;
    if (total <= 1) return;
    let nextIdx = activeIdx;
    while (nextIdx === activeIdx) {
      nextIdx = Math.floor(Math.random() * total);
    }
    const chosen = SKINS[nextIdx];
    if (isNemoSkinId(chosen.id)) lastNemoSkinRef.current = chosen.id;
    setSkinFilter("all");
    setSkinQuery("");
    setSave({ ...save, skin: chosen.id });
    showToastMsg("🎲", `${t.randomFishToast} ${getLocalizedSkinName(chosen.id, chosen.name, lang)}!`);
    requestAnimationFrame(() => {
      tileRefs.current[nextIdx]?.scrollIntoView({ behavior: "smooth", block: "nearest" });
    });
  }, [activeIdx, lang, save, setSave, showToastMsg, t.randomFishToast]);

  const buyUp = (id: keyof Upgrades) => {
    const lv = save.upgrades[id];
    if (lv >= MAX_UPGRADE) return;
    const cost = UPGRADE_COSTS[lv];
    if (save.coins < cost) {
      showToastMsg("⚠️", t.notEnoughCoins);
      return;
    }
    setSave({ ...save, coins: save.coins - cost, upgrades: { ...save.upgrades, [id]: lv + 1 } });
    const upg = UPGRADE_META.find((u) => u.id === id);
    const upgName = upg ? (lang === "id" ? upg.idText.name : upg.en.name) : "Upgrade";
    showToastMsg("⚡", `${upgName} ${t.upgradedTo} ${lv + 1}!`);
  };

  const filteredSkins = useMemo(() => {
    const q = skinQuery.trim().toLowerCase();
    const activeNemoId = isNemoSkinId(cur.id) ? cur.id : lastNemoSkinRef.current;
    return SKINS.map((skin, origIdx) => ({ skin, origIdx })).filter(({ skin }) => {
      if (!q && isNemoSkinId(skin.id) && skin.id !== activeNemoId) return false;
      if (skinFilter === "predator" && !PREDATOR_SKIN_IDS.has(skin.id)) return false;
      if (skinFilter === "rare" && !skin.rare) return false;
      if (skinFilter === "reef" && (skin.rare || PREDATOR_SKIN_IDS.has(skin.id))) return false;
      if (q) {
        const locName = getLocalizedSkinName(skin.id, skin.name, lang).toLowerCase();
        const locSub = getLocalizedSkinSubtitle(skin.id, skin.subtitle, lang).toLowerCase();
        if (!locName.includes(q) && !locSub.includes(q) && !skin.name.toLowerCase().includes(q)) return false;
      }
      return true;
    });
  }, [cur.id, lang, skinFilter, skinQuery]);

  const measureTileBounds = useCallback(() => {
    const scroller = gridScrollRef.current;
    if (!scroller) return;
    scrollTopRef.current = scroller.scrollTop;
    scrollerHRef.current = scroller.clientHeight || 440;
    const bounds: ({ top: number; bottom: number } | undefined)[] = new Array(SKINS.length);
    for (let i = 0; i < SKINS.length; i++) {
      const btn = tileRefs.current[i];
      if (btn && btn.isConnected) {
        const top = btn.offsetTop;
        bounds[i] = { top, bottom: top + btn.offsetHeight };
      }
    }
    tileBoundsRef.current = bounds as { top: number; bottom: number }[];
    lastDrawStepRef.current = -1;
  }, []);

  useEffect(() => {
    if (modal !== "hub" || hubTab !== "skins") return;
    const scroller = gridScrollRef.current;
    if (!scroller) return;
    measureTileBounds();
    const ro = typeof ResizeObserver !== "undefined" ? new ResizeObserver(measureTileBounds) : null;
    ro?.observe(scroller);
    drawnKeysRef.current = [];
    return () => ro?.disconnect();
  }, [modal, hubTab, skinFilter, skinQuery, measureTileBounds]);

  useEffect(() => {
    lastDrawStepRef.current = -1;
    carouselDrawnKeysRef.current = [undefined, undefined, undefined, undefined, undefined];
    heroDrawnKeyRef.current = undefined;
    nemoDrawnKeysRef.current = [];
  }, [save.mode3D, save.skin, skinFilter, skinQuery, modal, hubTab]);

  // Keyboard navigation: Escape closes modals, Left/Right cycles carousel when on main menu
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if (paused) return;
      if (e.key === "Escape" && modal) {
        e.preventDefault();
        setModal(null);
        return;
      }
      if (!modal) {
        const tag = (e.target as HTMLElement | null)?.tagName;
        if (tag === "INPUT" || tag === "TEXTAREA") return;
        if (e.key === "ArrowLeft") {
          e.preventDefault();
          stepCarousel(-1);
        } else if (e.key === "ArrowRight") {
          e.preventDefault();
          stepCarousel(1);
        }
      }
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [modal, paused, stepCarousel]);

  // Incremental sprite baking & carousel + modal canvas animation loop
  useEffect(() => {
    let alive = true;
    let raf = 0;

    const buildOne2DFrame = (s: (typeof SKINS)[number], fi: number) => {
      let arr = TILE_CANVASES_2D[s.id];
      if (!arr) {
        arr = new Array<HTMLCanvasElement | undefined>(TILE_CYCLE.length);
        TILE_CANVASES_2D[s.id] = arr;
      }
      if (arr[fi]) return false;
      const box = TILE_BOX_2D[s.id];
      const res = spritePreviewFrameSingle(skinToSpecies(s, false), 144, TILE_CYCLE[fi], fi, box);
      if (!TILE_BOX_2D[s.id]) TILE_BOX_2D[s.id] = res.box;
      arr[fi] = res.canvas;
      return true;
    };

    const buildOne3DFrame = (s: (typeof SKINS)[number], fi: number) => {
      let arr = TILE_CANVASES_3D[s.id];
      if (!arr) {
        arr = new Array<HTMLCanvasElement | undefined>(TILE_CYCLE.length);
        TILE_CANVASES_3D[s.id] = arr;
      }
      if (arr[fi]) return false;
      const j = TILE_CYCLE[fi];
      const ph = (fi / TILE_CYCLE.length) * Math.PI * 2;
      const jawVal = j > 0 ? j / 6 : j < 0 ? -0.18 : 0;
      arr[fi] = fish3d.renderSnapshot(
        skinToSpecies(s, true),
        {
          jaw: jawVal,
          chompPhase: j === -1 ? 0.08 : 0,
          chompDur: 0.13,
          chompBitFired: j === -1,
          biteLunge: j === -1 ? 1.6 : j >= 5 ? -0.5 : 0,
          tailPh: ph * 2,
          wag2: ph * 2,
          bend: Math.sin(ph) * 0.05,
          turnFlip: 1,
          tilt: Math.sin(ph) * 0.04,
          gulpT: j === -1 ? 0.65 : 0,
          gulpK: 0.65,
          sq: j === -1 ? 0.14 : 0,
          expr: j === -1 ? "happy" : "normal",
          puff: j === -1,
          sucking: false,
          swimSpeed: 0.55,
          inspectYaw: -0.16,
          inspectPitch: 0.04,
        },
        160,
        96
      );
      return true;
    };

    const tick = (now: number) => {
      if (!alive) return;
      if (document.hidden || pausedRef.current) {
        raf = requestAnimationFrame(tick);
        return;
      }
      if (isScrollingRef.current) {
        raf = requestAnimationFrame(tick);
        return;
      }

      const useMode3D = mode3DRef.current;
      const useSoft = softWebGLRef.current;
      const activeModal = modalRef.current;
      const curHubTab = hubTabRef.current;
      const activeIndex = activeIdxRef.current;
      const cIndices = carouselIndicesRef.current;

      const visibleIndices: number[] = [];
      if (activeModal === "hub" && curHubTab === "skins") {
        const viewTop = scrollTopRef.current - 150;
        const viewBottom = scrollTopRef.current + scrollerHRef.current + 150;
        const bounds = tileBoundsRef.current;
        for (let i = 0; i < SKINS.length; i++) {
          const b = bounds[i];
          if (!b) continue;
          if (b.bottom >= viewTop && b.top <= viewBottom) {
            visibleIndices.push(i);
          }
        }
      }

      const pickerOpen = activeModal === "nemo";
      const bakeOrder = Array.from(
        new Set([
          activeIndex,
          ...cIndices,
          ...(pickerOpen ? nemoIndicesRef.current : []),
          ...visibleIndices,
        ])
      );

      let bakedAny = false;
      const isLoading = loadingRef.current;

      let bakedCount = 0;
      const max2DBakes = 2;
      for (const idx of bakeOrder) {
        const s = SKINS[idx];
        if (!s) continue;
        const want3D = !isLoading && (!!s.is3D || !!(useMode3D && s.supports3D));
        if (want3D) {
          if (!TILE_CANVASES_3D[s.id]?.[0]) {
            buildOne3DFrame(s, 0);
            bakedAny = true;
            bakedCount = 99;
            break;
          }
        } else if (!s.is3D && !TILE_CANVASES_2D[s.id]?.[0]) {
          buildOne2DFrame(s, 0);
          bakedAny = true;
          bakedCount++;
          if (bakedCount >= max2DBakes) break;
        }
      }

      if (!bakedAny && !isLoading) {
        outer: for (const idx of bakeOrder) {
          const s = SKINS[idx];
          if (!s) continue;
          const want3D = !!(s.is3D || (useMode3D && s.supports3D));
          if (want3D) {
            const arr = TILE_CANVASES_3D[s.id];
            for (let fi = 1; fi < TILE_CYCLE.length; fi++) {
              if (!arr || !arr[fi]) {
                buildOne3DFrame(s, fi);
                bakedAny = true;
                break outer;
              }
            }
          } else if (!s.is3D) {
            const arr = TILE_CANVASES_2D[s.id];
            for (let fi = 1; fi < TILE_CYCLE.length; fi++) {
              if (!arr || !arr[fi]) {
                buildOne2DFrame(s, fi);
                bakedAny = true;
                break outer;
              }
            }
          }
        }
      }

      const baseStep = Math.floor(now / 135);
      const isBiting = now < softBiteUntilRef.current;
      const shouldDraw = bakedAny || isBiting || baseStep !== lastDrawStepRef.current;

      if (shouldDraw) {
        lastDrawStepRef.current = baseStep;

        // 1. Center hero fallback canvas (2D / loading / softWebGL)
        const heroSkin = SKINS[activeIndex];
        const heroUses3D = !!(heroSkin.is3D || (useMode3D && heroSkin.supports3D));
        if (isLoading || useSoft || !heroUses3D || activeModal !== null) {
          const hcv = heroCanvasRef.current;
          if (hcv !== lastHeroCanvasElRef.current) {
            lastHeroCanvasElRef.current = hcv;
            heroDrawnKeyRef.current = undefined;
          }
          const hHas3D = heroUses3D && !!TILE_CANVASES_3D[heroSkin.id]?.[0];
          const hFrames = hHas3D
            ? TILE_CANVASES_3D[heroSkin.id]
            : heroSkin.is3D
              ? undefined
              : TILE_CANVASES_2D[heroSkin.id];
          if (hcv && hFrames) {
            let hfIdx = 0;
            if (isBiting) {
              const biteSeq = [1, 2, 3, 0];
              hfIdx = biteSeq[Math.floor(now / 95) % biteSeq.length];
            } else {
              hfIdx = baseStep % hFrames.length;
            }
            const hFrame = hFrames[hfIdx] || hFrames[0];
            if (hFrame) {
              const actualHf = hFrame === hFrames[0] && !hFrames[hfIdx] ? 0 : hfIdx;
              const hKey = `${heroSkin.id}|${hHas3D ? 1 : 0}|${actualHf}`;
              if (heroDrawnKeyRef.current !== hKey) {
                heroDrawnKeyRef.current = hKey;
                drawFishCanvas(hcv, hFrame, 260, 170, (TILE_SCALE[heroSkin.id] ?? 1) * (hHas3D ? 1.02 : 1.05), 1.6);
              }
            }
          }
        }

        // 2. Side fish slots in the 5-fish horizontal carousel (-2, -1, +1, +2)
        for (let slot = 0; slot < 5; slot++) {
          if (slot === 2) continue;
          const idx = cIndices[slot];
          const s = SKINS[idx];
          const cv = carouselCanvasRefs.current[slot];
          if (!s || !cv) continue;
          const use3DTile = !!(s.is3D || (useMode3D && s.supports3D));
          const has3D = use3DTile && !!TILE_CANVASES_3D[s.id]?.[0];
          const frames = has3D ? TILE_CANVASES_3D[s.id] : s.is3D ? undefined : TILE_CANVASES_2D[s.id];
          if (!frames) continue;
          const fIdx = (baseStep + slot) % frames.length;
          const frame = frames[fIdx] || frames[0];
          if (!frame) continue;
          const actualIdx = frame === frames[0] && !frames[fIdx] ? 0 : fIdx;
          const drawKey = `${s.id}|${has3D ? 1 : 0}|${actualIdx}`;
          if (carouselDrawnKeysRef.current[slot] !== drawKey) {
            carouselDrawnKeysRef.current[slot] = drawKey;
            const isNear = slot === 1 || slot === 3;
            const cssW = isNear ? 168 : 132;
            const cssH = isNear ? 114 : 92;
            drawFishCanvas(cv, frame, cssW, cssH, (TILE_SCALE[s.id] ?? 1) * (has3D ? 0.98 : 1.02), 1.5);
          }
        }

        // 3. All Fish Grid inside Hub modal
        if (activeModal === "hub" && curHubTab === "skins") {
          for (const idx of visibleIndices) {
            const s = SKINS[idx];
            const cv = tileCanvasRefs.current[idx];
            if (!cv) continue;
            const use3DTile = !!(s.is3D || (useMode3D && s.supports3D));
            const has3D = use3DTile && !!TILE_CANVASES_3D[s.id]?.[0];
            const frames = has3D ? TILE_CANVASES_3D[s.id] : s.is3D ? undefined : TILE_CANVASES_2D[s.id];
            if (!frames) continue;

            let fIdx = 0;
            if (isBiting && idx === activeIndex) {
              const biteSeq = [1, 2, 3, 0];
              fIdx = biteSeq[Math.floor(now / 95) % biteSeq.length];
            } else {
              fIdx = (baseStep + idx) % frames.length;
            }
            const frame = frames[fIdx] || frames[0];
            if (!frame) continue;

            const actualIdx = frame === frames[0] && !frames[fIdx] ? 0 : fIdx;
            const drawKey = `${s.id}|${has3D ? 1 : 0}|${actualIdx}`;
            if (drawnKeysRef.current[idx] !== drawKey) {
              drawnKeysRef.current[idx] = drawKey;
              drawFishCanvas(cv, frame, 132, 74, (TILE_SCALE[s.id] ?? 1) * (has3D ? 0.94 : 1), 1.3);
            }
          }
        }

        // 4. Nemo Skin Picker modal
        if (pickerOpen) {
          const nIndices = nemoIndicesRef.current;
          for (let ni = 0; ni < nIndices.length; ni++) {
            const idx = nIndices[ni];
            const s = SKINS[idx];
            const cv = nemoPickerCanvasRefs.current[ni];
            if (!s || !cv) continue;
            const use3DTile = !!(s.is3D || (useMode3D && s.supports3D));
            const has3D = use3DTile && !!TILE_CANVASES_3D[s.id]?.[0];
            const frames = has3D ? TILE_CANVASES_3D[s.id] : TILE_CANVASES_2D[s.id];
            if (!frames) continue;

            let fIdx = 0;
            if (isBiting && idx === activeIndex) {
              const biteSeq = [1, 2, 3, 0];
              fIdx = biteSeq[Math.floor(now / 95) % biteSeq.length];
            } else {
              fIdx = (baseStep + ni) % frames.length;
            }
            const frame = frames[fIdx] || frames[0];
            if (!frame) continue;

            const actualIdx = frame === frames[0] && !frames[fIdx] ? 0 : fIdx;
            const drawKey = `${s.id}|${has3D ? 1 : 0}|${actualIdx}`;
            if (nemoDrawnKeysRef.current[ni] !== drawKey) {
              nemoDrawnKeysRef.current[ni] = drawKey;
              drawFishCanvas(cv, frame, 156, 88, (TILE_SCALE[s.id] ?? 1) * (has3D ? 0.98 : 1.02), 1.4);
            }
          }
        }
      }

      raf = requestAnimationFrame(tick);
    };

    raf = requestAnimationFrame(tick);
    return () => {
      alive = false;
      cancelAnimationFrame(raf);
      clearTimeout(toastTimerRef.current);
      clearTimeout(scrollIdleTimerRef.current);
    };
  }, []);

  const handleGridScroll = () => {
    const scroller = gridScrollRef.current;
    if (scroller) scrollTopRef.current = scroller.scrollTop;
    isScrollingRef.current = true;
    clearTimeout(scrollIdleTimerRef.current);
    scrollIdleTimerRef.current = window.setTimeout(() => {
      isScrollingRef.current = false;
      lastDrawStepRef.current = -1;
    }, 100);
  };

  const loadingPct = Math.round(loadPct * 100);
  const loadingStageText =
    loadPct < 0.22
      ? t.loadingStages[0]
      : loadPct < 0.49
        ? t.loadingStages[1]
        : loadPct < 0.88
          ? t.loadingStages[2]
          : loadPct < 0.99
            ? t.loadingStages[3]
            : t.loadingStages[4];

  const centerFishName = getLocalizedSkinName(cur.id, cur.name, lang);

  return (
    <div className="absolute inset-0 z-10 flex flex-col justify-between items-center px-3 py-3 sm:py-5 overflow-hidden select-none pointer-events-none">
      {/* ================= TOP-CENTER: EXISTING Fish.io TITLE FONT INSIDE WATER SPLASH ================= */}
      <header className="relative z-20 flex flex-col items-center pt-1 sm:pt-2 shrink-0 pointer-events-auto">
        <div className="relative px-8 py-3 flex items-center justify-center">
          <TitleSplashSvg />
          <h1 className="relative z-10 font-display text-[54px] sm:text-[72px] md:text-[82px] font-extrabold leading-none tracking-tight flex items-baseline">
            <span className="fish-word-gold">Fish</span>
            <span className="fish-word-io">.io</span>
          </h1>
        </div>

        {localizedEquippedTitle && (
          <div className="mt-1 px-3 py-0.5 rounded-full bg-[#062658]/80 border border-yellow-300/70 text-[11px] font-extrabold text-yellow-200 shadow-md">
            👑 {t.equippedTitle}: « {localizedEquippedTitle} »
          </div>
        )}
      </header>

      {/* ================= CENTER: 5-FISH CAROUSEL + GOLDEN CROWN + NAME + ORANGE PLAY ================= */}
      <main className="relative z-20 flex-1 w-full max-w-[1060px] flex flex-col items-center justify-center min-h-0 pointer-events-auto">
        {/* Horizontal 5-Fish Carousel Row */}
        <div
          className="relative w-full flex items-center justify-center gap-1 sm:gap-3 md:gap-4"
          onPointerDown={(e) => {
            dragStartXRef.current = e.clientX;
          }}
          onPointerUp={(e) => {
            if (dragStartXRef.current === null) return;
            const dx = e.clientX - dragStartXRef.current;
            dragStartXRef.current = null;
            if (Math.abs(dx) > 42) {
              stepCarousel(dx < 0 ? 1 : -1);
            }
          }}
        >
          {/* Left Golden Arrow */}
          <button
            type="button"
            onClick={() => stepCarousel(-1)}
            aria-label="Previous fish"
            className="arcade-arrow-btn shrink-0 p-1 z-30"
          >
            <GoldenArrowIcon dir="left" />
          </button>

          {/* 5 Carousel Slots: -2, -1, 0 (Center Crowned Hero), +1, +2 */}
          <div className="flex items-center justify-center gap-1 sm:gap-2.5 md:gap-4 flex-1 max-w-[840px]">
            {carouselSlots.map((slot, slotIdx) => {
              const { offset, skin: s } = slot;
              const isCenter = offset === 0;
              const isNear = Math.abs(offset) === 1;
              const sName = getLocalizedSkinName(s.id, s.name, lang);

              if (isCenter) {
                return (
                  <div key={`center-${s.id}`} className="relative flex flex-col items-center justify-center shrink-0 mx-1 sm:mx-2">
                    {/* Golden Radial Spotlight Glow behind active fish */}
                    <div
                      className="hero-golden-aura absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[230px] h-[230px] sm:w-[275px] sm:h-[275px] rounded-full"
                      aria-hidden="true"
                    />

                    {/* Golden Crown perched above center fish */}
                    <GoldenCrownIcon className="relative z-20 w-12 h-9 sm:w-16 sm:h-12 -mb-3 sm:-mb-4 drop-shadow-[0_4px_6px_rgba(0,0,0,0.5)]" />

                    {/* Center Fish Visual (Live 3D or Animated Canvas) */}
                    <div
                      onClick={() => {
                        if (!showLiveHero3D) triggerTestBite();
                      }}
                      title={t.testBite}
                      className="relative z-10 w-[195px] h-[126px] sm:w-[250px] sm:h-[160px] flex items-center justify-center cursor-pointer"
                    >
                      {showLiveHero3D ? (
                        <Fish3DViewport
                          species={heroSpecies}
                          onBiteCount={biteTrig}
                          paused={paused || modal !== null}
                          interactive={true}
                          bulkScale={save.bulkPref}
                        />
                      ) : (
                        <canvas
                          ref={heroCanvasRef}
                          aria-label={sName}
                          className="bob w-[195px] h-[126px] sm:w-[250px] sm:h-[160px] block drop-shadow-[0_12px_18px_rgba(2,16,44,0.65)]"
                        />
                      )}
                    </div>
                  </div>
                );
              }

              const visibilityClass = isNear ? "hidden sm:flex" : "hidden md:flex";
              const sizeClass = isNear
                ? "w-[132px] h-[90px] sm:w-[158px] sm:h-[108px]"
                : "w-[110px] h-[78px] md:w-[126px] md:h-[88px] opacity-90";

              return (
                <button
                  key={`slot-${offset}-${s.id}`}
                  type="button"
                  onClick={() => selectSkin(s.id, false)}
                  aria-label={sName}
                  title={sName}
                  className={`${visibilityClass} relative z-10 items-center justify-center cursor-pointer transition-transform duration-150 hover:scale-110 active:scale-95 shrink-0`}
                >
                  <canvas
                    ref={(el) => {
                      carouselCanvasRefs.current[slotIdx] = el;
                    }}
                    className={`${sizeClass} block drop-shadow-[0_8px_14px_rgba(2,16,44,0.58)]`}
                  />
                </button>
              );
            })}
          </div>

          {/* Right Golden Arrow */}
          <button
            type="button"
            onClick={() => stepCarousel(1)}
            aria-label="Next fish"
            className="arcade-arrow-btn shrink-0 p-1 z-30"
          >
            <GoldenArrowIcon dir="right" />
          </button>
        </div>

        {/* Center Fish Name + Quick Browser / Nemo Variant Buttons */}
        <div className="relative z-20 flex flex-col items-center -mt-1 sm:mt-0 mb-3 sm:mb-4">
          <div className="font-display text-[26px] sm:text-[34px] font-extrabold text-white text-outline leading-tight tracking-wide">
            {centerFishName}
          </div>
          <div className="mt-1 flex items-center justify-center gap-2">
            <button
              type="button"
              onClick={() => {
                setHubTab("skins");
                setModal("hub");
              }}
              className="px-3 py-1 rounded-full bg-[#06316e]/80 hover:bg-[#094391] border border-cyan-300/55 text-[11px] font-extrabold text-cyan-100 cursor-pointer shadow transition-colors"
            >
              🐠 {t.allFish} ({SKINS.length})
            </button>
            {isNemoSkinId(cur.id) && (
              <button
                type="button"
                onClick={() => setModal("nemo")}
                className="px-3 py-1 rounded-full bg-orange-600/90 hover:bg-orange-500 border border-amber-200/75 text-[11px] font-extrabold text-white cursor-pointer shadow transition-colors"
              >
                🎨 {t.nemoVariants}
              </button>
            )}
          </div>
        </div>

        {/* Golden-Orange Glossy PLAY Button over Blue Water Splash */}
        <div className="relative z-20 flex items-center justify-center">
          <PlaySplashWingsSvg />
          <button
            type="button"
            onClick={() => onPlay(cur.id)}
            className="ocean-play-orange relative z-10 overflow-hidden min-w-[238px] sm:min-w-[292px] px-10 py-3 sm:py-3.5 flex items-center justify-center gap-3.5"
          >
            {loading && (
              <span
                className="absolute inset-y-0 left-0 bg-white/30 transition-all duration-150"
                style={{ width: `${loadingPct}%` }}
              />
            )}
            <span className="relative font-display text-[30px] sm:text-[38px] font-extrabold tracking-wide text-white text-outline leading-none">
              {loading ? `${loadingPct}%` : t.play}
            </span>
            <svg viewBox="0 0 36 40" className="relative w-7 h-8 sm:w-8 sm:h-9 shrink-0 drop-shadow-[0_2px_2px_rgba(92,31,2,0.7)]" fill="none" aria-hidden="true">
              <path
                d="M6 7 C6 3.5 10 1.5 13 3.4 L31 15.6 C33.8 17.5 33.8 22.5 31 24.4 L13 36.6 C10 38.5 6 36.5 6 33 Z"
                fill="#FFE44D"
                stroke="#5C1F02"
                strokeWidth="3.2"
                strokeLinejoin="round"
              />
            </svg>
          </button>
        </div>

        {loading && (
          <div className="relative z-20 mt-2 text-[11px] font-extrabold tracking-widest uppercase text-cyan-100 text-outline">
            {loadingStageText}
          </div>
        )}
      </main>

      {/* ================= BOTTOM BAR: CENTER (Leaderboard + Trophies) & RIGHT (Theme + Setting) ================= */}
      <footer className="relative z-20 w-full max-w-[1260px] flex items-end justify-center pb-1 sm:pb-2 pointer-events-none">
        {/* Bottom-Center: Leaderboard & Trophies */}
        <div className="pointer-events-auto flex items-center justify-center gap-3 sm:gap-5 flex-wrap">
          <button
            type="button"
            onClick={() => {
              setHubTab("records");
              setModal("hub");
            }}
            className="ocean-pill-blue min-w-[170px] sm:min-w-[205px] px-5 py-2.5 flex items-center justify-center gap-2.5"
          >
            <TrophyCupIcon />
            <span className="font-display text-[17px] sm:text-[20px] font-extrabold text-white text-outline tracking-wide">
              {t.leaderboard}
            </span>
          </button>

          <button
            type="button"
            onClick={onOpenTrophies}
            className="ocean-pill-blue min-w-[165px] sm:min-w-[195px] px-5 py-2.5 flex items-center justify-center gap-2.5"
          >
            <GoldStarIcon />
            <span className="font-display text-[17px] sm:text-[20px] font-extrabold text-white text-outline tracking-wide">
              {t.trophies}
            </span>
          </button>
        </div>

        {/* Bottom-Right Stacked: Theme (Palm Island) & Setting (Wooden Ship Steering Wheel) */}
        <div className="pointer-events-auto fixed bottom-3 right-3 sm:bottom-5 sm:right-5 flex flex-col gap-2.5 items-stretch z-30">
          <button
            type="button"
            onClick={() => setModal("theme")}
            className="ocean-pill-blue min-w-[146px] sm:min-w-[172px] px-4 py-2 flex items-center gap-2.5"
          >
            <TropicalIslandIcon />
            <span className="font-display text-[17px] sm:text-[19px] font-extrabold text-white text-outline tracking-wide">
              {t.theme}
            </span>
          </button>

          <button
            type="button"
            onClick={() => setModal("setting")}
            className="ocean-pill-blue min-w-[146px] sm:min-w-[172px] px-4 py-2 flex items-center gap-2.5"
          >
            <WoodenShipWheelIcon />
            <span className="font-display text-[17px] sm:text-[19px] font-extrabold text-white text-outline tracking-wide">
              {t.setting}
            </span>
          </button>
        </div>
      </footer>

      {/* ================= MODAL 1: OCEAN HUB (LEADERBOARD / UPGRADES / ALL FISH) ================= */}
      {modal === "hub" && (
        <div
          className="fixed inset-0 z-40 flex items-center justify-center p-3 sm:p-5 bg-slate-950/75 pointer-events-auto"
          onClick={() => setModal(null)}
          role="dialog"
          aria-modal="true"
          aria-label={t.leaderboard}
        >
          <div
            className="artistic-wood-board relative w-full max-w-[920px] h-[86vh] max-h-[680px] flex flex-col gap-3 p-4 sm:p-5 overflow-hidden shadow-2xl"
            onClick={(e) => e.stopPropagation()}
          >
            <CornerRivets />

            <header className="relative z-10 flex flex-wrap items-center justify-between gap-2 pb-2.5 border-b border-amber-200/20 shrink-0">
              <nav className="flex items-center gap-1.5 flex-wrap">
                <button
                  type="button"
                  onClick={() => setHubTab("records")}
                  className="ui-btn px-3.5 py-1.5 text-[12.5px] text-white flex items-center gap-1.5"
                  style={{
                    background:
                      hubTab === "records" ? "linear-gradient(180deg, #ff9938 0%, #d95b12 100%)" : "#4d2c14",
                  }}
                >
                  <span>🏆</span>
                  <span>{t.leaderboard}</span>
                </button>
                <button
                  type="button"
                  onClick={() => setHubTab("upgrades")}
                  className="ui-btn px-3.5 py-1.5 text-[12.5px] text-white flex items-center gap-1.5"
                  style={{
                    background:
                      hubTab === "upgrades" ? "linear-gradient(180deg, #ff9938 0%, #d95b12 100%)" : "#4d2c14",
                  }}
                >
                  <span>⚡</span>
                  <span>{t.upgrades}</span>
                </button>
                <button
                  type="button"
                  onClick={() => setHubTab("skins")}
                  className="ui-btn px-3.5 py-1.5 text-[12.5px] text-white flex items-center gap-1.5"
                  style={{
                    background:
                      hubTab === "skins" ? "linear-gradient(180deg, #ff9938 0%, #d95b12 100%)" : "#4d2c14",
                  }}
                >
                  <span>🐠</span>
                  <span>
                    {t.allFish} ({SKINS.length})
                  </span>
                </button>
              </nav>

              <div className="flex items-center gap-2 ml-auto">
                <div className="ff-carved-slot px-3 h-[34px] flex items-center gap-1.5 shrink-0">
                  <img src={coin} className="w-4 h-4 shrink-0" alt="" />
                  <span className="font-extrabold text-[14px] text-yellow-300 tabular-nums">
                    {save.coins.toLocaleString("en-US")}
                  </span>
                </div>
                <button
                  type="button"
                  onClick={() => setModal(null)}
                  className="ui-btn px-3 py-1.5 text-[12px] text-amber-100"
                  style={{ background: "linear-gradient(180deg, #8c5b2f 0%, #5c3614 100%)" }}
                >
                  ✕ {t.close}
                </button>
              </div>
            </header>

            {/* HUB TAB 1: OCEAN RECORDS */}
            {hubTab === "records" && (
              <div className="relative z-10 flex-1 min-h-0 overflow-y-auto wood-scroll pr-1 flex flex-col gap-3">
                <div className="artistic-inset p-3.5 flex items-center justify-between gap-3 flex-wrap">
                  <div>
                    <h2 className="text-[18px] font-extrabold text-amber-100 text-outline">{t.recordsTitle}</h2>
                    <div className="text-[12px] font-semibold text-cyan-200/90 mt-0.5">
                      {save.name.trim() || t.defaultPlayerName} · {centerFishName}
                      {localizedEquippedTitle ? ` · «${localizedEquippedTitle}»` : ""}
                    </div>
                  </div>
                  <button
                    type="button"
                    onClick={() => {
                      setModal(null);
                      onOpenTrophies();
                    }}
                    className="ui-btn px-3.5 py-1.5 text-[12px] text-white"
                    style={{ background: "linear-gradient(180deg, #0ea5e9 0%, #0369a1 100%)" }}
                  >
                    🏅 {t.trophies} ({unlockedTrophyCount}/{TROPHIES.length})
                  </button>
                </div>

                <div className="grid grid-cols-2 sm:grid-cols-3 gap-2.5">
                  {[
                    { icon: "🏆", label: t.bestScore, val: save.best.toLocaleString("en-US"), col: "text-yellow-300" },
                    { icon: "👑", label: t.rank1Wins, val: `${save.rank1Count}×`, col: "text-amber-200" },
                    {
                      icon: "⏱️",
                      label: t.fastestPeak,
                      val: save.bestPeakTimeSec !== null ? formatSecShort(save.bestPeakTimeSec, lang) : t.notYet,
                      col: "text-cyan-200",
                    },
                    { icon: "🔥", label: t.bestCombo, val: `x${save.bestCombo}`, col: "text-orange-300" },
                    { icon: "🌊", label: t.deepestDive, val: `${save.bestDepth.toLocaleString("en-US")} m`, col: "text-sky-200" },
                    { icon: "🎮", label: t.totalRuns, val: `${save.totalRuns}`, col: "text-emerald-200" },
                  ].map((st) => (
                    <div key={st.label} className="artistic-inset p-3 flex flex-col gap-1">
                      <div className="text-[11px] font-bold text-amber-200/75 flex items-center gap-1.5">
                        <span>{st.icon}</span>
                        <span>{st.label}</span>
                      </div>
                      <div className={`text-[20px] sm:text-[22px] font-extrabold tabular-nums ${st.col}`}>
                        {st.val}
                      </div>
                    </div>
                  ))}
                </div>

                <div className="artistic-inset p-3.5 flex items-center justify-between gap-3 flex-wrap mt-auto">
                  <div className="text-[12px] font-bold text-amber-100/90">{t.controlsHint}</div>
                  <button
                    type="button"
                    onClick={() => {
                      setModal(null);
                      onPlay(cur.id);
                    }}
                    className="ui-btn px-4 py-1.5 text-[13px] text-white"
                    style={{ background: "linear-gradient(180deg, #4be880 0%, #1ba248 100%)" }}
                  >
                    ▶ {t.playNow}
                  </button>
                </div>
              </div>
            )}

            {/* HUB TAB 2: UPGRADES WORKSHOP */}
            {hubTab === "upgrades" && (
              <div className="relative z-10 flex-1 min-h-0 flex flex-col gap-2.5 overflow-y-auto wood-scroll pr-1">
                <div className="artistic-inset px-3.5 py-2.5 shrink-0">
                  <div className="text-[15px] font-extrabold text-amber-100">{t.workshopTitle}</div>
                  <div className="text-[11.5px] font-medium text-amber-200/80">{t.workshopDesc}</div>
                </div>

                <div className="flex flex-col gap-2.5">
                  {UPGRADE_META.map((u) => {
                    const lv = save.upgrades[u.id];
                    const max = lv >= MAX_UPGRADE;
                    const cost = max ? 0 : UPGRADE_COSTS[lv];
                    const canBuy = !max && save.coins >= cost;
                    const pct = Math.round((lv / MAX_UPGRADE) * 100);
                    const uCopy = lang === "id" ? u.idText : u.en;
                    return (
                      <div key={u.id} className="artistic-inset p-3.5 flex items-center justify-between gap-3">
                        <div className="flex items-center gap-3 min-w-0 flex-1">
                          <div className="ff-carved-slot w-12 h-12 flex items-center justify-center text-2xl shrink-0">
                            {u.icon}
                          </div>
                          <div className="min-w-0 flex-1">
                            <div className="flex items-center gap-2 flex-wrap">
                              <span className="text-[15px] font-extrabold text-white">{uCopy.name}</span>
                              <span className="px-2 py-0.5 rounded-md bg-cyan-950/90 border border-cyan-400/40 text-[11px] font-extrabold text-cyan-200 tabular-nums">
                                Lv {lv}/{MAX_UPGRADE}
                              </span>
                            </div>
                            <p className="text-[11.5px] text-amber-100/80 mt-0.5">{uCopy.desc}</p>
                            <div className="ff-bar-slot h-3 mt-2 overflow-hidden relative">
                              <div className="ff-yellow-fill h-full transition-all duration-200" style={{ width: `${pct}%` }} />
                            </div>
                          </div>
                        </div>

                        <button
                          type="button"
                          onClick={() => buyUp(u.id)}
                          disabled={!canBuy}
                          className="ui-btn px-3.5 py-2 min-w-[106px] text-[12.5px] text-white shrink-0 flex items-center justify-center gap-1.5 disabled:opacity-45 disabled:cursor-not-allowed tabular-nums"
                          style={{
                            background: max
                              ? "linear-gradient(180deg, #10b981 0%, #047857 100%)"
                              : canBuy
                                ? "linear-gradient(180deg, #ffb422 0%, #d97706 100%)"
                                : "#3f240f",
                          }}
                        >
                          {max ? (
                            <span>✓ {t.maxed}</span>
                          ) : (
                            <>
                              <img src={coin} className="w-4 h-4 shrink-0" alt="" />
                              <span className="text-[#231004] font-black">{cost}</span>
                            </>
                          )}
                        </button>
                      </div>
                    );
                  })}
                </div>
              </div>
            )}

            {/* HUB TAB 3: ALL FISH COLLECTION BROWSER */}
            {hubTab === "skins" && (
              <div className="relative z-10 flex-1 min-h-0 flex flex-col gap-2">
                <div className="flex flex-wrap items-center justify-between gap-2 shrink-0">
                  <div className="ff-carved-slot p-0.5 flex items-center gap-0.5 overflow-x-auto">
                    {(
                      [
                        { id: "all", label: `${t.filterAll} (${SKINS.length})` },
                        { id: "predator", label: `🦈 ${t.filterPredator}` },
                        { id: "reef", label: `🐠 ${t.filterReef}` },
                        { id: "rare", label: `★ ${t.filterRare}` },
                      ] as { id: SkinFilter; label: string }[]
                    ).map((tab) => (
                      <button
                        key={tab.id}
                        type="button"
                        onClick={() => setSkinFilter(tab.id)}
                        className={`px-2.5 py-1 rounded-md text-[11px] font-extrabold cursor-pointer transition-colors whitespace-nowrap shrink-0 ${
                          skinFilter === tab.id
                            ? "bg-amber-400 text-[#231004] shadow-sm"
                            : "text-amber-100/80 hover:text-white hover:bg-white/5"
                        }`}
                      >
                        {tab.label}
                      </button>
                    ))}
                  </div>

                  <div className="flex items-center gap-2 ml-auto">
                    <button
                      type="button"
                      onClick={pickRandomSkin}
                      className="ui-btn px-2.5 py-1 text-[11px] text-white"
                      style={{ background: "linear-gradient(180deg, #3292bc 0%, #1a587a 100%)" }}
                    >
                      🎲 {t.randomFish}
                    </button>
                    <div className="ff-carved-slot px-2.5 py-1 flex items-center gap-1.5 w-[170px] sm:w-[200px]">
                      <span className="text-[11px] text-amber-200/75" aria-hidden="true">
                        🔍
                      </span>
                      <input
                        type="text"
                        value={skinQuery}
                        onChange={(e) => setSkinQuery(e.target.value)}
                        placeholder={t.searchFishPlaceholder}
                        className="bg-transparent border-none outline-none text-[11.5px] font-bold text-amber-50 placeholder-amber-200/45 w-full"
                      />
                      {skinQuery && (
                        <button
                          type="button"
                          onClick={() => setSkinQuery("")}
                          className="text-[10px] font-extrabold text-amber-200/80 hover:text-white cursor-pointer px-1"
                        >
                          ✕
                        </button>
                      )}
                    </div>
                  </div>
                </div>

                <div ref={gridScrollRef} onScroll={handleGridScroll} className="flex-1 min-h-0 overflow-y-auto wood-scroll pr-1.5 pb-1">
                  {filteredSkins.length === 0 ? (
                    <div className="artistic-inset p-6 text-center flex flex-col items-center justify-center gap-2 my-4">
                      <div className="text-2xl">🐚</div>
                      <div className="text-sm font-extrabold text-amber-100">{t.noFishFound}</div>
                      <button
                        type="button"
                        onClick={() => {
                          setSkinFilter("all");
                          setSkinQuery("");
                        }}
                        className="ui-btn px-3 py-1 text-xs text-white"
                        style={{ background: "linear-gradient(180deg, #06b6d4 0%, #0369a1 100%)" }}
                      >
                        {t.showAllFish}
                      </button>
                    </div>
                  ) : (
                    <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-2.5">
                      {filteredSkins.map(({ skin: s, origIdx: idx }) => {
                        const isActive = s.id === cur.id;
                        const sName = getLocalizedSkinName(s.id, s.name, lang);
                        const sSub = getLocalizedSkinSubtitle(s.id, s.subtitle, lang);
                        return (
                          <button
                            key={s.id}
                            type="button"
                            ref={(el) => {
                              tileRefs.current[idx] = el;
                            }}
                            onClick={() => selectSkin(s.id, true)}
                            className={`${
                              isActive
                                ? "wood-fish-tile-active"
                                : s.rare
                                  ? "wood-fish-tile wood-fish-tile-rare"
                                  : "wood-fish-tile"
                            } p-2 flex flex-col justify-between gap-1.5 text-center`}
                          >
                            <div
                              className={`${
                                s.rare ? "etalase-lagoon-window etalase-lagoon-window-rare" : "etalase-lagoon-window"
                              } relative w-full h-[78px] overflow-hidden flex items-center justify-center`}
                            >
                              {s.rare ? (
                                <span className="badge-langka absolute top-1 left-1 z-10 px-1.5 py-0.5 rounded text-[8.5px] font-extrabold uppercase tracking-wider text-white">
                                  ★ {t.rareBadge}
                                </span>
                              ) : isNemoSkinId(s.id) ? (
                                <span className="absolute top-1 left-1 z-10 px-1.5 py-0.5 rounded text-[8.5px] font-extrabold uppercase tracking-wider text-white bg-gradient-to-b from-orange-400 to-orange-600 border border-amber-200/50 shadow-sm">
                                  🎨 {t.nemoVariants}
                                </span>
                              ) : null}
                              {(s.supports3D || s.is3D) && (
                                <span
                                  className={`absolute top-1 right-1 z-10 px-1.5 py-0.5 rounded text-[9px] font-extrabold uppercase ${
                                    s.is3D || save.mode3D
                                      ? "bg-cyan-400 text-[#052038]"
                                      : "bg-slate-950/65 text-cyan-200 border border-cyan-300/35"
                                  }`}
                                >
                                  {s.is3D ? "3D ONLY" : "3D"}
                                </span>
                              )}
                              <canvas
                                ref={(el) => {
                                  tileCanvasRefs.current[idx] = el;
                                }}
                                aria-label={sName}
                                className="w-[132px] h-[74px] object-contain block pointer-events-none"
                              />
                            </div>

                            <div className="px-0.5">
                              <div className={`text-[13.5px] font-extrabold leading-tight truncate ${isActive ? "text-[#2b1405]" : "text-amber-50"}`}>
                                {sName}
                              </div>
                              <div className={`text-[10.5px] font-bold truncate mt-0.5 ${isActive ? "text-[#5c2c0a]" : "text-cyan-200/90"}`}>
                                {sSub}
                              </div>
                            </div>

                            <div
                              className={`h-[24px] rounded-lg flex items-center justify-center text-[10.5px] font-extrabold tracking-wide ${
                                isActive
                                  ? "bg-[#241105] text-yellow-300 border border-[#613412]"
                                  : "bg-black/40 text-amber-300 border border-amber-200/15"
                              }`}
                            >
                              {isActive ? `✓ ${t.active}` : t.select}
                            </div>
                          </button>
                        );
                      })}
                    </div>
                  )}
                </div>
              </div>
            )}
          </div>
        </div>
      )}

      {/* ================= MODAL 2: THEME & OCEAN VISUALS ================= */}
      {modal === "theme" && (
        <div
          className="fixed inset-0 z-40 flex items-center justify-center p-3 sm:p-5 bg-slate-950/75 pointer-events-auto"
          onClick={() => setModal(null)}
          role="dialog"
          aria-modal="true"
          aria-label={t.themeModalTitle}
        >
          <div
            className="artistic-wood-board relative w-full max-w-[680px] max-h-[88vh] flex flex-col gap-3 p-4 sm:p-5 overflow-hidden shadow-2xl"
            onClick={(e) => e.stopPropagation()}
          >
            <CornerRivets />

            <header className="relative z-10 flex items-center justify-between gap-3 pb-2 border-b border-amber-200/20 shrink-0">
              <div>
                <h2 className="text-[19px] sm:text-[22px] font-extrabold text-amber-100 text-outline flex items-center gap-2">
                  <span>🏝️</span>
                  <span>{t.themeModalTitle}</span>
                </h2>
                <p className="text-[11.5px] font-semibold text-cyan-200/90 mt-0.5">{t.themeModalDesc}</p>
              </div>
              <button
                type="button"
                onClick={() => setModal(null)}
                className="ui-btn px-3 py-1.5 text-[12px] text-amber-100 shrink-0"
                style={{ background: "linear-gradient(180deg, #8c5b2f 0%, #5c3614 100%)" }}
              >
                ✕ {t.close}
              </button>
            </header>

            <div className="relative z-10 flex-1 min-h-0 overflow-y-auto wood-scroll pr-1 flex flex-col gap-2.5">
              {/* 3D Ocean World */}
              <button
                type="button"
                onClick={() => setSave({ ...save, laut: !save.laut })}
                className={`w-full rounded-xl border p-3 flex items-center justify-between gap-3 cursor-pointer text-left transition-all ${
                  save.laut
                    ? "bg-[#06364e]/90 border-teal-300/80 shadow-[0_0_16px_rgba(45,212,191,0.28)]"
                    : "bg-[#241206]/85 border-[#a67342]/60"
                }`}
              >
                <div className="flex items-center gap-2.5 min-w-0">
                  <span className="text-xl">🌊</span>
                  <div>
                    <div className="text-[13px] font-extrabold text-teal-100">{t.ocean3DMode}</div>
                    <div className="text-[11px] text-cyan-100/80">{t.ocean3DDesc}</div>
                  </div>
                </div>
                <span
                  className={`shrink-0 px-2.5 py-1 rounded-lg text-[11px] font-extrabold ${
                    save.laut ? "bg-teal-300 text-[#042a36]" : "bg-amber-400 text-[#231004]"
                  }`}
                >
                  {save.laut ? t.on : t.off}
                </span>
              </button>

              {/* Ocean Backdrop */}
              <div className="artistic-inset p-3 flex flex-col gap-2">
                <div className="text-[12px] font-extrabold text-amber-200">🎨 {t.backdropLabel}</div>
                <div className="grid grid-cols-2 sm:grid-cols-3 gap-1.5">
                  {(
                    [
                      { id: "game1", en: "🌊 Ocean Classic", idLabel: "🌊 Laut Biru (G1)" },
                      { id: "reef_g1", en: "☀️ Reef + G1 Water", idLabel: "☀️ Reef + Air G1" },
                      { id: "game2", en: "🌴 Tropical Reef", idLabel: "🌴 Reef (G2)" },
                      { id: "shipwreck", en: "⚓ Shipwreck", idLabel: "⚓ Kapal Karam" },
                      { id: "kelp", en: "🌿 Kelp Forest", idLabel: "🌿 Hutan Kelp" },
                      { id: "temple", en: "🏛️ Coral Temple", idLabel: "🏛️ Kuil Karang" },
                      { id: "lagoon", en: "✨ Crystal Lagoon", idLabel: "✨ Laguna Gua" },
                    ] as { id: BgStyle; en: string; idLabel: string }[]
                  ).map((opt) => {
                    const active = save.bgStyle === opt.id;
                    return (
                      <button
                        key={opt.id}
                        type="button"
                        onClick={() => setSave({ ...save, bgStyle: opt.id })}
                        className={`px-2.5 py-1.5 rounded-lg text-[11.5px] font-extrabold cursor-pointer transition-colors ${
                          active ? "bg-teal-300 text-[#042a36] shadow-sm" : "bg-black/35 text-amber-100/85 hover:bg-black/55"
                        }`}
                      >
                        {lang === "id" ? opt.idLabel : opt.en}
                      </button>
                    );
                  })}
                </div>
              </div>

              {/* Reef Model + Reef Style + Boulders */}
              <div className="artistic-inset p-3 flex flex-col gap-2.5">
                <div className="flex items-center justify-between gap-2 flex-wrap">
                  <span className="text-[12px] font-extrabold text-amber-200">🪸 {t.reefModeLabel}</span>
                  <div className="flex items-center gap-1 flex-wrap">
                    {(
                      [
                        { id: "game1", en: "🪨 Original G1", idLabel: "🪨 Asli G1" },
                        { id: "game2", en: "🪸 100% G2 Reef", idLabel: "🪸 100% G2" },
                        { id: "mix", en: "🌺 Mix G1+G2", idLabel: "🌺 Mix G1+G2" },
                      ] as { id: ReefMixMode; en: string; idLabel: string }[]
                    ).map((opt) => (
                      <button
                        key={opt.id}
                        type="button"
                        onClick={() => setSave({ ...save, laut: true, reefMix: opt.id })}
                        className={`px-2.5 py-1 rounded-md text-[11px] font-extrabold cursor-pointer ${
                          save.reefMix === opt.id ? "bg-teal-300 text-[#042a36]" : "bg-black/35 text-amber-100/80 hover:text-white"
                        }`}
                      >
                        {lang === "id" ? opt.idLabel : opt.en}
                      </button>
                    ))}
                  </div>
                </div>

                {save.reefMix !== "game1" && (
                  <div className="flex items-center justify-between gap-2 flex-wrap">
                    <span className="text-[12px] font-extrabold text-amber-200">🪨 {t.rockStyleLabel}</span>
                    <div className="flex items-center gap-1">
                      {(
                        [
                          { id: "g1", en: "🪨 G1 Boulders", idLabel: "🪨 G1 Asli" },
                          { id: "g2", en: "⛰️ G2 Cliffs", idLabel: "⛰️ G2 Tebing" },
                        ] as { id: ReefRockMode; en: string; idLabel: string }[]
                      ).map((opt) => (
                        <button
                          key={opt.id}
                          type="button"
                          onClick={() => setSave({ ...save, laut: true, rockStyle: opt.id })}
                          className={`px-2.5 py-1 rounded-md text-[11px] font-extrabold cursor-pointer ${
                            save.rockStyle === opt.id ? "bg-amber-300 text-[#231004]" : "bg-black/35 text-amber-100/80 hover:text-white"
                          }`}
                        >
                          {lang === "id" ? opt.idLabel : opt.en}
                        </button>
                      ))}
                    </div>
                  </div>
                )}

                <div className="flex items-center justify-between gap-2 flex-wrap">
                  <span className="text-[12px] font-extrabold text-amber-200">🏔️ {t.reefDepthLabel}</span>
                  <div className="flex items-center gap-1">
                    <button
                      type="button"
                      onClick={() => setSave({ ...save, reef3D: true })}
                      className={`px-3 py-1 rounded-md text-[11px] font-extrabold cursor-pointer ${
                        save.reef3D ? "bg-cyan-300 text-[#052038]" : "bg-black/35 text-amber-100/80"
                      }`}
                    >
                      3D
                    </button>
                    <button
                      type="button"
                      onClick={() => setSave({ ...save, reef3D: false })}
                      className={`px-3 py-1 rounded-md text-[11px] font-extrabold cursor-pointer ${
                        !save.reef3D ? "bg-amber-400 text-[#231004]" : "bg-black/35 text-amber-100/80"
                      }`}
                    >
                      2D
                    </button>
                  </div>
                </div>
              </div>

              {/* Ocean Lighting & Graphics */}
              <div className="artistic-inset p-3 flex flex-col gap-2.5">
                <div className="flex items-center justify-between gap-2 flex-wrap">
                  <span className="text-[12px] font-extrabold text-amber-200">💡 {t.oceanLightLabel}</span>
                  <div className="flex items-center gap-1">
                    {(
                      [
                        { id: "after", en: "✨ Enhanced (Soft)", idLabel: "✨ After (Halus)" },
                        { id: "before", en: "🌑 Classic", idLabel: "🌑 Before (Awal)" },
                      ] as { id: OceanLightingMode; en: string; idLabel: string }[]
                    ).map((opt) => (
                      <button
                        key={opt.id}
                        type="button"
                        onClick={() => setSave({ ...save, oceanLighting: opt.id })}
                        className={`px-2.5 py-1 rounded-md text-[11px] font-extrabold cursor-pointer ${
                          save.oceanLighting === opt.id ? "bg-amber-300 text-[#231004]" : "bg-black/35 text-amber-100/80 hover:text-white"
                        }`}
                      >
                        {lang === "id" ? opt.idLabel : opt.en}
                      </button>
                    ))}
                  </div>
                </div>

                <div className="flex items-center justify-between gap-2 flex-wrap">
                  <span className="text-[12px] font-extrabold text-amber-200">🖥️ {t.graphicsLabel}</span>
                  <div className="flex items-center gap-1 flex-wrap">
                    {(
                      [
                        { id: "hd_boost", label: `🚀 ${t.hud.gfxBoost}` },
                        { id: "super_hd", label: `💎 ${t.hud.gfxSuper}` },
                        { id: "ultra_fps", label: `⚡ ${t.hud.gfxUltra}` },
                      ] as { id: GraphicsMode; label: string }[]
                    ).map((opt) => (
                      <button
                        key={opt.id}
                        type="button"
                        onClick={() => setSave({ ...save, graphicsMode: opt.id })}
                        className={`px-2.5 py-1 rounded-md text-[11px] font-extrabold cursor-pointer ${
                          save.graphicsMode === opt.id ? "bg-cyan-300 text-[#052038]" : "bg-black/35 text-amber-100/80 hover:text-white"
                        }`}
                      >
                        {opt.label}
                      </button>
                    ))}
                  </div>
                </div>
              </div>
            </div>

            <footer className="relative z-10 flex items-center justify-end gap-2 pt-1 border-t border-amber-200/15 shrink-0">
              <button
                type="button"
                onClick={() => setModal(null)}
                className="ui-btn px-4 py-1.5 text-[12.5px] text-white"
                style={{ background: "linear-gradient(180deg, #4be880 0%, #1ba248 100%)" }}
              >
                {t.saveAndClose}
              </button>
            </footer>
          </div>
        </div>
      )}

      {/* ================= MODAL 3: SETTINGS (LANGUAGE, PLAYER NAME, AUDIO, CAMERA, SPEED) ================= */}
      {modal === "setting" && (
        <div
          className="fixed inset-0 z-40 flex items-center justify-center p-3 sm:p-5 bg-slate-950/75 pointer-events-auto"
          onClick={() => setModal(null)}
          role="dialog"
          aria-modal="true"
          aria-label={t.settingsModalTitle}
        >
          <div
            className="artistic-wood-board relative w-full max-w-[640px] max-h-[88vh] flex flex-col gap-3 p-4 sm:p-5 overflow-hidden shadow-2xl"
            onClick={(e) => e.stopPropagation()}
          >
            <CornerRivets />

            <header className="relative z-10 flex items-center justify-between gap-3 pb-2 border-b border-amber-200/20 shrink-0">
              <div className="flex items-center gap-2.5">
                <WoodenShipWheelIcon />
                <div>
                  <h2 className="text-[19px] sm:text-[22px] font-extrabold text-amber-100 text-outline">
                    {t.settingsModalTitle}
                  </h2>
                  <p className="text-[11.5px] font-semibold text-cyan-200/90">{t.settingsModalDesc}</p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setModal(null)}
                className="ui-btn px-3 py-1.5 text-[12px] text-amber-100 shrink-0"
                style={{ background: "linear-gradient(180deg, #8c5b2f 0%, #5c3614 100%)" }}
              >
                ✕ {t.close}
              </button>
            </header>

            <div className="relative z-10 flex-1 min-h-0 overflow-y-auto wood-scroll pr-1 flex flex-col gap-2.5">
              {/* Language Switcher */}
              <div className="artistic-inset p-3 flex items-center justify-between gap-2 flex-wrap">
                <span className="text-[12.5px] font-extrabold text-amber-200">🌐 {t.languageLabel}</span>
                <div className="flex items-center gap-1.5">
                  <button
                    type="button"
                    onClick={() => setSave({ ...save, lang: "en" })}
                    className={`px-3 py-1.5 rounded-lg text-[11.5px] font-extrabold cursor-pointer transition-colors ${
                      save.lang === "en" ? "bg-cyan-300 text-[#052038] shadow-sm" : "bg-black/40 text-amber-100/80 hover:text-white"
                    }`}
                  >
                    🇺🇸 {t.langEn}
                  </button>
                  <button
                    type="button"
                    onClick={() => setSave({ ...save, lang: "id" })}
                    className={`px-3 py-1.5 rounded-lg text-[11.5px] font-extrabold cursor-pointer transition-colors ${
                      save.lang === "id" ? "bg-amber-300 text-[#231004] shadow-sm" : "bg-black/40 text-amber-100/80 hover:text-white"
                    }`}
                  >
                    🇮🇩 {t.langId}
                  </button>
                </div>
              </div>

              {/* Player Name */}
              <div className="artistic-inset p-3 flex flex-col gap-1.5">
                <label className="text-[12px] font-extrabold text-amber-200">🏷️ {t.playerNameLabel}</label>
                <div className="ff-carved-slot px-3 py-2 flex items-center gap-2 focus-within:border-amber-300/70">
                  <input
                    type="text"
                    value={save.name}
                    maxLength={14}
                    onChange={(e) => setSave({ ...save, name: e.target.value })}
                    onKeyDown={(e) => {
                      if (e.key === "Enter") {
                        setModal(null);
                        onPlay(cur.id);
                      }
                    }}
                    placeholder={t.playerNamePlaceholder}
                    className="bg-transparent border-none outline-none text-amber-50 font-extrabold text-[14px] w-full placeholder-amber-200/45"
                  />
                </div>
              </div>

              {/* Fish Model 2D / 3D + Audio */}
              <div className="artistic-inset p-3 flex flex-col gap-2.5">
                <div className="flex items-center justify-between gap-2 flex-wrap">
                  <span className="text-[12px] font-extrabold text-amber-200">🐠 {t.fishRenderLabel}</span>
                  <div className="flex items-center gap-1">
                    <button
                      type="button"
                      onClick={() => setSave({ ...save, mode3D: false })}
                      className={`px-3 py-1 rounded-md text-[11.5px] font-extrabold cursor-pointer ${
                        !save.mode3D ? "bg-amber-400 text-[#231004]" : "bg-black/35 text-amber-100/80"
                      }`}
                    >
                      {t.fish2D}
                    </button>
                    <button
                      type="button"
                      onClick={() => setSave({ ...save, mode3D: true })}
                      className={`px-3 py-1 rounded-md text-[11.5px] font-extrabold cursor-pointer ${
                        save.mode3D ? "bg-cyan-300 text-[#052038]" : "bg-black/35 text-amber-100/80"
                      }`}
                    >
                      {t.fish3D}
                    </button>
                  </div>
                </div>

                <div className="flex items-center justify-between gap-2 flex-wrap">
                  <span className="text-[12px] font-extrabold text-amber-200">🔊 {t.soundPackLabel}</span>
                  <div className="flex items-center gap-1 flex-wrap">
                    {(
                      [
                        { id: "wav", label: `🎵 ${t.soundWav}` },
                        { id: "classic", label: `🎹 ${t.soundClassic}` },
                      ] as { id: SoundPack; label: string }[]
                    ).map((opt) => (
                      <button
                        key={opt.id}
                        type="button"
                        onClick={() => {
                          sfx.init();
                          sfx.setPack(opt.id);
                          setSave({ ...save, soundPack: opt.id });
                          if (opt.id === "wav") {
                            void sfx.whenReady(["bite1", "bite2", "eat"]).then(() => {
                              if (sfx.pack === "wav") sfx.gulp(1.0, true, 0);
                            });
                          } else {
                            window.setTimeout(() => sfx.gulp(1.0, true, 0), 40);
                          }
                        }}
                        className={`px-2.5 py-1 rounded-md text-[11px] font-extrabold cursor-pointer ${
                          save.soundPack === opt.id
                            ? opt.id === "wav"
                              ? "bg-emerald-300 text-[#042e29]"
                              : "bg-amber-400 text-[#231004]"
                            : "bg-black/35 text-amber-100/80 hover:text-white"
                        }`}
                      >
                        {opt.label}
                      </button>
                    ))}
                  </div>
                </div>

                {onToggleMute && (
                  <div className="flex items-center justify-between gap-2 flex-wrap">
                    <span className="text-[12px] font-extrabold text-amber-200">🔈 {t.muteLabel}</span>
                    <button
                      type="button"
                      onClick={onToggleMute}
                      className={`px-3 py-1 rounded-md text-[11.5px] font-extrabold cursor-pointer ${
                        !muted ? "bg-emerald-300 text-[#042e29]" : "bg-rose-400 text-rose-950"
                      }`}
                    >
                      {muted ? `🔇 ${t.soundMuted}` : `🔊 ${t.soundOn}`}
                    </button>
                  </div>
                )}
              </div>

              {/* Speed, Camera Zoom & Swallow Size */}
              <div className="artistic-inset p-3 flex flex-col gap-2.5">
                <div className="flex items-center justify-between gap-2 flex-wrap">
                  <span className="text-[12px] font-extrabold text-amber-200">⚡ {t.swimSpeedLabel}</span>
                  <div className="flex items-center gap-1">
                    {[0.8, 1.0, 1.3, 1.6].map((val) => (
                      <button
                        key={val}
                        type="button"
                        onClick={() => setSave({ ...save, speedPref: val })}
                        className={`px-2.5 py-1 rounded-md text-[11px] font-extrabold cursor-pointer tabular-nums ${
                          Math.abs(save.speedPref - val) < 0.05
                            ? "bg-amber-400 text-[#231004]"
                            : "bg-black/35 text-amber-100/80 hover:text-white"
                        }`}
                      >
                        {val.toFixed(1)}x
                      </button>
                    ))}
                  </div>
                </div>

                <div className="flex flex-col gap-1.5">
                  <div className="flex items-center justify-between gap-2 flex-wrap">
                    <span className="text-[12px] font-extrabold text-amber-200">🔍 {t.cameraZoomLabel}</span>
                    <div className="flex items-center gap-1">
                      {[
                        { val: 1.0, label: t.zoomNormal },
                        { val: 1.34, label: t.zoomMid },
                        { val: 1.75, label: t.zoomClose },
                      ].map((opt) => {
                        const active =
                          opt.val === 1.0
                            ? save.cameraZoom < 1.18
                            : opt.val === 1.34
                              ? save.cameraZoom >= 1.18 && save.cameraZoom < 1.55
                              : save.cameraZoom >= 1.55;
                        return (
                          <button
                            key={opt.val}
                            type="button"
                            onClick={() => setSave({ ...save, cameraZoom: opt.val })}
                            className={`px-2.5 py-1 rounded-md text-[11px] font-extrabold cursor-pointer ${
                              active ? "bg-amber-300 text-[#231004]" : "bg-black/35 text-amber-100/80 hover:text-white"
                            }`}
                          >
                            {opt.label}
                          </button>
                        );
                      })}
                    </div>
                  </div>
                  <div className="flex items-center gap-2">
                    <span className="text-[10.5px] font-bold text-amber-200/75">{t.far}</span>
                    <input
                      type="range"
                      min={1.0}
                      max={1.85}
                      step={0.05}
                      value={save.cameraZoom}
                      onChange={(e) => setSave({ ...save, cameraZoom: Number(e.target.value) })}
                      className="flex-1 h-1.5 accent-amber-300 cursor-pointer"
                    />
                    <span className="text-[11px] font-extrabold text-amber-100 tabular-nums w-10 text-right">
                      {save.cameraZoom.toFixed(2)}×
                    </span>
                  </div>
                </div>

                <div className="flex items-center justify-between gap-2 flex-wrap">
                  <span className="text-[12px] font-extrabold text-amber-200">🍽️ {t.bulkLabel}</span>
                  <div className="flex items-center gap-1">
                    {[1.0, 1.7, 2.0].map((val) => (
                      <button
                        key={val}
                        type="button"
                        onClick={() => {
                          setSave({ ...save, bulkPref: val });
                          triggerTestBite();
                        }}
                        className={`px-2.5 py-1 rounded-md text-[11px] font-extrabold cursor-pointer tabular-nums ${
                          Math.abs(save.bulkPref - val) < 0.05
                            ? "bg-cyan-300 text-[#052038]"
                            : "bg-black/35 text-amber-100/80 hover:text-white"
                        }`}
                      >
                        {val.toFixed(1)}x
                      </button>
                    ))}
                  </div>
                </div>
              </div>
            </div>

            <footer className="relative z-10 flex items-center justify-between gap-2 pt-1 border-t border-amber-200/15 shrink-0 flex-wrap">
              <span className="text-[11px] font-bold text-amber-100/80">{t.controlsHint}</span>
              <button
                type="button"
                onClick={() => setModal(null)}
                className="ui-btn px-4 py-1.5 text-[12.5px] text-white ml-auto"
                style={{ background: "linear-gradient(180deg, #4be880 0%, #1ba248 100%)" }}
              >
                {t.saveAndClose}
              </button>
            </footer>
          </div>
        </div>
      )}

      {/* ================= MODAL 4: NEMO 5-MORPH SKIN PICKER ================= */}
      {modal === "nemo" && (
        <div
          className="fixed inset-0 z-40 flex items-center justify-center p-3 sm:p-5 bg-slate-950/75 pointer-events-auto"
          onClick={() => setModal(null)}
          role="dialog"
          aria-modal="true"
          aria-label={t.nemoModalTitle}
        >
          <div
            className="artistic-wood-board relative w-full max-w-[780px] max-h-[90vh] flex flex-col gap-3 p-4 sm:p-5 overflow-hidden shadow-2xl"
            onClick={(e) => e.stopPropagation()}
          >
            <CornerRivets />

            <header className="relative z-10 flex items-center justify-between gap-3 pb-2 border-b border-amber-200/20 shrink-0">
              <div className="min-w-0">
                <h2 className="text-[18px] sm:text-[21px] font-extrabold text-amber-100 text-outline flex items-center gap-2">
                  <span aria-hidden="true">🐠</span>
                  <span>
                    {t.nemoModalTitle} ({nemoSkins.length})
                  </span>
                </h2>
                <p className="text-[11.5px] font-semibold text-cyan-200/90 mt-0.5">{t.nemoModalDesc}</p>
              </div>
              <button
                type="button"
                onClick={() => setModal(null)}
                className="ui-btn px-3 py-1.5 text-[12px] text-amber-100 shrink-0"
                style={{ background: "linear-gradient(180deg, #8c5b2f 0%, #5c3614 100%)" }}
              >
                ✕ {t.close}
              </button>
            </header>

            <div className="relative z-10 grid grid-cols-2 sm:grid-cols-3 gap-2.5 overflow-y-auto wood-scroll pr-1">
              {nemoSkins.map(({ skin: s }, ni) => {
                const isActive = s.id === cur.id;
                const sName = getLocalizedSkinName(s.id, s.name, lang);
                const meta = NEMO_VARIANT_META[s.id]?.[lang] || {
                  badge: "NEMO",
                  desc: getLocalizedSkinSubtitle(s.id, s.subtitle, lang),
                };
                return (
                  <button
                    key={s.id}
                    type="button"
                    onClick={() => pickNemoVariant(s.id)}
                    className={`${isActive ? "wood-fish-tile-active" : "wood-fish-tile"} p-2.5 flex flex-col justify-between gap-1.5 text-center`}
                  >
                    <div className="etalase-lagoon-window relative w-full h-[92px] overflow-hidden flex items-center justify-center">
                      <span className="absolute top-1 left-1 z-10 px-1.5 py-0.5 rounded text-[8.5px] font-extrabold uppercase tracking-wider bg-slate-950/75 text-amber-200 border border-amber-300/35">
                        {meta.badge}
                      </span>
                      {s.supports3D && (
                        <span
                          className={`absolute top-1 right-1 z-10 px-1.5 py-0.5 rounded text-[9px] font-extrabold uppercase ${
                            save.mode3D
                              ? "bg-cyan-400 text-[#052038]"
                              : "bg-slate-950/65 text-cyan-200 border border-cyan-300/35"
                          }`}
                        >
                          {save.mode3D ? "3D" : "2D"}
                        </span>
                      )}
                      <canvas
                        ref={(el) => {
                          nemoPickerCanvasRefs.current[ni] = el;
                        }}
                        aria-label={sName}
                        className="w-[156px] h-[88px] object-contain block pointer-events-none"
                      />
                    </div>

                    <div className="px-0.5">
                      <div className={`text-[14px] font-extrabold leading-tight truncate ${isActive ? "text-[#2b1405]" : "text-amber-50"}`}>
                        {sName}
                      </div>
                      <div className={`text-[10.5px] font-bold truncate mt-0.5 ${isActive ? "text-[#5c2c0a]" : "text-cyan-200/90"}`}>
                        {meta.desc}
                      </div>
                    </div>

                    <div
                      className={`h-[26px] rounded-lg flex items-center justify-center text-[11px] font-extrabold tracking-wide ${
                        isActive
                          ? "bg-[#241105] text-yellow-300 border border-[#613412]"
                          : "bg-black/40 text-amber-300 border border-amber-200/15"
                      }`}
                    >
                      {isActive ? `✓ ${t.active}` : t.chooseSkin}
                    </div>
                  </button>
                );
              })}
            </div>

            <footer className="relative z-10 flex items-center justify-between gap-2 pt-1 border-t border-amber-200/15 shrink-0">
              <div className="text-[11.5px] font-bold text-amber-100/90 truncate">
                {t.nowActive} <span className="text-yellow-300 font-extrabold">{centerFishName}</span>
              </div>
              <div className="flex items-center gap-2 shrink-0">
                <button
                  type="button"
                  onClick={() => setModal(null)}
                  className="ui-btn px-3.5 py-1.5 text-[12px] text-amber-100"
                  style={{ background: "linear-gradient(180deg, #8c5b2f 0%, #5c3614 100%)" }}
                >
                  {t.saveAndClose}
                </button>
                <button
                  type="button"
                  onClick={() => {
                    setModal(null);
                    onPlay(cur.id);
                  }}
                  className="ui-btn px-4 py-1.5 text-[12.5px] text-white"
                  style={{ background: "linear-gradient(180deg, #4be880 0%, #1ba248 100%)" }}
                >
                  ▶ {t.playNow}
                </button>
              </div>
            </footer>
          </div>
        </div>
      )}

      {/* TOAST NOTIFICATION */}
      {toast && (
        <div className="fixed top-4 left-1/2 -translate-x-1/2 z-50 pointer-events-none">
          <div className="artistic-wood-board px-4 py-2 flex items-center gap-2 text-xs sm:text-sm font-extrabold text-amber-50 shadow-2xl">
            <span aria-hidden="true">{toast.icon}</span>
            <span>{toast.msg}</span>
          </div>
        </div>
      )}
    </div>
  );
}
