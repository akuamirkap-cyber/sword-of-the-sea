export declare function rand(seed: number): () => number;
export declare function fbm2(x: number, y: number, octaves?: number): number;
export declare function fbm3(x: number, y: number, z: number, octaves?: number): number;
export declare function hash2(x: number, y: number): number;
export declare function noise2(x: number, y: number): number;
export declare function noise3(x: number, y: number, z: number): number;
export declare function sampler3(...args: unknown[]): (x: number, y: number, z: number) => number;
export declare function surfaceNets(...args: unknown[]): {
  nv: number;
  pos: Float32Array;
  idx: Uint32Array;
};
export declare const clamp: (v: number, a: number, b: number) => number;
export declare const lerp: (a: number, b: number, t: number) => number;
export declare const smoothstep: (a: number, b: number, x: number) => number;
export declare const saturate: (v: number) => number;
export declare const TAU: number;
