import * as THREE from "three";
import { RoomEnvironment } from "three/examples/jsm/environments/RoomEnvironment.js";
import { isSoftwareWebGL } from "./fish3d";

export type MenuIcon3DKind = "crown" | "wheel" | "island";

interface IconRig {
  kind: MenuIcon3DKind;
  scene: THREE.Scene;
  camera: THREE.PerspectiveCamera;
  root: THREE.Group;
  update: (t: number, hoverAmt: number, boostPhase: number) => void;
  aspect: number;
  baseW: number;
  baseH: number;
  dispose: () => void;
}

interface SubEntry {
  id: number;
  kind: MenuIcon3DKind;
  canvas: HTMLCanvasElement;
  ctx: CanvasRenderingContext2D | null;
  hoverTarget: number;
  hoverCur: number;
  boostTarget: number;
  boostCur: number;
  boostVel: number;
  paused: boolean;
  lastCssW: number;
  lastCssH: number;
  lastDrawT: number;
  staticDone: boolean;
}

function makeCanvasTex(
  w: number,
  h: number,
  paint: (ctx: CanvasRenderingContext2D, w: number, h: number) => void,
  srgb = true,
  repeat = false
): THREE.CanvasTexture {
  const cv = document.createElement("canvas");
  cv.width = w;
  cv.height = h;
  const ctx = cv.getContext("2d")!;
  paint(ctx, w, h);
  const tex = new THREE.CanvasTexture(cv);
  tex.colorSpace = srgb ? THREE.SRGBColorSpace : THREE.NoColorSpace;
  tex.wrapS = repeat ? THREE.RepeatWrapping : THREE.ClampToEdgeWrapping;
  tex.wrapT = repeat ? THREE.RepeatWrapping : THREE.ClampToEdgeWrapping;
  tex.anisotropy = 4;
  tex.needsUpdate = true;
  return tex;
}

function setupIconLights(scene: THREE.Scene, warmKey = 0xfff8e6, rimHex = 0x7ce8ff): void {
  const hemi = new THREE.HemisphereLight(0xf2fbff, 0x2b6cb0, 1.18);
  const key = new THREE.DirectionalLight(warmKey, 1.55);
  key.position.set(-1.9, 3.1, 3.4);
  const fill = new THREE.DirectionalLight(0xfff1d6, 0.56);
  fill.position.set(2.6, 1.0, 2.2);
  const rim = new THREE.DirectionalLight(rimHex, 0.72);
  rim.position.set(1.8, 1.6, -2.8);
  scene.add(hemi, key, fill, rim);
}

function addCrispOutline(
  mesh: THREE.Mesh,
  hex: number,
  scaleX: number,
  scaleY = scaleX,
  scaleZ = scaleX,
  trackM: <T extends THREE.Material>(m: T) => T
): THREE.Mesh {
  const mat = trackM(
    new THREE.MeshBasicMaterial({
      color: hex,
      side: THREE.BackSide,
      depthWrite: true,
    })
  );
  const shell = new THREE.Mesh(mesh.geometry, mat);
  shell.scale.set(scaleX, scaleY, scaleZ);
  shell.renderOrder = -1;
  mesh.add(shell);
  return shell;
}

/* ============================================================================
 * 1. 3D ROYAL GOLDEN CROWN (MAHKOTA EMAS 3D)
 *    Full sculpted 360° 5-point king crown: beveled thick flared gold band,
 *    top/bottom pearl-beaded trim rails, plush crimson velvet dome lining,
 *    shiny gold crown tips with orb finials, sparkling faceted Ruby,
 *    ocean Sapphires & Emeralds mounted in raised beveled golden bezels!
 * ============================================================================ */
function buildCrownRig(envTex: THREE.Texture | null): IconRig {
  const geos: THREE.BufferGeometry[] = [];
  const mats: THREE.Material[] = [];
  const texs: THREE.Texture[] = [];
  const tG = <T extends THREE.BufferGeometry>(g: T) => (geos.push(g), g);
  const tM = <T extends THREE.Material>(m: T) => (mats.push(m), m);
  const tT = <T extends THREE.Texture>(x: T) => (texs.push(x), x);

  const scene = new THREE.Scene();
  if (envTex) {
    scene.environment = envTex;
    scene.environmentIntensity = 0.62;
  }
  setupIconLights(scene, 0xfff9e0, 0xffea94);

  // Subtle top highlight spot for sparkling gold crown shimmer
  const sparkleLight = new THREE.PointLight(0xfff4b8, 1.25, 6);
  sparkleLight.position.set(-1.1, 1.6, 1.8);
  scene.add(sparkleLight);

  // Generous studio distance guarantees top center orb & full golden halo never clip on float/hover
  const camera = new THREE.PerspectiveCamera(29, 1.24, 0.1, 20);
  camera.position.set(0, 0.72, 3.36);
  camera.lookAt(0, 0.12, 0);

  // Hand-painted subtle warm hammered gold map (bright royal 24k saturation)
  const goldTex = tT(
    makeCanvasTex(256, 128, (c, w, h) => {
      const g = c.createLinearGradient(0, 0, 0, h);
      g.addColorStop(0, "#fff5a8");
      g.addColorStop(0.26, "#ffd83b");
      g.addColorStop(0.68, "#f5a616");
      g.addColorStop(1, "#d97706");
      c.fillStyle = g;
      c.fillRect(0, 0, w, h);
      // Warm luminous hammered satin glint strokes
      for (let i = 0; i < 120; i++) {
        const x = ((i * 73) % w);
        const y = ((i * 41) % h);
        c.fillStyle = i % 2 === 0 ? "rgba(255,252,212,0.14)" : "rgba(180,83,9,0.09)";
        c.beginPath();
        c.ellipse(x, y, 16, 4, 0, 0, Math.PI * 2);
        c.fill();
      }
    })
  );

  const goldWallMat = tM(
    new THREE.MeshPhysicalMaterial({
      map: goldTex,
      color: 0xffffff,
      metalness: 0.44,
      roughness: 0.2,
      clearcoat: 0.85,
      clearcoatRoughness: 0.1,
      emissive: 0x7c3e00,
      emissiveIntensity: 0.22,
    })
  );

  const goldBandMat = tM(
    new THREE.MeshPhysicalMaterial({
      color: 0xffbf1f,
      metalness: 0.48,
      roughness: 0.22,
      clearcoat: 0.85,
      clearcoatRoughness: 0.11,
      emissive: 0x6b2f00,
      emissiveIntensity: 0.24,
    })
  );

  const goldBrightMat = tM(
    new THREE.MeshPhysicalMaterial({
      color: 0xffe45c,
      metalness: 0.42,
      roughness: 0.15,
      clearcoat: 1.0,
      clearcoatRoughness: 0.06,
      emissive: 0x854d0e,
      emissiveIntensity: 0.26,
    })
  );

  const goldDarkTrimMat = tM(
    new THREE.MeshStandardMaterial({
      color: 0xb45309,
      metalness: 0.52,
      roughness: 0.34,
      emissive: 0x451a03,
      emissiveIntensity: 0.18,
    })
  );

  const root = new THREE.Group();
  const crown = new THREE.Group();
  crown.position.y = -0.02;
  root.add(crown);

  // Height function for iconic 5-pointed royal crown matching front-facing crown silhouette
  // Angle theta = 0 is directly facing camera (+Z)!
  const peakAngles = [
    { a: 0, h: 0.56, w: 0.34, r: 0.125 }, // Center imperial peak (tallest!)
    { a: 1.18, h: 0.41, w: 0.36, r: 0.102 }, // Front-right iconic flare peak
    { a: -1.18, h: 0.41, w: 0.36, r: 0.102 }, // Front-left iconic flare peak
    { a: 2.38, h: 0.36, w: 0.38, r: 0.088 }, // Back-right royal peak
    { a: -2.38, h: 0.36, w: 0.38, r: 0.088 }, // Back-left royal peak
  ];
  const crownTopY = (theta: number): number => {
    let best = 0.09;
    for (const p of peakAngles) {
      let da = theta - p.a;
      while (da > Math.PI) da -= Math.PI * 2;
      while (da < -Math.PI) da += Math.PI * 2;
      const t = Math.max(0, 1 - Math.abs(da) / (p.w * 1.95));
      // Rounded U-valley sweeping seamlessly to crisp pointed crown horn
      const curve = Math.pow(t, 1.78);
      const val = 0.08 + (p.h - 0.08) * curve;
      if (val > best) best = val;
    }
    return best;
  };

  // Sculpted thick flared 3D crown shell (outer wall, inner wall, beveled top edge, bottom seat)
  const segU = 120;
  const segV = 12;
  const baseY = -0.22;
  const rBase = 0.56;
  const wallThick = 0.085;

  const buildShell = (isOuter: boolean) => {
    const pos: number[] = [];
    const uvs: number[] = [];
    const idx: number[] = [];
    for (let iv = 0; iv <= segV; iv++) {
      const v = iv / segV;
      for (let iu = 0; iu <= segU; iu++) {
        const u = iu / segU;
        const th = (u - 0.5) * Math.PI * 2;
        const topY = crownTopY(th);
        const y = baseY + (topY - baseY) * v;
        // Graceful regal bell flare (wider toward sculpted points!)
        const flare = Math.pow(v, 1.35) * (0.16 + (topY - 0.1) * 0.22);
        const taperEdge = v > 0.88 ? (1 - v) / 0.12 : 1;
        const halfT = wallThick * 0.5 * (0.72 + 0.28 * Math.sqrt(Math.max(0, taperEdge)));
        const r = rBase + flare + (isOuter ? halfT : -halfT);
        pos.push(Math.sin(th) * r, y, Math.cos(th) * r);
        uvs.push(u * 2, 1 - v);
      }
    }
    const stride = segU + 1;
    for (let iv = 0; iv < segV; iv++) {
      for (let iu = 0; iu < segU; iu++) {
        const a = iv * stride + iu;
        const b = a + 1;
        const c = a + stride;
        const d = c + 1;
        if (isOuter) {
          idx.push(a, b, d, a, d, c);
        } else {
          idx.push(a, d, b, a, c, d);
        }
      }
    }
    const g = new THREE.BufferGeometry();
    g.setAttribute("position", new THREE.Float32BufferAttribute(pos, 3));
    g.setAttribute("uv", new THREE.Float32BufferAttribute(uvs, 2));
    g.setIndex(idx);
    g.computeVertexNormals();
    return tG(g);
  };

  const outerCrown = new THREE.Mesh(buildShell(true), goldWallMat);
  const innerCrown = new THREE.Mesh(buildShell(false), goldDarkTrimMat);
  crown.add(outerCrown, innerCrown);

  // Smooth glossy sculpted tubular rim hugging exact undulating top wave of the crown
  const rimPts: THREE.Vector3[] = [];
  const rimN = 96;
  for (let i = 0; i < rimN; i++) {
    const th = (i / rimN) * Math.PI * 2;
    const ty = crownTopY(th);
    const flare = 0.16 + (ty - 0.1) * 0.22;
    const r = rBase + flare;
    rimPts.push(new THREE.Vector3(Math.sin(th) * r, ty, Math.cos(th) * r));
  }
  const rimCurve = new THREE.CatmullRomCurve3(rimPts, true, "catmullrom", 0.2);
  const topRimMesh = new THREE.Mesh(tG(new THREE.TubeGeometry(rimCurve, 140, 0.044, 14, true)), goldBrightMat);
  crown.add(topRimMesh);

  // Heavy plush beveled lower royal gold circlet band
  const bandPts = [
    new THREE.Vector2(0.49, -0.37),
    new THREE.Vector2(0.585, -0.37),
    new THREE.Vector2(0.625, -0.335),
    new THREE.Vector2(0.632, -0.265),
    new THREE.Vector2(0.622, -0.205),
    new THREE.Vector2(0.58, -0.175),
    new THREE.Vector2(0.49, -0.175),
  ];
  const bandMesh = new THREE.Mesh(tG(new THREE.LatheGeometry(bandPts, 64)), goldBandMat);
  crown.add(bandMesh);
  addCrispOutline(bandMesh, 0x4c1d02, 1.032, 1.05, 1.032, tM);

  // Crisp rolled golden trim rails flanking the headband top & bottom
  const lowerBeadGeo = tG(new THREE.TorusGeometry(0.618, 0.036, 14, 64));
  const lowerBead = new THREE.Mesh(lowerBeadGeo, goldBrightMat);
  lowerBead.rotation.x = Math.PI / 2;
  lowerBead.position.y = -0.355;
  const upperBead = new THREE.Mesh(tG(new THREE.TorusGeometry(0.614, 0.036, 14, 64)), goldBrightMat);
  upperBead.rotation.x = Math.PI / 2;
  upperBead.position.y = -0.185;
  crown.add(lowerBead, upperBead);

  // Delicate encircling ring of tiny polished golden rivet pearls along lower band border
  const tinyBeadGeo = tG(new THREE.SphereGeometry(0.025, 10, 8));
  const numBandBeads = 24;
  for (let i = 0; i < numBandBeads; i++) {
    const th = (i / numBandBeads) * Math.PI * 2;
    const dot = new THREE.Mesh(tinyBeadGeo, goldBrightMat);
    dot.position.set(Math.sin(th) * 0.635, -0.188, Math.cos(th) * 0.635);
    crown.add(dot);
  }

  // Soft plush dark-ruby crimson royal velvet pillow nestled inside the crown
  const velvetTex = tT(
    makeCanvasTex(128, 128, (c, w, h) => {
      const g = c.createRadialGradient(w * 0.4, h * 0.34, 8, w * 0.5, h * 0.5, w * 0.6);
      g.addColorStop(0, "#ef233c");
      g.addColorStop(0.55, "#b91c2c");
      g.addColorStop(1, "#6b0d1a");
      c.fillStyle = g;
      c.fillRect(0, 0, w, h);
    })
  );
  const velvetMat = tM(
    new THREE.MeshPhysicalMaterial({
      map: velvetTex,
      roughness: 0.78,
      metalness: 0.0,
      sheen: 0.9,
      sheenRoughness: 0.42,
      sheenColor: new THREE.Color(0xff9eb0),
      emissive: 0x3b0610,
      emissiveIntensity: 0.22,
    })
  );
  // Plush sculpted 5-lobed quilted royal ruby-velvet interior cushion peaking richly inside the golden points
  const velvetGeo = tG(new THREE.SphereGeometry(0.57, 44, 26, 0, Math.PI * 2, 0, Math.PI * 0.62));
  {
    const pa = velvetGeo.attributes.position;
    for (let i = 0; i < pa.count; i++) {
      const x = pa.getX(i);
      const y = pa.getY(i);
      const z = pa.getZ(i);
      const rHor = Math.hypot(x, z);
      const ang = Math.atan2(x, z);
      const env = Math.min(1, rHor / 0.55) * Math.max(0, y / 0.57);
      // Soft pillowy quilted royal puff crease between crown lobes
      const tuft = 1 + 0.065 * Math.abs(Math.cos(ang * 2.5)) * env;
      pa.setXYZ(i, x * tuft, y * 0.76 * tuft, z * tuft);
    }
    velvetGeo.computeVertexNormals();
  }
  const velvetCap = new THREE.Mesh(velvetGeo, velvetMat);
  velvetCap.position.y = -0.12;
  crown.add(velvetCap);

  // Subtle decorative golden fleur-crest ridges climbing each of the 5 crown spines for luxury specular sheen
  for (const p of peakAngles) {
    const startR = rBase + 0.055;
    const endR = rBase + 0.16 + (p.h - 0.1) * 0.22 + 0.032;
    const spineCurve = new THREE.QuadraticBezierCurve3(
      new THREE.Vector3(Math.sin(p.a) * startR, -0.16, Math.cos(p.a) * startR),
      new THREE.Vector3(Math.sin(p.a) * ((startR + endR) * 0.52), p.h * 0.42, Math.cos(p.a) * ((startR + endR) * 0.52)),
      new THREE.Vector3(Math.sin(p.a) * endR, p.h - 0.01, Math.cos(p.a) * endR)
    );
    const rib = new THREE.Mesh(tG(new THREE.TubeGeometry(spineCurve, 14, 0.032, 8, false)), goldBrightMat);
    crown.add(rib);
  }

  // Tiny sculpted dark gold floor cap so zero light ever leaks underneath
  const bottomDisc = new THREE.Mesh(tG(new THREE.CircleGeometry(0.56, 36)), goldDarkTrimMat);
  bottomDisc.rotation.x = Math.PI / 2;
  bottomDisc.position.y = -0.35;
  crown.add(bottomDisc);

  // 5 Lustrous sculpted pearl-gold tip finials sitting right atop each peak!
  const finialOrbGeo = tG(new THREE.SphereGeometry(1, 24, 20));
  const collarGeo = tG(new THREE.TorusGeometry(0.62, 0.22, 10, 20));
  for (const p of peakAngles) {
    const flare = 0.16 + (p.h - 0.1) * 0.22;
    const r = rBase + flare + 0.015;
    const fx = Math.sin(p.a) * r;
    const fz = Math.cos(p.a) * r;
    const fy = p.h + p.r * 0.72;

    const orb = new THREE.Mesh(finialOrbGeo, goldBrightMat);
    orb.scale.setScalar(p.r);
    orb.position.set(fx, fy, fz);
    addCrispOutline(orb, 0x5c2602, 1.11, 1.11, 1.11, tM);
    crown.add(orb);

    const collar = new THREE.Mesh(collarGeo, goldBandMat);
    collar.scale.setScalar(p.r);
    collar.rotation.x = Math.PI / 2;
    collar.position.set(fx, p.h + p.r * 0.04, fz);
    crown.add(collar);
  }

  // Faceted luxury inset gemstones (Hero Ruby + Turquoise Sapphires + Emeralds)
  const makeGemMat = (color: number, emissive: number) =>
    tM(
      new THREE.MeshPhysicalMaterial({
        color,
        emissive,
        emissiveIntensity: 0.34,
        metalness: 0.08,
        roughness: 0.06,
        clearcoat: 1.0,
        clearcoatRoughness: 0.03,
        reflectivity: 1.0,
        flatShading: true,
      })
    );
  const rubyMat = makeGemMat(0xff2744, 0x991124);
  const sapphMat = makeGemMat(0x22c8ff, 0x065c8a);
  const emeraldMat = makeGemMat(0x16e07f, 0x06643a);

  const bezelGeo = tG(new THREE.TorusGeometry(1, 0.25, 12, 24));
  const gemGeo = tG(new THREE.OctahedronGeometry(1, 0));

  const placeGem = (angle: number, y: number, radius: number, size: number, mat: THREE.Material, stretchY = 1.18) => {
    const g = new THREE.Group();
    g.position.set(Math.sin(angle) * radius, y, Math.cos(angle) * radius);
    g.rotation.y = angle;
    g.rotation.x = -0.14;

    const bez = new THREE.Mesh(bezelGeo, goldBrightMat);
    bez.scale.set(size * 1.02, size * stretchY * 0.96, size * 0.92);
    g.add(bez);

    const gem = new THREE.Mesh(gemGeo, mat);
    gem.scale.set(size * 0.88, size * stretchY, size * 0.56);
    gem.position.z = size * 0.12;
    g.add(gem);
    crown.add(g);
  };

  // Center vivid hero crimson ruby diamond on front spine!
  placeGem(0, 0.06, 0.68, 0.135, rubyMat, 1.24);
  // Symmetric radiant turquoise-sapphire jewels on left & right crown flanks
  placeGem(0.62, -0.02, 0.655, 0.095, sapphMat, 1.14);
  placeGem(-0.62, -0.02, 0.655, 0.095, sapphMat, 1.14);
  // Sparkling band center ruby + alternating sapphire/emerald bezel stones around circlet!
  placeGem(0, -0.27, 0.638, 0.068, rubyMat, 0.92);
  placeGem(0.55, -0.27, 0.638, 0.062, emeraldMat, 0.92);
  placeGem(-0.55, -0.27, 0.638, 0.062, emeraldMat, 0.92);
  placeGem(1.12, -0.27, 0.638, 0.062, sapphMat, 0.92);
  placeGem(-1.12, -0.27, 0.638, 0.062, sapphMat, 0.92);
  placeGem(1.75, -0.27, 0.638, 0.058, rubyMat, 0.92);
  placeGem(-1.75, -0.27, 0.638, 0.058, rubyMat, 0.92);

  scene.add(root);

  return {
    kind: "crown",
    scene,
    camera,
    root,
    aspect: 1.24,
    baseW: 256,
    baseH: 206,
    update(t, hoverAmt, boostPhase) {
      // Gentle regal float & expressive 3D side sway showing true golden roundness and velvet cushion
      const swayYaw = Math.sin(t * 1.15) * 0.24 + Math.sin(boostPhase) * 0.42;
      const swayPitch = 0.04 + Math.sin(t * 1.7 + 0.8) * 0.045 - hoverAmt * 0.06;
      const swayRoll = Math.sin(t * 0.92 + 0.4) * 0.055;
      crown.rotation.set(swayPitch, swayYaw, swayRoll);
      crown.position.y = -0.02 + Math.sin(t * 2.15) * 0.032 + hoverAmt * 0.04;
      const pulse = 1 + hoverAmt * 0.05;
      crown.scale.setScalar(pulse);
      // Gliding sunlit gleam rolling across the golden ridge & faceted gemstones
      sparkleLight.position.set(Math.sin(t * 1.6) * 1.5, 1.55 + Math.cos(t * 1.2) * 0.2, 2.0);
      sparkleLight.intensity = 1.2 + Math.sin(t * 2.8) * 0.22 + hoverAmt * 0.35;
    },
    dispose() {
      geos.forEach((g) => g.dispose());
      mats.forEach((m) => m.dispose());
      texs.forEach((x) => x.dispose());
    },
  };
}

/* ============================================================================
 * 2. 3D WOODEN SHIP'S STEERING WHEEL (RODA SETIR KAPAL KAYU 3D)
 *    Varnished carved mahogany-teak captain's wheel, twin brass rim trim bands,
 *    8 brass bolt rivets, 8 lathe-turned wooden baluster spokes + ergonomic
 *    curved sailor grip handles tipped with glossy 24k brass cap knobs, and
 *    stepped machined brass center hub!
 * ============================================================================ */
function buildWheelRig(envTex: THREE.Texture | null): IconRig {
  const geos: THREE.BufferGeometry[] = [];
  const mats: THREE.Material[] = [];
  const texs: THREE.Texture[] = [];
  const tG = <T extends THREE.BufferGeometry>(g: T) => (geos.push(g), g);
  const tM = <T extends THREE.Material>(m: T) => (mats.push(m), m);
  const tT = <T extends THREE.Texture>(x: T) => (texs.push(x), x);

  const scene = new THREE.Scene();
  if (envTex) {
    scene.environment = envTex;
    scene.environmentIntensity = 0.52;
  }
  setupIconLights(scene, 0xfff6e0, 0x7dd3fc);

  // Perfectly framed studio camera giving crisp margin around all 8 brass-capped handles at any spin & tilt
  const camera = new THREE.PerspectiveCamera(29, 1.0, 0.1, 20);
  camera.position.set(0, 0.04, 4.24);
  camera.lookAt(0, 0, 0);

  // Rich procedural warm marine-varnished teak/mahogany wood texture
  const woodTex = tT(
    makeCanvasTex(
      256,
      128,
      (c, w, h) => {
        c.fillStyle = "#b56a2c";
        c.fillRect(0, 0, w, h);
        // Repeating longitudinal rich mahogany grain
        for (let y = 0; y < h; y++) {
          const wave = Math.sin(y * 0.28) * 14 + Math.sin(y * 0.72) * 7;
          const r = Math.min(245, Math.max(85, Math.round(182 + wave)));
          const g = Math.min(200, Math.max(46, Math.round(108 + wave * 0.65)));
          const b = Math.min(130, Math.max(18, Math.round(45 + wave * 0.34)));
          c.fillStyle = `rgb(${r},${g},${b})`;
          c.fillRect(0, y, w, 1);
        }
        // Subtle darker warm teak streaks & ring mortise seams
        for (let i = 0; i < 42; i++) {
          c.fillStyle = i % 3 === 0 ? "rgba(255,212,150,0.16)" : "rgba(68,26,6,0.16)";
          c.fillRect(0, (i * 19) % h, w, 2);
        }
        c.fillStyle = "rgba(56,22,4,0.34)";
        for (let s = 0; s < 8; s++) {
          const x = Math.round((s / 8) * w);
          c.fillRect(x, 0, 2, h);
        }
      },
      true,
      true
    )
  );
  woodTex.repeat.set(2, 1);

  const woodRimMat = tM(
    new THREE.MeshPhysicalMaterial({
      map: woodTex,
      color: 0xffecd6,
      roughness: 0.32,
      metalness: 0.04,
      clearcoat: 0.62,
      clearcoatRoughness: 0.18,
      emissive: 0x2d1202,
      emissiveIntensity: 0.14,
    })
  );

  const woodHandleMat = tM(
    new THREE.MeshPhysicalMaterial({
      color: 0xd07c36,
      roughness: 0.28,
      metalness: 0.04,
      clearcoat: 0.68,
      clearcoatRoughness: 0.15,
      emissive: 0x3b1804,
      emissiveIntensity: 0.15,
    })
  );

  const woodDarkMat = tM(
    new THREE.MeshPhysicalMaterial({
      color: 0x874518,
      roughness: 0.38,
      metalness: 0.05,
      clearcoat: 0.45,
      clearcoatRoughness: 0.24,
    })
  );

  const brassMat = tM(
    new THREE.MeshPhysicalMaterial({
      color: 0xffd242,
      metalness: 0.56,
      roughness: 0.19,
      clearcoat: 0.88,
      clearcoatRoughness: 0.09,
      emissive: 0x6b3800,
      emissiveIntensity: 0.22,
    })
  );

  const darkBronzeMat = tM(
    new THREE.MeshStandardMaterial({
      color: 0x4f2308,
      metalness: 0.42,
      roughness: 0.36,
    })
  );

  const root = new THREE.Group();
  const tiltGroup = new THREE.Group();
  const spinner = new THREE.Group();
  tiltGroup.add(spinner);
  root.add(tiltGroup);

  // Thick beveled primary wooden outer helm wheel ring (radius 0.56, chunky readable girth!)
  const rimR = 0.56;
  const rimTube = 0.115;
  const mainRim = new THREE.Mesh(tG(new THREE.TorusGeometry(rimR, rimTube, 24, 72)), woodRimMat);
  mainRim.scale.set(1, 1, 0.92);
  spinner.add(mainRim);
  addCrispOutline(mainRim, 0x361604, 1.03, 1.03, 1.04, tM);

  // Rich twin inlaid machined brass accent bands framing the front & back faces of the wooden ring!
  const makeBrassInlay = (r: number, z: number, tube: number) => {
    const m = new THREE.Mesh(tG(new THREE.TorusGeometry(r, tube, 12, 64)), brassMat);
    m.position.z = z;
    spinner.add(m);
  };
  makeBrassInlay(rimR + 0.036, 0.088, 0.017);
  makeBrassInlay(rimR - 0.036, 0.088, 0.017);
  makeBrassInlay(rimR + 0.036, -0.088, 0.017);
  makeBrassInlay(rimR - 0.036, -0.088, 0.017);

  // Graceful inner turned wood-and-brass ring lining inside the rim for extra craftsmanship
  const innerTrim = new THREE.Mesh(tG(new THREE.TorusGeometry(rimR - rimTube + 0.008, 0.02, 12, 64)), woodDarkMat);
  spinner.add(innerTrim);

  // 8 Lathe-turned classic captain's spokes + ergonomic sailor grip handles + gleaming brass finial caps
  const spokeProfile = [
    new THREE.Vector2(0.056, 0.16),
    new THREE.Vector2(0.068, 0.21), // collar near hub
    new THREE.Vector2(0.044, 0.25), // pinch
    new THREE.Vector2(0.062, 0.34), // plump graceful spindle waist
    new THREE.Vector2(0.045, 0.43), // tapered rim collar
    new THREE.Vector2(0.058, 0.47),
  ];
  const spokeGeo = tG(new THREE.LatheGeometry(spokeProfile, 18));

  const gripProfile = [
    new THREE.Vector2(0.058, 0.64), // snugly exits wood ring
    new THREE.Vector2(0.072, 0.675), // flared base shoulder
    new THREE.Vector2(0.052, 0.72), // comfy grip neck
    new THREE.Vector2(0.088, 0.79), // iconic chunky carved wooden captain's knob
    new THREE.Vector2(0.082, 0.855),
    new THREE.Vector2(0.05, 0.89),
    new THREE.Vector2(0.001, 0.905),
  ];
  const gripGeo = tG(new THREE.LatheGeometry(gripProfile, 20));
  const collarRingGeo = tG(new THREE.CylinderGeometry(0.078, 0.084, 0.048, 18));
  const tipCapGeo = tG(new THREE.SphereGeometry(0.046, 16, 14));
  const rivetGeo = tG(new THREE.SphereGeometry(0.036, 14, 10));

  for (let i = 0; i < 8; i++) {
    const a = (i / 8) * Math.PI * 2;
    const arm = new THREE.Group();
    arm.rotation.z = a;

    // Lathe-turned wooden radial spoke
    const sp = new THREE.Mesh(spokeGeo, woodHandleMat);
    arm.add(sp);

    // Warm dark-brass socket collar joining the outer handle cleanly to the wheel rim
    const socket = new THREE.Mesh(collarRingGeo, brassMat);
    socket.position.y = 0.67;
    arm.add(socket);

    // Classic plush rounded outer wooden grip handle
    const grip = new THREE.Mesh(gripGeo, woodHandleMat);
    addCrispOutline(grip, 0x361604, 1.09, 1.02, 1.09, tM);
    arm.add(grip);

    // Gleaming polished brass knob cap right on every handle tip!
    const tip = new THREE.Mesh(tipCapGeo, brassMat);
    tip.position.y = 0.895;
    arm.add(tip);

    // Authentic arched brass reinforcement strap wrapping every spoke seam around the mahogany ring
    const bandStrap = new THREE.Mesh(tG(new THREE.TorusGeometry(rimTube * 1.03, 0.018, 10, 24)), brassMat);
    bandStrap.position.set(0, rimR, 0);
    bandStrap.rotation.y = Math.PI / 2;
    bandStrap.scale.set(0.92, 1, 1);
    arm.add(bandStrap);

    // Raised polished golden brass dome rivet bolted on front AND back of the wooden ring!
    const rivF = new THREE.Mesh(rivetGeo, brassMat);
    rivF.scale.set(1.12, 1.12, 0.62);
    rivF.position.set(0, rimR, 0.108);
    const rivB = rivF.clone();
    rivB.position.z = -0.108;
    arm.add(rivF, rivB);

    spinner.add(arm);
  }

  // Sculpted machined-brass royal centerpiece hub (front & back mirrored axle profile)
  const hubPts = [
    new THREE.Vector2(0.001, -0.22),
    new THREE.Vector2(0.11, -0.22),
    new THREE.Vector2(0.165, -0.16),
    new THREE.Vector2(0.242, -0.11),
    new THREE.Vector2(0.256, 0.0),
    new THREE.Vector2(0.242, 0.11),
    new THREE.Vector2(0.195, 0.155),
    new THREE.Vector2(0.14, 0.19),
    new THREE.Vector2(0.088, 0.215),
    new THREE.Vector2(0.001, 0.225),
  ];
  const hubGeo = tG(new THREE.LatheGeometry(hubPts, 40));
  hubGeo.rotateX(Math.PI / 2);
  const hubMesh = new THREE.Mesh(hubGeo, brassMat);
  spinner.add(hubMesh);

  // Stepped bevelled antique-bronze nautical axle core medallion on front face
  const capRing = new THREE.Mesh(tG(new THREE.TorusGeometry(0.115, 0.022, 12, 32)), darkBronzeMat);
  capRing.position.z = 0.195;
  const centerBolt = new THREE.Mesh(tG(new THREE.CylinderGeometry(0.072, 0.084, 0.06, 8)), darkBronzeMat);
  centerBolt.rotation.x = Math.PI / 2;
  centerBolt.position.z = 0.21;
  const innerShine = new THREE.Mesh(tG(new THREE.SphereGeometry(0.044, 16, 12)), brassMat);
  innerShine.scale.set(1, 1, 0.65);
  innerShine.position.z = 0.232;
  spinner.add(capRing, centerBolt, innerShine);

  // Subtle decorative 8 micro brass collar bolts around centerpiece hub
  const hubDotGeo = tG(new THREE.SphereGeometry(0.022, 10, 8));
  for (let i = 0; i < 8; i++) {
    const a = (i / 8) * Math.PI * 2 + Math.PI / 8;
    const dot = new THREE.Mesh(hubDotGeo, darkBronzeMat);
    dot.position.set(Math.cos(a) * 0.19, Math.sin(a) * 0.19, 0.145);
    spinner.add(dot);
  }

  scene.add(root);

  return {
    kind: "wheel",
    scene,
    camera,
    root,
    aspect: 1.0,
    baseW: 248,
    baseH: 248,
    update(t, hoverAmt, boostPhase) {
      // Gentle living captain's helm rock left/right + cheerful smooth turntable spin on hover!
      const steer = Math.sin(t * 0.82) * 0.42 + Math.sin(t * 0.37) * 0.22 + boostPhase;
      spinner.rotation.z = steer;
      // Rich sculpted 3/4 tilt clearly showing wooden ring depth, solid hub & protruding handles
      tiltGroup.rotation.y = -0.34 + Math.sin(t * 1.05) * 0.12 + hoverAmt * 0.12;
      tiltGroup.rotation.x = 0.16 + Math.cos(t * 0.9) * 0.06 - hoverAmt * 0.04;
      tiltGroup.position.y = Math.sin(t * 1.75 + 1.1) * 0.022 + hoverAmt * 0.02;
      const s = 1 + hoverAmt * 0.045;
      tiltGroup.scale.setScalar(s);
    },
    dispose() {
      geos.forEach((g) => g.dispose());
      mats.forEach((m) => m.dispose());
      texs.forEach((x) => x.dispose());
    },
  };
}

/* ============================================================================
 * 3. 3D TROPICAL ISLAND DIORAMA (PULAU TROPIS 3D)
 *    Pixar/Nintendo stylized sunny 3D island miniature: crystal turquoise
 *    lagoon disc with animated lapping crispy white sea-foam surf rim, plump
 *    curved honey-gold sandy beach mound, adorable coral-red 3D starfish &
 *    smooth coastal limestone boulders, lush sunlit emerald hillside with
 *    bush puffs, twin curved segmented coconut palm trees with glossy brown
 *    coconuts & lush multi-tier breezy swaying arched 3D palm fronds!
 * ============================================================================ */
function buildIslandRig(envTex: THREE.Texture | null): IconRig {
  const geos: THREE.BufferGeometry[] = [];
  const mats: THREE.Material[] = [];
  const texs: THREE.Texture[] = [];
  const tG = <T extends THREE.BufferGeometry>(g: T) => (geos.push(g), g);
  const tM = <T extends THREE.Material>(m: T) => (mats.push(m), m);
  const tT = <T extends THREE.Texture>(x: T) => (texs.push(x), x);

  const scene = new THREE.Scene();
  if (envTex) {
    scene.environment = envTex;
    scene.environmentIntensity = 0.44;
  }
  setupIconLights(scene, 0xfff8dc, 0x7eeeff);

  // Classic bright Pixar postcard 3/4 framing: full sparkling lagoon disc + generous palm-canopy margin!
  const camera = new THREE.PerspectiveCamera(29, 1.14, 0.1, 20);
  camera.position.set(0, 1.12, 3.74);
  camera.lookAt(0, 0.25, 0);

  const root = new THREE.Group();
  const island = new THREE.Group();
  island.position.y = -0.18;
  root.add(island);

  // 1. Sparkling crystal turquoise ocean lagoon plinth (radial aqua gradient + smooth glassy water clearcoat)
  const waterTex = tT(
    makeCanvasTex(256, 256, (c, w, h) => {
      const cx = w / 2;
      const cy = h / 2;
      const g = c.createRadialGradient(cx, cy, w * 0.12, cx, cy, w * 0.5);
      g.addColorStop(0, "#a5f3fc");
      g.addColorStop(0.46, "#38e4f2");
      g.addColorStop(0.76, "#0ea5e9");
      g.addColorStop(1, "#0369a1");
      c.fillStyle = g;
      c.fillRect(0, 0, w, h);
      // Crisp sunlit tropical ripple rings
      c.strokeStyle = "rgba(255,255,255,0.28)";
      c.lineWidth = 3;
      for (const r of [w * 0.34, w * 0.42]) {
        c.beginPath();
        c.arc(cx, cy, r, 0, Math.PI * 2);
        c.stroke();
      }
      // Sunlit dappled caustic spots
      c.fillStyle = "rgba(232,253,255,0.26)";
      for (let i = 0; i < 18; i++) {
        const a = (i / 18) * Math.PI * 2;
        const rr = w * (0.31 + (i % 3) * 0.055);
        c.beginPath();
        c.ellipse(cx + Math.cos(a) * rr, cy + Math.sin(a) * rr, 9, 4.5, a + 1.5, 0, Math.PI * 2);
        c.fill();
      }
    })
  );

  // Chunky pillowed floating turquoise water coin disc (beautiful solid underside curve too!)
  const discPts = [
    new THREE.Vector2(0.001, -0.16),
    new THREE.Vector2(0.54, -0.155),
    new THREE.Vector2(0.78, -0.11),
    new THREE.Vector2(0.88, -0.04),
    new THREE.Vector2(0.89, 0.015),
    new THREE.Vector2(0.84, 0.045),
    new THREE.Vector2(0.001, 0.05),
  ];
  const waterGeo = tG(new THREE.LatheGeometry(discPts, 56));
  // Planer top-down UV projection so concentric aqua rings align around the beach
  {
    const pa = waterGeo.attributes.position;
    const ua = new Float32Array(pa.count * 2);
    for (let i = 0; i < pa.count; i++) {
      ua[i * 2] = 0.5 + pa.getX(i) / 1.82;
      ua[i * 2 + 1] = 0.5 + pa.getZ(i) / 1.82;
    }
    waterGeo.setAttribute("uv", new THREE.BufferAttribute(ua, 2));
  }
  const waterMat = tM(
    new THREE.MeshPhysicalMaterial({
      map: waterTex,
      roughness: 0.12,
      metalness: 0.04,
      clearcoat: 1.0,
      clearcoatRoughness: 0.05,
      emissive: 0x064d78,
      emissiveIntensity: 0.16,
    })
  );
  const waterDisc = new THREE.Mesh(waterGeo, waterMat);
  island.add(waterDisc);
  addCrispOutline(waterDisc, 0x063566, 1.03, 1.08, 1.03, tM);

  // Crispy animated lapping white sea-foam shore rings!
  const foamMat = tM(
    new THREE.MeshStandardMaterial({
      color: 0xf4feff,
      emissive: 0xd8f8ff,
      emissiveIntensity: 0.36,
      roughness: 0.35,
      transparent: true,
      opacity: 0.9,
    })
  );
  const makeWavyFoam = (radius: number, thick: number, amp: number, lobes: number) => {
    const pts: THREE.Vector3[] = [];
    const n = 56;
    for (let i = 0; i < n; i++) {
      const a = (i / n) * Math.PI * 2;
      const r = radius + Math.sin(a * lobes) * amp + Math.cos(a * (lobes - 2)) * amp * 0.45;
      pts.push(new THREE.Vector3(Math.cos(a) * r, 0.056, Math.sin(a) * r * 0.95));
    }
    const curve = new THREE.CatmullRomCurve3(pts, true);
    return tG(new THREE.TubeGeometry(curve, 64, thick, 8, true));
  };
  const innerFoam = new THREE.Mesh(makeWavyFoam(0.665, 0.032, 0.025, 7), foamMat);
  const outerFoamMat = tM(foamMat.clone());
  outerFoamMat.opacity = 0.56;
  const outerFoam = new THREE.Mesh(makeWavyFoam(0.765, 0.017, 0.018, 9), outerFoamMat);
  outerFoam.position.y = -0.004;
  island.add(innerFoam, outerFoam);

  // 2. Plump curved honey-gold tropical sandy beach mound with natural soft shoreline gradient
  const sandTex = tT(
    makeCanvasTex(256, 128, (c, w, h) => {
      const g = c.createLinearGradient(0, 0, 0, h);
      g.addColorStop(0, "#fff2a8");
      g.addColorStop(0.5, "#fcd34d");
      g.addColorStop(0.84, "#f59e0b");
      g.addColorStop(1, "#c97416");
      c.fillStyle = g;
      c.fillRect(0, 0, w, h);
      // Warm organic dry sand speckle
      for (let i = 0; i < 240; i++) {
        c.fillStyle = i % 2 === 0 ? "rgba(255,250,224,0.22)" : "rgba(180,98,18,0.14)";
        c.beginPath();
        c.arc((i * 53) % w, (i * 37) % h, 1.8, 0, Math.PI * 2);
        c.fill();
      }
    })
  );
  const sandGeo = tG(new THREE.SphereGeometry(0.65, 42, 24, 0, Math.PI * 2, 0, Math.PI * 0.54));
  // Soft organic shore silhouette ripples + dome plumpness
  {
    const pa = sandGeo.attributes.position;
    for (let i = 0; i < pa.count; i++) {
      const x = pa.getX(i);
      const y = pa.getY(i);
      const z = pa.getZ(i);
      const ang = Math.atan2(z, x);
      const bump = 1 + Math.sin(ang * 3 + 0.5) * 0.055 + Math.cos(ang * 5 - 0.8) * 0.025;
      pa.setXYZ(i, x * bump, y * 0.5 + 0.015, z * bump * 0.94);
    }
    sandGeo.computeVertexNormals();
  }
  const sandMat = tM(
    new THREE.MeshStandardMaterial({
      map: sandTex,
      roughness: 0.68,
      metalness: 0.0,
      emissive: 0x6b3e04,
      emissiveIntensity: 0.14,
    })
  );
  const sandDome = new THREE.Mesh(sandGeo, sandMat);
  sandDome.position.y = 0.02;
  island.add(sandDome);

  // 3. Cute vibrant emerald sunlit tropical grass hill topping the island center!
  const grassGeo = tG(new THREE.SphereGeometry(0.42, 34, 20, 0, Math.PI * 2, 0, Math.PI * 0.56));
  {
    const pa = grassGeo.attributes.position;
    for (let i = 0; i < pa.count; i++) {
      const x = pa.getX(i);
      const y = pa.getY(i);
      const z = pa.getZ(i);
      const ang = Math.atan2(z, x);
      const w = 1 + Math.sin(ang * 4 + 1.1) * 0.065;
      pa.setXYZ(i, x * w, y * 0.54, z * w * 0.92);
    }
    grassGeo.computeVertexNormals();
  }
  const grassTex = tT(
    makeCanvasTex(128, 128, (c, w, h) => {
      const g = c.createLinearGradient(0, 0, 0, h);
      g.addColorStop(0, "#76ef52");
      g.addColorStop(0.55, "#28c852");
      g.addColorStop(1, "#15803d");
      c.fillStyle = g;
      c.fillRect(0, 0, w, h);
    })
  );
  const grassMat = tM(
    new THREE.MeshStandardMaterial({
      map: grassTex,
      roughness: 0.58,
      metalness: 0.0,
      emissive: 0x0b401c,
      emissiveIntensity: 0.18,
    })
  );
  const grassCap = new THREE.Mesh(grassGeo, grassMat);
  grassCap.position.set(-0.02, 0.21, -0.02);
  island.add(grassCap);

  // Adorable rounded plump tropical shore boulders (right back) & vivid red starfish (front-left sand!)
  const rockMat = tM(new THREE.MeshStandardMaterial({ color: 0xc2b8a8, roughness: 0.78 }));
  const r1 = new THREE.Mesh(tG(new THREE.DodecahedronGeometry(0.115, 1)), rockMat);
  r1.scale.set(1.25, 0.72, 0.95);
  r1.position.set(0.39, 0.17, 0.14);
  const r2 = new THREE.Mesh(tG(new THREE.DodecahedronGeometry(0.078, 1)), rockMat);
  r2.scale.set(1.1, 0.78, 1.0);
  r2.position.set(0.49, 0.12, 0.02);
  island.add(r1, r2);

  // Cute coral-red 5-arm starfish soaking up sun on the front-left sandy beach!
  const starMat = tM(
    new THREE.MeshPhysicalMaterial({
      color: 0xff5447,
      roughness: 0.42,
      clearcoat: 0.35,
      emissive: 0x7f1d1d,
      emissiveIntensity: 0.2,
    })
  );
  const starGrp = new THREE.Group();
  const armGeo = tG(new THREE.ConeGeometry(0.032, 0.095, 8));
  armGeo.rotateX(Math.PI / 2);
  for (let i = 0; i < 5; i++) {
    const a = (i / 5) * Math.PI * 2;
    const arm = new THREE.Mesh(armGeo, starMat);
    arm.position.set(Math.sin(a) * 0.044, 0, Math.cos(a) * 0.044);
    arm.rotation.y = a;
    arm.scale.set(1, 0.56, 1);
    starGrp.add(arm);
  }
  const starCore = new THREE.Mesh(tG(new THREE.SphereGeometry(0.034, 10, 8)), starMat);
  starCore.scale.set(1, 0.55, 1);
  starGrp.add(starCore);
  starGrp.position.set(-0.34, 0.2, 0.34);
  starGrp.rotation.set(0.34, 0.2, 0.26);
  island.add(starGrp);

  // Lush snug sculpted rounded emerald fern shrubs around palm roots
  const shrubMat = tM(
    new THREE.MeshStandardMaterial({
      color: 0x2fd35c,
      roughness: 0.54,
      emissive: 0x0d4f22,
      emissiveIntensity: 0.16,
    })
  );
  const shrubGeo = tG(new THREE.SphereGeometry(1, 14, 12));
  const shrubs: [number, number, number, number][] = [
    [-0.2, 0.37, 0.04, 0.105],
    [0.2, 0.36, -0.04, 0.095],
    [0.05, 0.39, -0.18, 0.092],
    [-0.1, 0.38, -0.16, 0.08],
  ];
  for (const [sx, sy, sz, sr] of shrubs) {
    const m = new THREE.Mesh(shrubGeo, shrubMat);
    m.position.set(sx, sy, sz);
    m.scale.set(sr * 1.15, sr * 0.82, sr * 1.08);
    island.add(m);
  }

  // Shared materials for segmented curving coconut palm trunks, brown coconuts, and arched juicy palm fronds!
  const trunkMatLight = tM(
    new THREE.MeshStandardMaterial({
      color: 0xd98a3b,
      roughness: 0.56,
      emissive: 0x451f05,
      emissiveIntensity: 0.16,
    })
  );
  const trunkMatDark = tM(
    new THREE.MeshStandardMaterial({
      color: 0xb06322,
      roughness: 0.62,
      emissive: 0x3b1804,
      emissiveIntensity: 0.16,
    })
  );
  const cocoMat = tM(
    new THREE.MeshPhysicalMaterial({
      color: 0x6f3915,
      roughness: 0.36,
      clearcoat: 0.48,
      clearcoatRoughness: 0.22,
      emissive: 0x261003,
      emissiveIntensity: 0.14,
    })
  );

  // Leaf texture with sunlit tropical golden-lime central rib & crisp striped palm leaflets
  const frondTex = tT(
    makeCanvasTex(128, 128, (c, w, h) => {
      const g = c.createLinearGradient(0, 0, w, 0);
      g.addColorStop(0, "#19a944");
      g.addColorStop(0.32, "#3ae056");
      g.addColorStop(0.5, "#9cf75c"); // bright sunlit center spine!
      g.addColorStop(0.68, "#3ae056");
      g.addColorStop(1, "#16963d");
      c.fillStyle = g;
      c.fillRect(0, 0, w, h);
      // Crisp feathered chevron palm-blade striping
      c.strokeStyle = "rgba(13, 88, 34, 0.26)";
      c.lineWidth = 2.6;
      for (let y = 6; y < h; y += 11) {
        c.beginPath();
        c.moveTo(w * 0.5, y);
        c.lineTo(0, y + 8);
        c.moveTo(w * 0.5, y);
        c.lineTo(w, y + 8);
        c.stroke();
      }
      // Subtle darkening at tip tail
      const tip = c.createLinearGradient(0, 0, 0, h);
      tip.addColorStop(0, "rgba(255,255,200,0.08)");
      tip.addColorStop(0.75, "rgba(0,0,0,0)");
      tip.addColorStop(1, "rgba(12,72,28,0.22)");
      c.fillStyle = tip;
      c.fillRect(0, 0, w, h);
    })
  );

  const makeFrondGeo = (len: number, maxW: number, archUp: number, droop: number) => {
    const segL = 12;
    const segW = 4; // cross section creates plush arched V-fold leaf!
    const pos: number[] = [];
    const uvs: number[] = [];
    const idx: number[] = [];
    for (let i = 0; i <= segL; i++) {
      const t = i / segL;
      // Graceful buoyant fountain arch: pops upward then drapes lushly outward and slightly downward!
      const z = t * len;
      const y = Math.sin(t * Math.PI * 0.82) * archUp - Math.pow(t, 2.2) * droop;
      // Lush iconic almond-palm leaflet silhouette with subtle scalloped fullness
      const halfW = maxW * Math.pow(Math.sin(Math.min(1, t) * Math.PI), 0.72) * (1 - 0.14 * t);
      for (let j = 0; j <= segW; j++) {
        const s = j / segW; // 0..1 across width
        const side = (s - 0.5) * 2; // -1..+1
        const foldDrop = -Math.abs(side) * halfW * 0.36; // plump crispy V-shaped natural palm ridge
        const x = side * halfW;
        pos.push(x, y + foldDrop, z);
        uvs.push(s, t);
      }
    }
    const stride = segW + 1;
    for (let i = 0; i < segL; i++) {
      for (let j = 0; j < segW; j++) {
        const a = i * stride + j;
        const b = a + 1;
        const c = a + stride;
        const d = c + 1;
        idx.push(a, c, b, b, c, d);
      }
    }
    const g = new THREE.BufferGeometry();
    g.setAttribute("position", new THREE.Float32BufferAttribute(pos, 3));
    g.setAttribute("uv", new THREE.Float32BufferAttribute(uvs, 2));
    g.setIndex(idx);
    g.computeVertexNormals();
    return tG(g);
  };

  const frondMatBright = tM(
    new THREE.MeshPhysicalMaterial({
      map: frondTex,
      color: 0xffffff,
      roughness: 0.36,
      metalness: 0.0,
      clearcoat: 0.32,
      clearcoatRoughness: 0.25,
      emissive: 0x0f511e,
      emissiveIntensity: 0.2,
      side: THREE.DoubleSide,
    })
  );
  const frondMatDeep = tM(
    new THREE.MeshPhysicalMaterial({
      map: frondTex,
      color: 0xd8f8de,
      roughness: 0.42,
      clearcoat: 0.24,
      emissive: 0x0a3d18,
      emissiveIntensity: 0.18,
      side: THREE.DoubleSide,
    })
  );

  const animatedFronds: { pivot: THREE.Group; basePitch: number; baseYaw: number; phase: number; amp: number }[] = [];

  const buildPalmTree = (
    pts: THREE.Vector3[],
    rBot: number,
    rTop: number,
    rings: number,
    frondScale: number,
    frondCount: number,
    hasCoconuts: boolean
  ) => {
    const curve = new THREE.CatmullRomCurve3(pts);
    const upVec = new THREE.Vector3(0, 1, 0);
    const treeGroup = new THREE.Group();

    // Sculpted stacked banded coconut palm segments (super lovable chunky 3D cartoon style!)
    for (let i = 0; i < rings; i++) {
      const t0 = i / rings;
      const t1 = (i + 1.12) / rings;
      const p0 = curve.getPoint(Math.min(1, t0));
      const p1 = curve.getPoint(Math.min(1, t1));
      const mid = p0.clone().add(p1).multiplyScalar(0.5);
      const dir = p1.clone().sub(p0);
      const segLen = Math.max(0.05, dir.length() * 1.08);
      const rad0 = rBot + (rTop - rBot) * t0;
      const rad1 = rBot + (rTop - rBot) * Math.min(1, t1);
      // Slight flared cup crown ridge on every ring gives true sculpted tropical palm texture!
      const segGeo = tG(new THREE.CylinderGeometry(rad1 * 1.14, rad0 * 0.94, segLen, 14));
      const seg = new THREE.Mesh(segGeo, i % 2 === 0 ? trunkMatLight : trunkMatDark);
      seg.position.copy(mid);
      seg.quaternion.setFromUnitVectors(upVec, dir.normalize());
      treeGroup.add(seg);
    }

    // Palm crown group anchored smoothly at trunk peak
    const topPos = curve.getPoint(1);
    const crownGrp = new THREE.Group();
    crownGrp.position.copy(topPos);
    treeGroup.add(crownGrp);

    // Rounded green crown rosette center
    const coreCrown = new THREE.Mesh(
      tG(new THREE.SphereGeometry(rTop * 1.32, 12, 10)),
      shrubMat
    );
    crownGrp.add(coreCrown);

    // Cozy trio of glossy dark chestnut coconuts tucked below the crown!
    if (hasCoconuts) {
      const cGeo = tG(new THREE.SphereGeometry(0.074 * frondScale, 16, 14));
      for (let i = 0; i < 3; i++) {
        const a = (i / 3) * Math.PI * 2 + 0.45;
        const coco = new THREE.Mesh(cGeo, cocoMat);
        coco.position.set(Math.cos(a) * 0.08 * frondScale, -0.055 * frondScale, Math.sin(a) * 0.08 * frondScale);
        coco.scale.set(1.0, 1.12, 1.0);
        crownGrp.add(coco);
      }
    }

    // Lush layered radiating fountain of arching 3D palm fronds
    const lowerGeo = makeFrondGeo(0.62 * frondScale, 0.165 * frondScale, 0.18 * frondScale, 0.34 * frondScale);
    const upperGeo = makeFrondGeo(0.46 * frondScale, 0.138 * frondScale, 0.24 * frondScale, 0.2 * frondScale);
    for (let i = 0; i < frondCount; i++) {
      const yaw = (i / frondCount) * Math.PI * 2 + 0.22;
      const pv = new THREE.Group();
      const basePitch = -0.04 + (i % 2) * 0.07;
      pv.rotation.order = "YXZ";
      pv.rotation.y = yaw;
      pv.rotation.x = basePitch;
      const leaf = new THREE.Mesh(lowerGeo, i % 2 === 0 ? frondMatBright : frondMatDeep);
      pv.add(leaf);
      crownGrp.add(pv);
      animatedFronds.push({ pivot: pv, basePitch, baseYaw: yaw, phase: i * 1.15, amp: 0.075 });
    }
    // Top playful cheeky young upright palm fronds catching maximum golden sun!
    const topN = Math.max(3, frondCount - 3);
    for (let i = 0; i < topN; i++) {
      const yaw = (i / topN) * Math.PI * 2 + 0.72;
      const pv = new THREE.Group();
      const basePitch = -0.34;
      pv.rotation.order = "YXZ";
      pv.rotation.y = yaw;
      pv.rotation.x = basePitch;
      pv.position.y = 0.025;
      const leaf = new THREE.Mesh(upperGeo, frondMatBright);
      pv.add(leaf);
      crownGrp.add(pv);
      animatedFronds.push({ pivot: pv, basePitch, baseYaw: yaw, phase: i * 1.5 + 0.7, amp: 0.095 });
    }

    island.add(treeGroup);
    return crownGrp;
  };

  // Hero tall gently curved coconut palm leaning heroically to the right!
  buildPalmTree(
    [
      new THREE.Vector3(-0.04, 0.33, -0.03),
      new THREE.Vector3(-0.05, 0.56, 0.0),
      new THREE.Vector3(0.04, 0.81, 0.02),
      new THREE.Vector3(0.16, 1.0, 0.03),
    ],
    0.095,
    0.055,
    8,
    1.0,
    6,
    true
  );

  // Cute secondary companion leaning palm curving playfully left for balanced rich postcard composition!
  buildPalmTree(
    [
      new THREE.Vector3(-0.12, 0.31, -0.07),
      new THREE.Vector3(-0.24, 0.49, -0.06),
      new THREE.Vector3(-0.36, 0.65, -0.03),
    ],
    0.066,
    0.042,
    6,
    0.66,
    5,
    false
  );

  scene.add(root);

  return {
    kind: "island",
    scene,
    camera,
    root,
    aspect: 1.14,
    baseW: 264,
    baseH: 232,
    update(t, hoverAmt, boostPhase) {
      // Serene floating paradise turntable sway showing curved golden coast, sparkling sea & full 3D palms
      island.rotation.y = Math.sin(t * 0.68) * 0.28 + Math.sin(boostPhase) * 0.36;
      island.rotation.z = Math.sin(t * 0.92 + 0.6) * 0.035;
      island.rotation.x = Math.cos(t * 0.8) * 0.025 - hoverAmt * 0.05;
      island.position.y = -0.18 + Math.sin(t * 1.65) * 0.026 + hoverAmt * 0.036;
      island.scale.setScalar(1 + hoverAmt * 0.05);

      // Gentle rhythmic white sea-foam wave surge lapping around golden sand
      const tide = 1 + Math.sin(t * 2.15) * 0.032;
      innerFoam.scale.set(tide, 1, tide);
      const tide2 = 1 + Math.sin(t * 2.15 - 1.2) * 0.04;
      outerFoam.scale.set(tide2, 1, tide2);
      outerFoamMat.opacity = 0.42 + 0.24 * (0.5 + 0.5 * Math.sin(t * 2.15 - 0.8));

      // Gentle ocean breeze gracefully swaying each individual sculpted 3D palm frond!
      const breeze = 1 + hoverAmt * 0.65;
      for (const f of animatedFronds) {
        const w = Math.sin(t * 2.35 + f.phase) * f.amp * breeze;
        const w2 = Math.cos(t * 1.7 + f.phase * 1.3) * f.amp * 0.45 * breeze;
        f.pivot.rotation.x = f.basePitch + w;
        f.pivot.rotation.y = f.baseYaw + w2;
      }
    },
    dispose() {
      geos.forEach((g) => g.dispose());
      mats.forEach((m) => m.dispose());
      texs.forEach((x) => x.dispose());
    },
  };
}

/* ============================================================================
 * POOLED SINGLE-CONTEXT RENDER SERVICE (0 extra WebGL context proliferation!)
 * Blits animated crisp antialias 3D emblems directly into subscribed canvases
 * ============================================================================ */
class MenuIcons3DService {
  private renderer: THREE.WebGLRenderer | null = null;
  private envRT: THREE.WebGLRenderTarget | null = null;
  private rigs = new Map<MenuIcon3DKind, IconRig>();
  private subs = new Map<number, SubEntry>();
  private nextId = 1;
  private raf = 0;
  private timer = 0;
  private running = false;
  private failed = false;
  private lastT = 0;
  private elapsed = 0;
  private soft = false;

  private ensureInit(): boolean {
    if (this.failed) return false;
    if (this.renderer) return true;
    try {
      this.soft = isSoftwareWebGL();
      const renderer = new THREE.WebGLRenderer({
        alpha: true,
        antialias: !this.soft,
        powerPreference: "high-performance",
        preserveDrawingBuffer: true,
      });
      renderer.outputColorSpace = THREE.SRGBColorSpace;
      renderer.toneMapping = THREE.ACESFilmicToneMapping;
      renderer.toneMappingExposure = 1.06;
      renderer.setClearColor(0x000000, 0);
      renderer.setPixelRatio(1);
      renderer.setSize(288, 288, false);

      const pmrem = new THREE.PMREMGenerator(renderer);
      const envRT = pmrem.fromScene(new RoomEnvironment(), 0.04);
      pmrem.dispose();

      renderer.domElement.addEventListener("webglcontextlost", (e) => {
        e.preventDefault();
        this.teardownGL();
      });

      this.renderer = renderer;
      this.envRT = envRT;
      return true;
    } catch {
      this.failed = true;
      return false;
    }
  }

  private teardownGL() {
    for (const r of this.rigs.values()) r.dispose();
    this.rigs.clear();
    this.envRT?.dispose();
    this.envRT = null;
    this.renderer?.dispose();
    this.renderer = null;
  }

  private getRig(kind: MenuIcon3DKind): IconRig | null {
    let rig = this.rigs.get(kind);
    if (rig) return rig;
    const env = this.envRT?.texture ?? null;
    if (kind === "crown") rig = buildCrownRig(env);
    else if (kind === "wheel") rig = buildWheelRig(env);
    else rig = buildIslandRig(env);
    this.rigs.set(kind, rig);
    return rig;
  }

  subscribe(kind: MenuIcon3DKind, canvas: HTMLCanvasElement, paused = false): number {
    const id = this.nextId++;
    const entry: SubEntry = {
      id,
      kind,
      canvas,
      ctx: canvas.getContext("2d"),
      hoverTarget: 0,
      hoverCur: 0,
      boostTarget: 0,
      boostCur: 0,
      boostVel: 0,
      paused,
      lastCssW: 0,
      lastCssH: 0,
      lastDrawT: -999,
      staticDone: false,
    };
    this.subs.set(id, entry);
    // Draw immediate crisp first frame right away (zero blank icon pop!)
    this.renderSingle(entry, this.elapsed, true);
    this.ensureLoop();
    return id;
  }

  unsubscribe(id: number): void {
    this.subs.delete(id);
    if (this.subs.size === 0) {
      this.stopLoop();
    }
  }

  setHovered(id: number, hovered: boolean): void {
    const s = this.subs.get(id);
    if (!s) return;
    const was = s.hoverTarget > 0.5;
    s.hoverTarget = hovered ? 1 : 0;
    if (hovered && !was) {
      // Playful satisfying impulse: ship wheel steers cleanly, island & crown delight tilt!
      s.boostTarget += s.kind === "wheel" ? Math.PI * 0.55 : Math.PI;
      s.staticDone = false;
    }
  }

  nudge(id: number, amount = Math.PI): void {
    const s = this.subs.get(id);
    if (!s) return;
    s.boostTarget += amount;
    s.staticDone = false;
  }

  setPaused(id: number, paused: boolean): void {
    const s = this.subs.get(id);
    if (!s || s.paused === paused) return;
    s.paused = paused;
    if (!paused) {
      // Immediately wake smooth loop when returning to start menu
      s.lastDrawT = -999;
      this.ensureLoop();
    } else if (this.allPaused()) {
      // Zero idle CPU/rAF work while swimming in-game!
      this.stopLoop();
    }
  }

  private allPaused(): boolean {
    for (const s of this.subs.values()) {
      if (!s.paused) return false;
    }
    return true;
  }

  private renderSingle(s: SubEntry, t: number, force = false): void {
    if (!s.ctx || (!force && s.paused)) return;
    if (!this.ensureInit() || !this.renderer) return;
    const rig = this.getRig(s.kind);
    if (!rig) return;

    const cssW = Math.max(24, Math.round(s.canvas.clientWidth || rig.baseW * 0.5));
    const cssH = Math.max(24, Math.round(s.canvas.clientHeight || rig.baseH * 0.5));
    const maxDpr = this.soft ? 1.25 : Math.min(window.devicePixelRatio || 1, 2);
    const pw = Math.max(48, Math.min(360, Math.round(cssW * maxDpr)));
    const ph = Math.max(48, Math.min(360, Math.round(cssH * maxDpr)));

    if (s.canvas.width !== pw || s.canvas.height !== ph) {
      s.canvas.width = pw;
      s.canvas.height = ph;
      s.lastCssW = cssW;
      s.lastCssH = cssH;
    }

    // Update renderer viewport size to match crisp high-res icon output (up to 320px)
    const rw = Math.min(320, Math.max(96, pw));
    const rh = Math.min(320, Math.max(96, ph));
    const curSize = this.renderer.getSize(tmpVec2);
    if (curSize.x !== rw || curSize.y !== rh) {
      this.renderer.setSize(rw, rh, false);
    }

    const asp = rw / rh;
    if (Math.abs(rig.camera.aspect - asp) > 0.002) {
      rig.camera.aspect = asp;
      rig.camera.updateProjectionMatrix();
    }

    rig.update(t, s.hoverCur, s.boostCur);
    this.renderer.clear();
    this.renderer.render(rig.scene, rig.camera);

    s.ctx.clearRect(0, 0, pw, ph);
    s.ctx.imageSmoothingEnabled = true;
    s.ctx.imageSmoothingQuality = "high";
    s.ctx.drawImage(this.renderer.domElement, 0, 0, rw, rh, 0, 0, pw, ph);
    s.lastDrawT = t;
  }

  private ensureLoop(): void {
    if (this.running) return;
    this.running = true;
    this.lastT = performance.now();

    const step = (now: number) => {
      if (!this.running) return;
      const dt = Math.min(0.05, Math.max(0.001, (now - this.lastT) / 1000));
      this.lastT = now;

      const reduced =
        typeof window !== "undefined" &&
        window.matchMedia?.("(prefers-reduced-motion: reduce)")?.matches;

      if (this.allPaused()) {
        this.stopLoop();
        return;
      }

      if (!document.hidden && this.subs.size > 0) {
        if (!reduced) this.elapsed += dt;

        // Smooth 30fps live breathing on GPU (~0.4ms total for all 3 tiny icons!), gentle rate on software WebGL
        const minGap = this.soft ? 0.16 : 0.03;
        for (const s of this.subs.values()) {
          if (s.paused) continue;
          if (!s.canvas.isConnected) continue;

          // Smooth exponential hover blend & damped interactive rotation spring
          const hk = 1 - Math.exp(-10 * dt);
          s.hoverCur += (s.hoverTarget - s.hoverCur) * hk;

          const bk = 1 - Math.exp(-6.2 * dt);
          const prevBoost = s.boostCur;
          s.boostCur += (s.boostTarget - s.boostCur) * bk;
          if (Math.abs(s.boostTarget - s.boostCur) < 0.002) s.boostCur = s.boostTarget;
          const activeMotion = Math.abs(s.hoverTarget - s.hoverCur) > 0.005 || Math.abs(s.boostCur - prevBoost) > 0.001;

          // Skip animation updates if reduced motion (keep 1 crisp frame) or small modal icons at lower cadence
          if (reduced && s.staticDone) continue;
          const slotGap = activeMotion ? 0.016 : s.canvas.clientWidth <= 52 ? 0.08 : minGap;
          if (this.elapsed - s.lastDrawT < slotGap && s.staticDone) continue;

          this.renderSingle(s, this.elapsed);
          s.staticDone = true;
        }
      }

      if (this.soft) {
        this.timer = window.setTimeout(() => {
          this.raf = requestAnimationFrame(step);
        }, 90);
      } else {
        this.raf = requestAnimationFrame(step);
      }
    };

    this.raf = requestAnimationFrame(step);
  }

  private stopLoop(): void {
    this.running = false;
    cancelAnimationFrame(this.raf);
    clearTimeout(this.timer);
  }

  isSupported(): boolean {
    return !this.failed;
  }
}

const tmpVec2 = new THREE.Vector2();
export const menuIcons3d = new MenuIcons3DService();
