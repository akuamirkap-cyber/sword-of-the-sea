// ============================================================================
// MODE "DUNIA LAUT 3D" — Above-Water 3D Coastal Life:
//   • 2x Scaled Soaring, Water-Skimming & Swimming 3D Pelicans with sleek
//     lofted hooked upper bill & smooth gular throat pouch, folded resting
//     wings on water, periodic water-scoop dip + surface ripples
//   • 2x Scaled Sculpted 3D Tourist Boats in separated non-overlapping coastal
//     lanes, featuring recessed teak cockpits, hull portholes, helms &
//     captains driving at the wheel, cushioned benches with seated tourists,
//     and standing/waving diver-proportioned vacationers
// ============================================================================
import * as THREE from "three";
import { WORLD_W } from "../ocean";
import { COMMON, SHARED } from "./glsl";
import { mulberry32 } from "./geometry";
import { buildDiverMesh } from "../penyelam/meshes.js";

type RGB = [number, number, number];

interface PartSpec {
  g: THREE.BufferGeometry;
  col: RGB;
  met?: number; // 0..0.85 standard dielectric/metal, >=0.91 ocean-sky reflective tinted boat glass
  ao?: number;
  part?: number; // 0=solid, 1=pelican wing, 2=attached flutter flag/bunting (uses anchorX), 4=wake/ripple foam, 5=tourist sway, 6=pelican head/neck/bill, 7=warm glowing harbor lantern/beacon
  /** Optional flutter anchor x (for mast flags) or y (for hanging bunting), encoded smoothly as wave mask */
  waveOrigin?: number;
  waveLen?: number;
  waveAxis?: "x" | "y";
}

interface MergedRaw {
  pos: Float32Array;
  norm: Float32Array;
  col: Float32Array;
  met: Float32Array;
  ao: Float32Array;
  part: Float32Array;
  count: number;
}

function mergeSurfaceParts(parts: PartSpec[], extras: MergedRaw[] = []): THREE.BufferGeometry {
  const clean: THREE.BufferGeometry[] = [];
  let totalVerts = 0;
  for (const p of parts) {
    const g = p.g.index ? p.g.toNonIndexed() : p.g;
    if (!g.getAttribute("normal")) g.computeVertexNormals();
    if (g.getAttribute("uv")) g.deleteAttribute("uv");
    clean.push(g);
    totalVerts += g.getAttribute("position").count;
  }
  for (const ex of extras) totalVerts += ex.count;

  const pos = new Float32Array(totalVerts * 3);
  const norm = new Float32Array(totalVerts * 3);
  const aCol = new Float32Array(totalVerts * 3);
  const aMet = new Float32Array(totalVerts);
  const aAO = new Float32Array(totalVerts);
  const aPart = new Float32Array(totalVerts);
  const aWave = new Float32Array(totalVerts);

  let off = 0;
  for (let i = 0; i < clean.length; i++) {
    const g = clean[i];
    const spec = parts[i];
    const gp = g.getAttribute("position") as THREE.BufferAttribute;
    const gn = g.getAttribute("normal") as THREE.BufferAttribute;
    const pa = gp.array as Float32Array;
    const n = gp.count;
    pos.set(pa, off * 3);
    norm.set(gn.array as Float32Array, off * 3);
    const [r, gr, b] = spec.col;
    const met = spec.met ?? 0.08;
    const ao = spec.ao ?? 1.0;
    const pt = spec.part ?? 0.0;
    const hasWave = pt > 1.5 && pt < 2.5 && spec.waveLen && spec.waveLen > 0.01;
    const wOrg = spec.waveOrigin ?? 0;
    const wInv = hasWave ? 1 / (spec.waveLen as number) : 0;
    const isYWave = spec.waveAxis === "y";
    for (let k = 0; k < n; k++) {
      const idx = off + k;
      aCol[idx * 3] = r;
      aCol[idx * 3 + 1] = gr;
      aCol[idx * 3 + 2] = b;
      aMet[idx] = met;
      aAO[idx] = ao;
      aPart[idx] = pt;
      if (hasWave) {
        const coord = isYWave ? wOrg - pa[k * 3 + 1] : Math.abs(pa[k * 3] - wOrg);
        aWave[idx] = Math.max(0, Math.min(1, coord * wInv));
      } else if (pt > 1.5 && pt < 2.5) {
        aWave[idx] = 0.5;
      }
    }
    off += n;
    if (g !== parts[i].g) parts[i].g.dispose();
    g.dispose();
  }

  for (const ex of extras) {
    pos.set(ex.pos, off * 3);
    norm.set(ex.norm, off * 3);
    aCol.set(ex.col, off * 3);
    aMet.set(ex.met, off);
    aAO.set(ex.ao, off);
    aPart.set(ex.part, off);
    off += ex.count;
  }

  const out = new THREE.BufferGeometry();
  out.setAttribute("position", new THREE.BufferAttribute(pos, 3));
  out.setAttribute("normal", new THREE.BufferAttribute(norm, 3));
  out.setAttribute("aCol", new THREE.BufferAttribute(aCol, 3));
  out.setAttribute("aMet", new THREE.BufferAttribute(aMet, 1));
  out.setAttribute("aAO", new THREE.BufferAttribute(aAO, 1));
  out.setAttribute("aPart", new THREE.BufferAttribute(aPart, 1));
  out.setAttribute("aWave", new THREE.BufferAttribute(aWave, 1));
  out.computeBoundingSphere();
  return out;
}

/** Build a non-indexed closed buffer geometry from lofted cross-section loops (each loop of equal point count). */
function loftRings(loops: THREE.Vector3[][], capStart = true, capEnd = true): THREE.BufferGeometry {
  const seg = loops[0].length;
  const tris: number[] = [];
  const pushTri = (a: THREE.Vector3, b: THREE.Vector3, c: THREE.Vector3) => {
    tris.push(a.x, a.y, a.z, b.x, b.y, b.z, c.x, c.y, c.z);
  };
  for (let i = 0; i < loops.length - 1; i++) {
    const L0 = loops[i];
    const L1 = loops[i + 1];
    for (let j = 0; j < seg; j++) {
      const jn = (j + 1) % seg;
      pushTri(L0[j], L1[j], L1[jn]);
      pushTri(L0[j], L1[jn], L0[jn]);
    }
  }
  if (capStart && loops.length > 0) {
    const L = loops[0];
    const c = new THREE.Vector3();
    for (const p of L) c.add(p);
    c.divideScalar(seg);
    for (let j = 0; j < seg; j++) {
      const jn = (j + 1) % seg;
      pushTri(c, L[jn], L[j]);
    }
  }
  if (capEnd && loops.length > 0) {
    const L = loops[loops.length - 1];
    const c = new THREE.Vector3();
    for (const p of L) c.add(p);
    c.divideScalar(seg);
    for (let j = 0; j < seg; j++) {
      const jn = (j + 1) % seg;
      pushTri(c, L[j], L[jn]);
    }
  }
  const geo = new THREE.BufferGeometry();
  geo.setAttribute("position", new THREE.Float32BufferAttribute(tris, 3));
  geo.computeVertexNormals();
  return geo;
}

// ------------------------------------------------------------------ Surface Daylight Material
function surfaceDaylightMaterial(transparentPass = false): THREE.ShaderMaterial {
  return new THREE.ShaderMaterial({
    uniforms: { ...SHARED },
    side: THREE.DoubleSide,
    transparent: transparentPass,
    depthWrite: !transparentPass,
    vertexShader: /* glsl */ `
attribute vec3 aCol;
attribute float aMet;
attribute float aAO;
attribute float aPart;
attribute float aWave;
attribute vec4 iCtrl; // (phase, flapAmp (<0 = folded swimming/perched wing!), wingFreq, glideOrSwimDip)
uniform float uTime;

varying vec3 vWP;
varying vec3 vN;
varying vec3 vCol;
varying float vMet;
varying float vAO;
varying float vPart;
varying float vPh;

void main(){
  vec3 pos = position;
  vec3 nrm = normal;
  float ph = iCtrl.x;

  // Pelican articulated left & right wings (part == 1.0)
  if (aPart > 0.5 && aPart < 1.5) {
    float side = pos.z >= 0.0 ? 1.0 : -1.0;
    float shZ = side * 2.1;
    float shY = 1.6;
    float dz = pos.z - shZ;
    float dy = pos.y - shY;
    float span = clamp(abs(dz) / 14.0, 0.0, 1.0);

    if (iCtrl.y < 0.0) {
      // Folded resting wing posture for pelicans swimming on water or perched on boats
      pos.z = side * (3.15 + abs(dz) * 0.085);
      pos.y = 1.25 + dy * 0.55 + sin(span * 2.6) * 1.45;
      pos.x -= abs(dz) * 0.42;
      pos.y += sin(uTime * 2.2 + ph) * 0.22 * span;
    } else {
      // Flying / soaring wingbeat + smooth glide cycles
      float beatWave = sin(uTime * iCtrl.z + ph - span * 0.45);
      float glideWave = sin(uTime * 0.48 + ph * 1.7);
      float activeFlap = mix(0.26, 1.0, smoothstep(-0.35, 0.35, glideWave));
      float ang = (beatWave * iCtrl.y * activeFlap + iCtrl.w) * (0.28 + 0.72 * span);
      float c = cos(ang), s = sin(ang) * side;
      pos.z = shZ + dz * c - dy * s;
      pos.y = shY + dz * s + dy * c;
      float ny = nrm.y, nz = nrm.z;
      nrm.z = nz * c - ny * s;
      nrm.y = nz * s + ny * c;
    }
  } else if (aPart > 1.5 && aPart < 2.5) {
    // Root-anchored cloth flutter: mast flags & roof bunting stay snugly attached at u=0 and billow gracefully to u=1
    float u = aWave * aWave;
    float flut = sin(uTime * 7.4 - pos.x * 0.28 + ph) * 2.35 * u;
    float lift = cos(uTime * 5.6 - pos.x * 0.24 + ph * 1.3) * 0.72 * aWave;
    pos.z += flut;
    pos.y += lift;
  } else if (aPart > 4.5 && aPart < 5.5) {
    // Cheerful diver-shaped tourists leaning gently on deck
    float sway = sin(uTime * 2.1 + ph + pos.x * 0.14) * 0.38 * clamp((pos.y - 20.0) / 14.0, 0.0, 1.0);
    pos.x += sway;
  } else if (aPart > 5.5 && aPart < 6.5) {
    // Pelican head, neck & pouched bill: gentle bob + water-scoop dip when swimming
    float pivotX = 4.2, pivotY = 0.8;
    float dx = pos.x - pivotX;
    float dy = pos.y - pivotY;
    float scoop = iCtrl.y < 0.0 ? pow(max(0.0, sin(uTime * 0.72 + ph * 2.3)), 14.0) * 0.42 : 0.0;
    float bob = sin(uTime * (iCtrl.y < 0.0 ? 2.4 : 1.4) + ph) * 0.042;
    float ang = -(scoop + bob);
    float c = cos(ang), s = sin(ang);
    pos.x = pivotX + dx * c - dy * s;
    pos.y = pivotY + dx * s + dy * c;
    float nx = nrm.x, ny = nrm.y;
    nrm.x = nx * c - ny * s;
    nrm.y = nx * s + ny * c;
  }

  mat4 mm = modelMatrix;
  #ifdef USE_INSTANCING
    mm = mm * instanceMatrix;
  #endif
  vec4 wp = mm * vec4(pos, 1.0);
  vWP = wp.xyz;
  vN = normalize(mat3(mm) * nrm);
  vCol = aCol;
  vMet = aMet;
  vAO = aAO;
  vPart = aPart;
  vPh = ph;
  gl_Position = projectionMatrix * viewMatrix * wp;
}`,
    fragmentShader:
      COMMON +
      /* glsl */ `
varying vec3 vWP;
varying vec3 vN;
varying vec3 vCol;
varying float vMet;
varying float vAO;
varying float vPart;
varying float vPh;

void main(){
  vec3 N = normalize(vN);
  if (!gl_FrontFacing) N = -N;

  // Translucent boat wake & swimming pelican water-ripple foam (vPart == 4.0)
  if (vPart > 3.5 && vPart < 4.5) {
    float r1 = 0.58 + 0.42 * sin(vWP.x * 0.11 - uTime * 4.2 + vPh);
    float r2 = 0.62 + 0.38 * cos(vWP.x * 0.23 + vWP.z * 0.18 - uTime * 5.4 + vPh * 1.7);
    float lace = r1 * 0.62 + r2 * 0.38;
    float fade = clamp(vAO * (0.52 + 0.56 * lace), 0.0, 1.0);
    vec3 foamCol = mix(vec3(0.64, 0.96, 1.0), vec3(1.0, 1.0, 1.0), clamp(0.42 + 0.58 * lace, 0.0, 1.0));
    float alpha = fade * 0.78;
    gl_FragColor = vec4(foamCol * alpha, alpha);
    return;
  }

  // Warm cozy sunlit harbor deck lanterns & beacon glow (vPart == 7.0)
  if (vPart > 6.5 && vPart < 7.5) {
    float pulse = 0.92 + 0.08 * sin(uTime * 3.6 + vPh * 2.1 + vWP.x * 0.05);
    vec3 glow = mix(vCol, vec3(1.0, 0.97, 0.80), 0.32) * (1.16 * pulse);
    gl_FragColor = vec4(min(glow, vec3(1.08)), 1.0);
    return;
  }

  // Stylized puffy storybook 3D cumulus clouds (vPart == 8.0): creamy sunlit tops, soft sky-blue bellies, zero specular
  if (vPart > 7.5 && vPart < 8.5) {
    vec3 Lc = normalize(vec3(-0.34, 0.84, 0.42));
    float up = clamp(N.y * 0.5 + 0.5, 0.0, 1.0);
    float sunSide = max(0.0, dot(N, Lc));
    float k = smoothstep(0.05, 0.85, up * 0.62 + sunSide * 0.5);
    vec3 belly = vec3(0.70, 0.84, 0.98) * vAO;
    vec3 top = vec3(1.0, 1.0, 1.0);
    vec3 c = mix(belly, top, k);
    c += vec3(1.0, 0.97, 0.88) * pow(sunSide, 3.0) * 0.08;
    gl_FragColor = vec4(c, 1.0);
    return;
  }

  vec3 L = normalize(vec3(-0.34, 0.84, 0.42));
  vec3 V = vec3(0.0, 0.0, 1.0);
  vec3 H = normalize(L + V);
  float ndl = max(dot(N, L), 0.0);
  float wrap = max(0.0, dot(N, L) * 0.55 + 0.45);
  float skyFill = clamp(N.y * 0.5 + 0.5, 0.0, 1.0);
  float seaBounce = max(0.0, -N.y);
  float fres = 1.0 - max(abs(N.z), 0.0);

  // Bright Pixar tropical coastal lighting: warm sunshine, airy azure sky, sparkling aqua hull under-bounce
  vec3 skyAmb = mix(vec3(0.46, 0.72, 0.90), vec3(0.88, 0.96, 1.0), skyFill);
  vec3 bounce = vec3(0.22, 0.82, 0.88) * seaBounce * 0.40;
  vec3 sunLit = vec3(1.06, 1.00, 0.89) * (ndl * 0.80 + wrap * 0.30);
  vec3 lighting = skyAmb * 0.48 + sunLit + bounce;

  vec3 col = vCol * lighting * (0.60 + 0.40 * vAO);

  // Reflective glossy ocean-glass cabin windows & curved panoramic windshields (met >= 0.93)
  if (vMet > 0.925) {
    float band = clamp(N.y * 0.65 + 0.52 + sin(vWP.x * 0.08 + uTime * 0.6) * 0.08, 0.0, 1.0);
    vec3 deepTint = vCol * vec3(0.42, 0.64, 0.84);
    vec3 skyRefl = mix(vec3(0.46, 0.88, 1.0), vec3(0.96, 0.99, 1.0), smoothstep(0.55, 0.95, band));
    float diagGlint = smoothstep(0.84, 0.96, fract(vWP.x * 0.018 - vWP.y * 0.022));
    col = mix(deepTint, skyRefl, 0.52 + 0.36 * fres) + vec3(0.96, 0.99, 1.0) * diagGlint * 0.24;
    float gSpec = pow(max(dot(N, H), 0.0), 84.0) * 0.92;
    col += vec3(1.0, 0.99, 0.95) * gSpec;
  } else {
    // Glossy marine gelcoat, varnished teak, brushed brass & polished chrome specular sheen
    float shin = mix(18.0, 76.0, vMet);
    float spec = pow(max(dot(N, H), 0.0), shin) * (0.14 + 0.72 * vMet);
    col += vec3(1.0, 0.99, 0.93) * spec;
    // Crisp soft sunlit sky rim highlight separating every boat & pelican clearly from the ocean horizon
    col += vec3(0.80, 0.95, 1.0) * (fres * fres) * 0.17;
  }

  // Wet turquoise splashline & translucent submerged keel sheen cleanly kissing water surface y = 0
  float waterlineRim = exp(-abs(vWP.y - 1.2) * 0.42) * 0.14;
  col += vec3(0.76, 0.98, 1.0) * waterlineRim;
  float subK = smoothstep(1.2, -7.2, vWP.y);
  if (subK > 0.005) {
    vec3 wetCol = col * vec3(0.54, 0.90, 0.96);
    col = mix(col, mix(wetCol, waterCol(-vWP.y), 0.26), subK);
  }

  // Distant stylized harbor island (vPart == 9.0): soft airy aerial-perspective haze pushes it gently behind the boats
  if (vPart > 8.5 && vPart < 9.5) {
    float hazeK = 0.22 + 0.10 * clamp(1.0 - vWP.y / 160.0, 0.0, 1.0);
    col = mix(col, vec3(0.74, 0.90, 1.0), hazeK);
  }

  gl_FragColor = vec4(col, 1.0);
}`,
  });
}

// ------------------------------------------------------------------ Composite 3D Pelican Geometry (faces +X)
function buildSculptedPelicanBeak(): PartSpec[] {
  const parts: PartSpec[] = [];
  const beakGold: RGB = [0.98, 0.75, 0.2];
  const beakTipRed: RGB = [0.94, 0.28, 0.14];
  const pouchPeach: RGB = [0.98, 0.54, 0.34];
  const rimCream: RGB = [1.0, 0.9, 0.66];

  // 1) Long sculpted Upper Bill (culmen): broad at forehead, flat arched ridge, sleek sharp tip at x=20
  const upperMainLoops: THREE.Vector3[][] = [];
  const upperHookLoops: THREE.Vector3[][] = [];
  const nMain = 9;
  for (let i = 0; i <= nMain; i++) {
    const t = i / nMain; // 0..0.88 span of main golden culmen
    const u = t * 0.88;
    const x = 8.4 + u * 11.4;
    const w = (1 - u * 0.84) * 1.42;
    const h = (1 - u * 0.68) * 1.02;
    const yRim = 7.25 - u * 0.65 - u * u * 0.25;
    const yTop = yRim + h + Math.sin(u * Math.PI) * 0.18;
    upperMainLoops.push([
      new THREE.Vector3(x, yTop, 0),
      new THREE.Vector3(x, yRim + h * 0.58, w * 0.68),
      new THREE.Vector3(x, yRim, w),
      new THREE.Vector3(x, yRim - 0.12, 0),
      new THREE.Vector3(x, yRim, -w),
      new THREE.Vector3(x, yRim + h * 0.58, -w * 0.68),
    ]);
  }
  parts.push({ g: loftRings(upperMainLoops, true, true), col: beakGold, met: 0.44, ao: 1.0, part: 6 });

  // Signature downward-hooked orange-red tip nail (unguiculus) seamlessly continuing main culmen
  const hookPts: [number, number, number, number][] = [
    [0.86, 0.0, 1.0, 1.0],
    [0.92, -0.08, 0.82, 0.88],
    [0.97, -0.34, 0.52, 0.62],
    [1.01, -0.82, 0.18, 0.25],
  ];
  for (const [u, hookDrop, wf, hf] of hookPts) {
    const x = 8.4 + u * 11.4;
    const w = (1 - 0.88 * 0.84) * 1.42 * wf;
    const h = (1 - 0.88 * 0.68) * 1.02 * hf;
    const yRim = 7.25 - u * 0.65 - u * u * 0.25 + hookDrop;
    const yTop = yRim + h;
    upperHookLoops.push([
      new THREE.Vector3(x, yTop, 0),
      new THREE.Vector3(x, yRim + h * 0.55, w * 0.68),
      new THREE.Vector3(x, yRim, w),
      new THREE.Vector3(x, yRim - 0.16, 0),
      new THREE.Vector3(x, yRim, -w),
      new THREE.Vector3(x, yRim + h * 0.55, -w * 0.68),
    ]);
  }
  parts.push({ g: loftRings(upperHookLoops, true, true), col: beakTipRed, met: 0.48, ao: 1.0, part: 6 });

  // 2) Graceful Lower Mandible Jaw Rim + Tucked Elastic Gular Throat Pouch
  // Profile follows the upper bill edge underneath, bowing smoothly beneath the jaw without bulging past the bill sides
  const pouchLoops: THREE.Vector3[][] = [];
  const jawRimLoops: THREE.Vector3[][] = [];
  const nPouch = 10;
  for (let i = 0; i <= nPouch; i++) {
    const u = i / nPouch;
    const x = 8.2 + u * 11.0;
    const wRim = (1 - u * 0.86) * 1.28;
    const yRim = 7.12 - u * 0.66 - u * u * 0.22;
    // Sleek pelican throat-pouch curve: deepest in the rear throat-mid area, tapering cleanly to tip
    const drop = Math.sin(Math.PI * Math.pow(u, 0.62)) * 2.25;
    const wBelly = wRim * 0.72;
    pouchLoops.push([
      new THREE.Vector3(x, yRim - 0.05, wRim * 0.82),
      new THREE.Vector3(x, yRim - drop * 0.52, wBelly),
      new THREE.Vector3(x, yRim - drop, 0),
      new THREE.Vector3(x, yRim - drop * 0.52, -wBelly),
      new THREE.Vector3(x, yRim - 0.05, -wRim * 0.82),
      new THREE.Vector3(x, yRim + 0.05, 0),
    ]);
    jawRimLoops.push([
      new THREE.Vector3(x, yRim + 0.08, 0),
      new THREE.Vector3(x, yRim + 0.05, wRim),
      new THREE.Vector3(x, yRim - 0.22, wRim * 0.88),
      new THREE.Vector3(x, yRim - 0.16, 0),
      new THREE.Vector3(x, yRim - 0.22, -wRim * 0.88),
      new THREE.Vector3(x, yRim + 0.05, -wRim),
    ]);
  }
  parts.push({ g: loftRings(pouchLoops, true, true), col: pouchPeach, met: 0.14, ao: 0.94, part: 6 });
  parts.push({ g: loftRings(jawRimLoops, true, true), col: rimCream, met: 0.34, ao: 1.0, part: 6 });

  return parts;
}

function buildPelicanGeometry(): THREE.BufferGeometry {
  const parts: PartSpec[] = [];
  const white: RGB = [0.98, 0.97, 0.94];
  const cream: RGB = [0.96, 0.92, 0.82];
  const mantleGray: RGB = [0.68, 0.74, 0.8];
  const wingTip: RGB = [0.16, 0.19, 0.25];
  const eyeDark: RGB = [0.05, 0.06, 0.09];
  const eyeRingYellow: RGB = [0.98, 0.84, 0.36];
  const footOrange: RGB = [0.96, 0.52, 0.16];

  // Plump streamlined boat-shaped body (bow chest at +X, tail at -X)
  const body = new THREE.SphereGeometry(4.4, 16, 12);
  body.scale(1.62, 0.92, 0.84);
  parts.push({ g: body, col: white, met: 0.08, ao: 0.95 });

  // Soft silver-gray dorsal feather saddle
  const saddle = new THREE.SphereGeometry(3.8, 12, 9, 0, Math.PI * 2, 0, Math.PI * 0.55);
  saddle.scale(1.55, 0.75, 0.8);
  saddle.translate(-0.6, 1.4, 0);
  parts.push({ g: saddle, col: mantleGray, met: 0.06, ao: 0.92 });

  // Fanned tail feathers flaring cleanly backward (-X)
  const tail = new THREE.ConeGeometry(2.5, 6.2, 5);
  tail.rotateZ(-Math.PI / 2 + 0.18);
  tail.scale(1.0, 0.36, 1.25);
  tail.translate(-8.2, 0.8, 0);
  parts.push({ g: tail, col: wingTip, met: 0.05, ao: 0.88 });

  // Graceful S-curved neck (part = 6.0 so swimming pelicans can bob & dip!)
  const neckCurve = new THREE.CatmullRomCurve3([
    new THREE.Vector3(4.2, 0.8, 0),
    new THREE.Vector3(5.6, 3.0, 0),
    new THREE.Vector3(5.2, 6.0, 0),
    new THREE.Vector3(6.8, 7.6, 0),
  ]);
  const neck = new THREE.TubeGeometry(neckCurve, 12, 1.65, 8, false);
  parts.push({ g: neck, col: white, met: 0.08, ao: 0.96, part: 6 });

  // Rounded head + cheerful cream nape crest
  const head = new THREE.SphereGeometry(2.35, 14, 10);
  head.scale(1.12, 0.96, 0.9);
  head.translate(7.3, 7.8, 0);
  parts.push({ g: head, col: white, met: 0.1, ao: 0.98, part: 6 });

  const crest = new THREE.ConeGeometry(1.0, 3.2, 6);
  crest.rotateZ(Math.PI * 0.62);
  crest.scale(1.0, 0.55, 0.65);
  crest.translate(5.0, 9.1, 0);
  parts.push({ g: crest, col: cream, met: 0.06, ao: 0.95, part: 6 });

  // Expressive golden eye ring + glossy dark eyes
  for (const sz of [-1, 1]) {
    const ring = new THREE.SphereGeometry(0.76, 8, 8);
    ring.scale(1.0, 0.9, 0.6);
    ring.translate(7.9, 8.3, sz * 1.72);
    parts.push({ g: ring, col: eyeRingYellow, met: 0.15, ao: 1.0, part: 6 });

    const eye = new THREE.SphereGeometry(0.5, 8, 8);
    eye.translate(8.15, 8.35, sz * 1.92);
    parts.push({ g: eye, col: eyeDark, met: 0.92, ao: 1.0, part: 6 });
  }

  // Sculpted long golden-amber pelican bill + hooked red-orange tip + sleek peach throat pouch
  parts.push(...buildSculptedPelicanBeak());

  // Articulated flapping/folding left & right wings (part = 1.0, swept neatly back -X)
  for (const sz of [-1, 1]) {
    const innerW = new THREE.BoxGeometry(6.8, 0.75, 9.2);
    innerW.rotateY(-sz * 0.14);
    innerW.translate(0.1, 1.8, sz * 6.5);
    parts.push({ g: innerW, col: white, met: 0.08, ao: 0.96, part: 1 });

    const outerW = new THREE.ConeGeometry(2.8, 8.8, 5);
    outerW.rotateX(sz * Math.PI * 0.5);
    outerW.rotateY(-sz * 0.36);
    outerW.rotateZ(0.2);
    outerW.scale(1.35, 0.25, 1.0);
    outerW.translate(-1.8, 2.0, sz * 14.0);
    parts.push({ g: outerW, col: wingTip, met: 0.06, ao: 0.9, part: 1 });
  }

  // Tucked orange webbed feet
  for (const sz of [-1, 1]) {
    const leg = new THREE.CylinderGeometry(0.35, 0.3, 3.2, 6);
    leg.rotateZ(-1.1);
    leg.translate(-4.6, -2.5, sz * 1.4);
    parts.push({ g: leg, col: footOrange, met: 0.2, ao: 0.85 });

    const web = new THREE.ConeGeometry(1.1, 2.4, 3);
    web.rotateZ(-Math.PI / 2);
    web.scale(1.0, 0.25, 0.9);
    web.translate(-6.4, -3.2, sz * 1.4);
    parts.push({ g: web, col: footOrange, met: 0.2, ao: 0.85 });
  }

  return mergeSurfaceParts(parts);
}

// ------------------------------------------------------------------ Stylized Diver-Proportioned Tourist Character Builder
// Uses clean PENYELAM diver anatomy (Dear Flight head + smooth torso + posed arms + posed legs),
// omitting ALL scuba gear (helmet, copper corselet, belts, tanks, boots, fins) for crisp resort attire!
interface TouristOutfitSpec {
  x: number;
  y: number;
  z: number;
  yaw: number;
  scale?: number;
  pose?: "stand" | "sit" | "drive";
  shirt: RGB;
  collar: RGB;
  shorts: RGB;
  skin: RGB;
  hair: RGB;
  hat?: "straw" | "captain" | "cap" | "none";
  hatCol?: RGB;
  hatBand?: RGB;
  sunglasses?: boolean;
  camera?: boolean;
  waveArm?: boolean;
}

function buildDiverTouristMerged(
  divSource: ReturnType<typeof buildDiverMesh>,
  cfg: TouristOutfitSpec,
): MergedRaw {
  const s = cfg.scale ?? 21.0;
  const pose = cfg.pose ?? "stand";
  const dv = new DataView(divSource.vb);
  const posArr: number[] = [];
  const normArr: number[] = [];
  const colArr: number[] = [];
  const metArr: number[] = [];
  const aoArr: number[] = [];
  const partArr: number[] = [];

  const qRot = new THREE.Quaternion().setFromAxisAngle(new THREE.Vector3(0, 1, 0), cfg.yaw);
  const v = new THREE.Vector3();
  const n = new THREE.Vector3();

  const colorForVertex = (mat: number, part: number, lx: number, ly: number): [RGB, number] => {
    if (part === 1) {
      if (mat === 51) return [cfg.hair, 0.08];
      if (mat === 53) return [[0.56, 0.14, 0.14], 0.12];
      if (mat === 55) return [[cfg.skin[0] * 0.85, cfg.skin[1] * 0.72, cfg.skin[2] * 0.68], 0.08];
      if (mat === 56) return [[cfg.hair[0] * 0.72, cfg.hair[1] * 0.72, cfg.hair[2] * 0.72], 0.08];
      if (mat === 58 && !cfg.sunglasses) {
        const dEye = Math.hypot(Math.abs(lx) - 0.0435, ly - 0.795);
        if (dEye < 0.017) return [[0.06, 0.08, 0.14], 0.88];
        if (dEye < 0.025) return [[0.96, 0.98, 1.0], 0.45];
      }
      return [cfg.skin, 0.1];
    }
    if (part === 0) {
      // Casual waistband shorts transition at lower hip + shirt neck V-trim
      if (ly < 0.345) return [cfg.shorts, 0.1];
      if (ly > 0.585) return [cfg.collar, 0.14];
      // Clean resort Hawaiian / nautical pattern stripes
      const stripe = Math.sin(ly * 46 + lx * 32) > 0.38;
      if (stripe) {
        return [
          [
            Math.min(1, cfg.shirt[0] * 0.8 + cfg.collar[0] * 0.25 + 0.08),
            Math.min(1, cfg.shirt[1] * 0.8 + cfg.collar[1] * 0.25 + 0.08),
            Math.min(1, cfg.shirt[2] * 0.8 + cfg.collar[2] * 0.25 + 0.08),
          ],
          0.1,
        ];
      }
      return [cfg.shirt, 0.1];
    }
    if (part === 2 || part === 3) {
      // Short-sleeve summer shirt upper sleeve + bare forearm & skin hands
      if (ly >= 0.475) return [cfg.shirt, 0.1];
      return [cfg.skin, 0.1];
    }
    // Legs (part === 4, 5): resort beach shorts + bare legs + bright deck sneakers
    if (ly >= 0.155) return [cfg.shorts, 0.1];
    if (ly >= 0.085) return [cfg.skin, 0.1];
    return [[0.96, 0.97, 0.99], 0.22];
  };

  const rotX = (vx: number, vy: number, vz: number, _px: number, py: number, pz: number, ang: number) => {
    const c = Math.cos(ang),
      sn = Math.sin(ang);
    const dy = vy - py,
      dz = vz - pz;
    return [vx, py + dy * c - dz * sn, pz + dy * sn + dz * c];
  };

  const pushTriVertex = (vi: number) => {
    const o = vi * 20;
    let lx = dv.getFloat32(o, true);
    let ly = dv.getFloat32(o + 4, true);
    let lz = dv.getFloat32(o + 8, true);
    let nx = dv.getInt8(o + 12) / 127;
    let ny = dv.getInt8(o + 13) / 127;
    let nz = dv.getInt8(o + 14) / 127;
    const ao = Math.max(0, dv.getInt8(o + 15) / 127);
    const mat = dv.getUint8(o + 16);
    const part = dv.getUint8(o + 17);

    // Compute shirt color BEFORE pose transforms so short sleeves / shorts follow limb UV!
    const [rgb, met] = colorForVertex(mat, part, lx, ly);

    // Pose 1: Driving / Steering at the helm wheel (both arms extended forward -Z & inward)
    if (pose === "drive" && (part === 2 || part === 3)) {
      const side = part === 2 ? -1 : 1;
      const sx = side * 0.155,
        sy = 0.542,
        sz = 0.0;
      const [rx, ry, rz] = rotX(lx, ly, lz, sx, sy, sz, 1.18);
      lx = rx - side * Math.max(0, -rz) * 0.28;
      ly = ry;
      lz = rz;
      const [nrx, nry, nrz] = rotX(nx, ny, nz, 0, 0, 0, 1.18);
      nx = nrx;
      ny = nry;
      nz = nrz;
    } else if (cfg.waveArm && part === 3) {
      // Pose 2: Happy waving right arm
      const sy = 0.542;
      const dx = lx - 0.155;
      const dy = ly - sy;
      const wa = 2.02;
      const c = Math.cos(wa),
        sn = Math.sin(wa);
      lx = 0.155 + dx * c - dy * sn;
      ly = sy + dx * sn + dy * c;
      const nrx = nx * c - ny * sn;
      const nry = nx * sn + ny * c;
      nx = nrx;
      ny = nry;
    }

    // Pose 3: Seated on bench! Bend thighs forward 82 deg (-Z) & lower legs back down 74 deg from knee
    if (pose === "sit" && (part === 4 || part === 5)) {
      const hipY = 0.285,
        hipZ = 0.0,
        kneeY = 0.175;
      const aThigh = 1.44;
      const cT = Math.cos(aThigh),
        sT = Math.sin(aThigh);
      const kneeWorldY = hipY + (kneeY - hipY) * cT;
      const kneeWorldZ = hipZ + (kneeY - hipY) * sT;

      if (ly >= kneeY) {
        [lx, ly, lz] = rotX(lx, ly, lz, lx, hipY, hipZ, aThigh);
        [nx, ny, nz] = rotX(nx, ny, nz, 0, 0, 0, aThigh);
      } else {
        const aShin = 0.12;
        const [tx, ty, tz] = rotX(lx, ly, lz, lx, kneeY, 0, aShin);
        lx = tx;
        ly = kneeWorldY + (ty - kneeY);
        lz = kneeWorldZ + tz;
        [nx, ny, nz] = rotX(nx, ny, nz, 0, 0, 0, aShin);
      }
    }

    // Seated casual arm pose: forearm bent slightly forward resting comfortably on lap
    if (pose === "sit" && (part === 2 || part === 3) && !cfg.waveArm) {
      const sy = 0.542,
        sz = 0.0;
      [lx, ly, lz] = rotX(lx, ly, lz, lx, sy, sz, 0.36);
      [nx, ny, nz] = rotX(nx, ny, nz, 0, 0, 0, 0.36);
    }

    v.set(lx * s, ly * s, lz * s).applyQuaternion(qRot);
    n.set(nx, ny, nz).applyQuaternion(qRot).normalize();

    posArr.push(cfg.x + v.x, cfg.y + v.y, cfg.z + v.z);
    normArr.push(n.x, n.y, n.z);
    colArr.push(rgb[0], rgb[1], rgb[2]);
    metArr.push(met);
    aoArr.push(Math.max(0.75, ao));
    partArr.push(pose === "stand" ? 5 : 0);
  };

  for (let t = 0; t < divSource.ib.length; t += 3) {
    const v0 = divSource.ib[t];
    const v1 = divSource.ib[t + 1];
    const v2 = divSource.ib[t + 2];
    const o0 = v0 * 20;
    const mat = dv.getUint8(o0 + 16);
    const part = dv.getUint8(o0 + 17);

    // Strip helmet (10), hoses (8), harpoon (9), flippers (6,7), tanks (6)
    if (part > 5 || mat === 6) continue;
    // On torso (part 0): strip copper corselet (1), brass bolts/buckle/knife (2), weight belt pouches (5), tank trim (8)!
    if (part === 0 && mat !== 0) continue;
    // On arms & legs: strip bulky brass diving cuffs & bulbous brass toe caps (mat === 2)
    if ((part >= 2 && part <= 5) && mat === 2) continue;

    pushTriVertex(v0);
    pushTriVertex(v1);
    pushTriVertex(v2);
  }

  // Clean Tourist Accessories in exact character space
  const accSpecs: PartSpec[] = [];
  const addAcc = (geo: THREE.BufferGeometry, col: RGB, met = 0.25) => {
    geo.scale(s, s, s);
    geo.applyQuaternion(qRot);
    geo.translate(cfg.x, cfg.y, cfg.z);
    accSpecs.push({ g: geo, col, met, ao: 0.96, part: pose === "stand" ? 5 : 0 });
  };

  // Casual slim leather belt or captain trim around waist
  const belt = new THREE.CylinderGeometry(0.122, 0.122, 0.024, 14);
  belt.scale(1.0, 1.0, 0.85);
  belt.translate(0, 0.348, 0);
  addAcc(belt, cfg.hat === "captain" ? [0.1, 0.15, 0.28] : [0.48, 0.28, 0.14], 0.2);

  if (cfg.sunglasses) {
    for (const sx of [-1, 1]) {
      const lens = new THREE.BoxGeometry(0.056, 0.032, 0.018);
      lens.translate(sx * 0.045, 0.794, -0.104);
      addAcc(lens, [0.05, 0.07, 0.13], 0.92);
    }
    const bridge = new THREE.BoxGeometry(0.034, 0.01, 0.014);
    bridge.translate(0, 0.802, -0.106);
    addAcc(bridge, [0.85, 0.72, 0.28], 0.85);
  }

  if (cfg.hat === "straw") {
    const brim = new THREE.CylinderGeometry(0.195, 0.205, 0.016, 14);
    brim.translate(0, 0.862, 0.005);
    addAcc(brim, cfg.hatCol ?? [0.95, 0.84, 0.56], 0.12);

    const crown = new THREE.CylinderGeometry(0.1, 0.115, 0.085, 14);
    crown.translate(0, 0.905, 0.005);
    addAcc(crown, cfg.hatCol ?? [0.95, 0.84, 0.56], 0.12);

    const band = new THREE.CylinderGeometry(0.117, 0.117, 0.022, 14);
    band.translate(0, 0.878, 0.005);
    addAcc(band, cfg.hatBand ?? cfg.shirt, 0.16);
  } else if (cfg.hat === "captain") {
    const capTop = new THREE.CylinderGeometry(0.128, 0.108, 0.072, 14);
    capTop.translate(0, 0.892, 0.005);
    addAcc(capTop, [0.98, 0.98, 0.99], 0.22);

    const band = new THREE.CylinderGeometry(0.11, 0.112, 0.03, 14);
    band.translate(0, 0.86, 0.005);
    addAcc(band, [0.08, 0.16, 0.36], 0.25);

    const visor = new THREE.BoxGeometry(0.15, 0.014, 0.095);
    visor.rotateX(0.18);
    visor.translate(0, 0.85, -0.105);
    addAcc(visor, [0.05, 0.07, 0.13], 0.78);
  } else if (cfg.hat === "cap") {
    const dome = new THREE.SphereGeometry(0.115, 12, 8, 0, Math.PI * 2, 0, Math.PI * 0.54);
    dome.translate(0, 0.855, 0.008);
    addAcc(dome, cfg.hatCol ?? cfg.shirt, 0.15);

    const peak = new THREE.BoxGeometry(0.14, 0.012, 0.085);
    peak.rotateX(0.12);
    peak.translate(0, 0.855, -0.102);
    addAcc(peak, cfg.hatBand ?? [0.98, 0.98, 0.98], 0.2);
  }

  if (cfg.camera) {
    const camBody = new THREE.BoxGeometry(0.11, 0.07, 0.045);
    camBody.translate(0, 0.49, -0.135);
    addAcc(camBody, [0.16, 0.18, 0.22], 0.55);

    const lens = new THREE.CylinderGeometry(0.025, 0.028, 0.045, 10);
    lens.rotateX(Math.PI / 2);
    lens.translate(0, 0.49, -0.168);
    addAcc(lens, [0.85, 0.9, 0.95], 0.88);
  }

  const accGeo = accSpecs.length ? mergeSurfaceParts(accSpecs) : null;
  const accCount = accGeo ? accGeo.getAttribute("position").count : 0;
  const baseCount = posArr.length / 3;
  const totalCount = baseCount + accCount;

  const pos = new Float32Array(totalCount * 3);
  const norm = new Float32Array(totalCount * 3);
  const col = new Float32Array(totalCount * 3);
  const met = new Float32Array(totalCount);
  const ao = new Float32Array(totalCount);
  const part = new Float32Array(totalCount);

  pos.set(posArr, 0);
  norm.set(normArr, 0);
  col.set(colArr, 0);
  met.set(metArr, 0);
  ao.set(aoArr, 0);
  part.set(partArr, 0);

  if (accGeo && accCount > 0) {
    pos.set(accGeo.getAttribute("position").array as Float32Array, baseCount * 3);
    norm.set(accGeo.getAttribute("normal").array as Float32Array, baseCount * 3);
    col.set(accGeo.getAttribute("aCol").array as Float32Array, baseCount * 3);
    met.set(accGeo.getAttribute("aMet").array as Float32Array, baseCount);
    ao.set(accGeo.getAttribute("aAO").array as Float32Array, baseCount);
    part.set(accGeo.getAttribute("aPart").array as Float32Array, baseCount);
    accGeo.dispose();
  }

  return { pos, norm, col, met, ao, part, count: totalCount };
}

// ------------------------------------------------------------------ Sculpted Luxury 3D Tourist Boat Hull & Props
interface HullStation {
  x: number;
  halfW: number;
  sheerY: number;
  chineY: number;
  keelY: number;
}

/** Linearly sample smooth hull curve attributes at any X position */
function sampleStation(stations: HullStation[], x: number): HullStation {
  if (x <= stations[0].x) return stations[0];
  const last = stations[stations.length - 1];
  if (x >= last.x) return last;
  for (let i = 0; i < stations.length - 1; i++) {
    const a = stations[i];
    const b = stations[i + 1];
    if (x >= a.x && x <= b.x) {
      const t = (x - a.x) / Math.max(1e-4, b.x - a.x);
      return {
        x,
        halfW: a.halfW + (b.halfW - a.halfW) * t,
        sheerY: a.sheerY + (b.sheerY - a.sheerY) * t,
        chineY: a.chineY + (b.chineY - a.chineY) * t,
        keelY: a.keelY + (b.keelY - a.keelY) * t,
      };
    }
  }
  return last;
}

/** Smooth outer hull half-beam z offset at exact elevation y (eliminates floating/clipping side trim & portholes!) */
function hullSideZ(st: HullStation, y: number): number {
  const span = Math.max(0.5, st.sheerY - st.chineY);
  const v = Math.max(0, Math.min(1, (y - st.chineY) / span)); // 0=chine, 1=sheer
  // Gentle flared maritime convex hull profile (sleek yacht fullness!)
  const factor = 0.8 + 0.2 * Math.sin(v * Math.PI * 0.5);
  return st.halfW * factor;
}

/** Loft clean outward-only exterior ribbon flush over hull flanks (zero ugly cross-hull strips or z-fighting!) */
function buildHullSideRibbon(
  stations: HullStation[],
  side: 1 | -1,
  topOff: number,
  botOff: number,
  pushOut: number,
  fromBottom = false,
): THREE.BufferGeometry {
  const tris: number[] = [];
  const push = (a: THREE.Vector3, b: THREE.Vector3, c: THREE.Vector3) => {
    tris.push(a.x, a.y, a.z, b.x, b.y, b.z, c.x, c.y, c.z);
  };
  const topPts: THREE.Vector3[] = [];
  const botPts: THREE.Vector3[] = [];
  for (const st of stations) {
    const yHi = fromBottom ? st.chineY + topOff : st.sheerY - topOff;
    const yLo = fromBottom ? st.chineY + botOff : st.sheerY - botOff;
    const yTop = Math.min(st.sheerY + 0.5, Math.max(st.chineY + 0.2, yHi));
    const yBot = Math.max(st.keelY + 1.0, Math.min(yTop - 0.15, yLo));
    const bowFade = Math.min(1, st.halfW / 2.2);
    const out = pushOut * (0.35 + 0.65 * bowFade);
    const zTop = side * (hullSideZ(st, yTop) + out);
    const zBot = side * (hullSideZ(st, yBot) + out);
    topPts.push(new THREE.Vector3(st.x, yTop, zTop));
    botPts.push(new THREE.Vector3(st.x, yBot, zBot));
  }
  for (let i = 0; i < topPts.length - 1; i++) {
    const t0 = topPts[i];
    const t1 = topPts[i + 1];
    const b0 = botPts[i];
    const b1 = botPts[i + 1];
    if (side > 0) {
      push(t0, b0, b1);
      push(t0, b1, t1);
    } else {
      push(t0, b1, b0);
      push(t0, t1, b1);
    }
  }
  const g = new THREE.BufferGeometry();
  g.setAttribute("position", new THREE.Float32BufferAttribute(tris, 3));
  g.computeVertexNormals();
  return g;
}

/** Build silky curved yacht hull with flush recessed side accent bands, beveled perimeter caprail, contoured interior teak deck & flared bow deck */
function buildSculptedBoatHullParts(
  stations: HullStation[],
  mainCol: RGB,
  keelCol: RGB,
  bootCol: RGB,
  stripeCol: RGB,
  pinstripeCol: RGB,
  gunwaleCol: RGB,
  deckCol: RGB,
  foredeckX: number,
  foredeckCol: RGB,
  deckY = 17.4,
): PartSpec[] {
  const parts: PartSpec[] = [];

  // 1. Sleek rounded flared hull body (12-point smooth cross-section per station!)
  const upperLoops: THREE.Vector3[][] = [];
  const keelLoops: THREE.Vector3[][] = [];
  for (const st of stations) {
    const w = Math.max(0.28, st.halfW);
    const y1 = st.chineY + (st.sheerY - st.chineY) * 0.68;
    const y2 = st.chineY + (st.sheerY - st.chineY) * 0.34;
    const z0 = hullSideZ(st, st.sheerY);
    const z1 = hullSideZ(st, y1);
    const z2 = hullSideZ(st, y2);
    const zc = w * 0.80;
    const deckDrop = Math.min(deckY, st.sheerY - 0.6);

    upperLoops.push([
      new THREE.Vector3(st.x, st.sheerY, z0),
      new THREE.Vector3(st.x, y1, z1),
      new THREE.Vector3(st.x, y2, z2),
      new THREE.Vector3(st.x, st.chineY, zc),
      new THREE.Vector3(st.x, st.keelY + 2.8, 0),
      new THREE.Vector3(st.x, st.chineY, -zc),
      new THREE.Vector3(st.x, y2, -z2),
      new THREE.Vector3(st.x, y1, -z1),
      new THREE.Vector3(st.x, st.sheerY, -z0),
      new THREE.Vector3(st.x, deckDrop, 0),
    ]);

    keelLoops.push([
      new THREE.Vector3(st.x, st.chineY + 0.9, zc * 0.99),
      new THREE.Vector3(st.x, (st.chineY + st.keelY) * 0.48, zc * 0.56),
      new THREE.Vector3(st.x, st.keelY + 0.2, zc * 0.2),
      new THREE.Vector3(st.x, st.keelY - 1.5, 0),
      new THREE.Vector3(st.x, st.keelY + 0.2, -zc * 0.2),
      new THREE.Vector3(st.x, (st.chineY + st.keelY) * 0.48, -zc * 0.56),
      new THREE.Vector3(st.x, st.chineY + 0.9, -zc * 0.99),
      new THREE.Vector3(st.x, st.chineY + 1.4, 0),
    ]);
  }
  parts.push({ g: loftRings(upperLoops, true, true), col: mainCol, met: 0.42, ao: 0.98 });
  parts.push({ g: loftRings(keelLoops, true, true), col: keelCol, met: 0.26, ao: 0.88 });

  // 2. Clean outward-only luxury molded nautical stripes hugging exact curved hull flanks (zero artifacts!)
  for (const sz of [-1, 1] as const) {
    // Graceful broad sheer signature colored sweep stripe
    parts.push({ g: buildHullSideRibbon(stations, sz, 2.2, 6.2, 0.46), col: stripeCol, met: 0.48, ao: 1.0 });
    // Crisp high-contrast hairline racing accent stripe right above
    parts.push({ g: buildHullSideRibbon(stations, sz, 0.75, 1.9, 0.52), col: pinstripeCol, met: 0.44, ao: 1.0 });
    // Gleaming waterline boot-top stripe hugging right over the dark navy/blue antifouling keel!
    parts.push({ g: buildHullSideRibbon(stations, sz, 2.6, 0.4, 0.42, true), col: bootCol, met: 0.56, ao: 0.98 });

    // Continuous smooth curved beveled yacht gunwale & rub-rail hugging EVERY curve from stern to pointed bow!
    const railPts = stations.map((st) => new THREE.Vector3(st.x, st.sheerY + 0.65, sz * (st.halfW + 0.32)));
    const railCurve = new THREE.CatmullRomCurve3(railPts);
    parts.push({ g: new THREE.TubeGeometry(railCurve, 22, 1.32, 8, false), col: gunwaleCol, met: 0.34, ao: 0.98 });

    // Subtle crisp lower black/chrome rub-rail bumper tracing the outside edge seamlessly
    const bumpPts = stations.map((st) => new THREE.Vector3(st.x, st.sheerY - 0.25, sz * (st.halfW + 0.88)));
    const bumpCurve = new THREE.CatmullRomCurve3(bumpPts);
    parts.push({ g: new THREE.TubeGeometry(bumpCurve, 18, 0.52, 6, false), col: [0.16, 0.2, 0.28], met: 0.45, ao: 0.92 });
  }

  // Smooth rounded aft transom caprail spanning port to starboard cleanly
  const s0 = stations[0];
  const transomCurve = new THREE.CatmullRomCurve3([
    new THREE.Vector3(s0.x, s0.sheerY + 0.65, -s0.halfW),
    new THREE.Vector3(s0.x - 1.6, s0.sheerY + 0.85, 0),
    new THREE.Vector3(s0.x, s0.sheerY + 0.65, s0.halfW),
  ]);
  parts.push({ g: new THREE.TubeGeometry(transomCurve, 10, 1.3, 8, false), col: gunwaleCol, met: 0.34, ao: 0.98 });

  // 3. Flush contoured warm caulked teak cockpit deck seated squarely inside curved hull walls (zero clipping!)
  const cockpitXs: number[] = [];
  for (let i = 0; i < 8; i++) {
    cockpitXs.push(s0.x + 2.5 + ((foredeckX - (s0.x + 2.5)) * i) / 7);
  }
  const dkTris: number[] = [];
  for (let i = 0; i < cockpitXs.length - 1; i++) {
    const a = sampleStation(stations, cockpitXs[i]);
    const b = sampleStation(stations, cockpitXs[i + 1]);
    const wa = Math.max(1, a.halfW - 1.0);
    const wb = Math.max(1, b.halfW - 1.0);
    // Double-strip softly crowned teak cockpit sole
    // Pure upward (+Y) CCW normals so the warm caulked teak cockpit glows smoothly in daylight
    dkTris.push(
      a.x, deckY, -wa, b.x, deckY + 0.25, 0, b.x, deckY, -wb,
      a.x, deckY, -wa, a.x, deckY + 0.25, 0, b.x, deckY + 0.25, 0,
      a.x, deckY + 0.25, 0, b.x, deckY, wb, b.x, deckY + 0.25, 0,
      a.x, deckY + 0.25, 0, a.x, deckY, wa, b.x, deckY, wb,
    );
  }
  const dkGeo = new THREE.BufferGeometry();
  dkGeo.setAttribute("position", new THREE.Float32BufferAttribute(dkTris, 3));
  dkGeo.computeVertexNormals();
  parts.push({ g: dkGeo, col: deckCol, met: 0.16, ao: 0.94 });

  // Neat delicate yacht teak caulked deck seams tucked strictly inside cockpit bounds
  const seamCol: RGB = [deckCol[0] * 0.56, deckCol[1] * 0.56, deckCol[2] * 0.56];
  const ckMid = (s0.x + 4 + foredeckX) * 0.5;
  const ckLen = foredeckX - s0.x - 6;
  for (const sz of [-8.4, -4.2, 0, 4.2, 8.4]) {
    const seam = new THREE.BoxGeometry(ckLen, 0.24, 0.38);
    seam.translate(ckMid, deckY + 0.3, sz);
    parts.push({ g: seam, col: seamCol, met: 0.08, ao: 0.86 });
  }

  // 4. Sculpted flush cambered raised foredeck flowing seamlessly inside the tapered bow sheerline!
  const lastX = stations[stations.length - 1].x;
  const foreSteps = 8;
  const fdTris: number[] = [];
  const pushFd = (x0: number, y0: number, z0: number, x1: number, y1: number, z1: number, x2: number, y2: number, z2: number) => {
    fdTris.push(x0, y0, z0, x1, y1, z1, x2, y2, z2);
  };
  for (let i = 0; i < foreSteps; i++) {
    const xa = foredeckX + ((lastX - foredeckX) * i) / foreSteps;
    const xb = foredeckX + ((lastX - foredeckX) * (i + 1)) / foreSteps;
    const sa = sampleStation(stations, xa);
    const sb = sampleStation(stations, xb);
    const wa = Math.max(0.25, sa.halfW);
    const wb = Math.max(0.22, sb.halfW);
    const ca = 1.8 * Math.min(1, wa / 11); // charming subtle crown arch camber
    const cb = 1.8 * Math.min(1, wb / 11);
    const yaE = sa.sheerY + 0.2;
    const ybE = sb.sheerY + 0.2;
    const yaM = yaE + ca * 0.72;
    const ybM = ybE + cb * 0.72;
    const yaC = yaE + ca;
    const ybC = ybE + cb;
    // 4 transverse dome camber strips across bow deck -> creamy smooth sunlit highlights!
    const profA: [number, number][] = [[-wa, yaE], [-wa * 0.5, yaM], [0, yaC], [wa * 0.5, yaM], [wa, yaE]];
    const profB: [number, number][] = [[-wb, ybE], [-wb * 0.5, ybM], [0, ybC], [wb * 0.5, ybM], [wb, ybE]];
    for (let j = 0; j < 4; j++) {
      // Pure upward (+Y) normals across the curved sunlit foredeck crown
      pushFd(xa, profA[j][1], profA[j][0], xb, profB[j + 1][1], profB[j + 1][0], xb, profB[j][1], profB[j][0]);
      pushFd(xa, profA[j][1], profA[j][0], xa, profA[j + 1][1], profA[j + 1][0], xb, profB[j + 1][1], profB[j + 1][0]);
    }
  }
  const fdGeo = new THREE.BufferGeometry();
  fdGeo.setAttribute("position", new THREE.Float32BufferAttribute(fdTris, 3));
  fdGeo.computeVertexNormals();
  parts.push({ g: fdGeo, col: foredeckCol, met: 0.36, ao: 0.99 });

  return parts;
}

/** Add smooth outward-facing circular beveled marine hull portholes accurately hugging hull flank contour! */
function addHullPortholes(
  parts: PartSpec[],
  stations: HullStation[],
  xs: number[],
  yOffFromChine: number,
  radius: number,
  ringCol: RGB,
  glassCol: RGB,
) {
  for (const px of xs) {
    const st = sampleStation(stations, px);
    const py = st.chineY + yOffFromChine;
    const baseZ = hullSideZ(st, py);
    for (const sz of [-1, 1]) {
      // Torus sits naturally in XY plane => cleanly faces ±Z (flush onto the outside of the boat hull!)
      const outerRing = new THREE.TorusGeometry(radius, radius * 0.24, 8, 16);
      outerRing.scale(1.16, 0.96, 0.85);
      outerRing.translate(px, py, sz * (baseZ + 0.42));
      parts.push({ g: outerRing, col: ringCol, met: 0.86, ao: 1.0 });

      // Sparkling sky-reflective recessed round portal marine glass pane
      const pane = new THREE.CylinderGeometry(radius * 0.88, radius * 0.88, 0.55, 14);
      pane.rotateX(Math.PI / 2);
      pane.scale(1.14, 0.94, 1);
      pane.translate(px, py, sz * (baseZ + 0.34));
      parts.push({ g: pane, col: glassCol, met: 0.95, ao: 1.0 });
    }
  }
}

/** Add cute sculpted rounded white-and-navy nautical mooring fenders hugging boat side hulls */
function addHullFenders(parts: PartSpec[], stations: HullStation[], xs: number[], bodyCol: RGB, capCol: RGB) {
  for (const fx of xs) {
    const st = sampleStation(stations, fx);
    const fy = st.sheerY - 5.2;
    const zOut = hullSideZ(st, fy) + 1.45;
    for (const sz of [-1, 1]) {
      const fBody = new THREE.CapsuleGeometry(1.38, 4.6, 4, 8);
      fBody.translate(fx, fy, sz * zOut);
      parts.push({ g: fBody, col: bodyCol, met: 0.34, ao: 0.98 });

      const topCap = new THREE.SphereGeometry(1.36, 7, 5);
      topCap.scale(1, 0.6, 1);
      topCap.translate(fx, fy + 3.0, sz * zOut);
      parts.push({ g: topCap, col: capCol, met: 0.3, ao: 0.95 });

      const rope = new THREE.CylinderGeometry(0.24, 0.24, 3.0, 5);
      rope.translate(fx, fy + 4.4, sz * (zOut - 0.35));
      parts.push({ g: rope, col: [0.9, 0.86, 0.74], met: 0.08, ao: 0.95 });
    }
  }
}

/** Add gleaming miniature red (port) & emerald-green (starboard) coastal boat navigation beacons */
function addNavLights(parts: PartSpec[], x: number, y: number, halfZ: number, chromeCol: RGB) {
  for (const sz of [-1, 1]) {
    const housing = new THREE.BoxGeometry(2.6, 1.8, 1.4);
    housing.translate(x, y, sz * halfZ);
    parts.push({ g: housing, col: chromeCol, met: 0.88, ao: 1.0 });
    const bulb = new THREE.SphereGeometry(0.95, 8, 6);
    bulb.scale(1.15, 0.85, 0.9);
    bulb.translate(x + 0.8, y, sz * (halfZ + 0.35));
    // Port = cozy ruby red, Starboard = jewel emerald green!
    parts.push({ g: bulb, col: sz < 0 ? [1.0, 0.24, 0.24] : [0.16, 0.98, 0.56], met: 0.2, ao: 1.0, part: 7 });
  }
}

/** Add cozy sculpted hanging brass harbor lantern with warm amber sunlit glow */
function addDeckLantern(parts: PartSpec[], x: number, yTop: number, z: number, brassCol: RGB) {
  const cord = new THREE.CylinderGeometry(0.22, 0.22, 2.2, 5);
  cord.translate(x, yTop - 1.1, z);
  parts.push({ g: cord, col: brassCol, met: 0.84, ao: 0.95 });

  const cap = new THREE.ConeGeometry(2.0, 1.6, 8);
  cap.translate(x, yTop - 2.4, z);
  parts.push({ g: cap, col: brassCol, met: 0.86, ao: 1.0 });

  const globe = new THREE.SphereGeometry(1.42, 8, 6);
  globe.scale(0.92, 1.22, 0.92);
  globe.translate(x, yTop - 4.2, z);
  parts.push({ g: globe, col: [1.0, 0.88, 0.42], met: 0.1, ao: 1.0, part: 7 });

  const base = new THREE.CylinderGeometry(1.3, 0.85, 0.8, 8);
  base.translate(x, yTop - 5.9, z);
  parts.push({ g: base, col: brassCol, met: 0.86, ao: 0.95 });
}

/** Add real curved 6-segment multi-panel waving yacht pennant anchored rigidly to its mast at mastX! */
function addMastPennant(
  parts: PartSpec[],
  mastX: number,
  yCenter: number,
  z: number,
  len: number,
  halfH: number,
  colMain: RGB,
  colStripe?: RGB,
) {
  const segs = 6;
  const tris: number[] = [];
  const stripeTris: number[] = [];
  for (let i = 0; i < segs; i++) {
    const u0 = i / segs;
    const u1 = (i + 1) / segs;
    const x0 = mastX - u0 * len;
    const x1 = mastX - u1 * len;
    // Classic crisp nautical swallowtail taper with subtle breezy loft
    const h0 = halfH * (1 - u0 * 0.72);
    const h1 = halfH * (1 - u1 * 0.72);
    const w0 = Math.sin(u0 * Math.PI * 1.4) * 0.85 * u0;
    const w1 = Math.sin(u1 * Math.PI * 1.4) * 0.85 * u1;
    const y0Top = yCenter + h0;
    const y0Bot = yCenter - h0;
    const y1Top = yCenter + h1;
    const y1Bot = yCenter - h1;

    if (colStripe) {
      const bandTop0 = yCenter + h0 * 0.28;
      const bandBot0 = yCenter - h0 * 0.28;
      const bandTop1 = yCenter + h1 * 0.28;
      const bandBot1 = yCenter - h1 * 0.28;
      // Top & bottom triangles (main color) + middle ribbon (accent stripe!)
      tris.push(x0, y0Top, z + w0, x1, y1Top, z + w1, x1, bandTop1, z + w1);
      tris.push(x0, y0Top, z + w0, x1, bandTop1, z + w1, x0, bandTop0, z + w0);
      tris.push(x0, bandBot0, z + w0, x1, bandBot1, z + w1, x1, y1Bot, z + w1);
      tris.push(x0, bandBot0, z + w0, x1, y1Bot, z + w1, x0, y0Bot, z + w0);
      stripeTris.push(x0, bandTop0, z + w0, x1, bandTop1, z + w1, x1, bandBot1, z + w1);
      stripeTris.push(x0, bandTop0, z + w0, x1, bandBot1, z + w1, x0, bandBot0, z + w0);
    } else {
      tris.push(x0, y0Top, z + w0, x1, y1Top, z + w1, x1, y1Bot, z + w1);
      tris.push(x0, y0Top, z + w0, x1, y1Bot, z + w1, x0, y0Bot, z + w0);
    }
  }
  const g = new THREE.BufferGeometry();
  g.setAttribute("position", new THREE.Float32BufferAttribute(tris, 3));
  g.computeVertexNormals();
  parts.push({ g, col: colMain, met: 0.14, ao: 1.0, part: 2, waveOrigin: mastX, waveLen: len, waveAxis: "x" });

  if (colStripe && stripeTris.length) {
    const gs = new THREE.BufferGeometry();
    gs.setAttribute("position", new THREE.Float32BufferAttribute(stripeTris, 3));
    gs.computeVertexNormals();
    parts.push({ g: gs, col: colStripe, met: 0.14, ao: 1.0, part: 2, waveOrigin: mastX, waveLen: len, waveAxis: "x" });
  }
}

function addShipWheel(parts: PartSpec[], x: number, y: number, z: number, radius: number, rimCol: RGB, spokeCol: RGB) {
  const wheelPitch = 0.52;
  const ring = new THREE.TorusGeometry(radius, radius * 0.15, 8, 18);
  ring.rotateY(Math.PI / 2);
  ring.rotateZ(wheelPitch);
  ring.translate(x, y, z);
  parts.push({ g: ring, col: rimCol, met: 0.72, ao: 1.0 });

  const hub = new THREE.CylinderGeometry(radius * 0.25, radius * 0.25, radius * 0.44, 10);
  hub.rotateZ(Math.PI / 2 + wheelPitch);
  hub.translate(x, y, z);
  parts.push({ g: hub, col: spokeCol, met: 0.88, ao: 1.0 });

  for (let i = 0; i < 4; i++) {
    const a = (i / 4) * Math.PI;
    const spoke = new THREE.CylinderGeometry(radius * 0.08, radius * 0.08, radius * 2.05, 5);
    spoke.rotateX(a);
    spoke.rotateZ(wheelPitch);
    spoke.translate(x, y, z);
    parts.push({ g: spoke, col: spokeCol, met: 0.86, ao: 1.0 });
  }
}

function addStripedLifebuoy(parts: PartSpec[], x: number, y: number, z: number, orangeCol: RGB, whiteCol: RGB) {
  for (let q = 0; q < 4; q++) {
    const arc = new THREE.TorusGeometry(3.9, 1.32, 8, 7, Math.PI * 0.49);
    arc.rotateZ(q * (Math.PI / 2));
    arc.translate(x, y, z);
    parts.push({ g: arc, col: q % 2 === 0 ? orangeCol : whiteCol, met: 0.3, ao: 1.0 });
  }
  // Crisp miniature navy grip-cord straps wrapping ring seams
  for (let q = 0; q < 4; q++) {
    const a = q * (Math.PI / 2);
    const band = new THREE.TorusGeometry(1.42, 0.26, 5, 8);
    band.rotateY(Math.PI / 2);
    band.rotateZ(a);
    band.translate(x + Math.cos(a) * 3.9, y + Math.sin(a) * 3.9, z);
    parts.push({ g: band, col: [0.96, 0.92, 0.78], met: 0.14, ao: 1.0 });
  }
}

/** Graceful genuinely curved 10-panel domed Riviera/tropical striped beach parasol with delicate scalloped overhang! */
function addStripedBeachParasol(
  parts: PartSpec[],
  x: number,
  yBase: number,
  poleH: number,
  r: number,
  colA: RGB,
  colB: RGB,
  poleCol: RGB,
  tiltZ = 0.08,
) {
  const topY = yBase + poleH;
  const topX = x - Math.sin(tiltZ) * poleH * 0.45;
  const pole = new THREE.CylinderGeometry(0.74, 0.92, poleH, 8);
  pole.rotateZ(tiltZ * 0.45);
  pole.translate((x + topX) * 0.5, yBase + poleH * 0.5, 0);
  parts.push({ g: pole, col: poleCol, met: 0.22, ao: 0.95 });

  // Gleaming brass collar slide hub under canopy
  const hub = new THREE.CylinderGeometry(1.4, 1.4, 1.6, 8);
  hub.translate(topX, topY - 2.6, 0);
  parts.push({ g: hub, col: [0.98, 0.80, 0.24], met: 0.84, ao: 1.0 });

  // Domed curved 3-ring convex ribs (true iconic storybook rounded beach umbrella silhouette!)
  const nSeg = 10;
  const domeH = 6.2;
  const rings = [0, 0.38, 0.74, 1.0];
  const rDrop = (u: number) => domeH * (1 - Math.pow(u, 1.62));
  const rSpread = (u: number) => r * Math.sin(u * Math.PI * 0.5);

  for (let i = 0; i < nSeg; i++) {
    const a0 = (i / nSeg) * Math.PI * 2;
    const a1 = ((i + 1) / nSeg) * Math.PI * 2;
    const aMid = (a0 + a1) * 0.5;
    const tris: number[] = [];
    for (let k = 0; k < rings.length - 1; k++) {
      const u0 = rings[k];
      const u1 = rings[k + 1];
      const rr0 = rSpread(u0);
      const rr1 = rSpread(u1);
      const y0 = topY + rDrop(u0) - 2.2;
      const y1 = topY + rDrop(u1) - 2.2;
      const sagMid = k === rings.length - 2 ? -0.45 : 0;
      const p00x = topX + Math.cos(a0) * rr0, p00z = Math.sin(a0) * rr0;
      const p01x = topX + Math.cos(a1) * rr0, p01z = Math.sin(a1) * rr0;
      const p10x = topX + Math.cos(a0) * rr1, p10z = Math.sin(a0) * rr1;
      const p11x = topX + Math.cos(a1) * rr1, p11z = Math.sin(a1) * rr1;
      // Pure upward/outward (+Y) domed normals for lush sunny shading on every parasol petal!
      if (k === 0) {
        tris.push(topX, y0, 0, p11x, y1, p11z, p10x, y1, p10z);
      } else {
        tris.push(p00x, y0, p00z, p11x, y1 + sagMid, p11z, p10x, y1 + sagMid, p10z);
        tris.push(p00x, y0, p00z, p01x, y0, p01z, p11x, y1 + sagMid, p11z);
      }
    }
    // Delicate hanging rounded valance drop rim around each parasol stripe bay
    const yRim = topY - 2.2;
    const dropY = yRim - 2.8;
    const r0x = topX + Math.cos(a0) * r, r0z = Math.sin(a0) * r;
    const r1x = topX + Math.cos(a1) * r, r1z = Math.sin(a1) * r;
    const rmx = topX + Math.cos(aMid) * (r * 0.99), rmz = Math.sin(aMid) * (r * 0.99);
    tris.push(r0x, yRim, r0z, rmx, dropY, rmz, r1x, yRim, r1z);
    tris.push(r0x, yRim, r0z, r0x, dropY + 1.0, r0z, rmx, dropY, rmz);
    tris.push(rmx, dropY, rmz, r1x, dropY + 1.0, r1z, r1x, yRim, r1z);

    const g = new THREE.BufferGeometry();
    g.setAttribute("position", new THREE.Float32BufferAttribute(tris, 3));
    g.computeVertexNormals();
    parts.push({ g, col: i % 2 === 0 ? colA : colB, met: 0.14, ao: 1.0 });
  }

  // Polished golden finial ball knob perched neatly on peak
  const finial = new THREE.SphereGeometry(1.45, 10, 8);
  finial.translate(topX, topY + domeH - 1.4, 0);
  parts.push({ g: finial, col: [1.0, 0.84, 0.26], met: 0.82, ao: 1.0 });
}

/** Graceful double-sided coastal bunting garland with root-anchored triangular flags flapping smoothly */
function addBuntingGarland(
  parts: PartSpec[],
  xStart: number,
  xEnd: number,
  yBase: number,
  zAbs: number,
  sag: number,
  colors: RGB[],
  bothSides = true,
) {
  const n = colors.length;
  const sides = bothSides ? [-1, 1] : [1];
  for (const sz of sides) {
    const z = sz * zAbs;
    const lineCurve = new THREE.CatmullRomCurve3([
      new THREE.Vector3(xStart, yBase, z),
      new THREE.Vector3((xStart + xEnd) * 0.5, yBase - sag, z),
      new THREE.Vector3(xEnd, yBase, z),
    ]);
    parts.push({ g: new THREE.TubeGeometry(lineCurve, 10, 0.24, 4, false), col: [0.98, 0.96, 0.90], met: 0.1, ao: 1.0 });

    const hw = Math.min(2.6, ((xEnd - xStart) / n) * 0.42);
    const fh = 4.2;
    for (let i = 0; i < n; i++) {
      const u = (i + 0.5) / n;
      const pt = lineCurve.getPoint(u);
      const triPts = new Float32Array([
        pt.x - hw, pt.y, z,
        pt.x + hw, pt.y, z,
        pt.x, pt.y - fh, z + sz * 0.25,
      ]);
      const g = new THREE.BufferGeometry();
      g.setAttribute("position", new THREE.BufferAttribute(triPts, 3));
      g.computeVertexNormals();
      parts.push({
        g,
        col: colors[i % colors.length],
        met: 0.12,
        ao: 1.0,
        part: 2,
        waveOrigin: pt.y,
        waveLen: fh,
        waveAxis: "y",
      });
    }
  }
}

/** Smooth swept double-bevel vaulted curved canopy deck roof (creates true luxury sculpted yacht / striped Bali gazebo!) */
function addVaultedCanopyRoof(
  parts: PartSpec[],
  xBack: number,
  xFront: number,
  yEave: number,
  halfZ: number,
  archH: number,
  thick: number,
  stripeCols: RGB[],
  trimCol: RGB,
  scallopCol: RGB | null,
  frontSweep = 0,
) {
  const nStripes = stripeCols.length;
  const arcSegs = 10;
  const roofY = (s: number) => yEave + Math.cos(s * Math.PI * 0.5) * archH; // s in [-1..1]
  const totalLen = xFront - xBack;

  for (let b = 0; b < nStripes; b++) {
    const xb0 = xBack + (totalLen * b) / nStripes;
    const xb1 = xBack + (totalLen * (b + 1)) / nStripes;
    const tris: number[] = [];
    const push = (
      ax: number, ay: number, az: number,
      bx: number, by: number, bz: number,
      cx: number, cy: number, cz: number,
    ) => { tris.push(ax, ay, az, bx, by, bz, cx, cy, cz); };

    for (let j = 0; j < arcSegs; j++) {
      const s0 = -1 + (2 * j) / arcSegs;
      const s1 = -1 + (2 * (j + 1)) / arcSegs;
      const z0 = s0 * halfZ;
      const z1 = s1 * halfZ;
      const sw0 = frontSweep * (1 - s0 * s0);
      const sw1 = frontSweep * (1 - s1 * s1);
      const fx0 = b === nStripes - 1 ? xb1 + sw0 : xb1;
      const fx1 = b === nStripes - 1 ? xb1 + sw1 : xb1;
      const bx0 = b === 0 ? xb0 - sw0 * 0.38 : xb0;
      const bx1 = b === 0 ? xb0 - sw1 * 0.38 : xb0;
      const y0T = roofY(s0) + thick * 0.5;
      const y1T = roofY(s1) + thick * 0.5;
      const y0B = roofY(s0) - thick * 0.5;
      const y1B = roofY(s1) - thick * 0.5;

      // Smooth outer sunlit arch crown (+Y outward normals -> velvety bright vaulted shading!)
      push(bx0, y0T, z0, fx1, y1T, z1, fx0, y0T, z0);
      push(bx0, y0T, z0, bx1, y1T, z1, fx1, y1T, z1);
      // Warm gently ocean-bounced underside roof ceiling (-Y downward normals)
      push(bx0, y0B, z0, fx0, y0B, z0, fx1, y1B, z1);
      push(bx0, y0B, z0, fx1, y1B, z1, bx1, y1B, z1);

      // Clean rounded bevel front & back end fascia caps
      if (b === nStripes - 1) {
        push(fx0, y0T, z0, fx0, y0B, z0, fx1, y1B, z1);
        push(fx0, y0T, z0, fx1, y1B, z1, fx1, y1T, z1);
      }
      if (b === 0) {
        push(bx0, y0T, z0, bx1, y1B, z1, bx0, y0B, z0);
        push(bx0, y0T, z0, bx1, y1T, z1, bx1, y1B, z1);
      }
    }
    const g = new THREE.BufferGeometry();
    g.setAttribute("position", new THREE.Float32BufferAttribute(tris, 3));
    g.computeVertexNormals();
    parts.push({ g, col: stripeCols[b], met: 0.24, ao: 0.99 });
  }

  // Crisp glossy rounded sculpted fascia tubes outlining port & starboard eaves
  for (const sz of [-1, 1]) {
    const eaveBar = new THREE.CylinderGeometry(thick * 0.62, thick * 0.62, totalLen + 1.4, 8);
    eaveBar.rotateZ(Math.PI / 2);
    eaveBar.translate((xBack + xFront) * 0.5, yEave, sz * (halfZ + 0.1));
    parts.push({ g: eaveBar, col: trimCol, met: 0.36, ao: 1.0 });

    // Charming curved downward half-circle luxury resort awning scallops fringing both side edges!
    if (scallopCol) {
      const nSc = 9;
      const scR = totalLen / (nSc * 2);
      for (let i = 0; i < nSc; i++) {
        const sx = xBack + (i + 0.5) * (totalLen / nSc);
        // theta 0..PI spans x = sin(th), z = cos(th); after rotateX(PI/2) + rotateZ(-PI/2) => pure downward semi-disc in XY plane!
        const tab = new THREE.CylinderGeometry(scR * 0.95, scR * 0.95, 0.72, 10, 1, false, 0, Math.PI);
        tab.rotateX(Math.PI / 2);
        tab.rotateZ(-Math.PI / 2);
        tab.scale(1.0, 0.76, 1.0);
        tab.translate(sx, yEave - 0.15, sz * (halfZ + 0.12));
        parts.push({ g: tab, col: i % 2 === 0 ? scallopCol : stripeCols[0], met: 0.16, ao: 0.99 });
      }
    }
  }
}

/** Add streamlined glossy sculpted modern twin/single marine outboard motor */
function addOutboardMotor(parts: PartSpec[], x: number, y: number, z: number, cowlCol: RGB, stripeCol: RGB, trimCol: RGB, scale = 1) {
  // Lower drive shaft leg curving cleanly down into sparkling ocean wake
  const leg = new THREE.CylinderGeometry(1.7 * scale, 1.25 * scale, 11.2 * scale, 8);
  leg.scale(1.45, 1, 0.72);
  leg.rotateZ(-0.08);
  leg.translate(x - 0.5 * scale, y - 5.2 * scale, z);
  parts.push({ g: leg, col: cowlCol, met: 0.56, ao: 0.92 });

  // Sleek aerodynamic egg-sculpted upper engine cowling hood
  const cowl = new THREE.SphereGeometry(4.4 * scale, 12, 9);
  cowl.scale(1.22, 1.06, 0.74);
  cowl.translate(x, y + 3.0 * scale, z);
  parts.push({ g: cowl, col: cowlCol, met: 0.62, ao: 1.0 });

  // Crisp sporty marine horizontal turquoise/gold stripe hugging snug outside the curved egg cowl
  const band = new THREE.TorusGeometry(3.72 * scale, 0.68 * scale, 7, 16);
  band.rotateX(Math.PI / 2);
  band.scale(1.48, 1.0, 0.94);
  band.translate(x, y + 3.1 * scale, z);
  parts.push({ g: band, col: stripeCol, met: 0.58, ao: 1.0 });

  // Cavitation fin plate + spinning bronze propeller bullet hub
  const torpedo = new THREE.CapsuleGeometry(1.15 * scale, 3.4 * scale, 4, 8);
  torpedo.rotateZ(Math.PI / 2);
  torpedo.translate(x - 2.0 * scale, y - 10.0 * scale, z);
  parts.push({ g: torpedo, col: trimCol, met: 0.82, ao: 0.94 });

  const skeg = new THREE.BoxGeometry(2.6 * scale, 3.0 * scale, 0.45 * scale);
  skeg.rotateZ(0.25);
  skeg.translate(x - 1.2 * scale, y - 11.6 * scale, z);
  parts.push({ g: skeg, col: cowlCol, met: 0.5, ao: 0.88 });
}

/**
 * STYLE 0: Luxury Tropical "Coral Explorer" Reef Sightseeing Yacht Cruiser
 * Sleek ivory fiberglass yacht, deep sapphire keel, bright aqua + coral sheer sweep,
 * outward-facing polished stainless portholes, flush panoramic tinted cabin glass &
 * swept triple-panel wrap windshield, gracefully arched hardtop canopy with turquoise/
 * ivory deck stripe, glowing amber courtesy soffit beacons, twin radar wings, domed radar,
 * plush white-and-aqua cushioned U-lounge with mahogany cocktail table & fruity drinks,
 * soft hanging hull fenders, sleek rear teak swim platform & ladder, sculpted twin
 * pearlescent marine outboards, waving attached gold/coral pennant & double-sided bunting,
 * plus 1 crisp captain + 4 cheerful snorkeling/photo tourists!
 */
function buildReefCruiserBoatGeometry(divSource: ReturnType<typeof buildDiverMesh>): THREE.BufferGeometry {
  const pearlWhite: RGB = [0.99, 0.99, 0.97];
  const navyKeel: RGB = [0.07, 0.23, 0.48];
  const deepNavy: RGB = [0.10, 0.22, 0.42];
  const turquoise: RGB = [0.05, 0.78, 0.84];
  const coral: RGB = [1.0, 0.41, 0.27];
  const sunGold: RGB = [1.0, 0.82, 0.22];
  const teak: RGB = [0.76, 0.50, 0.26];
  const richTeak: RGB = [0.56, 0.33, 0.15];
  const chrome: RGB = [0.90, 0.95, 0.99];
  const oceanGlass: RGB = [0.24, 0.74, 0.94];
  const darkGlass: RGB = [0.14, 0.36, 0.56];
  const cushionCream: RGB = [0.98, 0.96, 0.92];
  const charcoal: RGB = [0.15, 0.19, 0.27];

  const stations: HullStation[] = [
    { x: -65, halfW: 13.8, sheerY: 19.6, chineY: 5.4, keelY: -3.2 },
    { x: -50, halfW: 15.2, sheerY: 19.8, chineY: 5.0, keelY: -3.8 },
    { x: -30, halfW: 16.2, sheerY: 20.1, chineY: 4.8, keelY: -4.1 },
    { x: -6, halfW: 16.5, sheerY: 20.6, chineY: 4.8, keelY: -4.1 },
    { x: 18, halfW: 15.8, sheerY: 21.6, chineY: 5.2, keelY: -3.8 },
    { x: 38, halfW: 13.8, sheerY: 23.1, chineY: 6.4, keelY: -2.8 },
    { x: 56, halfW: 10.4, sheerY: 25.2, chineY: 8.6, keelY: -0.9 },
    { x: 72, halfW: 5.6, sheerY: 27.8, chineY: 12.6, keelY: 2.6 },
    { x: 84, halfW: 0.55, sheerY: 30.6, chineY: 19.2, keelY: 9.8 },
  ];

  // Sleek smooth hull + clean outward wave stripes + flush contoured teak cockpit & cambered pearl foredeck
  const parts = buildSculptedBoatHullParts(
    stations,
    pearlWhite,
    navyKeel,
    sunGold, // sparkling golden waterline boot-top!
    turquoise, // bold tropical reef-teal signature waist stripe
    coral, // crisp sporty coral pinstripe
    pearlWhite, // crisp white sculptural rounded yacht caprail
    teak,
    24, // sculpted cambered foredeck starts gracefully forward of the bridge console
    pearlWhite,
    17.4,
  );

  // Subtle inset dark-teak top inlay along cockpit coamings following the exact gunwale curve
  for (const sz of [-1, 1] as const) {
    const padPts = [-58, -36, -12, 12, 22].map((x) => {
      const st = sampleStation(stations, x);
      return new THREE.Vector3(x, st.sheerY + 1.55, sz * (st.halfW - 0.9));
    });
    parts.push({ g: new THREE.TubeGeometry(new THREE.CatmullRomCurve3(padPts), 14, 0.85, 6, false), col: turquoise, met: 0.22, ao: 0.99 });
  }

  // True outward-facing polished chrome-framed circular yacht portholes (flush on hull!)
  addHullPortholes(parts, stations, [-42, -20, 2, 22], 6.4, 2.45, chrome, oceanGlass);

  // Sleek tapered yacht-cabin glossy sky-reflective hull window flush along exact curved bow sides!
  for (const sz of [-1, 1] as const) {
    const segXs = [33, 41, 49, 57];
    const makeHullWindow = (halfH: number, outPush: number, col: RGB, met: number) => {
      const tris: number[] = [];
      for (let i = 0; i < segXs.length - 1; i++) {
        const x0 = segXs[i], x1 = segXs[i + 1];
        const taper0 = i === 0 ? 0.82 : 1.0 - (i / segXs.length) * 0.28;
        const taper1 = i === segXs.length - 2 ? 0.42 : 1.0 - ((i + 1) / segXs.length) * 0.28;
        const s0 = sampleStation(stations, x0), s1 = sampleStation(stations, x1);
        const y0 = s0.sheerY - 8.6, y1 = s1.sheerY - 8.4;
        const h0 = halfH * taper0, h1 = halfH * taper1;
        const z0t = sz * (hullSideZ(s0, y0 + h0) + outPush);
        const z0b = sz * (hullSideZ(s0, y0 - h0) + outPush);
        const z1t = sz * (hullSideZ(s1, y1 + h1) + outPush);
        const z1b = sz * (hullSideZ(s1, y1 - h1) + outPush);
        if (sz > 0) {
          tris.push(x0, y0 + h0, z0t, x0, y0 - h0, z0b, x1, y1 - h1, z1b);
          tris.push(x0, y0 + h0, z0t, x1, y1 - h1, z1b, x1, y1 + h1, z1t);
        } else {
          tris.push(x0, y0 + h0, z0t, x1, y1 - h1, z1b, x0, y0 - h0, z0b);
          tris.push(x0, y0 + h0, z0t, x1, y1 + h1, z1t, x1, y1 - h1, z1b);
        }
      }
      const g = new THREE.BufferGeometry();
      g.setAttribute("position", new THREE.Float32BufferAttribute(tris, 3));
      g.computeVertexNormals();
      parts.push({ g, col, met, ao: 1.0 });
    };
    makeHullWindow(2.35, 0.44, chrome, 0.88);
    makeHullWindow(1.72, 0.62, darkGlass, 0.96);
  }

  // Cute hanging teardrop snowy luxury docking fenders along side flanks
  addHullFenders(parts, stations, [-54, -8], pearlWhite, deepNavy);

  // Plush forward ivory sunbathing pad flush on cambered foredeck with soft coral head-roll bolster pillow!
  const sunPad = new THREE.BoxGeometry(21, 1.6, 14.4);
  sunPad.rotateZ(0.11);
  sunPad.translate(45, 26.2, 0);
  parts.push({ g: sunPad, col: cushionCream, met: 0.16, ao: 1.0 });
  const padTrim = new THREE.BoxGeometry(21.6, 0.68, 15.0);
  padTrim.rotateZ(0.11);
  padTrim.translate(45, 25.55, 0);
  parts.push({ g: padTrim, col: turquoise, met: 0.22, ao: 0.98 });
  const headRoll = new THREE.CylinderGeometry(1.32, 1.32, 13.4, 8);
  headRoll.rotateX(Math.PI / 2);
  headRoll.translate(36.2, 26.2, 0);
  parts.push({ g: headRoll, col: coral, met: 0.16, ao: 1.0 });

  // Sleek recessed tinted marine foredeck skylight hatch with silver frame
  const hatchRim = new THREE.CylinderGeometry(4.6, 4.8, 0.85, 12);
  hatchRim.rotateZ(0.16);
  hatchRim.translate(62, 27.6, 0);
  parts.push({ g: hatchRim, col: chrome, met: 0.88, ao: 1.0 });
  const hatchGlass = new THREE.CylinderGeometry(3.8, 3.8, 0.95, 12);
  hatchGlass.rotateZ(0.16);
  hatchGlass.translate(62, 27.72, 0);
  parts.push({ g: hatchGlass, col: oceanGlass, met: 0.96, ao: 1.0 });

  // Coiled ivory bow docking rope + gleaming sculpted stainless anchor sprite on chrome bow roller!
  const ropeCoil = new THREE.TorusGeometry(2.5, 0.65, 6, 12);
  ropeCoil.rotateX(Math.PI / 2);
  ropeCoil.translate(69, 28.8, -3.2);
  parts.push({ g: ropeCoil, col: [0.95, 0.88, 0.70], met: 0.08, ao: 0.96 });

  const bowChute = new THREE.BoxGeometry(9.2, 1.4, 2.8);
  bowChute.rotateZ(0.20);
  bowChute.translate(83.2, 30.8, 0);
  parts.push({ g: bowChute, col: chrome, met: 0.90, ao: 1.0 });
  // Stylized bow horn anchor flukes hanging sleekly underneath chute
  const anchorRing = new THREE.TorusGeometry(2.1, 0.52, 6, 10, Math.PI * 1.15);
  anchorRing.rotateZ(Math.PI * 0.9);
  anchorRing.translate(84.5, 27.2, 0);
  parts.push({ g: anchorRing, col: chrome, met: 0.90, ao: 1.0 });

  // Graceful wrapping twin-tier stainless yacht bow pulpit guardrails matching actual curved hull bow width
  for (const sz of [-1, 1] as const) {
    const railXs = [26, 44, 60, 74];
    const topPts: THREE.Vector3[] = [];
    const midPts: THREE.Vector3[] = [];
    for (const rx of railXs) {
      const st = sampleStation(stations, rx);
      const rz = sz * Math.max(2.0, st.halfW - 1.1);
      const baseY = st.sheerY + 0.8;
      const post = new THREE.CylinderGeometry(0.46, 0.54, 7.8, 6);
      post.translate(rx, baseY + 3.9, rz);
      parts.push({ g: post, col: chrome, met: 0.90, ao: 1.0 });
      topPts.push(new THREE.Vector3(rx, baseY + 7.8, rz));
      midPts.push(new THREE.Vector3(rx, baseY + 4.0, rz));
    }
    const noseSt = sampleStation(stations, 82);
    topPts.push(new THREE.Vector3(82, noseSt.sheerY + 7.8, sz * 1.1));
    midPts.push(new THREE.Vector3(82, noseSt.sheerY + 4.1, sz * 0.9));
    parts.push({ g: new THREE.TubeGeometry(new THREE.CatmullRomCurve3(topPts), 14, 0.58, 6, false), col: chrome, met: 0.90, ao: 1.0 });
    parts.push({ g: new THREE.TubeGeometry(new THREE.CatmullRomCurve3(midPts), 12, 0.30, 5, false), col: chrome, met: 0.88, ao: 0.98 });
  }
  // Curved forward chrome nose bridge bar linking port & starboard rails seamlessly
  const noseJoin = new THREE.CylinderGeometry(0.56, 0.56, 2.8, 6);
  noseJoin.rotateX(Math.PI / 2);
  noseJoin.translate(82, 37.9, 0);
  parts.push({ g: noseJoin, col: chrome, met: 0.90, ao: 1.0 });

  // Gleaming port (red) & starboard (green) running lights mounted sleekly by windshield flanks
  addNavLights(parts, 26, 27.6, 13.8, chrome);

  // Sculpted Modern Aero Helm Bridge Console + Backlit Cyan Chartplotter + Dual Throttle + Captain Wheel!
  const helmBase = new THREE.BoxGeometry(15.5, 13.0, 19.6);
  helmBase.translate(21.5, 24.4, 0);
  parts.push({ g: helmBase, col: pearlWhite, met: 0.42, ao: 0.98 });
  // Smooth front curved rounded dash brow facing bow
  const helmBrow = new THREE.CylinderGeometry(6.8, 7.6, 19.6, 10, 1, false, 0, Math.PI);
  helmBrow.rotateX(Math.PI / 2);
  helmBrow.scale(0.9, 1.0, 1.0);
  helmBrow.translate(25.2, 25.0, 0);
  parts.push({ g: helmBrow, col: pearlWhite, met: 0.42, ao: 0.99 });

  // Matte marine-navy recessed glare-free helm top dashboard + wooden pinstripe trim
  const dashCap = new THREE.BoxGeometry(13.2, 2.0, 18.8);
  dashCap.translate(20.5, 31.4, 0);
  parts.push({ g: dashCap, col: deepNavy, met: 0.34, ao: 0.96 });
  const helmAccent = new THREE.BoxGeometry(16.0, 1.8, 20.0);
  helmAccent.translate(21.2, 26.8, 0);
  parts.push({ g: helmAccent, col: turquoise, met: 0.36, ao: 1.0 });

  // Glowing illuminated cyan reef radar / sonar screen & brass helm compass
  const sonarFrame = new THREE.BoxGeometry(1.8, 4.8, 6.8);
  sonarFrame.rotateZ(0.42);
  sonarFrame.translate(18.0, 33.8, -3.6);
  parts.push({ g: sonarFrame, col: charcoal, met: 0.5, ao: 0.95 });
  const sonarScreen = new THREE.BoxGeometry(0.6, 3.8, 5.8);
  sonarScreen.rotateZ(0.42);
  sonarScreen.translate(17.2, 33.9, -3.6);
  parts.push({ g: sonarScreen, col: [0.28, 0.96, 1.0], met: 0.2, ao: 1.0, part: 7 });

  const helmCompass = new THREE.SphereGeometry(1.75, 10, 8);
  helmCompass.translate(21.5, 33.4, 3.4);
  parts.push({ g: helmCompass, col: sunGold, met: 0.88, ao: 1.0 });

  const thShaft = new THREE.CylinderGeometry(0.38, 0.38, 4.6, 6);
  thShaft.rotateZ(0.32);
  thShaft.translate(16.8, 33.6, 6.2);
  parts.push({ g: thShaft, col: chrome, met: 0.9, ao: 1.0 });
  const thKnob = new THREE.SphereGeometry(0.98, 8, 6);
  thKnob.translate(16.0, 35.8, 6.2);
  parts.push({ g: thKnob, col: coral, met: 0.45, ao: 1.0 });

  addShipWheel(parts, 13.8, 30.2, 0.8, 4.3, charcoal, chrome);

  // Sweeping Sleek Wrap-Around Reflective Sky-Blue Panoramic Windshield (5 smooth framed panels!)
  const wsMid = new THREE.BoxGeometry(1.4, 13.6, 15.8);
  wsMid.rotateZ(-0.46);
  wsMid.translate(24.8, 37.6, 0);
  parts.push({ g: wsMid, col: oceanGlass, met: 0.96, ao: 1.0 });
  for (const sz of [-1, 1] as const) {
    const wsSide = new THREE.BoxGeometry(16.0, 12.6, 1.3);
    wsSide.rotateZ(-0.18);
    wsSide.rotateY(-sz * 0.16);
    wsSide.translate(16.8, 37.8, sz * 10.6);
    parts.push({ g: wsSide, col: oceanGlass, met: 0.96, ao: 1.0 });

    // Brushed aluminum angled A-pillar front frame + subtle mid window divider
    const pillar = new THREE.CylinderGeometry(0.68, 0.78, 14.6, 8);
    pillar.rotateZ(-0.46);
    pillar.translate(24.7, 37.6, sz * 8.1);
    parts.push({ g: pillar, col: pearlWhite, met: 0.56, ao: 1.0 });

    // Top sleek side-frame rail kissing the curved hardtop brow
    const topSide = new THREE.CylinderGeometry(0.62, 0.62, 16.5, 6);
    topSide.rotateZ(Math.PI / 2);
    topSide.translate(15.2, 43.8, sz * 11.4);
    parts.push({ g: topSide, col: chrome, met: 0.9, ao: 1.0 });
  }
  const wsCap = new THREE.CylinderGeometry(0.82, 0.82, 19.0, 8);
  wsCap.rotateX(Math.PI / 2);
  wsCap.translate(21.6, 43.6, 0);
  parts.push({ g: wsCap, col: chrome, met: 0.90, ao: 1.0 });

  // Plush U-Shaped Resort Cockpit Lounge + Warm Coral Throw Pillows + Round Mahogany Cocktail Table & Tropical Drinks!
  const aftBench = new THREE.BoxGeometry(10.5, 4.0, 23.0);
  aftBench.translate(-48, 19.6, 0);
  parts.push({ g: aftBench, col: pearlWhite, met: 0.34, ao: 0.96 });
  const aftPad = new THREE.BoxGeometry(9.8, 1.6, 22.0);
  aftPad.translate(-48, 22.2, 0);
  parts.push({ g: aftPad, col: turquoise, met: 0.16, ao: 1.0 });
  const aftBack = new THREE.BoxGeometry(2.6, 5.4, 22.4);
  aftBack.translate(-52.4, 24.8, 0);
  parts.push({ g: aftBack, col: cushionCream, met: 0.16, ao: 0.99 });

  const midBench = new THREE.BoxGeometry(30, 4.0, 8.0);
  midBench.translate(-16, 19.6, -8.8);
  parts.push({ g: midBench, col: pearlWhite, met: 0.34, ao: 0.96 });
  const midPad = new THREE.BoxGeometry(29.2, 1.6, 7.4);
  midPad.translate(-16, 22.2, -8.8);
  parts.push({ g: midPad, col: turquoise, met: 0.16, ao: 1.0 });
  const midBack = new THREE.BoxGeometry(29.4, 5.6, 2.0);
  midBack.translate(-16, 25.0, -11.9);
  parts.push({ g: midBack, col: cushionCream, met: 0.16, ao: 0.99 });
  const midPipe = new THREE.CylinderGeometry(0.65, 0.65, 29.6, 6);
  midPipe.rotateZ(Math.PI / 2);
  midPipe.translate(-16, 27.7, -11.9);
  parts.push({ g: midPipe, col: coral, met: 0.22, ao: 1.0 });
  // Cheerful angled scatter cushion accent pillows
  for (const [px, pz, col] of [[-46, 7.6, coral], [-46, -7.6, sunGold], [-3, -9.8, coral]] as [number, number, RGB][]) {
    const pil = new THREE.BoxGeometry(2.4, 3.2, 3.6);
    pil.rotateZ(-0.22);
    pil.translate(px, 24.4, pz);
    parts.push({ g: pil, col, met: 0.14, ao: 1.0 });
  }

  // Polished varnished mahogany cocktail table + colorful resort mocktails with tiny straws
  const tblLeg = new THREE.CylinderGeometry(0.85, 1.3, 7.4, 8);
  tblLeg.translate(-14, 21.0, 2.4);
  parts.push({ g: tblLeg, col: chrome, met: 0.90, ao: 1.0 });
  const tblTop = new THREE.CylinderGeometry(5.8, 5.4, 1.2, 16);
  tblTop.translate(-14, 25.0, 2.4);
  parts.push({ g: tblTop, col: richTeak, met: 0.36, ao: 0.98 });
  const tblRim = new THREE.TorusGeometry(5.65, 0.34, 6, 16);
  tblRim.rotateX(Math.PI / 2);
  tblRim.translate(-14, 25.4, 2.4);
  parts.push({ g: tblRim, col: sunGold, met: 0.72, ao: 1.0 });
  for (const [cx, cz, cupCol] of [
    [-16.0, 1.0, coral],
    [-12.2, 3.4, sunGold],
    [-12.8, 0.2, [0.22, 0.90, 0.72]],
  ] as [number, number, RGB][]) {
    const cup = new THREE.CylinderGeometry(0.92, 0.64, 2.4, 8);
    cup.translate(cx, 26.7, cz);
    parts.push({ g: cup, col: cupCol, met: 0.32, ao: 1.0 });
    const straw = new THREE.CylinderGeometry(0.16, 0.16, 2.0, 4);
    straw.rotateZ(0.35);
    straw.translate(cx + 0.4, 28.0, cz);
    parts.push({ g: straw, col: pearlWhite, met: 0.1, ao: 1.0 });
  }

  // Sculpted Swept Luxury White Fiberglass Radar Arch Columns (signature sleek yacht sweep!)
  for (const sz of [-1, 1] as const) {
    // Graceful broad rear swept fiberglass arch leg (matches Sunseeker / Riva Riviera cruisers!)
    const aftWing = new THREE.CatmullRomCurve3([
      new THREE.Vector3(-48, 20.4, sz * 14.2),
      new THREE.Vector3(-51.5, 35.4, sz * 13.8),
      new THREE.Vector3(-43.5, 50.0, sz * 12.8),
    ]);
    parts.push({ g: new THREE.TubeGeometry(aftWing, 12, 1.72, 8, false), col: pearlWhite, met: 0.46, ao: 0.99 });

    // Subtle inlaid glossy aqua stripe accentuating rear arch curve
    const aftTrim = new THREE.CatmullRomCurve3([
      new THREE.Vector3(-46.5, 22.0, sz * 14.4),
      new THREE.Vector3(-48.4, 35.5, sz * 14.1),
      new THREE.Vector3(-41.0, 49.0, sz * 13.0),
    ]);
    parts.push({ g: new THREE.TubeGeometry(aftTrim, 10, 0.48, 6, false), col: turquoise, met: 0.45, ao: 1.0 });

    // Slim gleaming forward brushed stainless T-top pillar meeting top of sleek panoramic windshield cleanly!
    const fwdLeg = new THREE.CatmullRomCurve3([
      new THREE.Vector3(16, 21.5, sz * 13.4),
      new THREE.Vector3(16.5, 36.2, sz * 12.9),
      new THREE.Vector3(14.0, 49.8, sz * 12.2),
    ]);
    parts.push({ g: new THREE.TubeGeometry(fwdLeg, 10, 0.98, 7, false), col: chrome, met: 0.90, ao: 1.0 });

    // Graceful slim mid-span cross-stanchion adding realistic ocean-liner stability
    const midStrut = new THREE.CylinderGeometry(0.62, 0.72, 28.5, 6);
    midStrut.rotateZ(-0.10);
    midStrut.translate(-17, 35.2, sz * 13.2);
    parts.push({ g: midStrut, col: chrome, met: 0.90, ao: 1.0 });
  }

  // Smooth Aerodynamic Vaulted Luxury Yacht Hardtop Canopy with crisp swept visor + sunny turquoise/coral resort overhang stripes!
  addVaultedCanopyRoof(
    parts,
    -49,
    20,
    49.8,
    13.8,
    4.0, // graceful rounded convex crown topping out at y = 54.8
    2.1,
    [pearlWhite, turquoise, pearlWhite, pearlWhite, coral, pearlWhite, turquoise, pearlWhite],
    deepNavy,
    null,
    5.8, // sleek aerodynamic rounded curved forward sun-visor projection!
  );

  // Tinted glossy sunroof skylight skylight strip flush on vaulted hardtop peak
  const skyLight = new THREE.BoxGeometry(26, 0.85, 11.2);
  skyLight.translate(-12, 54.6, 0);
  parts.push({ g: skyLight, col: darkGlass, met: 0.96, ao: 1.0 });
  const skyFrame = new THREE.BoxGeometry(27.6, 0.65, 12.6);
  skyFrame.translate(-12, 54.35, 0);
  parts.push({ g: skyFrame, col: chrome, met: 0.88, ao: 1.0 });

  // Warm recessed golden deck courtesy mini-lamps under rear & front canopy corners!
  for (const lx of [-38, 12]) {
    for (const sz of [-1, 1]) {
      const lamp = new THREE.SphereGeometry(1.15, 8, 6);
      lamp.scale(1.1, 0.55, 1.1);
      lamp.translate(lx, 48.6, sz * 11.4);
      parts.push({ g: lamp, col: [1.0, 0.92, 0.56], met: 0.1, ao: 1.0, part: 7 });
    }
  }

  // Festive colorful double-sided tropical resort bunting tucked neatly under both side roof eaves!
  addBuntingGarland(parts, -44, 15, 48.8, 13.8, 3.0, [coral, sunGold, turquoise, pearlWhite, coral, sunGold, turquoise], true);

  // Sleek raised fiberglass arch radar pedestal, glossy white radar radome, twin swept whip VHF antennas, glowing stern mast beacon & attached waving golden yacht pennant!
  const radPed = new THREE.BoxGeometry(6.4, 2.2, 5.6);
  radPed.translate(9, 55.2, 0);
  parts.push({ g: radPed, col: pearlWhite, met: 0.45, ao: 1.0 });
  const radarDome = new THREE.SphereGeometry(4.2, 14, 9);
  radarDome.scale(1.12, 0.52, 1.12);
  radarDome.translate(9, 57.2, 0);
  parts.push({ g: radarDome, col: pearlWhite, met: 0.56, ao: 1.0 });
  const domeBand = new THREE.TorusGeometry(4.45, 0.36, 5, 16);
  domeBand.rotateX(Math.PI / 2);
  domeBand.translate(9, 57.1, 0);
  parts.push({ g: domeBand, col: turquoise, met: 0.5, ao: 1.0 });

  for (const sz of [-1, 1]) {
    const ant = new THREE.CylinderGeometry(0.18, 0.40, 17, 5);
    ant.rotateZ(0.24);
    ant.translate(12, 60.8, sz * 9.8);
    parts.push({ g: ant, col: chrome, met: 0.90, ao: 1.0 });
  }

  // Crisp angled silver ensign mast flying a genuine root-attached undulating gold & coral burgee flag!
  const mast = new THREE.CylinderGeometry(0.62, 0.92, 23, 8);
  mast.translate(-44, 62.0, 0);
  parts.push({ g: mast, col: chrome, met: 0.90, ao: 1.0 });
  const mastTopLight = new THREE.SphereGeometry(1.18, 8, 6);
  mastTopLight.translate(-44, 73.8, 0);
  parts.push({ g: mastTopLight, col: [1.0, 0.95, 0.62], met: 0.1, ao: 1.0, part: 7 });
  addMastPennant(parts, -44.2, 68.4, 0, 17.5, 4.4, sunGold, coral);

  // Classic quad-striped coastal rescue lifebuoys + sculpted curved rear teak swim deck + chrome folding ladder
  for (const sz of [-1, 1]) {
    addStripedLifebuoy(parts, -30, 20.6, sz * 15.8, coral, pearlWhite);
  }
  const swimDeck = new THREE.BoxGeometry(9.6, 2.0, 25.5);
  swimDeck.translate(-69.2, 10.6, 0);
  parts.push({ g: swimDeck, col: teak, met: 0.18, ao: 0.94 });
  const swimTrim = new THREE.BoxGeometry(10.2, 2.2, 26.2);
  swimTrim.translate(-69.1, 10.2, 0);
  parts.push({ g: swimTrim, col: pearlWhite, met: 0.42, ao: 0.96 });
  for (const rz of [10.4, 12.8]) {
    const rail = new THREE.CylinderGeometry(0.36, 0.36, 11.5, 6);
    rail.translate(-73.4, 8.6, rz);
    parts.push({ g: rail, col: chrome, met: 0.92, ao: 1.0 });
  }
  for (const ry of [4.8, 7.6, 10.4]) {
    const rung = new THREE.CylinderGeometry(0.32, 0.32, 2.6, 5);
    rung.rotateX(Math.PI / 2);
    rung.translate(-73.4, ry, 11.6);
    parts.push({ g: rung, col: chrome, met: 0.92, ao: 1.0 });
  }

  // Twin sleek modern sculpted pearlescent-and-navy marine outboard engines with bright turquoise branding stripes!
  for (const sz of [-1, 1]) {
    addOutboardMotor(parts, -68.0, 15.6, sz * 6.0, deepNavy, turquoise, chrome, 1.05);
  }

  // Cheerful Captain driving at wheel + 4 smiling richly styled vacationing tourists (guaranteed clean deck clearance!)
  const diverTourists: MergedRaw[] = [
    buildDiverTouristMerged(divSource, {
      x: 8.6,
      y: 18.0,
      z: 0.8,
      yaw: -Math.PI / 2,
      scale: 20.8,
      pose: "drive",
      shirt: [0.98, 0.99, 1.0],
      collar: deepNavy,
      shorts: [0.10, 0.22, 0.46],
      skin: [0.92, 0.69, 0.51],
      hair: [0.22, 0.13, 0.07],
      hat: "captain",
    }),
    buildDiverTouristMerged(divSource, {
      x: -10,
      y: 17.2,
      z: -7.8,
      yaw: Math.PI + 0.08,
      scale: 20.8,
      pose: "sit",
      shirt: [1.0, 0.36, 0.52],
      collar: [1.0, 0.88, 0.32],
      shorts: [0.96, 0.90, 0.72],
      skin: [0.96, 0.75, 0.58],
      hair: [0.30, 0.17, 0.08],
      hat: "straw",
      hatBand: coral,
      sunglasses: true,
    }),
    buildDiverTouristMerged(divSource, {
      x: -25,
      y: 17.2,
      z: -7.8,
      yaw: Math.PI - 0.16,
      scale: 20.4,
      pose: "sit",
      shirt: [0.14, 0.82, 0.92],
      collar: [1.0, 0.54, 0.22],
      shorts: [0.16, 0.28, 0.50],
      skin: [0.86, 0.60, 0.44],
      hair: [0.16, 0.10, 0.06],
      hat: "cap",
      hatCol: sunGold,
      camera: true,
    }),
    buildDiverTouristMerged(divSource, {
      x: -37,
      y: 17.8,
      z: 6.4,
      yaw: Math.PI - 0.22,
      scale: 20.8,
      pose: "stand",
      shirt: [1.0, 0.76, 0.18],
      collar: [0.16, 0.84, 0.62],
      shorts: [0.98, 0.97, 0.92],
      skin: [0.94, 0.71, 0.53],
      hair: [0.58, 0.35, 0.15],
      hat: "straw",
      hatBand: turquoise,
      sunglasses: true,
      waveArm: true,
    }),
    buildDiverTouristMerged(divSource, {
      x: 47,
      y: 26.9,
      z: 2.0,
      yaw: Math.PI * 0.74,
      scale: 20.2,
      pose: "stand",
      shirt: [0.20, 0.86, 0.62],
      collar: [1.0, 0.92, 0.42],
      shorts: [0.18, 0.34, 0.62],
      skin: [0.91, 0.65, 0.48],
      hair: [0.18, 0.10, 0.06],
      hat: "cap",
      hatCol: coral,
      camera: true,
    }),
  ];

  return mergeSurfaceParts(parts, diverTourists);
}

/**
 * STYLE 1: Classic "Paradise Lagoon" Bali/Tropical Island Outrigger Canopy Boat
 * Hand-crafted coastal sightseeing gem: rich cream-ivory & varnished mahogany flared hull,
 * shimmering azure-blue keel, gilded sun-gold band + coral tropical accent, ornate curved
 * carved upturned island bow stem topped with shining brass crown & woven garland, glossy
 * solid brass outward portholes, tapered torpedo outrigger (ama) with arched golden-lashed
 * laminated teak booms (kiato), showstopper vaulted barrel-arched blue-and-cream striped
 * scalloped canvas resort pavilion canopy, warm glowing hanging brass deck lanterns,
 * 10-panel sculpted curved coral-cream beach umbrella on foredeck, carved mahogany/brass
 * helm wheel + gleaming brass binnacle compass, chilled coastal cooler, cozy cushions,
 * fluttering attached dual-color swallowtail flag, cheerful captain & waving island guests!
 */
function buildIslandCanopyBoatGeometry(divSource: ReturnType<typeof buildDiverMesh>): THREE.BufferGeometry {
  const teak: RGB = [0.74, 0.46, 0.21];
  const mahogany: RGB = [0.48, 0.24, 0.10];
  const cream: RGB = [0.99, 0.96, 0.89];
  const sunnyGold: RGB = [1.0, 0.80, 0.20];
  const brass: RGB = [0.96, 0.78, 0.28];
  const azureBlue: RGB = [0.10, 0.48, 0.88];
  const seaTeal: RGB = [0.06, 0.72, 0.78];
  const coral: RGB = [0.99, 0.38, 0.30];
  const glass: RGB = [0.34, 0.84, 0.97];

  const stations: HullStation[] = [
    { x: -62, halfW: 11.6, sheerY: 19.6, chineY: 5.6, keelY: -3.0 },
    { x: -45, halfW: 14.2, sheerY: 19.4, chineY: 5.0, keelY: -3.6 },
    { x: -20, halfW: 15.6, sheerY: 19.6, chineY: 4.8, keelY: -3.9 },
    { x: 6, halfW: 15.5, sheerY: 20.1, chineY: 4.9, keelY: -3.8 },
    { x: 30, halfW: 13.8, sheerY: 21.6, chineY: 6.0, keelY: -3.0 },
    { x: 50, halfW: 10.2, sheerY: 24.4, chineY: 8.6, keelY: -1.0 },
    { x: 67, halfW: 5.0, sheerY: 28.4, chineY: 13.4, keelY: 3.6 },
    { x: 79, halfW: 0.5, sheerY: 32.8, chineY: 21.4, keelY: 11.4 },
  ];

  // Classic tropical warm hull with deep azure sea bottom, crisp coral boot-line, gold band, glossy teak sheer rail
  const parts = buildSculptedBoatHullParts(
    stations,
    cream,
    azureBlue,
    coral, // crisp festive resort waterline stripe!
    sunnyGold, // radiant sunlit broad accent ribbon
    seaTeal, // crisp island lagoon accent trim!
    mahogany, // curved hand-varnished solid mahogany full-hull caprail
    teak,
    40, // roomy sunlit wooden bow stage behind iconic curving prow
    teak,
    17.4,
  );

  // Ornate graceful curved upturned Balinese/tropical carved wooden swan-neck prow spire + gold collars + festive floral ring!
  const prowCurve = new THREE.CatmullRomCurve3([
    new THREE.Vector3(73, 30.8, 0),
    new THREE.Vector3(79, 34.4, 0),
    new THREE.Vector3(83.5, 40.4, 0),
    new THREE.Vector3(82.4, 44.6, 0),
  ]);
  parts.push({ g: new THREE.TubeGeometry(prowCurve, 12, 1.85, 8, false), col: mahogany, met: 0.30, ao: 0.98 });
  // Brass accent collars + glossy sun-gold carved lotus ball crest on prow!
  for (const [gx, gy, r] of [[80.4, 36.2, 2.25], [82.8, 39.8, 2.05]] as [number, number, number][]) {
    const band = new THREE.TorusGeometry(r, 0.52, 6, 12);
    band.rotateX(Math.PI / 2 - 0.5);
    band.translate(gx, gy, 0);
    parts.push({ g: band, col: brass, met: 0.84, ao: 1.0 });
  }
  const garland = new THREE.TorusGeometry(2.35, 0.72, 6, 10);
  garland.rotateX(Math.PI / 2 - 0.3);
  garland.translate(82.0, 38.2, 0);
  parts.push({ g: garland, col: coral, met: 0.16, ao: 1.0 });
  const prowOrb = new THREE.SphereGeometry(2.05, 10, 8);
  prowOrb.translate(82.4, 45.6, 0);
  parts.push({ g: prowOrb, col: sunnyGold, met: 0.86, ao: 1.0 });

  // True outward-facing polished solid-brass circular yacht portholes + soft woven rope dock fenders!
  addHullPortholes(parts, stations, [-36, -12, 12], 6.4, 2.4, brass, glass);
  addHullFenders(parts, stations, [-50, 28], [0.95, 0.89, 0.72], mahogany);

  // Coiled warm natural hemp anchor line & neat wooden bow cleat on sunny varnished prow deck
  const bowCoil = new THREE.TorusGeometry(2.7, 0.68, 6, 12);
  bowCoil.rotateX(Math.PI / 2);
  bowCoil.translate(58, 27.8, 2.4);
  parts.push({ g: bowCoil, col: [0.93, 0.85, 0.64], met: 0.08, ao: 0.96 });

  // Sleek lathe-sculpted double-pointed tapered Polynesian torpedo outrigger (ama) gliding smoothly on the sea!
  const amaProf = [
    new THREE.Vector2(0.05, -45),
    new THREE.Vector2(1.4, -39),
    new THREE.Vector2(2.85, -30),
    new THREE.Vector2(3.5, -14),
    new THREE.Vector2(3.6, 0),
    new THREE.Vector2(3.5, 14),
    new THREE.Vector2(2.8, 30),
    new THREE.Vector2(1.3, 40),
    new THREE.Vector2(0.05, 47),
  ];
  const amaGeo = new THREE.LatheGeometry(amaProf, 14);
  amaGeo.rotateZ(-Math.PI / 2);
  amaGeo.scale(1.0, 0.86, 1.0);
  amaGeo.translate(-2, 2.0, 26.2);
  parts.push({ g: amaGeo, col: cream, met: 0.36, ao: 0.96 });

  // Vibrant sculpted heritage royal-blue & golden sleeve bands smoothly contouring outrigger!
  for (const [ax, len, col] of [
    [-2, 20, azureBlue],
    [22, 6.2, sunnyGold],
    [-26, 6.2, sunnyGold],
    [34, 4.0, coral],
  ] as [number, number, RGB][]) {
    const sleeve = new THREE.CylinderGeometry(3.65, 3.65, len, 12);
    sleeve.rotateZ(Math.PI / 2);
    sleeve.scale(1.0, 0.87, 1.0);
    sleeve.translate(ax, 2.0, 26.2);
    parts.push({ g: sleeve, col, met: 0.42, ao: 1.0 });
  }

  // Twin seamlessly arched laminated teak bamboo outrigger cross-booms (kiato) with golden decorative rope lashings!
  for (const bx of [-26, 18]) {
    const kiatoCurve = new THREE.CatmullRomCurve3([
      new THREE.Vector3(bx, 18.6, 12.6),
      new THREE.Vector3(bx, 21.8, 18.8),
      new THREE.Vector3(bx, 15.6, 24.4),
      new THREE.Vector3(bx, 4.4, 26.2),
    ]);
    parts.push({ g: new THREE.TubeGeometry(kiatoCurve, 14, 1.12, 8, false), col: teak, met: 0.22, ao: 0.95 });

    // Tight ornamental double gold braided cord ring wrapping each joint cleanly!
    const lash = new THREE.TorusGeometry(1.55, 0.52, 6, 10);
    lash.rotateX(Math.PI / 2);
    lash.translate(bx, 5.2, 26.2);
    parts.push({ g: lash, col: sunnyGold, met: 0.24, ao: 1.0 });
    const innerLash = new THREE.TorusGeometry(1.42, 0.42, 6, 10);
    innerLash.translate(bx, 19.2, 13.8);
    parts.push({ g: innerLash, col: coral, met: 0.2, ao: 0.98 });
  }

  // Classic Carved Aft Varnished Mahogany Helm Stand + Gleaming Brass Compass Binnacle + Ship's Steering Wheel!
  const helmBox = new THREE.BoxGeometry(8.8, 11.4, 11.4);
  helmBox.translate(-35.5, 23.0, 0);
  parts.push({ g: helmBox, col: mahogany, met: 0.26, ao: 0.96 });
  const helmFrame = new THREE.BoxGeometry(9.6, 1.8, 12.4);
  helmFrame.translate(-35.5, 29.2, 0);
  parts.push({ g: helmFrame, col: teak, met: 0.30, ao: 0.99 });
  const compassHood = new THREE.SphereGeometry(2.1, 10, 8);
  compassHood.translate(-34.2, 31.4, -3.0);
  parts.push({ g: compassHood, col: brass, met: 0.88, ao: 1.0 });
  addShipWheel(parts, -40.2, 29.4, 0.8, 4.5, teak, brass);

  // Sleek classic sculpted rear resort outboard motor (white/azure finish complementing traditional trim!)
  addOutboardMotor(parts, -65.0, 15.2, 0, azureBlue, sunnyGold, brass, 1.0);

  // Plush slatted teak guest lounge benches + striped resort cushion pads + vintage cooler + tropical swim gear!
  for (const sz of [-1, 1]) {
    const bench = new THREE.BoxGeometry(36, 3.8, 7.2);
    bench.translate(-8, 19.4, sz * 8.6);
    parts.push({ g: bench, col: teak, met: 0.18, ao: 0.94 });
    const pad = new THREE.BoxGeometry(35, 1.5, 6.6);
    pad.translate(-8, 22.0, sz * 8.6);
    parts.push({ g: pad, col: sz < 0 ? cream : coral, met: 0.16, ao: 1.0 });
    const bolster = new THREE.CylinderGeometry(0.95, 0.95, 34, 6);
    bolster.rotateZ(Math.PI / 2);
    bolster.translate(-8, 24.4, sz * 11.6);
    parts.push({ g: bolster, col: sz < 0 ? seaTeal : sunnyGold, met: 0.16, ao: 0.99 });
  }
  // Cute vintage rounded coral & ivory island drink cooler + tiny braided lunch basket
  const cooler = new THREE.BoxGeometry(9.6, 5.4, 6.4);
  cooler.translate(15.5, 20.2, 2.2);
  parts.push({ g: cooler, col: coral, met: 0.36, ao: 0.99 });
  const coolerLid = new THREE.BoxGeometry(10.0, 1.4, 6.8);
  coolerLid.translate(15.5, 23.4, 2.2);
  parts.push({ g: coolerLid, col: cream, met: 0.38, ao: 1.0 });
  const coolerStripe = new THREE.BoxGeometry(10.1, 0.9, 6.6);
  coolerStripe.translate(15.5, 20.4, 2.2);
  parts.push({ g: coolerStripe, col: sunnyGold, met: 0.3, ao: 1.0 });

  // Classic turned varnished mahogany pavilion columns (6 neat posts!) with sculpted wooden corner arches & brass base boots
  for (const px of [-38, -11, 14]) {
    for (const sz of [-1, 1]) {
      const post = new THREE.CylinderGeometry(0.92, 1.12, 29.8, 8);
      post.translate(px, 34.4, sz * 12.2);
      parts.push({ g: post, col: mahogany, met: 0.24, ao: 0.96 });
      // Brass turned foot ferrule & capital ring
      const cap = new THREE.TorusGeometry(1.12, 0.34, 5, 10);
      cap.rotateX(Math.PI / 2);
      cap.translate(px, 47.4, sz * 12.2);
      parts.push({ g: cap, col: brass, met: 0.84, ao: 1.0 });
    }
  }
  // Curved graceful resort corner wood knee-brace scrolls along eaves
  for (const [px, dir] of [[-38, 1], [14, -1]] as [number, number][]) {
    for (const sz of [-1, 1]) {
      const brace = new THREE.CatmullRomCurve3([
        new THREE.Vector3(px, 42.4, sz * 12.2),
        new THREE.Vector3(px + dir * 2.2, 46.2, sz * 12.2),
        new THREE.Vector3(px + dir * 6.4, 48.2, sz * 12.2),
      ]);
      parts.push({ g: new THREE.TubeGeometry(brace, 7, 0.65, 6, false), col: teak, met: 0.22, ao: 0.95 });
    }
  }

  // Showstopper Arched Vaulted Barrel-Canopy Resort Sailcloth Roof (crisp wide alternating tropical azure & sunlit cream stripes + adorable scalloped gold/blue fringe border!)
  addVaultedCanopyRoof(
    parts,
    -42,
    18,
    48.8,
    14.6,
    7.2, // authentic buoyant cozy barrel arch lifting generously above all guests (crown = y 56.6!)
    1.5,
    [azureBlue, cream, azureBlue, cream, azureBlue, cream, azureBlue, cream, azureBlue],
    sunnyGold, // classic bright gilded wooden eave trim bar!
    sunnyGold, // charming sunlit scalloped resort canopy overhang valances on both flanks!
    2.2,
  );

  // Carved varnished mahogany canopy crown ridge pole + decorative twin brass ball finials
  const ridge = new THREE.CylinderGeometry(1.05, 1.05, 64.5, 8);
  ridge.rotateZ(Math.PI / 2);
  ridge.translate(-12, 56.8, 0);
  parts.push({ g: ridge, col: mahogany, met: 0.28, ao: 1.0 });
  for (const rx of [-44.6, 20.6]) {
    const ball = new THREE.SphereGeometry(1.65, 8, 6);
    ball.translate(rx, 56.9, 0);
    parts.push({ g: ball, col: brass, met: 0.86, ao: 1.0 });
  }

  // 4 Cozy Warm Hanging Brass Harbor Deck Lanterns glowing cheerily beneath all 4 corners of the pavilion!
  for (const lx of [-35.5, 11.5]) {
    for (const sz of [-1, 1]) {
      addDeckLantern(parts, lx, 48.2, sz * 13.6, brass);
    }
  }

  // Cheerful double-sided breezy triangular bunting slung playfully beneath the scalloped gazebo eaves
  addBuntingGarland(parts, -36, 12, 46.2, 14.8, 3.0, [coral, cream, sunnyGold, seaTeal, coral, sunnyGold], true);

  // Sculpted 10-Panel Real Curved Domed Coral-and-Cream Striped Riviera Beach Parasol shading the sunny bow deck with generous headroom!
  addStripedBeachParasol(parts, 35, 18.0, 29.5, 16.0, coral, cream, teak, 0.12);

  // Classic quad-striped lifesaver ring bolted neatly onto curved side midship (both flanks!)
  for (const sz of [-1, 1]) {
    addStripedLifebuoy(parts, 24, 18.6, sz * 14.8, coral, cream);
  }

  // Gleaming aft finial flagstaff hoisting a smooth fluttering coral-and-gold tropical paradise burgee!
  const mast = new THREE.CylinderGeometry(0.62, 0.88, 20, 7);
  mast.translate(-40, 62.5, 0);
  parts.push({ g: mast, col: brass, met: 0.86, ao: 1.0 });
  const finial = new THREE.SphereGeometry(1.1, 8, 6);
  finial.translate(-40, 72.8, 0);
  parts.push({ g: finial, col: sunnyGold, met: 0.88, ao: 1.0 });
  addMastPennant(parts, -40.2, 68.0, 0, 16.5, 4.3, coral, sunnyGold);

  // Captain steering at the mahogany/brass wheel + cheerful island tourists relaxing & waving!
  const diverTourists: MergedRaw[] = [
    buildDiverTouristMerged(divSource, {
      x: -44.8,
      y: 18.0,
      z: 0.8,
      yaw: -Math.PI / 2,
      scale: 20.4,
      pose: "drive",
      shirt: [0.98, 0.98, 0.99],
      collar: azureBlue,
      shorts: [0.14, 0.28, 0.50],
      skin: [0.85, 0.59, 0.41],
      hair: [0.16, 0.09, 0.05],
      hat: "captain",
    }),
    buildDiverTouristMerged(divSource, {
      x: -2,
      y: 17.2,
      z: -7.8,
      yaw: Math.PI + 0.12,
      scale: 20.8,
      pose: "sit",
      shirt: [1.0, 0.48, 0.22],
      collar: [1.0, 0.88, 0.30],
      shorts: [0.16, 0.34, 0.58],
      skin: [0.96, 0.75, 0.58],
      hair: [0.48, 0.28, 0.12],
      hat: "straw",
      hatBand: azureBlue,
      sunglasses: true,
    }),
    buildDiverTouristMerged(divSource, {
      x: -18,
      y: 17.2,
      z: -7.8,
      yaw: Math.PI - 0.18,
      scale: 20.4,
      pose: "sit",
      shirt: [0.98, 0.36, 0.64],
      collar: [0.36, 0.92, 1.0],
      shorts: [0.97, 0.97, 0.98],
      skin: [0.86, 0.61, 0.44],
      hair: [0.20, 0.12, 0.08],
      hat: "cap",
      hatCol: seaTeal,
      camera: true,
    }),
    buildDiverTouristMerged(divSource, {
      x: 27,
      y: 18.0,
      z: 3.4,
      yaw: Math.PI - 0.30,
      scale: 20.8,
      pose: "stand",
      shirt: [0.18, 0.86, 0.64],
      collar: [1.0, 0.92, 0.42],
      shorts: [0.96, 0.90, 0.72],
      skin: [0.91, 0.65, 0.47],
      hair: [0.18, 0.11, 0.06],
      hat: "straw",
      hatBand: coral,
      sunglasses: true,
      waveArm: true,
    }),
  ];

  return mergeSurfaceParts(parts, diverTourists);
}

/** Smooth organic foamy curved V-shaped bow wave ribbons + shimmering twin stern propeller wake! */
function buildWakeFoamGeometry(): THREE.BufferGeometry {
  const parts: PartSpec[] = [];
  const foam: RGB = [0.88, 0.99, 1.0];

  // Sweeping graceful symmetrical curved bow spray ribbons parting effortlessly past both flanks!
  for (const sz of [-1, 1]) {
    const segs = 10;
    const tris: number[] = [];
    const ptAt = (u: number): [number, number, number] => {
      // u=0 at crisp waterline bow stem (+72), u=1 sweeping smoothly aft past stern (-102)
      const x = 72 - u * 174;
      const spread = 2.6 + Math.pow(u, 0.68) * 23.0;
      const width = 1.6 + Math.sin(u * Math.PI) * 5.2 + u * 2.2;
      return [x, sz * spread, width];
    };
    for (let i = 0; i < segs; i++) {
      const u0 = i / segs;
      const u1 = (i + 1) / segs;
      const [x0, z0, w0] = ptAt(u0);
      const [x1, z1, w1] = ptAt(u1);
      const y = -0.35 + (1 - u0) * 0.45;
      tris.push(x0, y, z0 - w0 * 0.42, x1, y, z1 - w1 * 0.42, x1, y, z1 + w1 * 0.58);
      tris.push(x0, y, z0 - w0 * 0.42, x1, y, z1 + w1 * 0.58, x0, y, z0 + w0 * 0.58);
    }
    const g = new THREE.BufferGeometry();
    g.setAttribute("position", new THREE.Float32BufferAttribute(tris, 3));
    g.computeVertexNormals();
    parts.push({ g, col: foam, ao: 0.72, part: 4 });
  }

  // Sparkling feathered soft twin stern prop-wash foam spray trails fanning cleanly behind the engines
  for (let i = 0; i < 6; i++) {
    const t = i / 5;
    const puff = new THREE.SphereGeometry(5.0 - t * 1.4, 8, 6);
    puff.scale(2.1 + t * 0.6, 0.22, 0.9 + t * 0.35);
    const zSide = (i % 2 === 0 ? 1 : -1) * (4.2 + t * 5.5);
    puff.translate(-74 - t * 52, -0.3, zSide);
    parts.push({ g: puff, col: foam, ao: 0.88 - t * 0.62, part: 4 });
  }
  // Tiny crispy curly splash collar directly kissing the cutting prow!
  const bowSplash = new THREE.SphereGeometry(4.4, 8, 6);
  bowSplash.scale(1.65, 0.34, 1.15);
  bowSplash.translate(69, 0.4, 0);
  parts.push({ g: bowSplash, col: [0.96, 1.0, 1.0], ao: 0.9, part: 4 });

  return mergeSurfaceParts(parts);
}

// ------------------------------------------------------------------ Stylized 3D Tropical Harbor Island Backdrop
const HARBOR_PART = 9;

function addPalmTree(parts: PartSpec[], x: number, yBase: number, z: number, h: number, lean: number, rng: () => number) {
  const trunkCol: RGB = [0.72, 0.48, 0.26];
  const leafA: RGB = [0.22, 0.74, 0.38];
  const leafB: RGB = [0.16, 0.62, 0.32];
  // Gently curved segmented trunk
  const segs = 5;
  let px = x;
  let py = yBase;
  for (let i = 0; i < segs; i++) {
    const segH = h / segs;
    const r0 = 1.6 - (i / segs) * 0.7;
    const seg = new THREE.CylinderGeometry(r0 * 0.86, r0, segH * 1.1, 7);
    seg.rotateZ(-lean * (i + 1) * 0.6);
    seg.translate(px + lean * segH * 0.5 * (i + 1), py + segH * 0.5, z);
    parts.push({ g: seg, col: i % 2 === 0 ? trunkCol : [0.62, 0.40, 0.20], met: 0.12, ao: 0.95, part: HARBOR_PART });
    px += lean * segH * (i + 1) * 0.5;
    py += segH;
  }
  // Crown of 7 arched teardrop fronds
  const n = 7;
  for (let k = 0; k < n; k++) {
    const a = (k / n) * Math.PI * 2 + rng() * 0.4;
    const frond = new THREE.SphereGeometry(1, 7, 5);
    frond.scale(7.2, 1.5, 2.6);
    frond.translate(5.6, -1.2, 0);
    frond.rotateZ(-0.42 - rng() * 0.2);
    frond.rotateY(a);
    frond.translate(px, py + 0.6, z);
    parts.push({ g: frond, col: k % 2 === 0 ? leafA : leafB, met: 0.1, ao: 1.0, part: HARBOR_PART });
  }
  for (let c = 0; c < 3; c++) {
    const coco = new THREE.SphereGeometry(1.0, 6, 5);
    coco.translate(px + Math.cos(c * 2.1) * 1.3, py - 0.6, z + Math.sin(c * 2.1) * 1.3);
    parts.push({ g: coco, col: [0.42, 0.26, 0.12], met: 0.2, ao: 1.0, part: HARBOR_PART });
  }
}

function addHarborHouse(
  parts: PartSpec[],
  x: number,
  yBase: number,
  z: number,
  w: number,
  hgt: number,
  d: number,
  wallCol: RGB,
  roofCol: RGB,
  yaw = 0,
) {
  const body = new THREE.BoxGeometry(w, hgt, d);
  body.translate(0, hgt * 0.5, 0);
  const roof = new THREE.CylinderGeometry(0.001, Math.max(w, d) * 0.78, hgt * 0.62, 4);
  roof.rotateY(Math.PI / 4);
  roof.translate(0, hgt + hgt * 0.31, 0);
  const trim = new THREE.BoxGeometry(w + 1.4, 1.1, d + 1.4);
  trim.translate(0, hgt - 0.2, 0);
  const door = new THREE.BoxGeometry(w * 0.22, hgt * 0.42, 0.6);
  door.translate(-w * 0.18, hgt * 0.21, d * 0.5 + 0.2);
  const winL = new THREE.BoxGeometry(w * 0.2, hgt * 0.2, 0.6);
  winL.translate(w * 0.22, hgt * 0.58, d * 0.5 + 0.2);
  const winR = new THREE.BoxGeometry(w * 0.2, hgt * 0.2, 0.6);
  winR.translate(-w * 0.18, hgt * 0.66, d * 0.5 + 0.2);
  const chimney = new THREE.BoxGeometry(2.2, 5, 2.2);
  chimney.translate(w * 0.28, hgt + 3.0, -d * 0.18);
  for (const [g, col, met, part] of [
    [body, wallCol, 0.14, HARBOR_PART],
    [roof, roofCol, 0.18, HARBOR_PART],
    [trim, [0.99, 0.98, 0.95], 0.2, HARBOR_PART],
    [door, [0.46, 0.26, 0.12], 0.2, HARBOR_PART],
    [winL, [1.0, 0.92, 0.58], 0.1, 7],
    [winR, [1.0, 0.92, 0.58], 0.1, 7],
    [chimney, [0.86, 0.84, 0.80], 0.14, HARBOR_PART],
  ] as [THREE.BufferGeometry, RGB, number, number][]) {
    g.rotateY(yaw);
    g.translate(x, yBase, z);
    parts.push({ g, col, met, ao: 0.98, part });
  }
}

/** Bright storybook tropical harbor island: emerald hills, sandy cove, pastel harbor village, teak pier, palms & striped lighthouse */
export function buildHarborIslandGeometry(): THREE.BufferGeometry {
  const parts: PartSpec[] = [];
  const rng = mulberry32(4471);
  const sand: RGB = [0.97, 0.90, 0.66];
  const grassA: RGB = [0.30, 0.76, 0.40];
  const grassB: RGB = [0.20, 0.64, 0.34];
  const grassC: RGB = [0.16, 0.52, 0.30];
  const rock: RGB = [0.62, 0.64, 0.66];
  const teak: RGB = [0.72, 0.46, 0.22];
  const white: RGB = [0.99, 0.99, 0.97];
  const red: RGB = [0.95, 0.26, 0.24];

  // 1. Soft sandy island base plate resting right on the waterline (slight submerged skirt gets the wet tint!)
  const base = new THREE.SphereGeometry(1, 28, 10);
  base.scale(400, 16, 90);
  base.translate(0, -5, 0);
  parts.push({ g: base, col: sand, met: 0.08, ao: 0.98, part: HARBOR_PART });

  // 2. Lush rolling emerald hills (layered depth)
  const hills: [number, number, number, number, number, RGB][] = [
    [30, 180, 0.72, -70, 0, grassC],
    [-230, 96, 0.58, -30, 2, grassB],
    [-70, 128, 0.66, -22, 1, grassA],
    [110, 104, 0.56, -20, 3, grassA],
    [250, 78, 0.52, -14, 2, grassB],
    [-330, 60, 0.5, -10, 1, grassA],
  ];
  for (const [hx, hr, sy, hz, hy, col] of hills) {
    const hill = new THREE.SphereGeometry(1, 20, 12);
    hill.scale(hr, hr * sy, hr * 0.7);
    hill.translate(hx, hy, hz);
    parts.push({ g: hill, col, met: 0.06, ao: 0.97, part: HARBOR_PART });
  }

  // 3. Sunny beach strip + gentle foam line
  const beach = new THREE.BoxGeometry(640, 3, 34);
  beach.translate(-20, 1.2, 42);
  parts.push({ g: beach, col: sand, met: 0.08, ao: 1.0, part: HARBOR_PART });
  const foamLine = new THREE.BoxGeometry(660, 0.9, 5);
  foamLine.translate(-20, 0.9, 60);
  parts.push({ g: foamLine, col: [0.96, 1.0, 1.0], met: 0.0, ao: 1.0, part: HARBOR_PART });

  // 4. Grey breakwater boulders protecting the lighthouse point
  for (let i = 0; i < 9; i++) {
    const bx = 215 + i * 18 + rng() * 6;
    const r = 6 + rng() * 6;
    const b = new THREE.DodecahedronGeometry(r, 0);
    b.scale(1.2, 0.72, 1);
    b.translate(bx, r * 0.3, 52 + rng() * 10);
    parts.push({ g: b, col: rock, met: 0.1, ao: 0.92, part: HARBOR_PART });
  }

  // 5. Pastel harbor village climbing the hillside
  const houses: [number, number, number, number, number, number, RGB, RGB, number][] = [
    [-150, 6, 20, 24, 20, 20, [1.0, 0.64, 0.56], [0.80, 0.30, 0.22], 0.1],
    [-112, 9, 8, 20, 17, 18, [0.98, 0.96, 0.86], [0.12, 0.44, 0.66], -0.12],
    [-74, 7, 24, 26, 23, 20, [0.56, 0.86, 0.90], [0.84, 0.36, 0.26], 0.06],
    [-36, 12, 6, 20, 18, 18, [1.0, 0.88, 0.48], [0.22, 0.52, 0.42], -0.2],
    [4, 8, 22, 24, 21, 20, [0.86, 0.78, 0.96], [0.74, 0.30, 0.34], 0.14],
    [44, 14, 4, 18, 16, 16, [0.98, 0.98, 0.94], [0.16, 0.46, 0.72], -0.06],
    [82, 7, 24, 28, 24, 22, [1.0, 0.70, 0.46], [0.82, 0.34, 0.24], 0.08],
    [126, 10, 8, 20, 18, 18, [0.66, 0.90, 0.78], [0.76, 0.30, 0.30], -0.14],
  ];
  for (const [hx, hy, hz, w, h, d, wc, rc, yaw] of houses) addHarborHouse(parts, hx, hy, hz, w, h, d, wc, rc, yaw);

  // Harbor-master clock tower with teal roof & glowing clock face
  const tower = new THREE.BoxGeometry(16, 44, 16);
  tower.translate(-2, 22 + 10, -14);
  parts.push({ g: tower, col: [0.97, 0.94, 0.86], met: 0.14, ao: 0.98, part: HARBOR_PART });
  const towerRoof = new THREE.CylinderGeometry(0.001, 13, 16, 4);
  towerRoof.rotateY(Math.PI / 4);
  towerRoof.translate(-2, 10 + 44 + 8, -14);
  parts.push({ g: towerRoof, col: [0.12, 0.60, 0.62], met: 0.2, ao: 1.0, part: HARBOR_PART });
  const clock = new THREE.CylinderGeometry(4.6, 4.6, 0.8, 16);
  clock.rotateX(Math.PI / 2);
  clock.translate(-2, 10 + 36, -14 + 8.4);
  parts.push({ g: clock, col: [1.0, 0.96, 0.78], met: 0.1, ao: 1.0, part: 7 });

  // 6. Long teak fishing pier on pilings stretching out into the cove, with cute bollards & a moored dinghy
  const pierX0 = -210;
  const pierLen = 150;
  const pier = new THREE.BoxGeometry(pierLen, 2.4, 16);
  pier.translate(pierX0 - pierLen * 0.5 + 40, 7.2, 70);
  parts.push({ g: pier, col: teak, met: 0.14, ao: 0.96, part: HARBOR_PART });
  for (let i = 0; i <= 6; i++) {
    const px = pierX0 + 40 - i * (pierLen / 6);
    for (const sz of [-1, 1]) {
      const pile = new THREE.CylinderGeometry(1.4, 1.6, 11, 6);
      pile.translate(px, 1.6, 70 + sz * 6.5);
      parts.push({ g: pile, col: [0.42, 0.27, 0.14], met: 0.1, ao: 0.9, part: HARBOR_PART });
      const bollard = new THREE.CylinderGeometry(0.9, 1.0, 3.6, 6);
      bollard.translate(px, 10.2, 70 + sz * 6.0);
      parts.push({ g: bollard, col: [0.98, 0.98, 0.96], met: 0.2, ao: 1.0, part: HARBOR_PART });
    }
  }
  // Rail along back side of pier
  const rail = new THREE.CylinderGeometry(0.5, 0.5, pierLen, 5);
  rail.rotateZ(Math.PI / 2);
  rail.translate(pierX0 - pierLen * 0.5 + 40, 12.6, 63);
  parts.push({ g: rail, col: [0.98, 0.98, 0.96], met: 0.2, ao: 1.0, part: HARBOR_PART });
  // Little moored white sailing dinghy with a sunny sail
  const dinghy = new THREE.CapsuleGeometry(3.2, 14, 4, 8);
  dinghy.rotateZ(Math.PI / 2);
  dinghy.scale(1, 0.7, 1);
  dinghy.translate(-305, 1.4, 70);
  parts.push({ g: dinghy, col: white, met: 0.3, ao: 0.96, part: HARBOR_PART });
  const dStripe = new THREE.BoxGeometry(18, 1.2, 6.8);
  dStripe.translate(-305, 2.6, 70);
  parts.push({ g: dStripe, col: [0.08, 0.46, 0.84], met: 0.3, ao: 1.0, part: HARBOR_PART });
  const dMast = new THREE.CylinderGeometry(0.4, 0.5, 26, 5);
  dMast.translate(-304, 15, 70);
  parts.push({ g: dMast, col: teak, met: 0.1, ao: 1.0, part: HARBOR_PART });
  const sailTri = new Float32Array([-304, 27, 70.3, -304, 6, 70.3, -292, 8, 70.3]);
  const sailG = new THREE.BufferGeometry();
  sailG.setAttribute("position", new THREE.BufferAttribute(sailTri, 3));
  sailG.computeVertexNormals();
  parts.push({ g: sailG, col: [1.0, 0.84, 0.30], met: 0.1, ao: 1.0, part: HARBOR_PART });

  // 7. Palm grove along the beach and hills
  const palms: [number, number, number, number, number][] = [
    [-262, 2, 36, 30, 0.08],
    [-186, 4, 44, 26, -0.1],
    [-20, 3, 46, 32, 0.12],
    [36, 10, 30, 24, -0.06],
    [160, 4, 44, 28, 0.1],
    [196, 12, 20, 22, -0.12],
    [-320, 3, 20, 20, 0.14],
  ];
  for (const [px, py, pz, ph, lean] of palms) addPalmTree(parts, px, py, pz, ph, lean, rng);

  // Striped beach parasols & tiny deck chairs on the sandy cove
  for (const [ux, col] of [[-240, red], [-60, [0.10, 0.70, 0.76]], [110, [1.0, 0.78, 0.22]]] as [number, RGB][]) {
    const pole = new THREE.CylinderGeometry(0.35, 0.4, 9, 5);
    pole.translate(ux, 6.5, 50);
    parts.push({ g: pole, col: teak, met: 0.1, ao: 1.0, part: HARBOR_PART });
    const canopy = new THREE.ConeGeometry(6.2, 3.6, 10);
    canopy.translate(ux, 11.2, 50);
    parts.push({ g: canopy, col, met: 0.1, ao: 1.0, part: HARBOR_PART });
    const canopyStripe = new THREE.ConeGeometry(6.35, 3.5, 10, 1, true, 0, Math.PI * 0.6);
    canopyStripe.translate(ux, 11.15, 50);
    parts.push({ g: canopyStripe, col: white, met: 0.1, ao: 1.0, part: HARBOR_PART });
  }

  // 8. Iconic red-and-white striped lighthouse on the rocky point with glowing lantern room
  const lhX = 300;
  const lhRock = new THREE.DodecahedronGeometry(22, 1);
  lhRock.scale(1.3, 0.55, 1);
  lhRock.translate(lhX, 4, 10);
  parts.push({ g: lhRock, col: rock, met: 0.1, ao: 0.92, part: HARBOR_PART });
  const lhH = 78;
  const lhBody = new THREE.CylinderGeometry(6.2, 9.0, lhH, 14);
  lhBody.translate(lhX, 12 + lhH * 0.5, 10);
  parts.push({ g: lhBody, col: white, met: 0.2, ao: 1.0, part: HARBOR_PART });
  for (let b = 0; b < 3; b++) {
    const by = 12 + 14 + b * 22;
    const rr = 9.0 - ((by - 12) / lhH) * 2.8;
    const band = new THREE.CylinderGeometry(rr + 0.2, rr + 0.45, 9, 14);
    band.translate(lhX, by, 10);
    parts.push({ g: band, col: red, met: 0.2, ao: 1.0, part: HARBOR_PART });
  }
  const gallery = new THREE.CylinderGeometry(9.2, 9.2, 2.2, 14);
  gallery.translate(lhX, 12 + lhH + 1.1, 10);
  parts.push({ g: gallery, col: [0.16, 0.20, 0.28], met: 0.5, ao: 1.0, part: HARBOR_PART });
  const galleryRail = new THREE.TorusGeometry(8.6, 0.5, 5, 18);
  galleryRail.rotateX(Math.PI / 2);
  galleryRail.translate(lhX, 12 + lhH + 5.0, 10);
  parts.push({ g: galleryRail, col: [0.16, 0.20, 0.28], met: 0.5, ao: 1.0, part: HARBOR_PART });
  const lantern = new THREE.CylinderGeometry(5.4, 5.4, 10, 12);
  lantern.translate(lhX, 12 + lhH + 7.2, 10);
  parts.push({ g: lantern, col: [1.0, 0.90, 0.46], met: 0.1, ao: 1.0, part: 7 });
  const lhRoof = new THREE.ConeGeometry(7.4, 9, 12);
  lhRoof.translate(lhX, 12 + lhH + 16.6, 10);
  parts.push({ g: lhRoof, col: red, met: 0.24, ao: 1.0, part: HARBOR_PART });
  const lhBall = new THREE.SphereGeometry(1.5, 8, 6);
  lhBall.translate(lhX, 12 + lhH + 21.8, 10);
  parts.push({ g: lhBall, col: [0.98, 0.80, 0.26], met: 0.8, ao: 1.0, part: HARBOR_PART });

  // Red & white channel buoys bobbing by the cove entrance
  for (const [bx, col] of [[-370, red], [360, [0.16, 0.90, 0.56]]] as [number, RGB][]) {
    const buoy = new THREE.SphereGeometry(3.2, 10, 8);
    buoy.translate(bx, 2.4, 78);
    parts.push({ g: buoy, col, met: 0.3, ao: 1.0, part: HARBOR_PART });
    const buoyTop = new THREE.CylinderGeometry(0.6, 0.6, 5, 5);
    buoyTop.translate(bx, 6.8, 78);
    parts.push({ g: buoyTop, col: white, met: 0.3, ao: 1.0, part: HARBOR_PART });
  }

  return mergeSurfaceParts(parts);
}

/** Three plump storybook cumulus cloud variants built from overlapping soft spheres with flattened bellies */
function buildCloudGeometries(): THREE.BufferGeometry[] {
  const specs: { puffs: [number, number, number][] }[] = [
    { puffs: [[0, 0, 26], [-30, -6, 19], [28, -5, 20], [-52, -12, 13], [50, -11, 13], [-12, 10, 17], [14, 9, 16]] },
    { puffs: [[0, 0, 20], [-24, -5, 15], [22, -4, 15], [-40, -10, 10], [38, -9, 10], [4, 8, 12]] },
    { puffs: [[0, 0, 30], [-36, -7, 22], [34, -6, 23], [-64, -14, 15], [62, -13, 15], [-16, 12, 19], [18, 11, 18], [0, -4, 24]] },
  ];
  return specs.map((sp) => {
    const parts: PartSpec[] = [];
    const white: RGB = [1, 1, 1];
    let minX = 0;
    let maxX = 0;
    for (const [px, py, r] of sp.puffs) {
      const puff = new THREE.SphereGeometry(r, 10, 7);
      puff.scale(1.0, 0.86, 0.82);
      puff.translate(px, py, 0);
      parts.push({ g: puff, col: white, met: 0.0, ao: 1.0, part: 8 });
      minX = Math.min(minX, px - r);
      maxX = Math.max(maxX, px + r);
    }
    // Flattened soft cloud belly plate
    const belly = new THREE.SphereGeometry(1, 16, 8);
    belly.scale((maxX - minX) * 0.52, 7, 16);
    belly.translate((minX + maxX) * 0.5, -14, 0);
    parts.push({ g: belly, col: white, met: 0.0, ao: 0.92, part: 8 });
    return mergeSurfaceParts(parts);
  });
}

function buildSwimRippleGeometry(): THREE.BufferGeometry {
  const parts: PartSpec[] = [];
  const foam: RGB = [0.88, 0.99, 1.0];
  const outer = new THREE.TorusGeometry(9.0, 0.75, 5, 18);
  outer.rotateX(Math.PI / 2);
  outer.scale(1.35, 0.3, 0.7);
  parts.push({ g: outer, col: foam, ao: 0.72, part: 4 });

  const trail = new THREE.SphereGeometry(3.2, 8, 6);
  trail.scale(1.9, 0.22, 0.9);
  trail.translate(-10.5, 0, 0);
  parts.push({ g: trail, col: foam, ao: 0.56, part: 4 });
  return mergeSurfaceParts(parts);
}

// ------------------------------------------------------------------ Live Animated Manager
interface PelicanState {
  mode: "soar" | "skim" | "swim" | "perch";
  boatIdx: number;
  x: number;
  baseY: number;
  z: number;
  dir: number;
  speed: number;
  scale: number;
  ph: number;
  flapFreq: number;
  flapAmp: number;
  glideBias: number;
}

interface BoatState {
  style: 0 | 1;
  x: number;
  minX: number;
  maxX: number;
  z: number;
  dir: number;
  speed: number;
  scale: number;
  ph: number;
}

const _mat4 = new THREE.Matrix4();
const _pos = new THREE.Vector3();
const _scale = new THREE.Vector3();
const _quat = new THREE.Quaternion();
const _qTilt = new THREE.Quaternion();
const _qYaw = new THREE.Quaternion();
const _qRoll = new THREE.Quaternion();
const _axisX = new THREE.Vector3(1, 0, 0);
const _axisY = new THREE.Vector3(0, 1, 0);
const _axisZ = new THREE.Vector3(0, 0, 1);

/** Advance ping-pong trajectory monotonically so heading `dir` ALWAYS matches velocity dx/dt. */
function evalPatrol(
  x0: number,
  initDir: number,
  speed: number,
  t: number,
  minX: number,
  maxX: number,
): { x: number; dir: number } {
  const span = Math.max(1, maxX - minX);
  const xClamped = Math.max(minX, Math.min(maxX, x0));
  const u0 = initDir > 0 ? xClamped - minX : span * 2 - (xClamped - minX);
  const wrap = (((u0 + speed * t) % (span * 2)) + span * 2) % (span * 2);
  if (wrap <= span) return { x: minX + wrap, dir: 1 };
  return { x: maxX - (wrap - span), dir: -1 };
}

export class SurfaceProps3D {
  readonly group = new THREE.Group();
  private pelicansMesh: THREE.InstancedMesh;
  private swimRippleMesh: THREE.InstancedMesh;
  private boatsMeshes: [THREE.InstancedMesh, THREE.InstancedMesh];
  private wakeMesh: THREE.InstancedMesh;
  private pelicans: PelicanState[] = [];
  private swimIndices: number[] = [];
  private boats: BoatState[] = [];
  private boatPosScratch: { x: number; dir: number; bobY: number; scale: number; z: number }[] = [];
  private cloudMeshes: THREE.InstancedMesh[] = [];
  private clouds: { variant: number; baseX: number; y: number; z: number; scale: number; speed: number; ph: number }[] = [];
  private disposables: { dispose: () => void }[] = [];

  constructor() {
    this.group.name = "coastal-surface-props";
    const rng = mulberry32(202607);

    // 1. Spawn 6 Tourist Boats across separated Z lanes & non-overlapping patrol sectors so boats NEVER clip!
    const sectors: [number, number][] = [
      [180, WORLD_W * 0.31],
      [WORLD_W * 0.35, WORLD_W * 0.65],
      [WORLD_W * 0.69, WORLD_W - 180],
    ];
    for (let s = 0; s < 3; s++) {
      const [sMin, sMax] = sectors[s];
      const mid = (sMin + sMax) * 0.5;
      // Foreground Lane (z = 16): Luxury Reef Sightseeing Cruiser
      this.boats.push({
        style: 0,
        x: mid - 120,
        minX: sMin,
        maxX: sMax,
        z: 16,
        dir: s % 2 === 0 ? 1 : -1,
        speed: 10.5 + rng() * 4.5,
        scale: 1.88,
        ph: rng() * Math.PI * 2,
      });
      // Mid-Distance Lane (z = 56): Tropical Island Canopy Boat
      this.boats.push({
        style: 1,
        x: mid + 140,
        minX: sMin,
        maxX: sMax,
        z: 56,
        dir: s % 2 === 0 ? -1 : 1,
        speed: 9.5 + rng() * 4.0,
        scale: 1.92,
        ph: rng() * Math.PI * 2,
      });
    }

    // 2. Spawn 14 2x-scaled 3D Pelicans:
    //    - 2 perched proudly atop boat roofs
    //    - 6 swimming buoyantly right on the ocean surface (wings folded, dipping sculpted bill)
    //    - 6 soaring & wave-skimming gracefully in the coastal sky
    for (let i = 0; i < 14; i++) {
      if (i < 2) {
        this.pelicans.push({
          mode: "perch",
          boatIdx: i * 2, // Boat 0 (Cruiser) and Boat 2 (Cruiser)
          x: 0,
          baseY: 50,
          z: 0,
          dir: i % 2 === 0 ? 1 : -1,
          speed: 0,
          scale: 1.56,
          ph: rng() * Math.PI * 2,
          flapFreq: 2.2,
          flapAmp: -1.0,
          glideBias: -0.35,
        });
      } else if (i < 8) {
        const idx = i - 2;
        this.swimIndices.push(i);
        this.pelicans.push({
          mode: "swim",
          boatIdx: -1,
          x: ((idx + 0.45) / 6) * WORLD_W + (rng() - 0.5) * 180,
          baseY: 2.6,
          z: 32 + rng() * 14,
          dir: i % 2 === 0 ? 1 : -1,
          speed: 11 + rng() * 6.5,
          scale: (0.86 + rng() * 0.16) * 2.0,
          ph: rng() * Math.PI * 2,
          flapFreq: 2.4,
          flapAmp: -1.0,
          glideBias: 0,
        });
      } else {
        const idx = i - 8;
        const isSkim = idx % 2 === 1;
        this.pelicans.push({
          mode: isSkim ? "skim" : "soar",
          boatIdx: -1,
          x: ((idx + 0.5) / 6) * WORLD_W + (rng() - 0.5) * 200,
          baseY: isSkim ? 48 + rng() * 22 : 96 + rng() * 76,
          z: 22 + rng() * 24,
          dir: i % 2 === 0 ? 1 : -1,
          speed: (isSkim ? 38 : 28) + rng() * 14,
          scale: (isSkim ? 0.88 : 0.8) * 2.0 + rng() * 0.35,
          ph: rng() * Math.PI * 2,
          flapFreq: 5.6 + rng() * 2.0,
          flapAmp: 0.62 + rng() * 0.18,
          glideBias: 0.12,
        });
      }
    }

    const solidMat = surfaceDaylightMaterial(false);
    const wakeMat = surfaceDaylightMaterial(true);
    this.disposables.push(solidMat, wakeMat);

    // ---- Instanced Tourist Boats (with PENYELAM diver-shaped captain + seated/standing tourists!)
    const divSource = buildDiverMesh();
    const cruiserGeo = buildReefCruiserBoatGeometry(divSource);
    const islandGeo = buildIslandCanopyBoatGeometry(divSource);
    const wakeGeo = buildWakeFoamGeometry();
    const swimRippleGeo = buildSwimRippleGeometry();
    this.disposables.push(cruiserGeo, islandGeo, wakeGeo, swimRippleGeo);

    const makeBoatInstanced = (geo: THREE.BufferGeometry, subset: BoatState[]): THREE.InstancedMesh => {
      const n = subset.length;
      const ctrl = new Float32Array(n * 4);
      subset.forEach((b, idx) => ctrl.set([b.ph, b.speed, 1, 0], idx * 4));
      geo.setAttribute("iCtrl", new THREE.InstancedBufferAttribute(ctrl, 4));
      const mesh = new THREE.InstancedMesh(geo, solidMat, n);
      mesh.frustumCulled = false;
      mesh.renderOrder = 22;
      this.group.add(mesh);
      return mesh;
    };

    const style0Boats = this.boats.filter((b) => b.style === 0);
    const style1Boats = this.boats.filter((b) => b.style === 1);
    this.boatsMeshes = [
      makeBoatInstanced(cruiserGeo, style0Boats),
      makeBoatInstanced(islandGeo, style1Boats),
    ];

    // ---- Instanced Boat Wake Foam
    const wakeCtrl = new Float32Array(this.boats.length * 4);
    this.boats.forEach((b, i) => wakeCtrl.set([b.ph, b.speed, 1, 0], i * 4));
    wakeGeo.setAttribute("iCtrl", new THREE.InstancedBufferAttribute(wakeCtrl, 4));
    this.wakeMesh = new THREE.InstancedMesh(wakeGeo, wakeMat, this.boats.length);
    this.wakeMesh.frustumCulled = false;
    this.wakeMesh.renderOrder = 21;
    // Boat wake foam disabled: the flat foam discs read as dark grey "stones" on the bright surface band
    this.wakeMesh.visible = false;

    // ---- Instanced Water Ripples beneath Swimming Pelicans
    const ripCtrl = new Float32Array(this.swimIndices.length * 4);
    this.swimIndices.forEach((pi, i) => ripCtrl.set([this.pelicans[pi].ph, 1, 1, 0], i * 4));
    swimRippleGeo.setAttribute("iCtrl", new THREE.InstancedBufferAttribute(ripCtrl, 4));
    this.swimRippleMesh = new THREE.InstancedMesh(swimRippleGeo, wakeMat, this.swimIndices.length);
    this.swimRippleMesh.frustumCulled = false;
    this.swimRippleMesh.renderOrder = 21;
    this.group.add(this.swimRippleMesh);

    // ---- Stylized puffy 3D cumulus clouds drifting slowly across the coastal sky
    const cloudGeos = buildCloudGeometries();
    for (let i = 0; i < 7; i++) {
      this.clouds.push({
        variant: i % 3,
        baseX: i * 430 + rng() * 160,
        y: 118 + (i % 4) * 34 + rng() * 22,
        z: -70 - (i % 3) * 12,
        scale: 0.62 + rng() * 0.5 + (i % 4 === 0 ? 0.35 : 0),
        speed: 3.2 + rng() * 3.2,
        ph: rng() * Math.PI * 2,
      });
    }
    cloudGeos.forEach((geo, v) => {
      const subset = this.clouds.filter((c) => c.variant === v);
      const cCtrl = new Float32Array(subset.length * 4);
      subset.forEach((c, k) => cCtrl.set([c.ph, 1, 1, 0], k * 4));
      geo.setAttribute("iCtrl", new THREE.InstancedBufferAttribute(cCtrl, 4));
      const mesh = new THREE.InstancedMesh(geo, solidMat, subset.length);
      mesh.frustumCulled = false;
      mesh.renderOrder = 18;
      this.group.add(mesh);
      this.cloudMeshes.push(mesh);
      this.disposables.push(geo);
    });

    // ---- Instanced 3D Pelicans
    const pelicanGeo = buildPelicanGeometry();
    this.disposables.push(pelicanGeo);
    const pelCtrl = new Float32Array(this.pelicans.length * 4);
    this.pelicans.forEach((p, i) => pelCtrl.set([p.ph, p.flapAmp, p.flapFreq, p.glideBias], i * 4));
    pelicanGeo.setAttribute("iCtrl", new THREE.InstancedBufferAttribute(pelCtrl, 4));
    this.pelicansMesh = new THREE.InstancedMesh(pelicanGeo, solidMat, this.pelicans.length);
    this.pelicansMesh.frustumCulled = false;
    this.pelicansMesh.renderOrder = 24;
    this.group.add(this.pelicansMesh);

    // Preallocate zero-GC scratch records so per-frame updates allocate zero heap objects
    this.boatPosScratch = this.boats.map((b) => ({ x: b.x, dir: b.dir, bobY: 0, scale: b.scale, z: b.z }));
    this.update(0, -120);
  }

  update(t: number, camTop: number, camLeft = -1e9, vw = 2e9) {
    const visible = camTop < 260;
    this.group.visible = visible;
    if (!visible) return;

    const minX = 180;
    const maxX = WORLD_W - 180;
    const viewMin = camLeft - 280;
    const viewMax = camLeft + vw + 280;

    let i0 = 0;
    let i1 = 0;
    let anyBoat0 = false;
    let anyBoat1 = false;
    const boatStates = this.boatPosScratch;

    for (let i = 0; i < this.boats.length; i++) {
      const b = this.boats[i];
      const pat = evalPatrol(b.x, b.dir, b.speed, t, b.minX, b.maxX);
      const bx = pat.x;
      const dir = pat.dir;
      const bobY = Math.sin(t * 1.42 + b.ph) * 2.2 + Math.cos(t * 2.25 + b.ph) * 0.55;
      const bs = boatStates[i];
      bs.x = bx;
      bs.dir = dir;
      bs.bobY = bobY;

      const inX = bx >= viewMin && bx <= viewMax;
      if (b.style === 0) {
        if (inX) anyBoat0 = true;
      } else if (inX) {
        anyBoat1 = true;
      }

      const waveRoll = Math.sin(t * 1.18 + b.ph) * 0.026;
      const pitchLean = Math.cos(t * 1.42 + b.ph) * 0.012;
      _pos.set(bx, bobY, b.z);
      _scale.setScalar(b.scale);
      _qYaw.setFromAxisAngle(_axisY, dir > 0 ? -0.18 : Math.PI + 0.18);
      _qRoll.setFromAxisAngle(_axisZ, waveRoll + pitchLean);
      _qTilt.setFromAxisAngle(_axisX, 0.22);
      _quat.multiplyQuaternions(_qTilt, _qRoll).multiply(_qYaw);

      _mat4.compose(_pos, _quat, _scale);
      if (b.style === 0) this.boatsMeshes[0].setMatrixAt(i0++, _mat4);
      else this.boatsMeshes[1].setMatrixAt(i1++, _mat4);

      _pos.set(bx, 0.45 + bobY * 0.18, b.z + 1.5);
      _qRoll.setFromAxisAngle(_axisZ, waveRoll * 0.18);
      _quat.multiplyQuaternions(_qTilt, _qRoll).multiply(_qYaw);
      _mat4.compose(_pos, _quat, _scale);
      this.wakeMesh.setMatrixAt(i, _mat4);
    }
    this.boatsMeshes[0].visible = anyBoat0;
    this.boatsMeshes[1].visible = anyBoat1;
    if (anyBoat0) this.boatsMeshes[0].instanceMatrix.needsUpdate = true;
    if (anyBoat1) this.boatsMeshes[1].instanceMatrix.needsUpdate = true;

    // ---- Distant harbor islands: slow 0.55 parallax so they feel far away, tiled seamlessly across the whole ocean
    const hasView = camLeft > -1e8;
    const cl = hasView ? camLeft : 0;
    const cvw = hasView ? Math.min(vw, 4000) : 1600;

    // ---- Puffy clouds: gentle 0.72 parallax + slow breezy drift + soft bob, wrapped across the visible sky band
    const CP = 2500;
    const cIdx = [0, 0, 0];
    for (let i = 0; i < this.clouds.length; i++) {
      const c = this.clouds[i];
      const winStart = cl - 320;
      const raw = c.baseX + t * c.speed + cl * 0.72 - winStart;
      const cx = winStart + (((raw % (CP + cvw)) + (CP + cvw)) % (CP + cvw));
      _pos.set(cx, c.y + Math.sin(t * 0.35 + c.ph) * 3.5, c.z);
      _scale.setScalar(c.scale);
      _qYaw.setFromAxisAngle(_axisY, 0);
      _qTilt.setFromAxisAngle(_axisX, 0);
      _quat.multiplyQuaternions(_qTilt, _qYaw);
      _mat4.compose(_pos, _quat, _scale);
      this.cloudMeshes[c.variant].setMatrixAt(cIdx[c.variant]++, _mat4);
    }
    for (const m of this.cloudMeshes) m.instanceMatrix.needsUpdate = true;

    let ripIdx = 0;
    for (let i = 0; i < this.pelicans.length; i++) {
      const p = this.pelicans[i];
      let px: number;
      let py: number;
      let pz: number;
      let dir: number;
      let bank = 0;

      if (p.mode === "perch" && p.boatIdx >= 0 && p.boatIdx < boatStates.length) {
        const bs = boatStates[p.boatIdx];
        const bStyle = this.boats[p.boatIdx].style;
        // Perched squarely atop our sleek vaulted luxury hardtop (behind skylight) / golden-trimmed Bali canopy ridge!
        const localX = bStyle === 0 ? -29 : -12;
        const roofY = bStyle === 0 ? 54.6 : 57.2;
        px = bs.x + bs.dir * localX * bs.scale;
        py = roofY * bs.scale + 4.4 + bs.bobY;
        pz = bs.z + (bStyle === 0 ? 2 : 0);
        dir = bs.dir;
        bank = Math.sin(t * 1.18 + this.boats[p.boatIdx].ph) * 0.032;
      } else if (p.mode === "swim") {
        const pat = evalPatrol(p.x, p.dir, p.speed, t, minX, maxX);
        px = pat.x;
        dir = pat.dir;
        const waveBob = Math.sin(t * 1.8 + p.ph) * 1.6;
        py = p.baseY + waveBob;
        pz = p.z;
        bank = Math.sin(t * 1.5 + p.ph) * 0.04;

        _pos.set(px, 0.55 + waveBob * 0.2, pz);
        _scale.setScalar(p.scale);
        _qYaw.setFromAxisAngle(_axisY, dir > 0 ? -0.18 : Math.PI + 0.18);
        _qRoll.setFromAxisAngle(_axisZ, 0);
        _qTilt.setFromAxisAngle(_axisX, 0.22);
        _quat.multiplyQuaternions(_qTilt, _qRoll).multiply(_qYaw);
        _mat4.compose(_pos, _quat, _scale);
        this.swimRippleMesh.setMatrixAt(ripIdx++, _mat4);
      } else {
        const pat = evalPatrol(p.x, p.dir, p.speed, t, minX, maxX);
        px = pat.x;
        dir = pat.dir;
        py = p.baseY + Math.sin(t * 1.3 + p.ph) * (p.mode === "skim" ? 7.5 : 14.5);
        pz = p.z + Math.cos(t * 0.7 + p.ph) * 8;
        bank = Math.cos(t * 1.3 + p.ph) * 0.14;
      }

      _pos.set(px, py, pz);
      _scale.setScalar(p.scale);
      _qYaw.setFromAxisAngle(_axisY, dir > 0 ? -0.34 : Math.PI + 0.34);
      _qRoll.setFromAxisAngle(_axisZ, bank);
      _qTilt.setFromAxisAngle(_axisX, 0.2);
      _quat.multiplyQuaternions(_qTilt, _qRoll).multiply(_qYaw);
      _mat4.compose(_pos, _quat, _scale);
      this.pelicansMesh.setMatrixAt(i, _mat4);
    }
    this.pelicansMesh.instanceMatrix.needsUpdate = true;
    this.swimRippleMesh.instanceMatrix.needsUpdate = true;
  }

  dispose() {
    for (const d of this.disposables) d.dispose();
  }
}
