// ============================================================================
// DISTANT COASTAL HARBOR BACKDROP, MOVING CUMULUS CLOUDS & SKY BALLOON PICKUPS
// Renders above SURFACE_Y behind foreground 3D tourist boats & pelicans so
// distant cranes, boathouses, wooden piers, fish trucks, and layered cumulus
// clouds drift smoothly across the horizon, plus glossy airborne balloons
// dangling pocket stopwatches & bonus skill charms for surface-leaping fish!
// ============================================================================

export type BalloonKind = "stopwatch" | "turbo" | "vortex" | "shield" | "pearl";

export interface SkyBalloon {
  x: number;
  y: number;
  baseY: number;
  vx: number;
  kind: BalloonKind;
  t: number;
  ph: number;
}

const HARBOR_SPAN = 2400;
const HARBOR_H = 220;
const SUPERSAMPLE = 2;

let harborCanvas: HTMLCanvasElement | null = null;
let cloudStamps: HTMLCanvasElement[] | null = null;

function createCloudStamps(): HTMLCanvasElement[] {
  if (cloudStamps) return cloudStamps;
  const specs = [
    {
      w: 360,
      h: 170,
      puffs: [
        { x: 185, y: 74, r: 58 },
        { x: 126, y: 90, r: 46 },
        { x: 246, y: 92, r: 44 },
        { x: 82, y: 112, r: 34 },
        { x: 290, y: 112, r: 33 },
        { x: 158, y: 114, r: 42 },
        { x: 218, y: 114, r: 40 },
      ],
    },
    {
      w: 290,
      h: 145,
      puffs: [
        { x: 146, y: 66, r: 48 },
        { x: 98, y: 84, r: 38 },
        { x: 198, y: 82, r: 39 },
        { x: 64, y: 100, r: 28 },
        { x: 234, y: 102, r: 27 },
        { x: 148, y: 98, r: 36 },
      ],
    },
    {
      w: 420,
      h: 185,
      puffs: [
        { x: 205, y: 68, r: 64 },
        { x: 140, y: 88, r: 52 },
        { x: 274, y: 86, r: 50 },
        { x: 88, y: 114, r: 38 },
        { x: 332, y: 114, r: 37 },
        { x: 175, y: 118, r: 46 },
        { x: 245, y: 118, r: 46 },
      ],
    },
  ];

  cloudStamps = specs.map((sp) => {
    const cv = document.createElement("canvas");
    cv.width = sp.w * SUPERSAMPLE;
    cv.height = sp.h * SUPERSAMPLE;
    const c = cv.getContext("2d")!;
    c.scale(SUPERSAMPLE, SUPERSAMPLE);

    // 1. Soft sky-blue ambient shadow underbelly
    c.save();
    c.fillStyle = "rgba(186, 224, 248, 0.85)";
    for (const p of sp.puffs) {
      c.beginPath();
      c.arc(p.x, p.y + 6, p.r * 1.01, 0, Math.PI * 2);
      c.fill();
    }
    c.restore();

    // 2. Main sunlit cumulus body with gentle vertical cream-to-ice-blue gradient
    c.save();
    const bodyG = c.createLinearGradient(0, 12, 0, sp.h - 16);
    bodyG.addColorStop(0, "#ffffff");
    bodyG.addColorStop(0.58, "#f7fcff");
    bodyG.addColorStop(1, "#dff2fd");
    c.fillStyle = bodyG;
    for (const p of sp.puffs) {
      c.beginPath();
      c.arc(p.x, p.y, p.r, 0, Math.PI * 2);
      c.fill();
    }
    c.restore();

    // 3. Upper-left golden sunlit highlight rims on top lobes
    c.save();
    c.fillStyle = "rgba(255, 254, 246, 0.92)";
    for (let i = 0; i < Math.min(3, sp.puffs.length); i++) {
      const p = sp.puffs[i];
      c.beginPath();
      c.arc(p.x - p.r * 0.12, p.y - p.r * 0.14, p.r * 0.72, 0, Math.PI * 2);
      c.fill();
    }
    c.restore();

    // 4. Flatten underside slightly so cumulus sits nicely above the horizon
    c.save();
    c.globalCompositeOperation = "destination-out";
    const cutG = c.createLinearGradient(0, sp.h - 46, 0, sp.h - 14);
    cutG.addColorStop(0, "rgba(0,0,0,0)");
    cutG.addColorStop(1, "rgba(0,0,0,1)");
    c.fillStyle = cutG;
    c.fillRect(0, sp.h - 46, sp.w, 46);
    c.restore();

    return cv;
  });

  return cloudStamps;
}

function drawHarborCrane(c: CanvasRenderingContext2D, x: number, baseY: number, scale: number, dir = 1) {
  c.save();
  c.translate(x, baseY);
  c.scale(dir * scale, scale);

  // Concrete & timber crane base
  c.fillStyle = "#5c85a1";
  c.fillRect(-14, -14, 28, 14);
  c.fillStyle = "#7ea6bf";
  c.fillRect(-10, -24, 20, 12);

  // Lattice mast tower
  c.strokeStyle = "#628ca8";
  c.lineWidth = 3;
  c.beginPath();
  c.moveTo(-7, -24);
  c.lineTo(-4, -92);
  c.lineTo(4, -92);
  c.lineTo(7, -24);
  c.stroke();

  c.lineWidth = 1.6;
  c.beginPath();
  for (let y = -32; y >= -86; y -= 14) {
    c.moveTo(-6, y);
    c.lineTo(6, y - 10);
    c.moveTo(6, y);
    c.lineTo(-6, y - 10);
  }
  c.stroke();

  // Control cab (warm harbor orange-red accent faded into coastal mist)
  c.fillStyle = "#c98578";
  c.fillRect(-9, -98, 22, 14);
  c.fillStyle = "#d9f4ff";
  c.fillRect(4, -95, 7, 6);

  // Angled lattice jib boom reaching over the harbor bay
  c.strokeStyle = "#bf7b6e";
  c.lineWidth = 2.8;
  c.beginPath();
  c.moveTo(-18, -94);
  c.lineTo(68, -124);
  c.moveTo(2, -104);
  c.lineTo(68, -124);
  c.stroke();

  // Counterweight block
  c.fillStyle = "#5d849e";
  c.fillRect(-26, -98, 13, 11);

  // Hoist cable & cargo hook
  c.strokeStyle = "#527892";
  c.lineWidth = 1.4;
  c.beginPath();
  c.moveTo(58, -120);
  c.lineTo(58, -74);
  c.stroke();
  c.beginPath();
  c.arc(56.5, -71, 3.2, 0, Math.PI * 1.35);
  c.stroke();

  c.restore();
}

function drawHarborCottage(c: CanvasRenderingContext2D, x: number, baseY: number, scale: number) {
  c.save();
  c.translate(x, baseY);
  c.scale(scale, scale);

  // Timber deck plinth
  c.fillStyle = "#6c8c9e";
  c.fillRect(-34, -6, 68, 6);

  // Boathouse walls
  c.fillStyle = "#ddeef5";
  c.fillRect(-28, -42, 56, 36);
  // Subtle siding shadow
  c.fillStyle = "#c6dfec";
  c.fillRect(6, -42, 22, 36);

  // Chimney
  c.fillStyle = "#8ca9bc";
  c.fillRect(11, -68, 9, 20);

  // Pitched harbor roof
  c.fillStyle = "#8fb3c9";
  c.beginPath();
  c.moveTo(-36, -40);
  c.lineTo(0, -68);
  c.lineTo(36, -40);
  c.closePath();
  c.fill();

  c.fillStyle = "#769cb3";
  c.beginPath();
  c.moveTo(0, -68);
  c.lineTo(36, -40);
  c.lineTo(28, -38);
  c.lineTo(0, -62);
  c.closePath();
  c.fill();

  // Warm cozy doorway & porthole/window
  c.fillStyle = "#7a9cb0";
  c.fillRect(-20, -28, 13, 22);
  c.fillStyle = "#a5d8ea";
  c.fillRect(-1, -30, 14, 12);
  c.strokeStyle = "#7a9cb0";
  c.lineWidth = 1.5;
  c.strokeRect(-1, -30, 14, 12);

  c.restore();
}

function drawFishTruck(c: CanvasRenderingContext2D, x: number, baseY: number, scale: number, dir = 1) {
  c.save();
  c.translate(x, baseY);
  c.scale(dir * scale, scale);

  // Insulated fish-delivery cargo tank/box
  c.fillStyle = "#e3f4fb";
  c.beginPath();
  c.roundRect(-34, -36, 46, 26, 6);
  c.fill();
  c.strokeStyle = "#8cb4cc";
  c.lineWidth = 1.6;
  c.stroke();

  // Painted fish emblem on truck side (nod to Feeding Frenzy harbor truck!)
  c.fillStyle = "#88b6d4";
  c.beginPath();
  c.ellipse(-10, -23, 12, 6.5, 0, 0, Math.PI * 2);
  c.fill();
  c.beginPath();
  c.moveTo(-21, -23);
  c.lineTo(-27, -28);
  c.lineTo(-27, -18);
  c.closePath();
  c.fill();

  // Truck cab
  c.fillStyle = "#92bed6";
  c.beginPath();
  c.moveTo(12, -31);
  c.lineTo(26, -31);
  c.quadraticCurveTo(33, -31, 35, -19);
  c.lineTo(35, -10);
  c.lineTo(12, -10);
  c.closePath();
  c.fill();

  // Cab window
  c.fillStyle = "#d3f2ff";
  c.beginPath();
  c.moveTo(15, -28);
  c.lineTo(25, -28);
  c.lineTo(30, -19);
  c.lineTo(15, -19);
  c.closePath();
  c.fill();

  // Chassis bumper
  c.fillStyle = "#6289a3";
  c.fillRect(-36, -12, 72, 4);

  // Wheels
  for (const wx of [-20, 22]) {
    c.fillStyle = "#486a82";
    c.beginPath();
    c.arc(wx, -8, 8.2, 0, Math.PI * 2);
    c.fill();
    c.fillStyle = "#bdd9e8";
    c.beginPath();
    c.arc(wx, -8, 4.1, 0, Math.PI * 2);
    c.fill();
  }

  c.restore();
}

function drawCrateStack(c: CanvasRenderingContext2D, x: number, baseY: number, scale: number) {
  c.save();
  c.translate(x, baseY);
  c.scale(scale, scale);

  // Wooden crates
  c.fillStyle = "#89a9be";
  c.fillRect(-20, -16, 16, 16);
  c.fillStyle = "#9bbad0";
  c.fillRect(-3, -18, 17, 18);
  c.fillStyle = "#7c9db3";
  c.fillRect(-13, -30, 14, 14);
  c.strokeStyle = "#6789a0";
  c.lineWidth = 1.2;
  c.strokeRect(-20, -16, 16, 16);
  c.strokeRect(-3, -18, 17, 18);
  c.strokeRect(-13, -30, 14, 14);

  // Harbor barrels next to crates
  c.fillStyle = "#84abc0";
  c.fillRect(18, -16, 10, 16);
  c.fillStyle = "#c49488";
  c.fillRect(30, -15, 9, 15);
  c.fillStyle = "#5f8299";
  c.fillRect(18, -11, 10, 2);
  c.fillRect(30, -10, 9, 2);

  c.restore();
}

function drawLighthouse(c: CanvasRenderingContext2D, x: number, baseY: number, scale: number) {
  c.save();
  c.translate(x, baseY);
  c.scale(scale, scale);

  // Rocky headland base
  c.fillStyle = "#91bad0";
  c.beginPath();
  c.moveTo(-42, 0);
  c.quadraticCurveTo(-24, -18, 0, -15);
  c.quadraticCurveTo(28, -16, 46, 0);
  c.closePath();
  c.fill();

  // Stripped lighthouse tower
  c.fillStyle = "#e3f5fc";
  c.beginPath();
  c.moveTo(-11, -14);
  c.lineTo(-6, -78);
  c.lineTo(6, -78);
  c.lineTo(11, -14);
  c.closePath();
  c.fill();

  c.fillStyle = "#cb8a7e";
  c.beginPath();
  c.moveTo(-9.3, -35);
  c.lineTo(-7.8, -53);
  c.lineTo(7.8, -53);
  c.lineTo(9.3, -35);
  c.closePath();
  c.fill();

  // Lantern gallery & cap
  c.fillStyle = "#5e86a0";
  c.fillRect(-9, -81, 18, 4);
  c.fillStyle = "#fff4bd";
  c.fillRect(-5.5, -90, 11, 9);
  c.fillStyle = "#c98578";
  c.beginPath();
  c.moveTo(-8, -90);
  c.lineTo(0, -99);
  c.lineTo(8, -90);
  c.closePath();
  c.fill();

  c.restore();
}

function getHarborStrip(): HTMLCanvasElement {
  if (harborCanvas) return harborCanvas;
  const cv = document.createElement("canvas");
  cv.width = HARBOR_SPAN * SUPERSAMPLE;
  cv.height = HARBOR_H * SUPERSAMPLE;
  const c = cv.getContext("2d")!;
  c.scale(SUPERSAMPLE, SUPERSAMPLE);

  const waterLineY = HARBOR_H - 10;
  const deckY = waterLineY - 26;

  // 1. Soft distant coastal headlands & hills along horizon
  c.fillStyle = "rgba(138, 206, 232, 0.52)";
  c.beginPath();
  c.moveTo(0, waterLineY);
  const hillPts: [number, number][] = [
    [0, waterLineY - 22],
    [180, waterLineY - 46],
    [420, waterLineY - 28],
    [680, waterLineY - 52],
    [960, waterLineY - 20],
    [1220, waterLineY - 42],
    [1520, waterLineY - 58],
    [1840, waterLineY - 26],
    [2120, waterLineY - 48],
    [HARBOR_SPAN, waterLineY - 22],
  ];
  for (let i = 0; i < hillPts.length - 1; i++) {
    const [x0, y0] = hillPts[i];
    const [x1, y1] = hillPts[i + 1];
    c.quadraticCurveTo(x0, y0, (x0 + x1) * 0.5, (y0 + y1) * 0.5);
  }
  c.lineTo(HARBOR_SPAN, waterLineY - 22);
  c.lineTo(HARBOR_SPAN, waterLineY + 12);
  c.lineTo(0, waterLineY + 12);
  c.closePath();
  c.fill();

  // 2. Two harbor dock piers separated by open bay stretches
  const piers = [
    { x0: 70, x1: 980 },
    { x0: 1240, x1: 2220 },
  ];

  // Harbor structures seated on piers
  drawCraneAndDeck();
  function drawCraneAndDeck() {
    // Pier 1: Crane, boathouse cottage, fish truck, crates
    drawHarborCrane(c, 220, deckY, 0.92, 1);
    drawHarborCottage(c, 450, deckY, 0.96);
    drawCrateStack(c, 585, deckY, 0.92);
    drawFishTruck(c, 745, deckY, 0.9, 1);
    drawCrateStack(c, 885, deckY, 0.86);

    // Coastal lighthouse on rocky headland between bays
    drawLighthouse(c, 1110, waterLineY - 4, 0.88);

    // Pier 2: Harbor warehouse cottage, fish truck, tall cargo crane, crates
    drawCrateStack(c, 1340, deckY, 0.92);
    drawHarborCottage(c, 1525, deckY, 0.92);
    drawFishTruck(c, 1735, deckY, 0.92, -1);
    drawHarborCrane(c, 1985, deckY, 0.96, -1);
    drawCrateStack(c, 2125, deckY, 0.9);
  }

  // Wooden pier decks, cross-braces, guard rails & pilings into water
  for (const p of piers) {
    const pw = p.x1 - p.x0;
    // Vertical pilings into water
    for (let px = p.x0 + 18; px <= p.x1 - 18; px += 46) {
      c.fillStyle = "#5b839d";
      c.fillRect(px - 3.2, deckY + 2, 6.4, waterLineY - deckY + 8);
      c.fillStyle = "#7ea5bd";
      c.fillRect(px - 1.5, deckY - 12, 3, 14);
      // Bollard cap
      c.fillStyle = "#507891";
      c.fillRect(px - 4, deckY - 14, 8, 3);
    }

    // Horizontal handrail bar
    c.strokeStyle = "#7aa2bb";
    c.lineWidth = 2.2;
    c.beginPath();
    c.moveTo(p.x0 + 14, deckY - 10);
    c.lineTo(p.x1 - 14, deckY - 10);
    c.stroke();

    // Main pier deck plank beam
    c.fillStyle = "#769cb4";
    c.fillRect(p.x0, deckY, pw, 6.5);
    c.fillStyle = "#9ac0d6";
    c.fillRect(p.x0, deckY, pw, 2.2);
  }

  // 3. Soft horizon aerial-perspective wash so harbor reads unmistakably far away!
  const fogG = c.createLinearGradient(0, 40, 0, HARBOR_H);
  fogG.addColorStop(0, "rgba(182, 240, 252, 0.06)");
  fogG.addColorStop(0.68, "rgba(182, 240, 252, 0.24)");
  fogG.addColorStop(1, "rgba(196, 246, 255, 0.56)");
  c.fillStyle = fogG;
  c.fillRect(0, 0, HARBOR_SPAN, HARBOR_H);

  harborCanvas = cv;
  return cv;
}

function drawMooredHarborShip(
  ctx: CanvasRenderingContext2D,
  x: number,
  waterY: number,
  t: number,
  phase: number,
  dir: number,
  scale: number,
) {
  const bob = Math.sin(t * 1.15 + phase) * 1.6;
  const roll = Math.cos(t * 0.95 + phase) * 0.025;
  ctx.save();
  ctx.translate(x, waterY - 2 + bob);
  ctx.rotate(roll);
  ctx.scale(dir * scale, scale);
  ctx.globalAlpha = 0.54;

  // Hull
  ctx.fillStyle = "#5e87a1";
  ctx.beginPath();
  ctx.moveTo(-36, -10);
  ctx.lineTo(38, -10);
  ctx.quadraticCurveTo(46, -10, 42, 0);
  ctx.lineTo(-32, 0);
  ctx.quadraticCurveTo(-38, -4, -36, -10);
  ctx.closePath();
  ctx.fill();

  // Superstructure cabin
  ctx.fillStyle = "#e2f4fb";
  ctx.fillRect(-16, -24, 28, 14);
  ctx.fillStyle = "#c27f74";
  ctx.fillRect(-18, -26, 32, 4);
  ctx.fillStyle = "#8bc5de";
  ctx.fillRect(-10, -21, 7, 5);
  ctx.fillRect(1, -21, 7, 5);

  // Smokestack & mast
  ctx.fillStyle = "#6e94ad";
  ctx.fillRect(-6, -34, 6, 8);
  ctx.strokeStyle = "#6990aa";
  ctx.lineWidth = 1.6;
  ctx.beginPath();
  ctx.moveTo(18, -10);
  ctx.lineTo(18, -38);
  ctx.lineTo(29, -22);
  ctx.stroke();

  ctx.restore();
}

export function drawHarborAndCloudsSky(
  ctx: CanvasRenderingContext2D,
  camLeft: number,
  camTop: number,
  vw: number,
  vh: number,
  t: number,
  paintSkyGradient = false,
) {
  const waterY = 4 - camTop; // matches SURFACE_Y = 4
  if (waterY <= 0) return;

  ctx.save();
  ctx.beginPath();
  ctx.rect(0, 0, vw + 2, Math.min(vh + 2, waterY + 3));
  ctx.clip();

  if (paintSkyGradient) {
    const g = ctx.createLinearGradient(0, Math.min(0, waterY - 260), 0, waterY + 2);
    g.addColorStop(0, "#2490eb");
    g.addColorStop(0.55, "#59cdf7");
    g.addColorStop(1, "#bbf5fc");
    ctx.fillStyle = g;
    ctx.fillRect(0, 0, vw + 1, waterY + 3);
  }

  const stamps = createCloudStamps();

  // 1. Far drifting cumulus clouds (slower drift, higher sky band)
  ctx.save();
  ctx.imageSmoothingEnabled = true;
  const farPeriod = Math.max(1500, vw + 520);
  for (let i = 0; i < 6; i++) {
    const st = stamps[i % stamps.length];
    const cw = (st.width / SUPERSAMPLE) * (0.72 + (i % 3) * 0.14);
    const ch = (st.height / SUPERSAMPLE) * (0.72 + (i % 3) * 0.14);
    const speed = 5.5 + (i % 3) * 1.9;
    const x = ((((i * 290 - camLeft * 0.1 + t * speed) % farPeriod) + farPeriod) % farPeriod) - cw * 0.85;
    const y = waterY - 120 - (i % 3) * 34 - ch * 0.42;
    if (x > vw + 40 || x + cw < -40 || y + ch < -20) continue;
    ctx.globalAlpha = 0.72;
    ctx.drawImage(st, x, y, cw, ch);
  }
  ctx.restore();

  // 2. Nearer sculpted puffy cumulus clouds drifting faster across sky
  ctx.save();
  ctx.imageSmoothingEnabled = true;
  const nearPeriod = Math.max(1700, vw + 620);
  for (let i = 0; i < 5; i++) {
    const st = stamps[(i + 1) % stamps.length];
    const scale = 0.92 + (i % 2) * 0.2;
    const cw = (st.width / SUPERSAMPLE) * scale;
    const ch = (st.height / SUPERSAMPLE) * scale;
    const speed = 10.5 + (i % 3) * 3.1;
    const x = ((((i * 370 + 140 - camLeft * 0.16 + t * speed) % nearPeriod) + nearPeriod) % nearPeriod) - cw * 0.85;
    const y = waterY - 78 - (i % 2) * 38 - ch * 0.46;
    if (x > vw + 40 || x + cw < -40 || y + ch < -20) continue;
    ctx.globalAlpha = 0.9;
    ctx.drawImage(st, x, y, cw, ch);
  }
  ctx.restore();

  // 3. Distant Coastal Harbor Backdrop anchored flush at the horizon waterline
  const harbor = getHarborStrip();
  const hScale = 0.74;
  const drawW = HARBOR_SPAN * hScale;
  const drawH = HARBOR_H * hScale;
  const off = (((camLeft * 0.19) % drawW) + drawW) % drawW;
  const baseHarborY = waterY - drawH + 8;

  ctx.save();
  ctx.imageSmoothingEnabled = true;
  ctx.globalAlpha = 0.78;
  for (let dx = -off; dx < vw + drawW; dx += drawW) {
    ctx.drawImage(harbor, dx, baseHarborY, drawW, drawH);
  }

  // Subtle moored harbor ships gently bobbing in the harbor bays
  const shipSpecs = [
    { x: 1095, dir: 1, ph: 0.4, sc: 0.72 },
    { x: 2295, dir: -1, ph: 2.3, sc: 0.78 },
  ];
  for (let dx = -off; dx < vw + drawW; dx += drawW) {
    for (const sh of shipSpecs) {
      const sx = dx + sh.x * hScale;
      if (sx < -60 || sx > vw + 60) continue;
      drawMooredHarborShip(ctx, sx, waterY, t, sh.ph, sh.dir, sh.sc);
    }
  }
  ctx.restore();

  ctx.restore();
}

export function getBalloonDanglingItemPos(b: SkyBalloon, t: number): { x: number; y: number; sway: number } {
  const sway = Math.sin(t * 2.5 + b.ph) * 5.2;
  return {
    x: b.x + sway,
    y: b.y + 44,
    sway,
  };
}

export function drawSkyBalloon(
  ctx: CanvasRenderingContext2D,
  b: SkyBalloon,
  camLeft: number,
  camTop: number,
  t: number,
) {
  const x = b.x - camLeft;
  const y = b.y - camTop;
  const item = getBalloonDanglingItemPos(b, t);
  const ix = item.x - camLeft;
  const iy = item.y - camTop;

  const pal =
    b.kind === "stopwatch"
      ? { top: "#ff7a78", mid: "#e11d48", dark: "#9f1239", rim: "#fda4af", glow: "rgba(255, 215, 110, 0.72)" }
      : b.kind === "turbo"
        ? { top: "#67e8f9", mid: "#06b6d4", dark: "#0e7490", rim: "#a5f3fc", glow: "rgba(80, 232, 255, 0.72)" }
        : b.kind === "vortex"
          ? { top: "#fdba74", mid: "#f97316", dark: "#c2410c", rim: "#fed7aa", glow: "rgba(255, 175, 80, 0.72)" }
          : b.kind === "shield"
            ? { top: "#6ee7b7", mid: "#10b981", dark: "#047857", rim: "#a7f3d0", glow: "rgba(95, 242, 185, 0.72)" }
            : { top: "#fde68a", mid: "#ec4899", dark: "#9d174d", rim: "#fbcfe8", glow: "rgba(255, 224, 130, 0.78)" };

  const tilt = Math.sin(t * 1.9 + b.ph) * 0.08;

  // Soft magical aura behind hanging stopwatch/skill badge
  ctx.save();
  ctx.globalCompositeOperation = "lighter";
  const auraR = 19 + Math.sin(t * 4.5 + b.ph) * 2.5;
  const aura = ctx.createRadialGradient(ix, iy, 2, ix, iy, auraR);
  aura.addColorStop(0, pal.glow);
  aura.addColorStop(1, "rgba(255,255,255,0)");
  ctx.fillStyle = aura;
  ctx.beginPath();
  ctx.arc(ix, iy, auraR, 0, Math.PI * 2);
  ctx.fill();
  ctx.restore();

  // Swaying curved string connecting balloon knot to hanging reward
  ctx.save();
  ctx.strokeStyle = "rgba(72, 54, 42, 0.78)";
  ctx.lineWidth = 1.15;
  ctx.beginPath();
  ctx.moveTo(x - Math.sin(tilt) * 16, y + 17);
  ctx.quadraticCurveTo((x + ix) * 0.5 - item.sway * 0.65, (y + 17 + iy - 10) * 0.5, ix, iy - 10);
  ctx.stroke();
  ctx.restore();

  // Glossy helium balloon
  ctx.save();
  ctx.translate(x, y);
  ctx.rotate(tilt);

  // Knot triangle
  ctx.fillStyle = pal.dark;
  ctx.beginPath();
  ctx.moveTo(-2.8, 17.5);
  ctx.lineTo(2.8, 17.5);
  ctx.lineTo(0, 14.5);
  ctx.closePath();
  ctx.fill();

  // Teardrop balloon body
  const bg = ctx.createRadialGradient(-5.2, -6.5, 2, 0, 0, 21);
  bg.addColorStop(0, "#ffffff");
  bg.addColorStop(0.18, pal.top);
  bg.addColorStop(0.68, pal.mid);
  bg.addColorStop(1, pal.dark);
  ctx.fillStyle = bg;
  ctx.beginPath();
  ctx.moveTo(0, -18.5);
  ctx.bezierCurveTo(13, -18.5, 16.5, -5, 12.5, 6.5);
  ctx.bezierCurveTo(9, 14, 3.5, 16, 0, 16);
  ctx.bezierCurveTo(-3.5, 16, -9, 14, -12.5, 6.5);
  ctx.bezierCurveTo(-16.5, -5, -13, -18.5, 0, -18.5);
  ctx.closePath();
  ctx.fill();
  ctx.strokeStyle = pal.dark;
  ctx.lineWidth = 1.1;
  ctx.stroke();

  // Glossy curved highlight crescent
  ctx.fillStyle = "rgba(255, 255, 255, 0.76)";
  ctx.beginPath();
  ctx.ellipse(-5.4, -7.2, 3.2, 5.8, -0.42, 0, Math.PI * 2);
  ctx.fill();
  ctx.fillStyle = "rgba(255, 255, 255, 0.92)";
  ctx.beginPath();
  ctx.arc(-6.8, -11.5, 1.4, 0, Math.PI * 2);
  ctx.fill();
  ctx.restore();

  // Dangling Stopwatch OR Bonus Skill Medallion
  ctx.save();
  ctx.translate(ix, iy);
  ctx.rotate(item.sway * 0.035);

  if (b.kind === "stopwatch") {
    // Pocket stopwatch ring & crown winder
    ctx.strokeStyle = "#cbd5e1";
    ctx.lineWidth = 1.8;
    ctx.beginPath();
    ctx.arc(0, -11.5, 2.7, 0, Math.PI * 2);
    ctx.stroke();
    ctx.fillStyle = "#94a3b8";
    ctx.fillRect(-2.2, -10.5, 4.4, 2.8);

    // Metallic silver-gold bezel
    const rimG = ctx.createLinearGradient(-10, -10, 10, 10);
    rimG.addColorStop(0, "#f8fafc");
    rimG.addColorStop(0.5, "#94a3b8");
    rimG.addColorStop(1, "#475569");
    ctx.fillStyle = rimG;
    ctx.beginPath();
    ctx.arc(0, 0, 10.2, 0, Math.PI * 2);
    ctx.fill();
    ctx.strokeStyle = "#1e293b";
    ctx.lineWidth = 1.1;
    ctx.stroke();

    // Crisp watch face
    const faceG = ctx.createRadialGradient(-2, -2, 1, 0, 0, 8.2);
    faceG.addColorStop(0, "#ffffff");
    faceG.addColorStop(1, "#dbeafe");
    ctx.fillStyle = faceG;
    ctx.beginPath();
    ctx.arc(0, 0, 7.9, 0, Math.PI * 2);
    ctx.fill();

    // Dial tick marks
    ctx.strokeStyle = "#334155";
    ctx.lineWidth = 0.9;
    for (let k = 0; k < 8; k++) {
      const a = (k * Math.PI) / 4;
      ctx.beginPath();
      ctx.moveTo(Math.cos(a) * 5.8, Math.sin(a) * 5.8);
      ctx.lineTo(Math.cos(a) * 7.2, Math.sin(a) * 7.2);
      ctx.stroke();
    }

    // Animated clock hands
    const secA = t * 5.2 + b.ph;
    ctx.strokeStyle = "#dc2626";
    ctx.lineWidth = 1.25;
    ctx.beginPath();
    ctx.moveTo(0, 0);
    ctx.lineTo(Math.cos(secA) * 5.5, Math.sin(secA) * 5.5);
    ctx.stroke();

    ctx.strokeStyle = "#0f172a";
    ctx.lineWidth = 1.5;
    ctx.beginPath();
    ctx.moveTo(0, 0);
    ctx.lineTo(Math.cos(t * 0.9 + b.ph) * 4.2, Math.sin(t * 0.9 + b.ph) * 4.2);
    ctx.stroke();

    ctx.fillStyle = "#f59e0b";
    ctx.beginPath();
    ctx.arc(0, 0, 1.3, 0, Math.PI * 2);
    ctx.fill();
  } else {
    // Golden locket frame + skill emblem
    ctx.fillStyle = "rgba(12, 34, 68, 0.85)";
    ctx.beginPath();
    ctx.arc(0, 0, 9.5, 0, Math.PI * 2);
    ctx.fill();
    ctx.strokeStyle = "#fde047";
    ctx.lineWidth = 1.8;
    ctx.stroke();

    if (b.kind === "turbo") {
      ctx.fillStyle = "#22d3ee";
      ctx.beginPath();
      ctx.moveTo(1.6, -5.8);
      ctx.lineTo(-3.8, 0.5);
      ctx.lineTo(0, 0.5);
      ctx.lineTo(-1.6, 5.8);
      ctx.lineTo(4.0, -0.5);
      ctx.lineTo(0.2, -0.5);
      ctx.closePath();
      ctx.fill();
    } else if (b.kind === "vortex") {
      ctx.strokeStyle = "#fb923c";
      ctx.lineWidth = 2.0;
      ctx.beginPath();
      ctx.arc(0, 0, 4.8, 0, Math.PI * 1.6);
      ctx.stroke();
      ctx.fillStyle = "#fed7aa";
      ctx.beginPath();
      ctx.arc(0, 0, 2.0, 0, Math.PI * 2);
      ctx.fill();
    } else if (b.kind === "shield") {
      ctx.fillStyle = "#34d399";
      ctx.beginPath();
      ctx.moveTo(0, -5.4);
      ctx.lineTo(4.8, -2.6);
      ctx.quadraticCurveTo(4.5, 3.0, 0, 5.8);
      ctx.quadraticCurveTo(-4.5, 3.0, -4.8, -2.6);
      ctx.closePath();
      ctx.fill();
    } else {
      // Pearl bonus medallion
      const pg = ctx.createRadialGradient(-2, -2, 0.8, 0, 0, 6);
      pg.addColorStop(0, "#ffffff");
      pg.addColorStop(0.55, "#fef3c7");
      pg.addColorStop(1, "#f472b6");
      ctx.fillStyle = pg;
      ctx.beginPath();
      ctx.arc(0, 0, 5.8, 0, Math.PI * 2);
      ctx.fill();
    }
  }
  ctx.restore();
}
