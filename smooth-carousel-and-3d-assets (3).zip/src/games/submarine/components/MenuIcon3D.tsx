import { useEffect, useRef, useState } from "react";
import { menuIcons3d, type MenuIcon3DKind } from "../game/menuIcons3d";

interface MenuIcon3DProps {
  kind: MenuIcon3DKind;
  className?: string;
  /** Optional trigger counter: incrementing plays a celebratory 3D tilt/turn glint */
  nudgeKey?: number;
  /** Pause live rendering when menu is hidden or game is active */
  paused?: boolean;
}

function FallbackSvg({ kind, className }: { kind: MenuIcon3DKind; className: string }) {
  if (kind === "crown") {
    return (
      <svg viewBox="0 0 88 64" className={className} fill="none" aria-hidden="true">
        <defs>
          <linearGradient id="fbCrown" x1="0" y1="0" x2="0" y2="1">
            <stop offset="0%" stopColor="#FFF7AE" />
            <stop offset="48%" stopColor="#FFD22B" />
            <stop offset="100%" stopColor="#D97706" />
          </linearGradient>
        </defs>
        <path
          d="M15 49 L9 21 L28 33 L44 13 L60 33 L79 21 L73 49 Z"
          fill="url(#fbCrown)"
          stroke="#5C2802"
          strokeWidth="3.5"
          strokeLinejoin="round"
        />
        <rect x="14" y="47" width="60" height="9" rx="4.5" fill="#F59E0B" stroke="#5C2802" strokeWidth="3.2" />
        <circle cx="9" cy="18" r="4.8" fill="#FFE869" stroke="#5C2802" strokeWidth="2.6" />
        <circle cx="44" cy="10" r="5.5" fill="#FFF3A1" stroke="#5C2802" strokeWidth="2.6" />
        <circle cx="79" cy="18" r="4.8" fill="#FFE869" stroke="#5C2802" strokeWidth="2.6" />
        <circle cx="44" cy="36" r="3.8" fill="#EF4444" stroke="#5C2802" strokeWidth="1.8" />
        <circle cx="28" cy="40" r="2.7" fill="#38BDF8" stroke="#5C2802" strokeWidth="1.5" />
        <circle cx="60" cy="40" r="2.7" fill="#38BDF8" stroke="#5C2802" strokeWidth="1.5" />
      </svg>
    );
  }
  if (kind === "island") {
    return (
      <svg viewBox="0 0 64 56" className={className} fill="none" aria-hidden="true">
        <ellipse cx="32" cy="44" rx="24" ry="7" fill="#38BDF8" stroke="#083366" strokeWidth="2" />
        <path d="M12 43 C15 33 49 33 52 43 C44 47 20 47 12 43 Z" fill="#FCD34D" stroke="#78350F" strokeWidth="2.3" />
        <path d="M31 37 C29 29 30 22 33 17" stroke="#78350F" strokeWidth="5.5" strokeLinecap="round" />
        <path d="M33 17 C24 10 14 14 12 22 C20 19 26 19 33 17 Z" fill="#22C55E" stroke="#14532D" strokeWidth="2" />
        <path d="M33 17 C42 10 52 14 54 22 C46 19 40 19 33 17 Z" fill="#16A34A" stroke="#14532D" strokeWidth="2" />
      </svg>
    );
  }
  return (
    <svg viewBox="0 0 64 64" className={className} fill="none" aria-hidden="true">
      <circle cx="32" cy="32" r="18.5" stroke="#A96228" strokeWidth="6.5" />
      <circle cx="32" cy="32" r="7" fill="#F59E0B" stroke="#2D1304" strokeWidth="2.4" />
    </svg>
  );
}

export default function MenuIcon3D({
  kind,
  className = "",
  nudgeKey = 0,
  paused = false,
}: MenuIcon3DProps) {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const subIdRef = useRef<number>(0);
  const prevNudgeRef = useRef<number>(nudgeKey);
  const [fallback, setFallback] = useState(false);

  useEffect(() => {
    const cv = canvasRef.current;
    if (!cv) return;
    if (!menuIcons3d.isSupported()) {
      setFallback(true);
      return;
    }

    const id = menuIcons3d.subscribe(kind, cv, paused);
    subIdRef.current = id;
    if (!menuIcons3d.isSupported()) {
      menuIcons3d.unsubscribe(id);
      subIdRef.current = 0;
      setFallback(true);
      return;
    }

    // Listen smoothly to closest interactive button hover so touching Theme/Setting sparks lively 3D spin/tilt
    const btn = cv.closest("button");
    const onEnter = () => menuIcons3d.setHovered(id, true);
    const onLeave = () => menuIcons3d.setHovered(id, false);
    if (btn) {
      btn.addEventListener("pointerenter", onEnter);
      btn.addEventListener("pointerleave", onLeave);
    }

    return () => {
      if (btn) {
        btn.removeEventListener("pointerenter", onEnter);
        btn.removeEventListener("pointerleave", onLeave);
      }
      menuIcons3d.unsubscribe(id);
      subIdRef.current = 0;
    };
  }, [kind]);

  useEffect(() => {
    if (subIdRef.current) {
      menuIcons3d.setPaused(subIdRef.current, paused);
    }
  }, [paused]);

  useEffect(() => {
    if (nudgeKey !== prevNudgeRef.current) {
      prevNudgeRef.current = nudgeKey;
      if (subIdRef.current) {
        menuIcons3d.nudge(subIdRef.current, kind === "wheel" ? Math.PI * 0.65 : Math.PI);
      }
    }
  }, [nudgeKey, kind]);

  const filterClass =
    kind === "crown"
      ? "drop-shadow-[0_6px_12px_rgba(48,20,0,0.48)]"
      : kind === "wheel"
        ? "drop-shadow-[0_6px_12px_rgba(12,18,34,0.56)]"
        : "drop-shadow-[0_6px_12px_rgba(4,28,58,0.52)]";

  if (fallback) {
    return <FallbackSvg kind={kind} className={`${className} shrink-0 ${filterClass}`} />;
  }

  return (
    <canvas
      ref={canvasRef}
      aria-hidden="true"
      className={`block shrink-0 pointer-events-none select-none ${filterClass} ${className}`}
    />
  );
}
