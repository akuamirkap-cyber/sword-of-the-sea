export type WeaponId = 'pistol' | 'rifle' | 'sniper';

export type ZoneId = 'compound' | 'courtyard' | 'alpine' | 'ridge';

export type GameMode = 'range' | 'drill';

export type WeaponAnimState =
  | 'ready'
  | 'ads'
  | 'firing'
  | 'bolt_cycle'
  | 'reloading'
  | 'inspecting'
  | 'equipping';

export interface WeaponSpec {
  id: WeaponId;
  name: string;
  label: string;
  caliber: string;
  fireMode: 'SEMI-AUTO' | 'FULL-AUTO' | 'BOLT-ACTION';
  magSize: number;
  rpm: number;
  reloadDuration: number;
  boltCycleDuration: number;
  damageBody: number;
  damageHead: number;
  muzzleVelocity: number; // m/s visual tracer speed
  recoilPitch: number; // upward kick rad
  recoilKickZ: number; // rearward kick m
  recoilYaw: number; // random horizontal sway
  cameraPunch: number; // world camera pitch kick
  adsFov: number;
  spreadHip: number;
  spreadAds: number;
  shellLabel: string;
  muzzleFxLabel: string;
  actionAnimLabel: string;
  ejectionTimingLabel: string;
}

export const WEAPON_SPECS: Record<WeaponId, WeaponSpec> = {
  pistol: {
    id: 'pistol',
    name: 'TACTICAL 1911',
    label: 'PISTOL',
    caliber: '.45 ACP / 9mm',
    fireMode: 'SEMI-AUTO',
    magSize: 12,
    rpm: 380,
    reloadDuration: 1.75,
    boltCycleDuration: 0,
    damageBody: 34,
    damageHead: 90,
    muzzleVelocity: 170,
    recoilPitch: 0.24,
    recoilKickZ: 0.052,
    recoilYaw: 0.032,
    cameraPunch: 0.022,
    adsFov: 58,
    spreadHip: 0.012,
    spreadAds: 0.002,
    shellLabel: 'Selongsong kuningan pendek (.45) — memantul kanan-atas dari ruang bakar (Ejection Port)',
    muzzleFxLabel: 'Api muzzle bintang 4 arah + asap bubuk mesiu + proyektil tracer emas',
    actionAnimLabel: 'Slide atas mundur penuh (Blowback), Hammer memukul, terkunci mundur saat ammo 0',
    ejectionTimingLabel: 'Langsung saat slide mundur setiap tembakan',
  },
  rifle: {
    id: 'rifle',
    name: 'M4A1 CARBINE',
    label: 'RIFLE',
    caliber: '5.56×45mm NATO',
    fireMode: 'FULL-AUTO',
    magSize: 30,
    rpm: 680,
    reloadDuration: 2.25,
    boltCycleDuration: 0,
    damageBody: 28,
    damageHead: 72,
    muzzleVelocity: 260,
    recoilPitch: 0.095,
    recoilKickZ: 0.042,
    recoilYaw: 0.028,
    cameraPunch: 0.015,
    adsFov: 50,
    spreadHip: 0.018,
    spreadAds: 0.0025,
    shellLabel: 'Selongsong botol 5.56mm — terpantul Brass Deflector sisi kanan',
    muzzleFxLabel: 'Api Flash-Hider multi-arah + peluru supersonik 5.56 + gas & asap tipis',
    actionAnimLabel: 'Dust Cover terbuka, Bolt Carrier bolak-balik cepat tiap peluru + recoil bahu ritmis',
    ejectionTimingLabel: 'Otomatis beruntun saat Bolt Carrier mundur',
  },
  sniper: {
    id: 'sniper',
    name: 'M24 MARKSMAN',
    label: 'SNIPER',
    caliber: '.338 LAPUA MAG',
    fireMode: 'BOLT-ACTION',
    magSize: 5,
    rpm: 46,
    reloadDuration: 2.75,
    boltCycleDuration: 1.05,
    damageBody: 110,
    damageHead: 250,
    muzzleVelocity: 420,
    recoilPitch: 0.34,
    recoilKickZ: 0.105,
    recoilYaw: 0.025,
    cameraPunch: 0.044,
    adsFov: 52, // Peripheral world FOV around the 3D scope tube while inside the glass magnifies at 4.7x (14.5°)!
    spreadHip: 0.032,
    spreadAds: 0.0002,
    shellLabel: 'Selongsong panjang .338 kuningan — keluar SAAT kokang bolt ditarik mundur!',
    muzzleFxLabel: 'Semburan gas Muzzle Brake kiri-kanan + api depan + shockwave + jejak contrail putih',
    actionAnimLabel: 'Hentakan recoil berat -> Tangan kanan angkat Bolt 60°, tarik mundur (buang selongsong), dorong & kunci!',
    ejectionTimingLabel: 'Tertunda: keluar tepat saat tangan menarik kokang Bolt ke belakang',
  },
};

export interface ZoneInfo {
  id: ZoneId;
  name: string;
  subtitle: string;
  recommendedWeapon: WeaponId;
  spawnPos: [number, number, number];
  spawnYaw: number;
}

export const ZONES: Record<ZoneId, ZoneInfo> = {
  compound: {
    id: 'compound',
    name: 'GEDUNG GENG GRAFFITI',
    subtitle: 'Gedung 2 Lantai + Pintu Interaktif & Kaca Jendela • Lawan Bot Cerdas',
    recommendedWeapon: 'rifle',
    spawnPos: [0, 1.34, 24.5],
    spawnYaw: 0,
  },
  courtyard: {
    id: 'courtyard',
    name: 'URBAN COURTYARD',
    subtitle: 'Jarak Dekat (10–35m) • Halaman & Target Latihan',
    recommendedWeapon: 'pistol',
    spawnPos: [180, 1.34, 9],
    spawnYaw: 0,
  },
  alpine: {
    id: 'alpine',
    name: 'ALPINE MEADOW',
    subtitle: 'Jarak Menengah (35–110m) • Arena Rifle',
    recommendedWeapon: 'rifle',
    spawnPos: [180, 1.34, -32],
    spawnYaw: 0,
  },
  ridge: {
    id: 'ridge',
    name: 'MOUNTAIN RIDGE',
    subtitle: 'Jarak Jauh (100–250m) • Arena Sniper',
    recommendedWeapon: 'sniper',
    spawnPos: [180, 5.84, -96],
    spawnYaw: 0,
  },
};

export interface CalloutPin {
  id: 'muzzle' | 'ejection' | 'action' | 'mag';
  title: string;
  subtitle: string;
  x: number; // screen px
  y: number; // screen px
  visible: boolean;
  active: boolean; // pulses brightly right when triggered!
}

export interface BodycamFilterSettings {
  /** 0.0 = Filter Sebelumnya (Gritty Curved Frame), 1.0 = Filter Setelahnya (Wide Crisp Fullscreen) */
  styleBlend: number;
  /** Scene brightness multiplier (default 1.18 matching bright sunlit look!) */
  brightness: number;
  /** Wide-angle fisheye barrel curvature (0..1) */
  fisheye: number;
  /** Curved black lens frame & corner vignette intensity (0..1) */
  blackFrame: number;
  /** Dynamic Depth of Field bokeh intensity (0..1) */
  blurDof: number;
  /** Chromatic aberration + CMOS sensor grain intensity (0..1) */
  chromaticGrain: number;
  /** Running camera shake intensity: 0 = Silky Smooth Default, 1 = Wild Panic Bodycam */
  cameraShake: number;
}

export function buildFilterFromBlend(
  styleBlend: number,
  brightness = 1.2,
  cameraShake = 0.14
): BodycamFilterSettings {
  const t = Math.max(0, Math.min(1, styleBlend));
  // t = 0 => Filter Sebelumnya (curved dark lens border, stronger fisheye, heavy grain/CA/DoF)
  // t = 1 => Filter Setelahnya (100% full-bleed wide screen, crisp FXAA/MSAA, gentle vignette & fine grain)
  return {
    styleBlend: t,
    brightness,
    fisheye: 0.86 * (1 - t) + 0.34 * t,
    blackFrame: 0.96 * (1 - t) + 0.0 * t,
    blurDof: 0.86 * (1 - t) + 0.26 * t,
    chromaticGrain: 0.86 * (1 - t) + 0.22 * t,
    cameraShake,
  };
}

// Default: 100% VERSI 2 (Full-Screen Wide Crisp Optics, Zero Black Frame, Bright Daylight, Smooth Running Camera)
export const DEFAULT_FILTER_SETTINGS: BodycamFilterSettings = buildFilterFromBlend(1.0, 1.2, 0.14);

export interface HitFeedback {
  id: number;
  isHeadshot: boolean;
  isKill: boolean;
  label: string;
  points: number;
  distance: number;
}

export interface HudSnapshot {
  weaponId: WeaponId;
  ammo: number;
  magSize: number;
  animState: WeaponAnimState;
  isAds: boolean;
  isCrouching: boolean;
  isSprinting: boolean;
  sniperScoped: boolean;
  scopeRangeMeters: number | null;
  crosshairSpread: number;
  isPointerLocked: boolean;
  showUi: boolean;
  bodycamEnabled: boolean;
  filterSettings: BodycamFilterSettings;
  exposureGain: number;
  focusDistance: number;
  isIndoors: boolean;
  freeAimScreenX: number; // px offset from screen center for dynamic free-aim crosshair when UI is shown
  freeAimScreenY: number;
  slowMo: boolean;
  showMechanics: boolean;
  zoneId: ZoneId;
  gameMode: GameMode;
  drillActive: boolean;
  drillTimeLeft: number;
  drillFinished: boolean;
  score: number;
  streak: number;
  shotsFired: number;
  shotsHit: number;
  headshots: number;
  playerHp: number;
  botsAlive: number;
  botKills: number;
  wave: number;
  botsEnabled: boolean;
  lastEventText: string;
  reloadProgress: number;
  boltProgress: number;
  calloutPins: CalloutPin[];
  hitFeedback: HitFeedback | null;
}
