import * as THREE from 'three';

/**
 * Curated real street-art & wall-painted graffiti photography (verified CORS: access-control-allow-origin: *)
 */
export const GRAFFITI_PHOTO_URLS = {
  boldColorWall:
    'https://images.pexels.com/photos/4165371/pexels-photo-4165371.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200',
  dynamicStreetMural:
    'https://images.pexels.com/photos/4165334/pexels-photo-4165334.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200',
  brickWildstyle:
    'https://images.pexels.com/photos/4165341/pexels-photo-4165341.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200',
  brickStreetTag:
    'https://images.pexels.com/photos/4165340/pexels-photo-4165340.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200',
  redYellowBrick:
    'https://images.pexels.com/photos/29678667/pexels-photo-29678667.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200',
  yellowConcrete:
    'https://images.pexels.com/photos/5703603/pexels-photo-5703603.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200',
  blueGreenBrick:
    'https://images.pexels.com/photos/15950174/pexels-photo-15950174.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200',
  abstractBrick:
    'https://images.pexels.com/photos/40242697/pexels-photo-40242697.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200',
  abandonedInterior:
    'https://images.pexels.com/photos/5735343/pexels-photo-5735343.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200',
  orangeConcrete:
    'https://images.pexels.com/photos/9981498/pexels-photo-9981498.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200',
  bwConcrete:
    'https://images.pexels.com/photos/9981497/pexels-photo-9981497.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200',
  yellowDarkBrick:
    'https://images.pexels.com/photos/15760054/pexels-photo-15760054.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200',
} as const;

export const CONCRETE_PHOTO_URLS = {
  crackedWall:
    'https://images.pexels.com/photos/14070661/pexels-photo-14070661.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200',
  industrialFloor:
    'https://images.pexels.com/photos/8996678/pexels-photo-8996678.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200',
  grayPlaster:
    'https://images.pexels.com/photos/5623106/pexels-photo-5623106.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200',
  shabbyExterior:
    'https://images.pexels.com/photos/2768389/pexels-photo-2768389.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200',
} as const;

export type GraffitiKey = keyof typeof GRAFFITI_PHOTO_URLS;
export type WoodDoorStyle = 'oak' | 'mahogany' | 'paintedWood';

function seededRand(seed: number): number {
  const x = Math.sin(seed * 127.1 + 311.7) * 43758.5453123;
  return x - Math.floor(x);
}

/**
 * Draws an image with true `object-fit: cover` math so graffiti photos NEVER stretch or squish!
 */
function drawImageCover(
  ctx: CanvasRenderingContext2D,
  img: HTMLImageElement,
  dw: number,
  dh: number
) {
  const srcAspect = img.width / Math.max(1, img.height);
  const dstAspect = dw / Math.max(1, dh);
  let sx = 0;
  let sy = 0;
  let sw = img.width;
  let sh = img.height;

  if (srcAspect > dstAspect) {
    sw = img.height * dstAspect;
    sx = (img.width - sw) * 0.5;
  } else {
    sh = img.width / dstAspect;
    sy = (img.height - sh) * 0.5;
  }
  ctx.drawImage(img, sx, sy, sw, sh, 0, 0, dw, dh);
}

/**
 * Architectural Poured-Concrete Formwork Base (seamless, tileable, ZERO mirrored Rorschach anomalies!)
 */
function paintSeamlessArchitecturalConcrete(
  ctx: CanvasRenderingContext2D,
  w: number,
  h: number,
  baseHex: string,
  panelGrid = true,
  grimeStrength = 0.42
) {
  ctx.fillStyle = baseHex;
  ctx.fillRect(0, 0, w, h);

  // Fine mineral concrete grain & mottled plaster variation
  for (let i = 0; i < 1800; i++) {
    const px = seededRand(i * 3.1) * w;
    const py = seededRand(i * 7.3) * h;
    const rw = 2 + seededRand(i * 11.7) * 14;
    const rh = 2 + seededRand(i * 5.9) * 10;
    const dark = i % 2 === 0;
    ctx.fillStyle = dark
      ? `rgba(26, 30, 35, ${0.03 + seededRand(i * 2.1) * 0.045})`
      : `rgba(248, 250, 252, ${0.025 + seededRand(i * 4.3) * 0.035})`;
    ctx.fillRect(px, py, rw, rh);
  }

  // Subtle poured-concrete slab formwork seams & tie-rod dimples (authentic urban concrete building!)
  if (panelGrid) {
    ctx.strokeStyle = 'rgba(30, 34, 40, 0.22)';
    ctx.lineWidth = 2;
    const rows = 2;
    const cols = 2;
    for (let r = 0; r < rows; r++) {
      const y = (r / rows) * h;
      ctx.beginPath();
      ctx.moveTo(0, y + 1);
      ctx.lineTo(w, y + 1);
      ctx.stroke();
    }
    for (let c = 0; c < cols; c++) {
      const x = (c / cols) * w;
      ctx.beginPath();
      ctx.moveTo(x + 1, 0);
      ctx.lineTo(x + 1, h);
      ctx.stroke();
    }
    // Small architectural formwork tie-holes
    ctx.fillStyle = 'rgba(32, 36, 42, 0.34)';
    for (let r = 0; r < rows; r++) {
      for (let c = 0; c < cols; c++) {
        const bx = (c / cols) * w;
        const by = (r / rows) * h;
        const pw = w / cols;
        const ph = h / rows;
        [
          [bx + pw * 0.2, by + ph * 0.25],
          [bx + pw * 0.8, by + ph * 0.25],
          [bx + pw * 0.2, by + ph * 0.75],
          [bx + pw * 0.8, by + ph * 0.75],
        ].forEach(([tx, ty]) => {
          ctx.beginPath();
          ctx.arc(tx, ty, 3.2, 0, Math.PI * 2);
          ctx.fill();
        });
      }
    }
  }

  // Subtle rain-weathering streaks & concrete hairline cracks
  for (let i = 0; i < 14; i++) {
    const sx = seededRand(i * 17.3 + 5) * w;
    const sw = 8 + seededRand(i * 9.1) * 20;
    const sh = h * (0.25 + seededRand(i * 13.7) * 0.45);
    const grad = ctx.createLinearGradient(sx, 0, sx, sh);
    grad.addColorStop(0, `rgba(28, 32, 38, ${0.15 * grimeStrength})`);
    grad.addColorStop(1, 'rgba(28, 32, 38, 0)');
    ctx.fillStyle = grad;
    ctx.fillRect(sx, 0, sw, sh);
  }
}

function overlayConcreteWeathering(ctx: CanvasRenderingContext2D, w: number, h: number) {
  ctx.save();
  ctx.globalCompositeOperation = 'multiply';

  const topAO = ctx.createLinearGradient(0, 0, 0, h * 0.18);
  topAO.addColorStop(0, 'rgba(130, 134, 140, 0.85)');
  topAO.addColorStop(1, 'rgba(255, 255, 255, 1)');
  ctx.fillStyle = topAO;
  ctx.fillRect(0, 0, w, h * 0.18);

  const botAO = ctx.createLinearGradient(0, h * 0.74, 0, h);
  botAO.addColorStop(0, 'rgba(255, 255, 255, 1)');
  botAO.addColorStop(1, 'rgba(108, 112, 118, 0.92)');
  ctx.fillStyle = botAO;
  ctx.fillRect(0, h * 0.74, w, h * 0.26);

  // Subtle hairline plaster cracks over paint
  ctx.strokeStyle = 'rgba(72, 76, 82, 0.28)';
  ctx.lineWidth = 1.4;
  for (let c = 0; c < 5; c++) {
    let cx = ((c + 0.5) / 5) * w;
    let cy = (c % 2) * h * 0.14;
    ctx.beginPath();
    ctx.moveTo(cx, cy);
    for (let s = 0; s < 7; s++) {
      cx += Math.sin(c * 9 + s * 3.1) * 12;
      cy += h * 0.11;
      ctx.lineTo(cx, cy);
    }
    ctx.stroke();
  }
  ctx.restore();
}

function loadCorsImage(url: string, onLoad: (img: HTMLImageElement) => void) {
  const img = new Image();
  img.crossOrigin = 'anonymous';
  img.decoding = 'async';
  img.onload = () => onLoad(img);
  img.src = url;
}

const concreteTexCache = new Map<string, THREE.CanvasTexture>();
const muralMatCache = new Map<string, THREE.MeshStandardMaterial>();
const pigmentDecalCache = new Map<string, THREE.MeshStandardMaterial>();
const sprayBannerCache = new Map<string, THREE.MeshStandardMaterial>();
const woodDoorTexCache = new Map<string, THREE.CanvasTexture>();

/**
 * Clean Seamless Architectural Concrete Texture (uses standard RepeatWrapping + subtle real concrete micro-grain
 * blended softly at 28% so there are ZERO mirrored Rorschach seams or weird patterns!).
 */
export function getWeatheredConcreteTexture(
  kind: keyof typeof CONCRETE_PHOTO_URLS,
  repeatX = 2,
  repeatY = 2,
  tintHex = '#a6acb2'
): THREE.CanvasTexture {
  const key = `${kind}-${repeatX}-${repeatY}-${tintHex}`;
  const cached = concreteTexCache.get(key);
  if (cached) return cached;

  const canvas = document.createElement('canvas');
  canvas.width = 512;
  canvas.height = 512;
  const ctx = canvas.getContext('2d')!;
  const isWall = kind !== 'industrialFloor';
  paintSeamlessArchitecturalConcrete(ctx, 512, 512, tintHex, isWall, 0.45);

  const tex = new THREE.CanvasTexture(canvas);
  tex.colorSpace = THREE.SRGBColorSpace;
  tex.wrapS = THREE.RepeatWrapping;
  tex.wrapT = THREE.RepeatWrapping;
  tex.repeat.set(repeatX, repeatY);
  tex.anisotropy = 4;

  // Blend real concrete photo grain using a seamless offset cross-fade so edges wrap invisibly!
  loadCorsImage(CONCRETE_PHOTO_URLS[kind], (img) => {
    const tmp = document.createElement('canvas');
    tmp.width = 512;
    tmp.height = 512;
    const tctx = tmp.getContext('2d')!;
    // Crop clean center patch from real concrete photo (avoiding any photo border stains!)
    const minDim = Math.min(img.width, img.height) * 0.72;
    const sx = (img.width - minDim) * 0.5;
    const sy = (img.height - minDim) * 0.5;
    tctx.drawImage(img, sx, sy, minDim, minDim, 0, 0, 512, 512);

    // Subtle soft radial edge feather on offset tile to erase tile boundary seams 100%
    ctx.clearRect(0, 0, 512, 512);
    paintSeamlessArchitecturalConcrete(ctx, 512, 512, tintHex, isWall, 0.48);

    ctx.save();
    ctx.globalCompositeOperation = 'soft-light';
    ctx.globalAlpha = 0.46;
    ctx.drawImage(tmp, 0, 0);
    ctx.restore();

    tex.needsUpdate = true;
  });

  concreteTexCache.set(key, tex);
  return tex;
}

/**
 * Aspect-Preserved Wall-Baked Real Graffiti Mural Material:
 * Uses exact `cover` cropping matching `aspect = width / height` so real street-art murals
 * NEVER stretch or distort and look 100% painted into the concrete bay!
 */
export function getWallMuralMaterial(
  graffitiKey: GraffitiKey,
  desaturateTint = 0.08,
  aspect = 2.0
): THREE.MeshStandardMaterial {
  const aspectBucket = Math.round(Math.max(0.5, Math.min(3.2, aspect)) * 4) / 4;
  const key = `mural-${graffitiKey}-${desaturateTint}-${aspectBucket}`;
  const cached = muralMatCache.get(key);
  if (cached) return cached;

  const h = 512;
  const w = Math.max(256, Math.min(1280, Math.round(h * aspectBucket)));
  const canvas = document.createElement('canvas');
  canvas.width = w;
  canvas.height = h;
  const ctx = canvas.getContext('2d')!;

  paintSeamlessArchitecturalConcrete(ctx, w, h, '#949aa1', true, 0.5);

  const tex = new THREE.CanvasTexture(canvas);
  tex.colorSpace = THREE.SRGBColorSpace;
  tex.anisotropy = 8;

  const mat = new THREE.MeshStandardMaterial({
    map: tex,
    roughness: 0.9,
    metalness: 0.02,
  });

  loadCorsImage(GRAFFITI_PHOTO_URLS[graffitiKey], (img) => {
    ctx.clearRect(0, 0, w, h);
    drawImageCover(ctx, img, w, h);

    if (desaturateTint > 0) {
      ctx.fillStyle = `rgba(146, 150, 156, ${desaturateTint})`;
      ctx.fillRect(0, 0, w, h);
    }

    overlayConcreteWeathering(ctx, w, h);
    tex.needsUpdate = true;
  });

  muralMatCache.set(key, mat);
  return mat;
}

/**
 * TRUE WALL-FUSED PIGMENT GRAFFITI DECAL (Replaces the old oval-blob mask!):
 * Extracts vivid spray-paint pigments directly from real street-art photography using
 * chroma/saturation keying + organic paint edge feathering, so ONLY the actual colorful
 * street-art graffiti clings directly to the raw grey concrete wall — ZERO oval patch,
 * ZERO brick background sticker, and ZERO aspect distortion!
 */
export function getFeatheredGraffitiDecalMaterial(
  graffitiKey: GraffitiKey,
  opacity = 0.95,
  aspect = 1.8
): THREE.MeshStandardMaterial {
  const aspectBucket = Math.round(Math.max(0.6, Math.min(2.6, aspect)) * 4) / 4;
  const key = `pigment-${graffitiKey}-${opacity}-${aspectBucket}`;
  const cached = pigmentDecalCache.get(key);
  if (cached) return cached;

  const h = 420;
  const w = Math.max(280, Math.min(1024, Math.round(h * aspectBucket)));
  const canvas = document.createElement('canvas');
  canvas.width = w;
  canvas.height = h;
  const ctx = canvas.getContext('2d')!;

  const tex = new THREE.CanvasTexture(canvas);
  tex.colorSpace = THREE.SRGBColorSpace;
  tex.anisotropy = 8;

  const mat = new THREE.MeshStandardMaterial({
    map: tex,
    transparent: true,
    opacity,
    roughness: 0.88,
    metalness: 0.02,
    depthWrite: false,
    polygonOffset: true,
    polygonOffsetFactor: -3,
    polygonOffsetUnits: -3,
  });

  loadCorsImage(GRAFFITI_PHOTO_URLS[graffitiKey], (img) => {
    ctx.clearRect(0, 0, w, h);
    drawImageCover(ctx, img, w, h);

    // Pixel-level Chroma & Edge Extraction: drop neutral grey/dark brick background, KEEP vivid spray-paint artwork!
    const imgData = ctx.getImageData(0, 0, w, h);
    const data = imgData.data;

    for (let py = 0; py < h; py++) {
      const ny = (py / h) * 2 - 1;
      const edgeY = Math.max(0, 1 - Math.pow(Math.abs(ny), 3.6));
      for (let px = 0; px < w; px++) {
        const nx = (px / w) * 2 - 1;
        const edgeX = Math.max(0, 1 - Math.pow(Math.abs(nx), 3.6));
        // Clean rectangular-softened border fade (NOT an oval blob!)
        const borderFade = Math.min(1, edgeX * edgeY * 2.2);

        const idx = (py * w + px) * 4;
        const r = data[idx];
        const g = data[idx + 1];
        const b = data[idx + 2];

        const maxC = Math.max(r, g, b);
        const minC = Math.min(r, g, b);
        const chroma = maxC - minC;
        const sat = maxC > 12 ? chroma / maxC : 0;

        // Keep rich colorful spray paint + crisp dark black outlines immediately next to paint (high contrast)
        // Drop flat muddy grey/brown concrete & brick backgrounds cleanly!
        const paintMask = THREE.MathUtils.smoothstep(sat, 0.24, 0.5) * THREE.MathUtils.smoothstep(chroma, 28, 72);
        const blackOutline = maxC < 44 ? 0.82 : 0.0;
        const rawAlpha = Math.max(paintMask, blackOutline * THREE.MathUtils.smoothstep(borderFade, 0.35, 0.85));

        // Slight concrete surface grit modulation so concrete texture breathes through paint!
        const grit = 0.86 + seededRand(px * 0.37 + py * 1.13) * 0.14;
        data[idx + 3] = Math.round(Math.max(0, Math.min(1, rawAlpha * borderFade * grit)) * 255);
      }
    }

    ctx.putImageData(imgData, 0, 0);
    tex.needsUpdate = true;
  });

  pigmentDecalCache.set(key, mat);
  return mat;
}

/**
 * Crisp Transparent Wildstyle Gang Spray-Tag Banner Material for wide narrow surfaces
 * (such as Balcony Parapets, Roof Headers, and Entry Beams) — 100% aspect-native, ZERO stretched photos!
 */
export function getSprayTagBannerMaterial(
  text: string,
  primaryColor: string,
  outlineColor: string,
  accentColor: string
): THREE.MeshStandardMaterial {
  const key = `banner-${text}-${primaryColor}-${outlineColor}`;
  const cached = sprayBannerCache.get(key);
  if (cached) return cached;

  const w = 1024;
  const h = 192;
  const canvas = document.createElement('canvas');
  canvas.width = w;
  canvas.height = h;
  const ctx = canvas.getContext('2d')!;

  ctx.clearRect(0, 0, w, h);

  // Subtle translucent aerosol overspray mist halo behind letters
  const halo = ctx.createRadialGradient(w * 0.5, h * 0.52, 24, w * 0.5, h * 0.52, w * 0.44);
  halo.addColorStop(0, `${accentColor}44`);
  halo.addColorStop(0.65, `${primaryColor}22`);
  halo.addColorStop(1, 'rgba(0,0,0,0)');
  ctx.fillStyle = halo;
  ctx.fillRect(0, 0, w, h);

  // Bold tilted street-graffiti throw-up lettering
  ctx.save();
  ctx.translate(w * 0.5, h * 0.56);
  ctx.transform(1, -0.04, -0.22, 1, 0, 0);
  ctx.textAlign = 'center';
  ctx.textBaseline = 'middle';
  ctx.font = '900 102px Impact, "Arial Black", sans-serif';

  // Deep 3D drop shadow block
  ctx.fillStyle = '#0d1014';
  for (let d = 10; d >= 1; d--) {
    ctx.fillText(text, d * 1.1, d * 1.1);
  }

  // Heavy black aerosol outline
  ctx.lineJoin = 'round';
  ctx.lineWidth = 18;
  ctx.strokeStyle = outlineColor;
  ctx.strokeText(text, 0, 0);

  // Vibrant vertical spray gradient fill
  const fillGrad = ctx.createLinearGradient(0, -56, 0, 56);
  fillGrad.addColorStop(0, accentColor);
  fillGrad.addColorStop(0.55, primaryColor);
  fillGrad.addColorStop(1, '#1f2937');
  ctx.fillStyle = fillGrad;
  ctx.fillText(text, 0, 0);

  // Crisp glossy white aerosol highlight slash across top of letters
  ctx.lineWidth = 3.5;
  ctx.strokeStyle = 'rgba(255,255,255,0.78)';
  ctx.strokeText(text, -2, -3);
  ctx.restore();

  // Organic vertical spray-paint drips running down the concrete!
  for (let i = 0; i < 24; i++) {
    const dx = w * 0.14 + seededRand(i * 19.3 + text.length) * (w * 0.72);
    const dy = h * 0.56 + seededRand(i * 7.1) * 20;
    const len = 14 + seededRand(i * 11.9) * 44;
    ctx.strokeStyle = i % 3 === 0 ? accentColor : primaryColor;
    ctx.lineWidth = 2.5 + seededRand(i * 5.3) * 3.5;
    ctx.lineCap = 'round';
    ctx.beginPath();
    ctx.moveTo(dx, dy);
    ctx.lineTo(dx, Math.min(h - 6, dy + len));
    ctx.stroke();
  }

  // Spray underline swoosh arrow
  ctx.strokeStyle = accentColor;
  ctx.lineWidth = 7;
  ctx.lineCap = 'round';
  ctx.beginPath();
  ctx.moveTo(w * 0.16, h * 0.84);
  ctx.quadraticCurveTo(w * 0.5, h * 0.72, w * 0.84, h * 0.82);
  ctx.stroke();

  const tex = new THREE.CanvasTexture(canvas);
  tex.colorSpace = THREE.SRGBColorSpace;
  tex.anisotropy = 8;

  const mat = new THREE.MeshStandardMaterial({
    map: tex,
    transparent: true,
    roughness: 0.86,
    metalness: 0.02,
    depthWrite: false,
    polygonOffset: true,
    polygonOffsetFactor: -3,
    polygonOffsetUnits: -3,
  });

  sprayBannerCache.set(key, mat);
  return mat;
}

/**
 * High-Detail Procedural Natural Wood-Grain Building Door Texture
 * (Authentic aged oak, rich mahogany, or weathered institutional painted timber with real wood fibers,
 * grain streaks, knots, and subtle handle scuffing!)
 */
export function getWoodenDoorTexture(style: WoodDoorStyle): THREE.CanvasTexture {
  const cached = woodDoorTexCache.get(style);
  if (cached) return cached;

  const w = 512;
  const h = 1024;
  const canvas = document.createElement('canvas');
  canvas.width = w;
  canvas.height = h;
  const ctx = canvas.getContext('2d')!;

  const palette =
    style === 'oak'
      ? { base: '#6b4a2e', dark: '#3d2715', light: '#8c6542', grainAlpha: 0.24 }
      : style === 'mahogany'
        ? { base: '#592d22', dark: '#30150e', light: '#7a4232', grainAlpha: 0.26 }
        : { base: '#495a5e', dark: '#2c373a', light: '#65787d', grainAlpha: 0.2 };

  ctx.fillStyle = palette.base;
  ctx.fillRect(0, 0, w, h);

  // Vertical natural wood plank bands
  const planks = 5;
  const pw = w / planks;
  for (let p = 0; p < planks; p++) {
    const shade = (seededRand(p * 31.7 + style.length) - 0.5) * 0.16;
    ctx.fillStyle = shade > 0 ? `rgba(255,235,210,${shade})` : `rgba(18,10,5,${-shade})`;
    ctx.fillRect(p * pw, 0, pw, h);
    // Fine vertical plank seam line
    ctx.fillStyle = 'rgba(20, 12, 6, 0.28)';
    ctx.fillRect(p * pw, 0, 2, h);
  }

  // Organic wavy wood-grain fibers running vertically
  for (let i = 0; i < 420; i++) {
    const gx = seededRand(i * 4.3 + style.length) * w;
    const freq = 0.005 + seededRand(i * 9.7) * 0.012;
    const amp = 1.5 + seededRand(i * 13.1) * 5.5;
    const phase = seededRand(i * 19.3) * Math.PI * 2;
    ctx.strokeStyle = i % 3 === 0 ? palette.light : palette.dark;
    ctx.globalAlpha = palette.grainAlpha * (0.4 + seededRand(i * 6.1) * 0.6);
    ctx.lineWidth = 0.8 + seededRand(i * 8.3) * 2.1;
    ctx.beginPath();
    ctx.moveTo(gx, 0);
    for (let y = 0; y <= h; y += 32) {
      ctx.lineTo(gx + Math.sin(y * freq + phase) * amp, y);
    }
    ctx.stroke();
  }
  ctx.globalAlpha = 1.0;

  // Natural dark wood knots
  for (let k = 0; k < 5; k++) {
    const kx = 45 + seededRand(k * 23.1 + 3) * (w - 90);
    const ky = 90 + seededRand(k * 17.7 + 9) * (h - 180);
    const kr = 6 + seededRand(k * 5.1) * 9;
    const g = ctx.createRadialGradient(kx, ky, 1, kx, ky, kr);
    g.addColorStop(0, 'rgba(28, 15, 7, 0.65)');
    g.addColorStop(0.65, 'rgba(55, 32, 16, 0.25)');
    g.addColorStop(1, 'rgba(55, 32, 16, 0)');
    ctx.fillStyle = g;
    ctx.save();
    ctx.translate(kx, ky);
    ctx.scale(0.65, 2.1);
    ctx.beginPath();
    ctx.arc(0, 0, kr, 0, Math.PI * 2);
    ctx.fill();
    ctx.restore();
  }

  // Painted-wood chipped paint scratches revealing warm oak timber underneath!
  if (style === 'paintedWood') {
    ctx.fillStyle = '#735336';
    for (let s = 0; s < 32; s++) {
      const sx = seededRand(s * 14.3) * w;
      const sy = seededRand(s * 27.9) * h;
      ctx.globalAlpha = 0.55;
      ctx.fillRect(sx, sy, 3 + seededRand(s * 3.1) * 14, 8 + seededRand(s * 6.7) * 38);
    }
    ctx.globalAlpha = 1.0;
  }

  // Aged bottom kick grime & subtle top shadow AO
  const botGrime = ctx.createLinearGradient(0, h * 0.78, 0, h);
  botGrime.addColorStop(0, 'rgba(15, 10, 6, 0)');
  botGrime.addColorStop(1, 'rgba(15, 10, 6, 0.45)');
  ctx.fillStyle = botGrime;
  ctx.fillRect(0, h * 0.78, w, h * 0.22);

  const tex = new THREE.CanvasTexture(canvas);
  tex.colorSpace = THREE.SRGBColorSpace;
  tex.anisotropy = 8;
  woodDoorTexCache.set(style, tex);
  return tex;
}

/**
 * Dynamic Bullet-Impact Spiderweb Glass Fracture Texture!
 * Centered right on the exact UV impact point (hitU, hitV) with a punched bullet hole,
 * powdery frosty white glass pulverization, concentric stress rings, and jagged branching fracture lines!
 */
export function createCrackedGlassTexture(hitU: number, hitV: number): THREE.CanvasTexture {
  const size = 512;
  const canvas = document.createElement('canvas');
  canvas.width = size;
  canvas.height = size;
  const ctx = canvas.getContext('2d')!;

  // Base dusty architectural glass tint
  ctx.fillStyle = 'rgba(152, 192, 208, 0.34)';
  ctx.fillRect(0, 0, size, size);

  const cx = Math.max(36, Math.min(size - 36, hitU * size));
  const cy = Math.max(36, Math.min(size - 36, (1 - hitV) * size));

  // 1. Frosty pulverized white glass stress halo around bullet entry hole
  const frost = ctx.createRadialGradient(cx, cy, 4, cx, cy, 62);
  frost.addColorStop(0, 'rgba(255, 255, 255, 0.92)');
  frost.addColorStop(0.28, 'rgba(230, 245, 255, 0.65)');
  frost.addColorStop(0.65, 'rgba(205, 232, 245, 0.22)');
  frost.addColorStop(1, 'rgba(205, 232, 245, 0)');
  ctx.fillStyle = frost;
  ctx.beginPath();
  ctx.arc(cx, cy, 62, 0, Math.PI * 2);
  ctx.fill();

  // 2. Concentric jagged spiderweb stress rings around the puncture
  const ringRadii = [22, 46, 82, 128];
  ringRadii.forEach((rad, rIdx) => {
    const segs = 14 + rIdx * 4;
    ctx.beginPath();
    for (let i = 0; i <= segs; i++) {
      const a = (i / segs) * Math.PI * 2;
      const jitter = (seededRand(i * 11.3 + rIdx * 29.7 + cx) - 0.5) * rad * 0.28;
      const rr = rad + jitter;
      const px = cx + Math.cos(a) * rr;
      const py = cy + Math.sin(a) * rr;
      if (i === 0) ctx.moveTo(px, py);
      else ctx.lineTo(px, py);
    }
    ctx.strokeStyle = 'rgba(255, 255, 255, 0.85)';
    ctx.lineWidth = rIdx < 2 ? 2.1 : 1.3;
    ctx.stroke();
    ctx.strokeStyle = 'rgba(18, 28, 36, 0.45)';
    ctx.lineWidth = 0.9;
    ctx.stroke();
  });

  // 3. 16 Jagged Branching Radial Fracture Lightning Cracks radiating to the glass edges!
  const rays = 16;
  for (let i = 0; i < rays; i++) {
    const baseAngle = (i / rays) * Math.PI * 2 + (seededRand(i * 7.7 + cy) - 0.5) * 0.26;
    const maxLen = 140 + seededRand(i * 19.1 + cx) * 320;
    let x = cx;
    let y = cy;
    let angle = baseAngle;

    const pts: [number, number][] = [[x, y]];
    const steps = 9;
    for (let s = 1; s <= steps; s++) {
      angle += (seededRand(i * 31 + s * 13.7 + cx) - 0.5) * 0.34;
      const segLen = maxLen / steps;
      x += Math.cos(angle) * segLen;
      y += Math.sin(angle) * segLen;
      pts.push([x, y]);

      // Secondary branching hairline fork!
      if (s === 3 || s === 5) {
        const bAngle = angle + (s === 3 ? 0.52 : -0.48);
        const bx = x + Math.cos(bAngle) * segLen * 1.9;
        const by = y + Math.sin(bAngle) * segLen * 1.9;
        ctx.beginPath();
        ctx.moveTo(x, y);
        ctx.lineTo(bx, by);
        ctx.strokeStyle = 'rgba(255, 255, 255, 0.72)';
        ctx.lineWidth = 1.25;
        ctx.stroke();
      }
    }

    // Dual-stroke crack (bright reflective crystal edge + dark depth line)
    ctx.beginPath();
    pts.forEach(([px, py], idx) => (idx === 0 ? ctx.moveTo(px, py) : ctx.lineTo(px, py)));
    ctx.strokeStyle = 'rgba(255, 255, 255, 0.92)';
    ctx.lineWidth = 2.4;
    ctx.stroke();

    ctx.beginPath();
    pts.forEach(([px, py], idx) => (idx === 0 ? ctx.moveTo(px + 1, py + 1) : ctx.lineTo(px + 1, py + 1)));
    ctx.strokeStyle = 'rgba(15, 25, 34, 0.52)';
    ctx.lineWidth = 1.1;
    ctx.stroke();
  }

  // 4. Clean Punched-Out Jagged Bullet Entry Hole right at center (transparent opening!)
  ctx.save();
  ctx.globalCompositeOperation = 'destination-out';
  ctx.beginPath();
  for (let i = 0; i < 9; i++) {
    const a = (i / 9) * Math.PI * 2;
    const r = 9 + seededRand(i * 17.3 + cx) * 6;
    const px = cx + Math.cos(a) * r;
    const py = cy + Math.sin(a) * r;
    if (i === 0) ctx.moveTo(px, py);
    else ctx.lineTo(px, py);
  }
  ctx.closePath();
  ctx.fill();
  ctx.restore();

  // Sharp crystalline rim around bullet hole
  ctx.beginPath();
  for (let i = 0; i < 9; i++) {
    const a = (i / 9) * Math.PI * 2;
    const r = 10 + seededRand(i * 17.3 + cx) * 6;
    const px = cx + Math.cos(a) * r;
    const py = cy + Math.sin(a) * r;
    if (i === 0) ctx.moveTo(px, py);
    else ctx.lineTo(px, py);
  }
  ctx.closePath();
  ctx.strokeStyle = 'rgba(255, 255, 255, 0.98)';
  ctx.lineWidth = 2.6;
  ctx.stroke();

  const tex = new THREE.CanvasTexture(canvas);
  tex.colorSpace = THREE.SRGBColorSpace;
  tex.anisotropy = 4;
  return tex;
}
