import * as THREE from 'three';
import { BoxCollider3D, buildGraffitiCompound, CompoundContext } from './compoundBuilder';

export const CLASSIC_RANGE_OFFSET_X = 180;

export interface TargetEntity {
  id: string;
  kind: 'dummy' | 'crate' | 'barrel' | 'gong';
  group: THREE.Group;
  pivot: THREE.Group; // rotates backward when knocked down or swings for gong
  hp: number;
  maxHp: number;
  alive: boolean;
  respawnTimer: number;
  knockAngle: number;
  knockVel: number;
  basePos: THREE.Vector3;
  // Moving / strafing behavior
  moveAxis?: 'x' | 'z';
  moveAmp?: number;
  moveSpeed?: number;
  movePhase?: number;
  zone: 'compound' | 'courtyard' | 'alpine' | 'ridge';
  hitMeshes: THREE.Object3D[];
}

export interface WorldCollider {
  minX: number;
  maxX: number;
  minZ: number;
  maxZ: number;
}

export interface WorldContext {
  targets: TargetEntity[];
  hitMeshes: THREE.Object3D[]; // flat array for instant raycasting
  colliders3D: BoxCollider3D[];
  compound: CompoundContext;
  sunLight: THREE.DirectionalLight;
  sunDirection: THREE.Vector3;
  getGroundHeight: (x: number, z: number, currentFootY?: number) => number;
  getIndoorDarkness: (x: number, y: number, z: number) => number;
  focusSunOnMap: (x: number, z: number) => void;
  resetAllTargets: () => void;
}

const WMAT = {
  grassLight: new THREE.MeshStandardMaterial({ color: 0x89ab5f, roughness: 0.92, flatShading: true }),
  grassMid: new THREE.MeshStandardMaterial({ color: 0x749752, roughness: 0.94, flatShading: true }),
  stonePaver: new THREE.MeshStandardMaterial({ color: 0xb4b09b, roughness: 0.9, flatShading: true }),
  wallCream: new THREE.MeshStandardMaterial({ color: 0xd9d2c0, roughness: 0.86, flatShading: true }),
  wallTrim: new THREE.MeshStandardMaterial({ color: 0xbab3a0, roughness: 0.88, flatShading: true }),
  windowDark: new THREE.MeshStandardMaterial({ color: 0x3b4856, roughness: 0.45, metalness: 0.25, flatShading: true }),
  awningRust: new THREE.MeshStandardMaterial({ color: 0xb86240, roughness: 0.8, flatShading: true }),
  kioskBlue: new THREE.MeshStandardMaterial({ color: 0x3c698c, roughness: 0.72, flatShading: true }),
  crateWood: new THREE.MeshStandardMaterial({ color: 0xb98c57, roughness: 0.85, flatShading: true }),
  crateTrim: new THREE.MeshStandardMaterial({ color: 0x8f6639, roughness: 0.88, flatShading: true }),
  rockLight: new THREE.MeshStandardMaterial({ color: 0x8d9599, roughness: 0.9, flatShading: true }),
  rockDark: new THREE.MeshStandardMaterial({ color: 0x677077, roughness: 0.92, flatShading: true }),
  mountainNear: new THREE.MeshStandardMaterial({ color: 0x608578, roughness: 0.94, flatShading: true }),
  mountainFar: new THREE.MeshStandardMaterial({ color: 0x79a4b0, roughness: 0.95, flatShading: true }),
  pineDark: new THREE.MeshStandardMaterial({ color: 0x2c5643, roughness: 0.88, flatShading: true }),
  pineMid: new THREE.MeshStandardMaterial({ color: 0x3a6d52, roughness: 0.86, flatShading: true }),
  trunk: new THREE.MeshStandardMaterial({ color: 0x5c4232, roughness: 0.92, flatShading: true }),
  cloudWhite: new THREE.MeshBasicMaterial({ color: 0xf7fbff }),
  targetSteel: new THREE.MeshStandardMaterial({ color: 0xebeef2, roughness: 0.45, metalness: 0.35, flatShading: true }),
  targetDark: new THREE.MeshStandardMaterial({ color: 0x2d3540, roughness: 0.55, metalness: 0.4, flatShading: true }),
  targetOrange: new THREE.MeshStandardMaterial({ color: 0xf05a28, roughness: 0.48, flatShading: true }),
  targetGold: new THREE.MeshStandardMaterial({ color: 0xffb82e, roughness: 0.35, metalness: 0.45, flatShading: true }),
  barrelRed: new THREE.MeshStandardMaterial({ color: 0xd63b2f, roughness: 0.48, metalness: 0.25, flatShading: true }),
  barrelStripe: new THREE.MeshStandardMaterial({ color: 0xf3d44f, roughness: 0.5, flatShading: true }),
};

function flatMesh(geo: THREE.BufferGeometry, mat: THREE.Material): THREE.Mesh {
  const g = geo.index ? geo.toNonIndexed() : geo;
  g.computeVertexNormals();
  return new THREE.Mesh(g, mat);
}

/**
 * AAA Physically-Inspired Rayleigh + Mie Atmospheric Sky Dome with Blazing Golden Sun Disc & Corona!
 */
function createSkyDome(sunDir: THREE.Vector3): THREE.Mesh {
  const skyGeo = new THREE.SphereGeometry(560, 40, 28);
  const skyMat = new THREE.ShaderMaterial({
    side: THREE.BackSide,
    depthWrite: false,
    fog: false,
    uniforms: {
      uSunDir: { value: sunDir.clone().normalize() },
    },
    vertexShader: /* glsl */ `
      varying vec3 vWorldDir;
      void main() {
        vWorldDir = normalize(position);
        gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0);
      }
    `,
    fragmentShader: /* glsl */ `
      uniform vec3 uSunDir;
      varying vec3 vWorldDir;

      void main() {
        vec3 dir = normalize(vWorldDir);
        float up = clamp(dir.y, 0.0, 1.0);

        // Rich AAA Rayleigh Zenith -> Mid Sky -> Warm Sunlit Horizon Gradient (Linear HDR)
        vec3 zenithCol = vec3(0.11, 0.34, 0.78);
        vec3 midSkyCol = vec3(0.36, 0.66, 0.94);
        vec3 horizonCol = vec3(0.84, 0.89, 0.93);
        vec3 groundCol = vec3(0.55, 0.59, 0.62);

        vec3 sky = mix(horizonCol, midSkyCol, smoothstep(0.0, 0.24, up));
        sky = mix(sky, zenithCol, smoothstep(0.18, 0.82, up));
        if (dir.y < 0.0) {
          sky = mix(horizonCol, groundCol, smoothstep(0.0, -0.25, dir.y));
        }

        // Mie Forward Atmospheric Sun Scattering (warm golden glow enveloping the solar quadrant!)
        float sunCos = max(0.0, dot(dir, normalize(uSunDir)));
        float horizonBoost = 1.0 - smoothstep(0.0, 0.55, up);
        vec3 mieWide = vec3(1.0, 0.78, 0.48) * pow(sunCos, 5.0) * (0.28 + horizonBoost * 0.38);
        vec3 mieHalo = vec3(1.0, 0.90, 0.68) * pow(sunCos, 42.0) * 0.75;
        vec3 sunCorona = vec3(1.5, 1.32, 0.95) * pow(sunCos, 280.0) * 1.45;
        // Crisp Blazing HDR Solar Disc!
        float sunDisc = smoothstep(0.9986, 0.99945, sunCos);
        vec3 discCol = vec3(3.2, 2.85, 2.2) * sunDisc;

        // Subtle high-altitude wispy cirrus haze streaks near horizon
        float cirrus = sin(dir.x * 11.0 + dir.z * 7.0) * cos(dir.z * 14.0 - dir.x * 5.0);
        float cirrusMask = smoothstep(0.04, 0.26, up) * (1.0 - smoothstep(0.32, 0.62, up)) * smoothstep(0.25, 0.9, cirrus);
        sky += vec3(0.12, 0.13, 0.14) * cirrusMask;

        vec3 finalCol = sky + mieWide + mieHalo + sunCorona + discCol;
        gl_FragColor = vec4(finalCol, 1.0);
      }
    `,
  });
  return new THREE.Mesh(skyGeo, skyMat);
}

function addLowPolyCloud(scene: THREE.Object3D, x: number, y: number, z: number, scale: number) {
  const g = new THREE.Group();
  g.position.set(x, y, z);
  const puffs = [
    [0, 0, 0, 1.4],
    [-1.4, -0.25, 0.2, 1.0],
    [1.45, -0.2, -0.15, 1.05],
    [0.5, 0.45, 0.1, 0.95],
    [-0.6, 0.35, -0.2, 0.85],
  ];
  puffs.forEach(([px, py, pz, r]) => {
    const m = flatMesh(new THREE.DodecahedronGeometry(r * scale, 0), WMAT.cloudWhite);
    m.position.set(px * scale, py * scale, pz * scale);
    m.scale.set(1.25, 0.68, 0.9);
    g.add(m);
  });
  scene.add(g);
}

function addPineTree(scene: THREE.Object3D, x: number, y: number, z: number, scale = 1) {
  const g = new THREE.Group();
  g.position.set(x, y, z);
  g.rotation.y = (x * 13.7 + z * 7.3) % (Math.PI * 2);

  const trunk = flatMesh(new THREE.CylinderGeometry(0.18 * scale, 0.28 * scale, 1.8 * scale, 6), WMAT.trunk);
  trunk.position.y = 0.9 * scale;
  trunk.castShadow = true;
  g.add(trunk);

  const tiers = [
    { y: 2.3, r: 1.55, h: 2.3, mat: WMAT.pineDark },
    { y: 3.7, r: 1.25, h: 2.1, mat: WMAT.pineMid },
    { y: 5.0, r: 0.9, h: 1.8, mat: WMAT.pineDark },
    { y: 6.1, r: 0.55, h: 1.4, mat: WMAT.pineMid },
  ];
  tiers.forEach((t) => {
    const cone = flatMesh(new THREE.ConeGeometry(t.r * scale, t.h * scale, 6), t.mat);
    cone.position.y = t.y * scale;
    cone.castShadow = true;
    cone.receiveShadow = true;
    g.add(cone);
  });

  scene.add(g);
}

function addBoulderCluster(scene: THREE.Object3D, x: number, y: number, z: number, scale = 1, count = 4) {
  const g = new THREE.Group();
  g.position.set(x, y, z);
  for (let i = 0; i < count; i++) {
    const ang = (i / count) * Math.PI * 2 + (x + z) * 0.13;
    const dist = i === 0 ? 0 : (0.7 + ((i * 0.53) % 0.9)) * scale;
    const r = (i === 0 ? 1.15 : 0.48 + ((i * 0.37) % 0.55)) * scale;
    const rock = flatMesh(new THREE.DodecahedronGeometry(r, 0), i % 2 === 0 ? WMAT.rockLight : WMAT.rockDark);
    rock.position.set(Math.cos(ang) * dist, r * 0.45, Math.sin(ang) * dist);
    rock.scale.set(1.1 + (i % 3) * 0.15, 0.72 + (i % 2) * 0.22, 0.95 + ((i + 1) % 3) * 0.14);
    rock.rotation.set(i * 0.7, i * 1.3, i * 0.4);
    rock.castShadow = true;
    rock.receiveShadow = true;
    g.add(rock);
  }
  scene.add(g);
}

function addRockSpire(scene: THREE.Object3D, x: number, y: number, z: number, r: number, h: number) {
  const spire = flatMesh(new THREE.ConeGeometry(r, h, 6), WMAT.rockDark);
  spire.position.set(x, y + h * 0.44, z);
  spire.scale.set(1.0, 1.0, 0.78);
  spire.rotation.y = (x + z) * 0.17;
  spire.castShadow = true;
  spire.receiveShadow = true;
  scene.add(spire);

  const shoulder = flatMesh(new THREE.DodecahedronGeometry(r * 0.72, 0), WMAT.rockLight);
  shoulder.position.set(x + r * 0.55, y + h * 0.18, z + r * 0.2);
  shoulder.scale.set(1.1, 1.35, 0.9);
  shoulder.castShadow = true;
  scene.add(shoulder);
}

function addCourtyardBuilding(
  scene: THREE.Object3D,
  colliders: WorldCollider[],
  x: number,
  z: number,
  w: number,
  h: number,
  d: number,
  withAwningSide: 'left' | 'right' | 'none' = 'none'
) {
  const g = new THREE.Group();
  g.position.set(x, 0, z);

  // Main sandstone/cream body
  const body = flatMesh(new THREE.BoxGeometry(w, h, d), WMAT.wallCream);
  body.position.y = h / 2;
  body.castShadow = true;
  body.receiveShadow = true;
  g.add(body);

  // Decorative top cornice & stone base trim
  const cornice = flatMesh(new THREE.BoxGeometry(w + 0.35, 0.45, d + 0.35), WMAT.wallTrim);
  cornice.position.y = h - 0.15;
  g.add(cornice);

  const plinth = flatMesh(new THREE.BoxGeometry(w + 0.22, 0.7, d + 0.22), WMAT.wallTrim);
  plinth.position.y = 0.35;
  g.add(plinth);

  // Recessed stylized windows facing the courtyard
  const sideSign = withAwningSide === 'right' ? 1 : withAwningSide === 'left' ? -1 : 0;
  if (sideSign !== 0) {
    const faceX = sideSign * (w / 2 + 0.04);
    for (let floor = 0; floor < Math.floor(h / 3.2); floor++) {
      const wy = 2.0 + floor * 3.1;
      for (let wz = -d * 0.3; wz <= d * 0.31; wz += 3.2) {
        const frame = flatMesh(new THREE.BoxGeometry(0.18, 1.55, 1.25), WMAT.wallTrim);
        frame.position.set(faceX, wy, wz);
        g.add(frame);
        const glass = flatMesh(new THREE.BoxGeometry(0.22, 1.25, 0.95), WMAT.windowDark);
        glass.position.set(faceX + sideSign * 0.02, wy, wz);
        g.add(glass);
      }
    }

    // Rust-terracotta storefront awning (matches Panel 1 left building!)
    const awning = flatMesh(new THREE.BoxGeometry(1.15, 0.24, Math.min(d * 0.55, 5.2)), WMAT.awningRust);
    awning.position.set(sideSign * (w / 2 + 0.48), 3.3, 0);
    awning.rotation.z = -sideSign * 0.28;
    awning.castShadow = true;
    g.add(awning);
  }

  scene.add(g);
  colliders.push({
    minX: x - w / 2 - 0.55,
    maxX: x + w / 2 + 0.55,
    minZ: z - d / 2 - 0.55,
    maxZ: z + d / 2 + 0.55,
  });
}

function buildCrateMesh(size: number, targetId?: string): { group: THREE.Group; hitMeshes: THREE.Object3D[] } {
  const g = new THREE.Group();
  const hitMeshes: THREE.Object3D[] = [];

  const body = flatMesh(new THREE.BoxGeometry(size, size, size), WMAT.crateWood);
  body.position.y = size / 2;
  body.castShadow = true;
  body.receiveShadow = true;
  if (targetId) body.userData = { targetId, hitbox: 'crate' };
  g.add(body);
  hitMeshes.push(body);

  // Outer wooden trim slats + diagonal brace matching Panel 1 crates!
  const edge = size * 0.09;
  const slatGeoH = new THREE.BoxGeometry(size + 0.05, edge, edge);
  const slatGeoV = new THREE.BoxGeometry(edge, size + 0.04, edge);
  [-size / 2, size / 2].forEach((s) => {
    const top = flatMesh(slatGeoH, WMAT.crateTrim);
    top.position.set(0, size - edge / 2, s);
    g.add(top);
    const bot = flatMesh(slatGeoH, WMAT.crateTrim);
    bot.position.set(0, edge / 2, s);
    g.add(bot);
    const left = flatMesh(slatGeoV, WMAT.crateTrim);
    left.position.set(s, size / 2, size / 2);
    g.add(left);
    const right = flatMesh(slatGeoV, WMAT.crateTrim);
    right.position.set(s, size / 2, -size / 2);
    g.add(right);
  });

  // Diagonal front & back braces
  const diagLen = size * 1.18;
  const diagFront = flatMesh(new THREE.BoxGeometry(diagLen, edge * 0.9, 0.06), WMAT.crateTrim);
  diagFront.position.set(0, size / 2, size / 2 + 0.01);
  diagFront.rotation.z = Math.PI / 4;
  g.add(diagFront);

  const diagBack = flatMesh(new THREE.BoxGeometry(diagLen, edge * 0.9, 0.06), WMAT.crateTrim);
  diagBack.position.set(0, size / 2, -size / 2 - 0.01);
  diagBack.rotation.z = -Math.PI / 4;
  g.add(diagBack);

  return { group: g, hitMeshes };
}

function buildHumanoidTarget(
  id: string,
  x: number,
  y: number,
  z: number,
  zone: 'courtyard' | 'alpine' | 'ridge',
  opts?: { moveAxis?: 'x' | 'z'; moveAmp?: number; moveSpeed?: number; movePhase?: number; scale?: number }
): TargetEntity {
  const sc = opts?.scale ?? 1.0;
  const group = new THREE.Group();
  group.position.set(x, y, z);

  // Base pedestal
  const base = flatMesh(new THREE.BoxGeometry(0.95 * sc, 0.14 * sc, 0.55 * sc), WMAT.targetDark);
  base.position.y = 0.07 * sc;
  base.receiveShadow = true;
  group.add(base);

  // Pivoting steel target frame
  const pivot = new THREE.Group();
  pivot.position.y = 0.14 * sc;
  group.add(pivot);

  const hitMeshes: THREE.Object3D[] = [];

  // Post
  const post = flatMesh(new THREE.BoxGeometry(0.12 * sc, 0.65 * sc, 0.08 * sc), WMAT.targetDark);
  post.position.y = 0.32 * sc;
  pivot.add(post);

  // Torso steel silhouette plate
  const torso = flatMesh(new THREE.BoxGeometry(0.68 * sc, 0.88 * sc, 0.09 * sc), WMAT.targetSteel);
  torso.position.y = 1.04 * sc;
  torso.castShadow = true;
  torso.userData = { targetId: id, hitbox: 'body' };
  pivot.add(torso);
  hitMeshes.push(torso);

  // Painted Orange Bullseye Center Plate on Torso
  const bullOuter = flatMesh(new THREE.CylinderGeometry(0.2 * sc, 0.2 * sc, 0.11 * sc, 8), WMAT.targetOrange);
  bullOuter.rotation.x = Math.PI / 2;
  bullOuter.position.set(0, 1.08 * sc, 0.01 * sc);
  bullOuter.userData = { targetId: id, hitbox: 'body' };
  pivot.add(bullOuter);
  hitMeshes.push(bullOuter);

  const bullInner = flatMesh(new THREE.CylinderGeometry(0.085 * sc, 0.085 * sc, 0.12 * sc, 8), WMAT.targetSteel);
  bullInner.rotation.x = Math.PI / 2;
  bullInner.position.set(0, 1.08 * sc, 0.012 * sc);
  bullInner.userData = { targetId: id, hitbox: 'body' };
  pivot.add(bullInner);
  hitMeshes.push(bullInner);

  // Neck + Distinct Gold-Orange Head Target (2.5x Headshot Bonus!)
  const neck = flatMesh(new THREE.BoxGeometry(0.16 * sc, 0.14 * sc, 0.07 * sc), WMAT.targetDark);
  neck.position.y = 1.54 * sc;
  pivot.add(neck);

  const head = flatMesh(new THREE.CylinderGeometry(0.18 * sc, 0.17 * sc, 0.1 * sc, 8), WMAT.targetGold);
  head.rotation.x = Math.PI / 2;
  head.position.set(0, 1.76 * sc, 0);
  head.castShadow = true;
  head.userData = { targetId: id, hitbox: 'head' };
  pivot.add(head);
  hitMeshes.push(head);

  return {
    id,
    kind: 'dummy',
    group,
    pivot,
    hp: 90,
    maxHp: 90,
    alive: true,
    respawnTimer: 0,
    knockAngle: 0,
    knockVel: 0,
    basePos: new THREE.Vector3(x, y, z),
    moveAxis: opts?.moveAxis,
    moveAmp: opts?.moveAmp,
    moveSpeed: opts?.moveSpeed,
    movePhase: opts?.movePhase ?? 0,
    zone,
    hitMeshes,
  };
}

function buildExplosiveBarrel(
  id: string,
  x: number,
  y: number,
  z: number,
  zone: 'courtyard' | 'alpine' | 'ridge'
): TargetEntity {
  const group = new THREE.Group();
  group.position.set(x, y, z);
  const pivot = new THREE.Group();
  group.add(pivot);

  const body = flatMesh(new THREE.CylinderGeometry(0.38, 0.38, 1.15, 9), WMAT.barrelRed);
  body.position.y = 0.58;
  body.castShadow = true;
  body.userData = { targetId: id, hitbox: 'barrel' };
  pivot.add(body);

  // Yellow hazard band & steel rims
  const stripe = flatMesh(new THREE.CylinderGeometry(0.395, 0.395, 0.22, 9), WMAT.barrelStripe);
  stripe.position.y = 0.62;
  stripe.userData = { targetId: id, hitbox: 'barrel' };
  pivot.add(stripe);

  [0.06, 0.36, 0.84, 1.12].forEach((ry) => {
    const rim = flatMesh(new THREE.CylinderGeometry(0.41, 0.41, 0.05, 9), WMAT.targetDark);
    rim.position.y = ry;
    pivot.add(rim);
  });

  return {
    id,
    kind: 'barrel',
    group,
    pivot,
    hp: 40,
    maxHp: 40,
    alive: true,
    respawnTimer: 0,
    knockAngle: 0,
    knockVel: 0,
    basePos: new THREE.Vector3(x, y, z),
    zone,
    hitMeshes: [body, stripe],
  };
}

function buildSniperGong(id: string, x: number, y: number, z: number, scale = 1.35): TargetEntity {
  const group = new THREE.Group();
  group.position.set(x, y, z);

  // A-frame wooden gantry stand
  const leftLeg = flatMesh(new THREE.BoxGeometry(0.18 * scale, 2.8 * scale, 0.18 * scale), WMAT.crateTrim);
  leftLeg.position.set(-1.15 * scale, 1.35 * scale, 0);
  leftLeg.rotation.z = -0.14;
  group.add(leftLeg);

  const rightLeg = flatMesh(new THREE.BoxGeometry(0.18 * scale, 2.8 * scale, 0.18 * scale), WMAT.crateTrim);
  rightLeg.position.set(1.15 * scale, 1.35 * scale, 0);
  rightLeg.rotation.z = 0.14;
  group.add(rightLeg);

  const topBar = flatMesh(new THREE.BoxGeometry(2.5 * scale, 0.2 * scale, 0.2 * scale), WMAT.crateWood);
  topBar.position.set(0, 2.65 * scale, 0);
  group.add(topBar);

  // Hanging swinging gong pivot at top bar
  const pivot = new THREE.Group();
  pivot.position.set(0, 2.55 * scale, 0);
  group.add(pivot);

  // Chains
  [-0.42, 0.42].forEach((cx) => {
    const chain = flatMesh(new THREE.BoxGeometry(0.06 * scale, 0.85 * scale, 0.06 * scale), WMAT.targetDark);
    chain.position.set(cx * scale, -0.45 * scale, 0);
    pivot.add(chain);
  });

  // Large High-Contrast Steel Gong Disc
  const plate = flatMesh(new THREE.CylinderGeometry(0.85 * scale, 0.85 * scale, 0.12 * scale, 10), WMAT.targetSteel);
  plate.rotation.x = Math.PI / 2;
  plate.position.set(0, -1.25 * scale, 0);
  plate.castShadow = true;
  plate.userData = { targetId: id, hitbox: 'body' };
  pivot.add(plate);

  // Bright Gold Center Bullseye (Counts as Headshot/Bullseye!)
  const bull = flatMesh(new THREE.CylinderGeometry(0.32 * scale, 0.32 * scale, 0.14 * scale, 8), WMAT.targetOrange);
  bull.rotation.x = Math.PI / 2;
  bull.position.set(0, -1.25 * scale, 0.02 * scale);
  bull.userData = { targetId: id, hitbox: 'head' };
  pivot.add(bull);

  return {
    id,
    kind: 'gong',
    group,
    pivot,
    hp: 9999, // Gongs swing dramatically on every hit without disappearing!
    maxHp: 9999,
    alive: true,
    respawnTimer: 0,
    knockAngle: 0,
    knockVel: 0,
    basePos: new THREE.Vector3(x, y, z),
    zone: 'ridge',
    hitMeshes: [plate, bull],
  };
}

/**
 * Computes stylized rolling alpine terrain height cleanly for both mesh sculpting and player movement!
 */
export function computeGroundHeight(x: number, z: number): number {
  // Flat stone Urban Courtyard & adjacent dark CQB room around z in [-28, +18], x in [-22, +24]
  if (z > -28 && x > -22 && x < 24) {
    return 0;
  }
  // Sniper Ridge Overlook Deck around z in [-102, -88], x in [-12, +12]
  if (z <= -88 && z >= -104 && Math.abs(x) <= 13) {
    // Smooth ramp up from z=-82..z=-91
    const ramp = THREE.MathUtils.clamp((-82 - z) / 9, 0, 1);
    return ramp * 4.5;
  }
  if (z < -80 && z > -88 && Math.abs(x) <= 12) {
    const ramp = THREE.MathUtils.clamp((-80 - z) / 8, 0, 1);
    return ramp * 4.5;
  }

  // Rolling alpine meadow & sweeping distant valley drop-off past z=-106!
  let h = 0;
  if (z <= -28 && z >= -95) {
    const t = (-28 - z) / 67;
    h += Math.sin(x * 0.065) * 1.15 * t + Math.cos(z * 0.08) * 0.75 * t;
    h += Math.max(0, (Math.abs(x) - 18) * 0.22);
    if (z < -76 && Math.abs(x) < 16) {
      const ramp = THREE.MathUtils.clamp((-76 - z) / 14, 0, 1);
      h = THREE.MathUtils.lerp(h, 4.5, ramp);
    }
  } else if (z < -95) {
    // Dramatic mountain valley overlook dropping below the ridge then rising into distant peaks!
    const distPastRidge = -95 - z;
    if (distPastRidge < 45) {
      h = 4.5 - distPastRidge * 0.24 + Math.sin(x * 0.05) * 1.8;
    } else {
      const valleyRise = (distPastRidge - 45) * 0.14;
      h = -6.3 + valleyRise + Math.sin(x * 0.045 + z * 0.03) * 4.8 + Math.abs(x) * 0.15;
    }
  }
  return h;
}

export function buildStylizedWorld(rootScene: THREE.Scene): WorldContext {
  const targets: TargetEntity[] = [];
  const hitMeshes: THREE.Object3D[] = [];
  const colliders: WorldCollider[] = [];

  // Cinematic Golden-Afternoon Sun Vector (rakes dramatically across facade, windows, skylights & enemies!)
  const sunOffset = new THREE.Vector3(44, 48, 36);
  const sunDir = sunOffset.clone().normalize();

  // 1. AAA Physically-Inspired Rayleigh+Mie Atmospheric Sky Dome + Sunlit Aerial Perspective Fog
  rootScene.background = new THREE.Color(0x98ccf0);
  rootScene.fog = new THREE.FogExp2(0xcfe0ec, 0.0026);
  const sky = createSkyDome(sunDir);
  sky.scale.setScalar(1.35);
  rootScene.add(sky);

  // 2. AAA 3-Point Outdoor Daylight Rig:
  //    - Cool Azure Sky vs Warm Ground Bounce Hemisphere Fill (creates authentic cool blue shadows!)
  //    - Blazing Warm Golden Key Sun with Ultra-Sharp 4096×4096 PCF Soft Shadows!
  //    - Subtle Cool Rim Backlight separating silhouettes in deep interior shade!
  const hemi = new THREE.HemisphereLight(0x9ad0ff, 0x665c50, 0.72);
  rootScene.add(hemi);

  const sun = new THREE.DirectionalLight(0xffe9c8, 2.25);
  sun.position.copy(sunOffset);
  sun.castShadow = true;
  sun.shadow.mapSize.set(4096, 4096);
  sun.shadow.camera.near = 6;
  sun.shadow.camera.far = 185;
  sun.shadow.camera.left = -36;
  sun.shadow.camera.right = 36;
  sun.shadow.camera.top = 36;
  sun.shadow.camera.bottom = -36;
  sun.shadow.bias = -0.00025;
  sun.shadow.normalBias = 0.032;
  sun.shadow.radius = 2.2;
  rootScene.add(sun);
  rootScene.add(sun.target);

  const fill = new THREE.DirectionalLight(0x88c4ff, 0.48);
  fill.position.set(-48, 24, -64);
  rootScene.add(fill);

  // 2.5 BUILD PRIMARY HERO MAP: 2-STORY ABANDONED GRAFFITI GANG BUILDING AT (0, 0, 0)!
  const compound = buildGraffitiCompound(rootScene);
  targets.push(...compound.targets);
  hitMeshes.push(...compound.hitMeshes);

  // Floating low-poly daylight clouds over the Abandoned Graffiti Compound
  addLowPolyCloud(rootScene, -36, 48, -32, 4.4);
  addLowPolyCloud(rootScene, 38, 54, -42, 5.2);
  addLowPolyCloud(rootScene, 6, 52, -74, 5.8);
  addLowPolyCloud(rootScene, -28, 46, 48, 4.2);

  // 3. CLASSIC 3-ZONE TRAINING RANGES (Mounted cleanly offset at X = +180 so there is zero overlap!)
  const rangeRoot = new THREE.Group();
  rangeRoot.position.set(CLASSIC_RANGE_OFFSET_X, 0, 0);
  rootScene.add(rangeRoot);
  const scene: THREE.Object3D = rangeRoot;

  // Low-Poly Faceted Terrain Mesh covering classic 3 zones seamlessly
  const terrainW = 220;
  const terrainD = 340;
  const terrainGeo = new THREE.PlaneGeometry(terrainW, terrainD, 72, 72);
  terrainGeo.rotateX(-Math.PI / 2);
  terrainGeo.translate(0, 0, -135);

  const posAttr = terrainGeo.attributes.position;
  for (let i = 0; i < posAttr.count; i++) {
    const vx = posAttr.getX(i);
    const vz = posAttr.getZ(i);
    posAttr.setY(i, computeGroundHeight(vx, vz));
  }
  const terrainNonIndexed = terrainGeo.toNonIndexed();
  terrainNonIndexed.computeVertexNormals();

  // Subtle vertex colors blending lush courtyard grass, alpine meadow, and rocky ridge slopes
  const vCount = terrainNonIndexed.attributes.position.count;
  const vColors = new Float32Array(vCount * 3);
  const cGrass = new THREE.Color(0x88aa5e);
  const cMeadow = new THREE.Color(0x769a53);
  const cSlopeRock = new THREE.Color(0x8d9594);
  const cValley = new THREE.Color(0x638f67);
  const tmpC = new THREE.Color();

  for (let i = 0; i < vCount; i++) {
    const vy = terrainNonIndexed.attributes.position.getY(i);
    const vz = terrainNonIndexed.attributes.position.getZ(i);
    const ny = terrainNonIndexed.attributes.normal.getY(i);
    if (ny < 0.82) {
      tmpC.copy(cSlopeRock);
    } else if (vz < -115) {
      tmpC.copy(cValley).lerp(cGrass, THREE.MathUtils.clamp((vy + 5) / 16, 0, 1));
    } else if (vz < -28) {
      tmpC.copy(cMeadow);
    } else {
      tmpC.copy(cGrass);
    }
    vColors[i * 3] = tmpC.r;
    vColors[i * 3 + 1] = tmpC.g;
    vColors[i * 3 + 2] = tmpC.b;
  }
  terrainNonIndexed.setAttribute('color', new THREE.BufferAttribute(vColors, 3));

  const terrainMesh = new THREE.Mesh(
    terrainNonIndexed,
    new THREE.MeshStandardMaterial({ vertexColors: true, roughness: 0.94, flatShading: true })
  );
  terrainMesh.receiveShadow = true;
  scene.add(terrainMesh);

  // =========================================================================
  // ZONE 1: URBAN COURTYARD (Panel 1 Visual Match: cream buildings, pavers, crates!)
  // =========================================================================
  // Stone courtyard paving tiles with grass gaps peeking through
  for (let pz = 13; pz >= -25; pz -= 2.2) {
    for (let px = -9.5; px <= 9.5; px += 2.25) {
      if ((Math.abs(px) > 6.5 && (Math.abs(pz * 3 + px) % 5 < 1.5)) || (Math.sin(px * 2.1 + pz) > 0.72)) {
        continue;
      }
      const paver = flatMesh(
        new THREE.BoxGeometry(1.92, 0.08, 1.92),
        WMAT.stonePaver
      );
      paver.position.set(px + Math.sin(pz) * 0.06, 0.025, pz + Math.cos(px) * 0.06);
      paver.receiveShadow = true;
      scene.add(paver);
    }
  }

  // Sunlit cream low-poly European buildings flanking left and right (Matches Panel 1!)
  addCourtyardBuilding(scene, colliders, -16.5, 5, 9, 13.5, 14, 'right');
  addCourtyardBuilding(scene, colliders, -16.2, -12, 8.5, 16.5, 13, 'right');
  addCourtyardBuilding(scene, colliders, 16.5, 6.2, 9, 12.0, 11.5, 'left');

  // ENTERABLE DARK TACTICAL CQB ROOM (Right Courtyard: x in [10.6..21.4], z in [-16.5..-3.5])
  // Built specifically so stepping from blazing daylight into this dark interior triggers authentic Aggressive Auto-Exposure!
  const darkWallMat = new THREE.MeshStandardMaterial({ color: 0x2a2f36, roughness: 0.96, flatShading: true });
  const darkFloorMat = new THREE.MeshStandardMaterial({ color: 0x22262c, roughness: 0.95, flatShading: true });
  const addRoomPart = (
    x: number,
    y: number,
    z: number,
    w: number,
    h: number,
    d: number,
    mat: THREE.Material,
    collide = true
  ) => {
    const m = flatMesh(new THREE.BoxGeometry(w, h, d), mat);
    m.position.set(x, y, z);
    m.castShadow = true;
    m.receiveShadow = true;
    scene.add(m);
    if (collide) {
      colliders.push({
        minX: x - w / 2 - 0.35,
        maxX: x + w / 2 + 0.35,
        minZ: z - d / 2 - 0.35,
        maxZ: z + d / 2 + 0.35,
      });
    }
  };
  // Floor & Thick Roof Slab blocking direct sunlight
  addRoomPart(16.0, 0.04, -10.0, 10.8, 0.08, 13.0, darkFloorMat, false);
  addRoomPart(16.0, 4.35, -10.0, 11.2, 0.55, 13.4, WMAT.wallCream, false);
  // Decorative upper concrete facade parapet matching courtyard buildings
  addRoomPart(16.0, 6.4, -10.0, 11.0, 3.6, 13.0, WMAT.wallCream, false);
  // Back (East) & South solid walls
  addRoomPart(21.2, 2.1, -10.0, 0.55, 4.2, 13.0, darkWallMat, true);
  addRoomPart(16.0, 2.1, -3.65, 10.8, 4.2, 0.55, darkWallMat, true);
  // West wall (facing Courtyard) split around wide open breach doorway at z in [-11.3..-7.9]
  addRoomPart(10.85, 2.1, -5.75, 0.55, 4.2, 4.3, WMAT.wallTrim, true);
  addRoomPart(10.85, 2.1, -13.9, 0.55, 4.2, 5.2, WMAT.wallTrim, true);
  addRoomPart(10.85, 3.65, -9.6, 0.55, 1.1, 3.4, WMAT.wallTrim, false); // doorway lintel
  // North wall split around secondary exit doorway toward Alpine Meadow (x in [13.5..16.5])
  addRoomPart(12.15, 2.1, -16.35, 2.7, 4.2, 0.55, darkWallMat, true);
  addRoomPart(18.95, 2.1, -16.35, 4.9, 4.2, 0.55, darkWallMat, true);
  addRoomPart(15.0, 3.65, -16.35, 3.0, 1.1, 0.55, darkWallMat, false);
  // Subtle interior pillar & warm low-intensity tactical ceiling lamp
  addRoomPart(15.8, 2.1, -9.8, 0.75, 4.2, 0.75, darkWallMat, true);
  const indoorLamp = new THREE.PointLight(0xffcb8c, 1.15, 11, 1.6);
  indoorLamp.position.set(17.2, 3.7, -9.8);
  scene.add(indoorLamp);
  const lampFixture = flatMesh(
    new THREE.BoxGeometry(0.65, 0.14, 0.22),
    new THREE.MeshBasicMaterial({ color: 0xffd8a8 })
  );
  lampFixture.position.set(17.2, 4.02, -9.8);
  scene.add(lampFixture);

  // Blue tactical urban kiosk / container near far courtyard corner (seen in Panel 1!)
  const kiosk = flatMesh(new THREE.BoxGeometry(3.4, 2.9, 4.8), WMAT.kioskBlue);
  kiosk.position.set(9.5, 1.45, -21.5);
  kiosk.castShadow = true;
  kiosk.receiveShadow = true;
  scene.add(kiosk);
  colliders.push({ minX: 7.4, maxX: 11.6, minZ: -24.3, maxZ: -18.7 });

  // Courtyard low stone archway walls framing the gateway out into the Alpine Meadow!
  const leftGateWall = flatMesh(new THREE.BoxGeometry(9.5, 3.2, 1.4), WMAT.wallCream);
  leftGateWall.position.set(-10.5, 1.6, -26.5);
  leftGateWall.castShadow = true;
  leftGateWall.receiveShadow = true;
  scene.add(leftGateWall);
  colliders.push({ minX: -15.6, maxX: -5.4, minZ: -27.5, maxZ: -25.5 });

  const rightGateWall = flatMesh(new THREE.BoxGeometry(9.5, 3.2, 1.4), WMAT.wallCream);
  rightGateWall.position.set(10.5, 1.6, -26.5);
  rightGateWall.castShadow = true;
  rightGateWall.receiveShadow = true;
  scene.add(rightGateWall);
  colliders.push({ minX: 5.4, maxX: 15.6, minZ: -27.5, maxZ: -25.5 });

  // Decorative static wooden crate stacks along the left building (exact Panel 1 foreground!)
  [
    [-8.6, 0, 3.2, 1.65],
    [-8.9, 0, -2.5, 1.45],
    [-9.2, 1.45, -2.6, 1.15],
    [8.6, 0, 1.4, 1.55],
  ].forEach(([cx, cy, cz, cs]) => {
    const { group } = buildCrateMesh(cs);
    group.position.set(cx, cy, cz);
    scene.add(group);
    if (cy === 0) {
      colliders.push({
        minX: cx - cs * 0.6,
        maxX: cx + cs * 0.6,
        minZ: cz - cs * 0.6,
        maxZ: cz + cs * 0.6,
      });
    }
  });

  // --- ZONE 1 INTERACTIVE TARGETS (Pistol CQB Range: 12m to 32m) ---
  const addTarget = (t: TargetEntity) => {
    targets.push(t);
    scene.add(t.group);
    hitMeshes.push(...t.hitMeshes);
  };

  addTarget(buildHumanoidTarget('cq-1', -4.2, 0, -6.5, 'courtyard'));
  addTarget(buildHumanoidTarget('cq-2', 4.4, 0, -10.5, 'courtyard'));
  addTarget(buildHumanoidTarget('cq-3', 0, 0, -15.5, 'courtyard', { moveAxis: 'x', moveAmp: 3.6, moveSpeed: 1.55 }));
  addTarget(buildHumanoidTarget('cq-4', -5.4, 0, -20.5, 'courtyard'));
  addTarget(buildHumanoidTarget('cq-5', 4.0, 0, -22.5, 'courtyard'));
  // Indoor dark-room breach targets (facing doorway!)
  const darkT1 = buildHumanoidTarget('cq-dark-1', 19.2, 0.08, -6.4, 'courtyard');
  darkT1.group.rotation.y = -Math.PI / 2;
  addTarget(darkT1);
  const darkT2 = buildHumanoidTarget('cq-dark-2', 19.4, 0.08, -13.4, 'courtyard');
  darkT2.group.rotation.y = -Math.PI * 0.42;
  addTarget(darkT2);
  addTarget(buildExplosiveBarrel('cq-barrel-1', -1.8, 0, -19.5, 'courtyard'));

  // Destructible Wooden Crates inside Courtyard!
  [
    ['crate-1', -2.6, 0, -4.5, 1.25],
    ['crate-2', 3.2, 0, -6.2, 1.3],
    ['crate-3', 5.2, 0, -16.8, 1.35],
  ].forEach(([id, cx, cy, cz, cs]) => {
    const { group, hitMeshes: hm } = buildCrateMesh(cs as number, id as string);
    group.position.set(cx as number, cy as number, cz as number);
    const entity: TargetEntity = {
      id: id as string,
      kind: 'crate',
      group,
      pivot: group,
      hp: 55,
      maxHp: 55,
      alive: true,
      respawnTimer: 0,
      knockAngle: 0,
      knockVel: 0,
      basePos: new THREE.Vector3(cx as number, cy as number, cz as number),
      zone: 'courtyard',
      hitMeshes: hm,
    };
    addTarget(entity);
  });

  // =========================================================================
  // ZONE 2: ALPINE MEADOW & ROCKY CRAGS (Panel 2 Visual Match: rocks, pines, spires!)
  // =========================================================================
  const boulderCoords: [number, number, number, number][] = [
    [-11, -40, 1.5, 5],
    [12, -46, 1.8, 5],
    [-8, -56, 1.3, 4],
    [9, -62, 1.6, 5],
    [-16, -68, 2.2, 5],
    [15, -75, 2.0, 5],
    [-14, -84, 1.9, 4],
    [14, -86, 1.8, 4],
    [4, -52, 0.9, 4],
    [-5, -72, 1.0, 4],
  ];
  boulderCoords.forEach(([bx, bz, bs, bc]) => {
    addBoulderCluster(scene, bx, computeGroundHeight(bx, bz) - 0.15, bz, bs, bc);
  });

  // Iconic dramatic alpine rock spires flanking the meadow (matches Panel 2!)
  addRockSpire(scene, -29, computeGroundHeight(-29, -56), -56, 9.5, 29);
  addRockSpire(scene, -24, computeGroundHeight(-24, -78), -78, 8.0, 23);
  addRockSpire(scene, 28, computeGroundHeight(28, -60), -60, 10.5, 27);
  addRockSpire(scene, 32, computeGroundHeight(32, -85), -85, 9.0, 24);
  addRockSpire(scene, -36, computeGroundHeight(-36, -104), -104, 12.0, 32);

  // Stylized dark-emerald alpine pine trees framing the slopes
  const pineCoords: [number, number, number][] = [
    [-19, -36, 1.15],
    [-22, -45, 1.35],
    [-17, -54, 1.05],
    [-25, -66, 1.4],
    [-19, -76, 1.2],
    [18, -38, 1.25],
    [22, -48, 1.35],
    [19, -58, 1.1],
    [24, -71, 1.45],
    [21, -82, 1.2],
    [-28, -94, 1.4],
    [27, -98, 1.35],
    [-14, -112, 1.25],
    [16, -116, 1.2],
    [-26, -125, 1.5],
    [29, -130, 1.45],
  ];
  pineCoords.forEach(([px, pz, ps]) => {
    addPineTree(scene, px, computeGroundHeight(px, pz) - 0.1, pz, ps);
  });

  // --- ZONE 2 INTERACTIVE TARGETS (Rifle Mid-Range: 40m to 88m) ---
  const addAlpineDummy = (
    id: string,
    x: number,
    z: number,
    opts?: { moveAxis?: 'x' | 'z'; moveAmp?: number; moveSpeed?: number; movePhase?: number }
  ) => {
    addTarget(buildHumanoidTarget(id, x, computeGroundHeight(x, z), z, 'alpine', { ...opts, scale: 1.08 }));
  };

  addAlpineDummy('alp-1', -6.5, -45);
  addAlpineDummy('alp-2', 6.8, -50);
  addAlpineDummy('alp-3', 0, -58, { moveAxis: 'x', moveAmp: 5.5, moveSpeed: 1.7 });
  addAlpineDummy('alp-4', -9.2, -66);
  addAlpineDummy('alp-5', 8.5, -70, { moveAxis: 'x', moveAmp: 3.5, moveSpeed: 2.0, movePhase: 1.4 });
  addAlpineDummy('alp-6', 1.5, -77);
  addTarget(buildExplosiveBarrel('alp-barrel-1', -3.5, computeGroundHeight(-3.5, -54), -54, 'alpine'));
  addTarget(buildExplosiveBarrel('alp-barrel-2', 5.2, computeGroundHeight(5.2, -67), -67, 'alpine'));

  // =========================================================================
  // ZONE 3: SNIPER MOUNTAIN RIDGE OVERLOOK & VALLEY PEAKS (Panel 3 Visual Match!)
  // =========================================================================
  // Elevated stone & wood sniper overlook ledge at z = -96, y = 4.5
  const ridgeDeck = flatMesh(new THREE.BoxGeometry(19, 0.5, 12), WMAT.stonePaver);
  ridgeDeck.position.set(0, 4.25, -96);
  ridgeDeck.receiveShadow = true;
  scene.add(ridgeDeck);

  // Low stone sniper shooting parapet at front edge of ridge
  const parapetL = flatMesh(new THREE.BoxGeometry(5.5, 0.9, 0.7), WMAT.rockLight);
  parapetL.position.set(-6.4, 4.9, -101.6);
  scene.add(parapetL);
  const parapetR = flatMesh(new THREE.BoxGeometry(5.5, 0.9, 0.7), WMAT.rockLight);
  parapetR.position.set(6.4, 4.9, -101.6);
  scene.add(parapetR);

  // Sweeping layered alpine mountain ridges in the distant valley (exact Panel 3 silhouette!)
  const mountains: [number, number, number, number, number, THREE.Material][] = [
    [-85, -18, -195, 68, 72, WMAT.mountainNear],
    [15, -20, -235, 86, 84, WMAT.mountainNear],
    [98, -18, -205, 76, 78, WMAT.mountainNear],
    [-145, -25, -270, 110, 108, WMAT.mountainFar],
    [-35, -24, -300, 118, 115, WMAT.mountainFar],
    [72, -24, -315, 122, 124, WMAT.mountainFar],
    [168, -24, -275, 104, 98, WMAT.mountainFar],
  ];
  mountains.forEach(([mx, my, mz, mr, mh, mat]) => {
    const peak = flatMesh(new THREE.ConeGeometry(mr, mh, 7), mat);
    peak.position.set(mx, my + mh * 0.5, mz);
    peak.scale.set(1.25, 1.0, 0.9);
    peak.rotation.y = (mx * 0.03) % Math.PI;
    scene.add(peak);
  });

  // Crisp Low-Poly White Clouds floating across the bright blue sky!
  addLowPolyCloud(scene, -45, 58, -130, 5.2);
  addLowPolyCloud(scene, 55, 68, -165, 6.4);
  addLowPolyCloud(scene, -110, 74, -220, 7.2);
  addLowPolyCloud(scene, 12, 62, -250, 6.8);
  addLowPolyCloud(scene, 115, 56, -210, 5.8);
  addLowPolyCloud(scene, -12, 54, -65, 4.0);

  // --- ZONE 3 LONG-RANGE SNIPER TARGETS & STEEL GONGS (100m to 250m from Ridge!) ---
  const addRidgeGong = (id: string, x: number, z: number, scale: number) => {
    const gy = computeGroundHeight(x, z);
    addTarget(buildSniperGong(id, x, gy, z, scale));
  };
  const addRidgeDummy = (id: string, x: number, z: number, scale: number, amp = 0) => {
    const gy = computeGroundHeight(x, z);
    addTarget(
      buildHumanoidTarget(id, x, gy, z, 'ridge', {
        scale,
        moveAxis: amp > 0 ? 'x' : undefined,
        moveAmp: amp,
        moveSpeed: 1.2,
      })
    );
  };

  // ~65m–165m from Sniper Ridge (z=-96)
  addRidgeGong('gong-1', -18, -162, 1.35);
  addRidgeGong('gong-2', 20, -184, 1.5);
  addRidgeGong('gong-3', -4, -218, 1.85);
  addRidgeGong('gong-4', 34, -242, 2.1);

  addRidgeDummy('sni-1', 6, -152, 1.35);
  addRidgeDummy('sni-2', -26, -178, 1.45, 6.0);
  addRidgeDummy('sni-3', 14, -204, 1.6, 7.5);
  addTarget(buildExplosiveBarrel('sni-barrel-1', 2.5, computeGroundHeight(2.5, -152), -152, 'ridge'));

  const resetAllTargets = () => {
    targets.forEach((t) => {
      t.hp = t.maxHp;
      t.alive = true;
      t.respawnTimer = 0;
      t.knockAngle = 0;
      t.knockVel = 0;
      t.group.visible = true;
      t.pivot.rotation.set(0, 0, 0);
    });
  };

  const sunDirection = sunDir.clone();

  // Merge 3D multi-level colliders from the Abandoned Graffiti Compound + offset classic 3-zone colliders!
  const colliders3D: BoxCollider3D[] = [
    ...compound.colliders3D,
    ...colliders.map((c) => ({
      minX: c.minX + CLASSIC_RANGE_OFFSET_X,
      maxX: c.maxX + CLASSIC_RANGE_OFFSET_X,
      minY: -2,
      maxY: 16,
      minZ: c.minZ,
      maxZ: c.maxZ,
    })),
  ];

  // Unified Floor Height Solver supporting 2-story stairs & balconies in Graffiti Compound AND rolling hills in Classic Range!
  const getGroundHeight = (x: number, z: number, currentFootY = 0): number => {
    if (x < 90) {
      return compound.getFloorHeight(x, z, currentFootY);
    }
    return computeGroundHeight(x - CLASSIC_RANGE_OFFSET_X, z);
  };

  // Unified Interior Darkness Solver for Aggressive Bodycam Auto-Exposure!
  const getIndoorDarkness = (x: number, y: number, z: number): number => {
    if (x < 90) {
      return compound.getIndoorDarkness(x, y, z);
    }
    const lx = x - CLASSIC_RANGE_OFFSET_X;
    const insideX = THREE.MathUtils.clamp((lx - 9.8) / 2.2, 0, 1) * THREE.MathUtils.clamp((21.6 - lx) / 1.2, 0, 1);
    const insideZ =
      THREE.MathUtils.clamp((z - -16.9) / 1.5, 0, 1) * THREE.MathUtils.clamp((-3.2 - z) / 1.5, 0, 1);
    return insideX * insideZ;
  };

  const focusSunOnMap = (cx: number, cz: number) => {
    sun.position.set(cx + sunOffset.x, sunOffset.y, cz + sunOffset.z);
    sun.target.position.set(cx, 0, cz);
    sun.target.updateMatrixWorld();
  };

  return {
    targets,
    hitMeshes,
    colliders3D,
    compound,
    sunLight: sun,
    sunDirection,
    getGroundHeight,
    getIndoorDarkness,
    focusSunOnMap,
    resetAllTargets,
  };
}
