import * as THREE from 'three';

export interface BodycamParams {
  enabled: boolean;
  time: number;
  exposure: number; // Aggressive auto-exposure multiplier
  brightness: number; // Adjustable bright sunlit baseline (default ~1.18 matching previous brightness!)
  glareStrength: number; // Highlight halation when looking at sun / exiting dark room / firing
  focusDistance: number; // Live autofocus distance in meters
  dofStrength: number; // 0..1 optical bokeh intensity
  fisheyeStrength: number; // 0..1 wide-angle barrel distortion
  blackFrameStrength: number; // 0..1 morphs between full-bleed (0) and previous curved black lens border (1)
  chromaticStrength: number; // 0..1 edge RGB dispersion
  grainStrength: number; // 0..1 sensor grain intensity
  vignetteStrength: number; // 0..1 optical corner falloff
  damagePulse: number; // 0..1 crimson peripheral hit feedback when taking bot fire
  sunScreenPos: THREE.Vector2; // Projected sun UV (0..1) for AAA golden sun corona & lens flare
  sunFlareStrength: number; // 0..1 sun visibility strength
  cameraNear: number;
  cameraFar: number;
  sniperScoped: boolean;
}

const VERT_SHADER = /* glsl */ `
  varying vec2 vUv;
  void main() {
    vUv = uv;
    gl_Position = vec4(position.xy, 0.0, 1.0);
  }
`;

const FRAG_SHADER = /* glsl */ `
  precision highp float;

  uniform sampler2D tWorld;
  uniform sampler2D tWorldDepth;
  uniform sampler2D tVm;

  uniform vec2 uResolution;
  uniform float uTime;
  uniform float uEnabled;
  uniform float uExposure;
  uniform float uBrightness;
  uniform float uGlareStrength;
  uniform float uFocusDist;
  uniform float uDofStrength;
  uniform float uFisheye;
  uniform float uBlackFrame;
  uniform float uChromatic;
  uniform float uGrain;
  uniform float uVignette;
  uniform float uDamagePulse;
  uniform vec2 uSunScreenPos;
  uniform float uSunFlare;
  uniform float uNear;
  uniform float uFar;

  varying vec2 vUv;

  float hash12(vec2 p) {
    vec3 p3 = fract(vec3(p.xyx) * 0.1031);
    p3 += dot(p3, p3.yzx + 33.33);
    return fract((p3.x + p3.y) * p3.z);
  }

  float getLuma(vec3 c) {
    return dot(c, vec3(0.299, 0.587, 0.114));
  }

  vec3 linearToSrgb(vec3 c) {
    return pow(max(c, vec3(0.0)), vec3(1.0 / 2.2));
  }

  // Bright, airy sunlit filmic tone curve (preserves previous bright look while keeping hand facets crisp!)
  vec3 brightFilmic(vec3 x) {
    vec3 a = x * (x * 1.48 + 0.24);
    vec3 b = x * (x * 1.18 + 0.68) + 0.045;
    return clamp(a / b, 0.0, 1.0);
  }

  float linearizeDepth(float depthSample) {
    float z = depthSample * 2.0 - 1.0;
    return (2.0 * uNear * uFar) / max(0.0001, (uFar + uNear - z * (uFar - uNear)));
  }

  // Dual-Mode Wide-Angle Fisheye:
  // uBlackFrame = 0.0 -> Full-bleed edge-to-edge wide lens (ZERO black borders!)
  // uBlackFrame = 1.0 -> Previous classic curved bodycam housing frame!
  vec2 computeFisheyeUv(vec2 uv, float fisheyeAmt, float frameAmt, out float outMask) {
    vec2 p = uv * 2.0 - 1.0;
    float aspect = uResolution.x / max(1.0, uResolution.y);

    // 1. Clean full-bleed normalized barrel warp (guaranteed in [0,1])
    float kClean = fisheyeAmt * 0.34;
    float ax = mix(1.0, aspect, 0.32);
    vec2 pa = vec2(p.x * ax, p.y);
    float r2Clean = dot(pa, pa);
    float maxR2 = ax * ax + 1.0;
    float scaleClean = (1.0 + kClean * r2Clean) / (1.0 + kClean * maxR2);
    vec2 uvClean = p * scaleClean * 0.5 + 0.5;

    // 2. Previous classic curved bodycam bezel warp
    float kRetro = 0.08 + fisheyeAmt * 0.26;
    vec2 pr = vec2(p.x * aspect, p.y);
    float r2Retro = dot(pr, pr);
    float zoomRetro = 1.0 - kRetro * 0.34;
    vec2 uvRetro = (p * (1.0 + kRetro * r2Retro + kRetro * 0.22 * r2Retro * r2Retro) * zoomRetro) * 0.5 + 0.5;

    // Smoothly morph between full-screen clean warp and curved retro frame!
    vec2 warped = mix(uvClean, uvRetro, frameAmt);

    // Out-of-lens rounded housing mask engages smoothly as uBlackFrame increases toward Filter Sebelumnya!
    vec2 edgeDist = abs(warped - 0.5) * 2.0;
    float maskRetro = 1.0 - smoothstep(0.985, 1.018, max(edgeDist.x, edgeDist.y));
    outMask = mix(1.0, maskRetro, smoothstep(0.15, 0.42, frameAmt));

    return warped;
  }

  // Lightweight high-quality FXAA sample for crisp anti-aliased world geometry
  vec3 sampleWorldFXAA(vec2 uv) {
    vec2 px = 1.0 / uResolution;
    vec3 rgbM  = texture2D(tWorld, uv).rgb;
    vec3 rgbNW = texture2D(tWorld, uv + vec2(-1.0, -1.0) * px).rgb;
    vec3 rgbNE = texture2D(tWorld, uv + vec2( 1.0, -1.0) * px).rgb;
    vec3 rgbSW = texture2D(tWorld, uv + vec2(-1.0,  1.0) * px).rgb;
    vec3 rgbSE = texture2D(tWorld, uv + vec2( 1.0,  1.0) * px).rgb;

    float lumaM  = getLuma(rgbM);
    float lumaNW = getLuma(rgbNW);
    float lumaNE = getLuma(rgbNE);
    float lumaSW = getLuma(rgbSW);
    float lumaSE = getLuma(rgbSE);

    float lumaMin = min(lumaM, min(min(lumaNW, lumaNE), min(lumaSW, lumaSE)));
    float lumaMax = max(lumaM, max(max(lumaNW, lumaNE), max(lumaSW, lumaSE)));
    float lumaRange = lumaMax - lumaMin;

    if (lumaRange < max(0.03, lumaMax * 0.085)) {
      return rgbM;
    }

    vec2 dir;
    dir.x = -((lumaNW + lumaNE) - (lumaSW + lumaSE));
    dir.y =  ((lumaNW + lumaSW) - (lumaNE + lumaSE));

    float dirReduce = max((lumaNW + lumaNE + lumaSW + lumaSE) * 0.03125, 0.0078125);
    float rcpDirMin = 1.0 / (min(abs(dir.x), abs(dir.y)) + dirReduce);
    dir = clamp(dir * rcpDirMin, vec2(-5.0), vec2(5.0)) * px;

    vec3 rgbA = 0.5 * (
      texture2D(tWorld, uv + dir * (1.0 / 3.0 - 0.5)).rgb +
      texture2D(tWorld, uv + dir * (2.0 / 3.0 - 0.5)).rgb
    );
    vec3 rgbB = rgbA * 0.5 + 0.25 * (
      texture2D(tWorld, uv + dir * -0.5).rgb +
      texture2D(tWorld, uv + dir *  0.5).rgb
    );

    float lumaB = getLuma(rgbB);
    return (lumaB < lumaMin || lumaB > lumaMax) ? rgbA : rgbB;
  }

  // Adjustable Dynamic Depth of Field Circle-of-Confusion
  float computeWorldCoC(float linearDist) {
    if (uDofStrength < 0.02) return 0.0;
    float d = min(linearDist, 230.0);
    float f = max(0.55, uFocusDist);

    float relDiff = abs(d - f) / max(d, f);
    float closeFactor = 1.0 - smoothstep(1.2, 18.0, f);
    // Wider deadzone when DoF slider is low -> razor crisp; tighter dreamy bokeh when DoF slider is high!
    float deadzone = mix(0.30, 0.08, max(closeFactor, uDofStrength * 0.55));
    float coc = smoothstep(deadzone, deadzone + 0.55, relDiff) * uDofStrength;
    return coc * mix(2.2, 5.8, max(closeFactor, uDofStrength * 0.45));
  }

  vec3 sampleWorldDoF(vec2 uv) {
    float centerDepth = linearizeDepth(texture2D(tWorldDepth, uv).r);
    float coc = computeWorldCoC(centerDepth);

    vec3 sharp = sampleWorldFXAA(uv);
    if (coc < 0.35) {
      return sharp;
    }

    vec2 texel = (1.0 / uResolution) * coc;
    vec3 acc = sharp * 1.4;
    float wSum = 1.4;

    vec2 offsets[8];
    offsets[0] = vec2( 1.0,  0.0);
    offsets[1] = vec2(-1.0,  0.0);
    offsets[2] = vec2( 0.0,  1.0);
    offsets[3] = vec2( 0.0, -1.0);
    offsets[4] = vec2( 0.58,  0.58);
    offsets[5] = vec2(-0.58,  0.58);
    offsets[6] = vec2( 0.58, -0.58);
    offsets[7] = vec2(-0.58, -0.58);

    for (int i = 0; i < 8; i++) {
      vec2 suv = clamp(uv + offsets[i] * texel, vec2(0.001), vec2(0.999));
      float sDepth = linearizeDepth(texture2D(tWorldDepth, suv).r);
      float sCoc = computeWorldCoC(sDepth);
      float w = (sDepth >= centerDepth - 0.6) ? 1.0 : clamp(sCoc / max(coc, 0.01), 0.12, 1.0);
      acc += texture2D(tWorld, suv).rgb * w;
      wSum += w;
    }
    return acc / wSum;
  }

  vec3 compositeRaw(vec2 uv) {
    vec3 w = texture2D(tWorld, uv).rgb;
    vec4 vm = texture2D(tVm, uv);
    return mix(w, vm.rgb, vm.a);
  }

  // AAA Clean Depth-Buffer Screen-Space Contact Ambient Occlusion (darkens corners, door trims, sills & under boots!)
  float computeContactSSAO(vec2 uv) {
    float cDepth = linearizeDepth(texture2D(tWorldDepth, uv).r);
    if (cDepth > 110.0) return 1.0; // sky / far mountains stay crisp & bright

    // Scale sampling radius in screen space inversely with distance so crevices stay physically consistent
    float radiusPx = clamp(24.0 / max(cDepth, 1.4), 3.0, 15.0);
    vec2 stepUv = (1.0 / uResolution) * radiusPx;
    float bias = 0.055 + cDepth * 0.012;
    float maxRange = 1.25 + cDepth * 0.05;

    float occ = 0.0;
    // 8 balanced compass & diagonal taps around pixel
    vec2 dirs[8];
    dirs[0] = vec2( 1.0,  0.0);
    dirs[1] = vec2(-1.0,  0.0);
    dirs[2] = vec2( 0.0,  1.0);
    dirs[3] = vec2( 0.0, -1.0);
    dirs[4] = vec2( 0.71,  0.71);
    dirs[5] = vec2(-0.71,  0.71);
    dirs[6] = vec2( 0.71, -0.71);
    dirs[7] = vec2(-0.71, -0.71);

    for (int i = 0; i < 8; i++) {
      vec2 suv = clamp(uv + dirs[i] * stepUv, vec2(0.002), vec2(0.998));
      float sDepth = linearizeDepth(texture2D(tWorldDepth, suv).r);
      float diff = cDepth - sDepth;
      if (diff > bias && diff < maxRange) {
        float rangeFade = 1.0 - smoothstep(bias, maxRange, diff);
        occ += rangeFade;
      }
    }
    // Smooth natural contact occlusion (up to ~34% crevice darkening — deep AAA grounding, zero muddy halos!)
    float ao = 1.0 - clamp((occ / 8.0) * 0.62, 0.0, 0.34);
    return mix(ao, 1.0, smoothstep(55.0, 110.0, cDepth));
  }

  void main() {
    // Clean bypass if Bodycam mode toggled OFF via [O] (still keeps crisp AAA SSAO & golden filmic tone!)
    if (uEnabled < 0.5) {
      vec3 rawW = sampleWorldFXAA(vUv) * computeContactSSAO(vUv);
      vec4 rawVm = texture2D(tVm, vUv);
      vec3 col = mix(rawW, rawVm.rgb, rawVm.a) * uBrightness;
      gl_FragColor = vec4(linearToSrgb(brightFilmic(col)), 1.0);
      return;
    }

    // 1. Adjustable Wide-Angle Fisheye & Optional Retro Curved Lens Frame
    float outMask = 1.0;
    vec2 uv = computeFisheyeUv(vUv, uFisheye, uBlackFrame, outMask);
    vec2 clampedUv = clamp(uv, vec2(0.001), vec2(0.999));

    // 2. Razor-Sharp World (FXAA + Dynamic DoF + Real Contact SSAO) + Crisp 4x MSAA Weapon & White Hands!
    float ssao = computeContactSSAO(clampedUv);
    vec3 worldCol = sampleWorldDoF(clampedUv) * ssao;
    vec4 vmSample = texture2D(tVm, clampedUv);
    vec3 baseCol = mix(worldCol, vmSample.rgb, vmSample.a);

    // 3. Adjustable Radial Chromatic Aberration
    vec2 radial = uv - 0.5;
    float r2 = dot(radial, radial);
    vec2 caShift = radial * (0.0005 + r2 * 0.0145) * uChromatic;
    float edgeWeight = smoothstep(0.02, 0.38, r2);

    vec3 color = baseCol;
    if (uChromatic > 0.02 && edgeWeight > 0.01) {
      vec3 colR = compositeRaw(clamp(clampedUv + caShift, vec2(0.001), vec2(0.999)));
      vec3 colB = compositeRaw(clamp(clampedUv - caShift, vec2(0.001), vec2(0.999)));
      color.r = mix(baseCol.r, colR.r, 0.78 * edgeWeight);
      color.b = mix(baseCol.b, colB.b, 0.78 * edgeWeight);
    }

    // 4. Bright Daylight Aggressive Auto-Exposure + Sun/Doorway Halation Glare
    float totalGain = uExposure * uBrightness;
    vec3 exposed = color * totalGain;
    if (uGlareStrength > 0.04) {
      vec2 gStep = (1.0 / uResolution) * (5.5 + uGlareStrength * 7.0);
      vec3 glare = vec3(0.0);
      vec3 s1 = compositeRaw(clamp(clampedUv + vec2( 1.0,  0.0) * gStep, 0.002, 0.998)) * totalGain;
      vec3 s2 = compositeRaw(clamp(clampedUv + vec2(-1.0,  0.0) * gStep, 0.002, 0.998)) * totalGain;
      vec3 s3 = compositeRaw(clamp(clampedUv + vec2( 0.0,  1.0) * gStep, 0.002, 0.998)) * totalGain;
      vec3 s4 = compositeRaw(clamp(clampedUv + vec2( 0.0, -1.0) * gStep, 0.002, 0.998)) * totalGain;
      glare += max(vec3(0.0), s1 - vec3(0.96));
      glare += max(vec3(0.0), s2 - vec3(0.96));
      glare += max(vec3(0.0), s3 - vec3(0.96));
      glare += max(vec3(0.0), s4 - vec3(0.96));
      exposed += glare * (0.16 * uGlareStrength);
    }

    // 4.5 AAA Cinematic Golden Sun Corona & Subtle Anamorphic Lens Flare (when looking near sun!)
    if (uSunFlare > 0.01) {
      float aspect = uResolution.x / max(1.0, uResolution.y);
      vec2 toSun = (clampedUv - uSunScreenPos) * vec2(aspect, 1.0);
      float sunDist = length(toSun);
      // Warm atmospheric golden corona
      float corona = exp(-sunDist * 3.4) * 0.36 + exp(-sunDist * 11.0) * 0.42;
      // Subtle horizontal anamorphic sunlight streak across lens!
      float anamorphic = exp(-abs(toSun.y) * 28.0) * exp(-abs(toSun.x) * 2.1) * 0.24;
      // Gentle opposite-corner optical ghost ring
      vec2 ghostPos = vec2(1.0) - uSunScreenPos;
      float ghostDist = length((clampedUv - ghostPos) * vec2(aspect, 1.0));
      float ghostRing = smoothstep(0.11, 0.06, abs(ghostDist - 0.12)) * 0.07;

      exposed += vec3(1.15, 0.88, 0.54) * (corona + anamorphic) * uSunFlare;
      exposed += vec3(0.75, 0.92, 1.08) * ghostRing * uSunFlare;
    }

    // 5. Luminous Bright-Daylight Filmic Tone Curve + Linear -> sRGB
    vec3 mapped = brightFilmic(exposed);
    // Preserve bright sunlit "silau" bloom when sensor genuinely overloads
    float overload = smoothstep(1.38, 2.5, max(exposed.r, max(exposed.g, exposed.b)));
    mapped = mix(mapped, vec3(1.0), overload * 0.45);

    color = linearToSrgb(mapped);

    // Subtle bodycam CMOS color response (keeps bright, lively sunlit palette!)
    float luma = getLuma(color);
    color = mix(vec3(luma), color, 0.94);
    color *= vec3(0.992, 1.002, 1.012);

    // 6. Adjustable Fine Sensor Grain (boosts naturally in dark CQB interior when ISO rises!)
    float isoBoost = 1.0 + max(0.0, uExposure - 1.15) * 1.4;
    vec2 grainCoord = gl_FragCoord.xy + vec2(fract(uTime * 23.17) * 512.0, fract(uTime * 37.91) * 512.0);
    float noise = (hash12(grainCoord) - 0.5) * 2.0;
    float shadowMask = mix(1.15, 0.45, luma);
    color += vec3(noise) * (uGrain * 0.048) * isoBoost * shadowMask;

    // 7. Adjustable Optical Vignette + Optional Curved Corner Darkening + Peripheral Damage Trauma Pulse
    vec2 vPos = (vUv - 0.5) * vec2(1.04, 1.04);
    float vDist = dot(vPos, vPos);
    float vigCurve = 1.0 - smoothstep(0.22, 0.94, vDist * (0.65 + uVignette * 0.72));
    float minCorner = mix(0.84, 0.34, uVignette);
    color *= mix(minCorner, 1.0, vigCurve) * outMask;

    if (uDamagePulse > 0.01) {
      float edgeBlood = smoothstep(0.16, 0.62, vDist) * uDamagePulse;
      color = mix(color, vec3(0.75, 0.06, 0.04), clamp(edgeBlood * 0.78, 0.0, 0.78));
    }

    gl_FragColor = vec4(clamp(color, 0.0, 1.0), 1.0);
  }
`;

export class BodycamPostPipeline {
  private worldRT: THREE.WebGLRenderTarget;
  private vmRT: THREE.WebGLRenderTarget;
  private postScene: THREE.Scene;
  private postCamera: THREE.OrthographicCamera;
  private material: THREE.ShaderMaterial;
  private quad: THREE.Mesh;

  constructor(renderer: THREE.WebGLRenderer, width: number, height: number) {
    const dpr = Math.min(window.devicePixelRatio, 2.0);
    const rtW = Math.max(2, Math.floor(width * dpr));
    const rtH = Math.max(2, Math.floor(height * dpr));

    const isWebGL2 = renderer.capabilities.isWebGL2;
    const texType = isWebGL2 ? THREE.HalfFloatType : THREE.UnsignedByteType;

    const depthTex = new THREE.DepthTexture(rtW, rtH);
    depthTex.type = isWebGL2 ? THREE.UnsignedIntType : THREE.UnsignedShortType;
    depthTex.format = THREE.DepthFormat;

    this.worldRT = new THREE.WebGLRenderTarget(rtW, rtH, {
      minFilter: THREE.LinearFilter,
      magFilter: THREE.LinearFilter,
      format: THREE.RGBAFormat,
      type: texType,
      depthBuffer: true,
      depthTexture: depthTex,
    });

    // Viewmodel target with hardware 4x MSAA so sculpted polygon hands & gun sights stay razor clean!
    this.vmRT = new THREE.WebGLRenderTarget(rtW, rtH, {
      minFilter: THREE.LinearFilter,
      magFilter: THREE.LinearFilter,
      format: THREE.RGBAFormat,
      type: texType,
      depthBuffer: true,
      samples: isWebGL2 ? 4 : 0,
    });

    this.postScene = new THREE.Scene();
    this.postCamera = new THREE.OrthographicCamera(-1, 1, 1, -1, 0, 1);

    this.material = new THREE.ShaderMaterial({
      vertexShader: VERT_SHADER,
      fragmentShader: FRAG_SHADER,
      depthTest: false,
      depthWrite: false,
      uniforms: {
        tWorld: { value: this.worldRT.texture },
        tWorldDepth: { value: this.worldRT.depthTexture },
        tVm: { value: this.vmRT.texture },
        uResolution: { value: new THREE.Vector2(rtW, rtH) },
        uTime: { value: 0 },
        uEnabled: { value: 1 },
        uExposure: { value: 1.05 },
        uBrightness: { value: 1.18 },
        uGlareStrength: { value: 0.15 },
        uFocusDist: { value: 14.0 },
        uDofStrength: { value: 0.35 },
        uFisheye: { value: 0.42 },
        uBlackFrame: { value: 0.14 },
        uChromatic: { value: 0.35 },
        uGrain: { value: 0.32 },
        uVignette: { value: 0.35 },
        uDamagePulse: { value: 0.0 },
        uSunScreenPos: { value: new THREE.Vector2(0.5, 0.5) },
        uSunFlare: { value: 0.0 },
        uNear: { value: 0.1 },
        uFar: { value: 700.0 },
      },
    });

    this.quad = new THREE.Mesh(new THREE.PlaneGeometry(2, 2), this.material);
    this.postScene.add(this.quad);
  }

  public setSize(width: number, height: number) {
    const dpr = Math.min(window.devicePixelRatio, 2.0);
    const rtW = Math.max(2, Math.floor(width * dpr));
    const rtH = Math.max(2, Math.floor(height * dpr));
    this.worldRT.setSize(rtW, rtH);
    this.vmRT.setSize(rtW, rtH);
    this.material.uniforms.uResolution.value.set(rtW, rtH);
  }

  public render(
    renderer: THREE.WebGLRenderer,
    worldScene: THREE.Scene,
    worldCamera: THREE.Camera,
    vmScene: THREE.Scene,
    vmCamera: THREE.Camera,
    renderViewmodel: boolean,
    params: BodycamParams
  ) {
    renderer.setRenderTarget(this.worldRT);
    renderer.setClearColor(0xa6daf7, 1);
    renderer.clear(true, true, true);
    renderer.render(worldScene, worldCamera);

    renderer.setRenderTarget(this.vmRT);
    renderer.setClearColor(0x000000, 0);
    renderer.clear(true, true, true);
    if (renderViewmodel) {
      renderer.render(vmScene, vmCamera);
    }

    const u = this.material.uniforms;
    u.uTime.value = params.time;
    u.uEnabled.value = params.enabled ? 1.0 : 0.0;
    u.uExposure.value = params.exposure;
    u.uBrightness.value = params.brightness;
    u.uGlareStrength.value = params.glareStrength;
    u.uFocusDist.value = params.focusDistance;
    u.uDofStrength.value = params.sniperScoped ? 0.0 : params.dofStrength;
    u.uFisheye.value = params.sniperScoped ? 0.05 : params.fisheyeStrength;
    u.uBlackFrame.value = params.sniperScoped ? 0.0 : params.blackFrameStrength;
    u.uChromatic.value = params.sniperScoped ? 0.12 : params.chromaticStrength;
    u.uGrain.value = params.grainStrength;
    u.uVignette.value = params.sniperScoped ? 0.25 : params.vignetteStrength;
    u.uNear.value = params.cameraNear;
    u.uFar.value = params.cameraFar;

    renderer.setRenderTarget(null);
    renderer.clear(true, true, false);
    renderer.render(this.postScene, this.postCamera);
  }

  public dispose() {
    this.worldRT.depthTexture?.dispose();
    this.worldRT.dispose();
    this.vmRT.dispose();
    this.quad.geometry.dispose();
    this.material.dispose();
  }
}
