import * as THREE from 'three';
import {
  getFeatheredGraffitiDecalMaterial,
  getSprayTagBannerMaterial,
  getWallMuralMaterial,
  getWeatheredConcreteTexture,
  getWoodenDoorTexture,
  GraffitiKey,
  WoodDoorStyle,
} from './graffitiTextures';
import { TargetEntity } from './worldBuilder';

export interface BoxCollider3D {
  minX: number;
  maxX: number;
  minY: number;
  maxY: number;
  minZ: number;
  maxZ: number;
  disabled?: boolean;
}

export interface InteractiveDoor {
  id: string;
  pivot: THREE.Group;
  center: THREE.Vector3;
  closedAngle: number;
  openAngle: number;
  isOpen: boolean;
  openProgress: number; // 0 = closed, 1 = swung open
  collider: BoxCollider3D;
  panelMeshes: THREE.Object3D[];
  floor: 0 | 1;
}

export interface BreakableGlassPane {
  id: string;
  mesh: THREE.Mesh;
  edgeShardsGroup: THREE.Group; // Jagged remaining glass teeth wedged inside window frame after full shatter!
  intactMat: THREE.Material;
  crackedMat?: THREE.Material;
  width: number;
  height: number;
  center: THREE.Vector3;
  stage: 0 | 1 | 2; // 0 = intact, 1 = spiderweb cracked with bullet hole, 2 = fully shattered!
  broken: boolean;
}

export interface NavNode {
  id: number;
  pos: THREE.Vector3;
  neighbors: number[];
  isCover: boolean;
  floor: 0 | 1;
  tag: string;
}

export interface CompoundContext {
  colliders3D: BoxCollider3D[];
  losMeshes: THREE.Object3D[]; // opaque walls/pillars/cover/doors for bot Line-of-Sight raycasts
  doors: InteractiveDoor[];
  doorHitMeshes: THREE.Object3D[];
  glassPanes: BreakableGlassPane[];
  glassHitMeshes: THREE.Object3D[];
  navNodes: NavNode[];
  targets: TargetEntity[];
  hitMeshes: THREE.Object3D[];
  burnLight: THREE.PointLight;
  flickerLights: THREE.PointLight[];
  dustMotes: THREE.Points;
  getFloorHeight: (x: number, z: number, currentFootY: number) => number;
  getIndoorDarkness: (x: number, y: number, z: number) => number;
}

const FLOOR2_Y = 4.2;

function makeTexturedBox(
  w: number,
  h: number,
  d: number,
  mat: THREE.Material | THREE.Material[],
  x: number,
  y: number,
  z: number
): THREE.Mesh {
  const geo = new THREE.BoxGeometry(w, h, d);
  const m = new THREE.Mesh(geo, mat);
  m.position.set(x, y, z);
  m.castShadow = true;
  m.receiveShadow = true;
  return m;
}

function makeFlatMesh(geo: THREE.BufferGeometry, mat: THREE.Material): THREE.Mesh {
  const g = geo.index ? geo.toNonIndexed() : geo;
  g.computeVertexNormals();
  const m = new THREE.Mesh(g, mat);
  m.castShadow = true;
  m.receiveShadow = true;
  return m;
}

/**
 * Places a feathered organic real-photo graffiti decal flush against any vertical concrete surface
 * facing +Z, -Z, +X, or -X with zero rectangular border and zero z-fighting!
 */
function addWallGraffitiDecal(
  parent: THREE.Group,
  key: GraffitiKey,
  x: number,
  y: number,
  z: number,
  w: number,
  h: number,
  facing: '+z' | '-z' | '+x' | '-x',
  opacity = 0.94
) {
  const aspect = w / Math.max(0.1, h);
  const mat = getFeatheredGraffitiDecalMaterial(key, opacity, aspect);
  const mesh = new THREE.Mesh(new THREE.PlaneGeometry(w, h), mat);
  const eps = 0.024;
  if (facing === '+z') {
    mesh.position.set(x, y, z + eps);
  } else if (facing === '-z') {
    mesh.position.set(x, y, z - eps);
    mesh.rotation.y = Math.PI;
  } else if (facing === '+x') {
    mesh.position.set(x + eps, y, z);
    mesh.rotation.y = Math.PI / 2;
  } else {
    mesh.position.set(x - eps, y, z);
    mesh.rotation.y = -Math.PI / 2;
  }
  mesh.receiveShadow = true;
  parent.add(mesh);
}

/**
 * Places a crisp transparent spray-painted gang tag banner on wide horizontal concrete parapets & headers!
 * Zero aspect distortion, zero squished photos!
 */
function addSprayTagBanner(
  parent: THREE.Group,
  text: string,
  primaryColor: string,
  outlineColor: string,
  accentColor: string,
  x: number,
  y: number,
  z: number,
  w: number,
  h: number,
  facing: '+z' | '-z' | '+x' | '-x'
) {
  const mat = getSprayTagBannerMaterial(text, primaryColor, outlineColor, accentColor);
  const mesh = new THREE.Mesh(new THREE.PlaneGeometry(w, h), mat);
  const eps = 0.026;
  if (facing === '+z') {
    mesh.position.set(x, y, z + eps);
  } else if (facing === '-z') {
    mesh.position.set(x, y, z - eps);
    mesh.rotation.y = Math.PI;
  } else if (facing === '+x') {
    mesh.position.set(x + eps, y, z);
    mesh.rotation.y = Math.PI / 2;
  } else {
    mesh.position.set(x - eps, y, z);
    mesh.rotation.y = -Math.PI / 2;
  }
  mesh.receiveShadow = true;
  parent.add(mesh);
}

/**
 * Places a wall-baked panoramic graffiti mural panel seamlessly flush into a concrete wall bay (exact aspect fit!).
 */
function addBakedMuralPanel(
  parent: THREE.Group,
  key: GraffitiKey,
  x: number,
  y: number,
  z: number,
  w: number,
  h: number,
  facing: '+z' | '-z' | '+x' | '-x',
  desat = 0.08
) {
  const aspect = w / Math.max(0.1, h);
  const mat = getWallMuralMaterial(key, desat, aspect);
  const mesh = new THREE.Mesh(new THREE.PlaneGeometry(w, h), mat);
  const eps = 0.018;
  if (facing === '+z') {
    mesh.position.set(x, y, z + eps);
  } else if (facing === '-z') {
    mesh.position.set(x, y, z - eps);
    mesh.rotation.y = Math.PI;
  } else if (facing === '+x') {
    mesh.position.set(x + eps, y, z);
    mesh.rotation.y = Math.PI / 2;
  } else {
    mesh.position.set(x - eps, y, z);
    mesh.rotation.y = -Math.PI / 2;
  }
  mesh.receiveShadow = true;
  parent.add(mesh);
}

export function buildGraffitiCompound(scene: THREE.Scene): CompoundContext {
  const group = new THREE.Group();
  scene.add(group);

  const colliders3D: BoxCollider3D[] = [];
  const losMeshes: THREE.Object3D[] = [];
  const doors: InteractiveDoor[] = [];
  const doorHitMeshes: THREE.Object3D[] = [];
  const glassPanes: BreakableGlassPane[] = [];
  const glassHitMeshes: THREE.Object3D[] = [];
  const targets: TargetEntity[] = [];
  const hitMeshes: THREE.Object3D[] = [];
  const flickerLights: THREE.PointLight[] = [];

  // Shared Real-Photo Concrete, Industrial & Architectural Materials
  const concreteWallMat = new THREE.MeshStandardMaterial({
    map: getWeatheredConcreteTexture('crackedWall', 3, 2, '#b0b5bc'),
    roughness: 0.92,
    metalness: 0.02,
  });
  const concreteDarkMat = new THREE.MeshStandardMaterial({
    map: getWeatheredConcreteTexture('grayPlaster', 2, 2, '#7d838b'),
    roughness: 0.94,
    metalness: 0.03,
  });
  const concreteTrimMat = new THREE.MeshStandardMaterial({
    map: getWeatheredConcreteTexture('grayPlaster', 2, 1, '#989da3'),
    roughness: 0.9,
    metalness: 0.04,
  });
  const concreteExteriorMat = new THREE.MeshStandardMaterial({
    map: getWeatheredConcreteTexture('shabbyExterior', 4, 2, '#bab6ab'),
    roughness: 0.91,
    metalness: 0.02,
  });
  const concreteFloorMat = new THREE.MeshStandardMaterial({
    map: getWeatheredConcreteTexture('industrialFloor', 8, 6, '#90959b'),
    roughness: 0.94,
    metalness: 0.02,
  });
  const yardAsphaltMat = new THREE.MeshStandardMaterial({
    map: getWeatheredConcreteTexture('industrialFloor', 6, 4, '#7a7e82'),
    roughness: 0.96,
    metalness: 0.02,
  });

  const rustMetalMat = new THREE.MeshStandardMaterial({ color: 0x4d413b, roughness: 0.78, metalness: 0.56, flatShading: true });
  const darkIronMat = new THREE.MeshStandardMaterial({ color: 0x262b31, roughness: 0.62, metalness: 0.66, flatShading: true });
  const steelFrameMat = new THREE.MeshStandardMaterial({ color: 0x1e2329, roughness: 0.58, metalness: 0.7, flatShading: true });
  const ductMetalMat = new THREE.MeshStandardMaterial({ color: 0x7b838c, roughness: 0.52, metalness: 0.64, flatShading: true });
  // Authentic Architectural Building Timber Door Materials (Natural Wood Grain + Recessed Panel Depth!)
  const doorOakMat = new THREE.MeshStandardMaterial({
    map: getWoodenDoorTexture('oak'),
    roughness: 0.78,
    metalness: 0.03,
  });
  const doorOakInsetMat = new THREE.MeshStandardMaterial({
    map: getWoodenDoorTexture('oak'),
    color: 0xd9c7b4,
    roughness: 0.84,
    metalness: 0.02,
  });
  const doorMahoganyMat = new THREE.MeshStandardMaterial({
    map: getWoodenDoorTexture('mahogany'),
    roughness: 0.74,
    metalness: 0.04,
  });
  const doorMahoganyInsetMat = new THREE.MeshStandardMaterial({
    map: getWoodenDoorTexture('mahogany'),
    color: 0xd8c2b8,
    roughness: 0.8,
    metalness: 0.03,
  });
  const doorPaintedMat = new THREE.MeshStandardMaterial({
    map: getWoodenDoorTexture('paintedWood'),
    roughness: 0.82,
    metalness: 0.04,
  });
  const doorPaintedInsetMat = new THREE.MeshStandardMaterial({
    map: getWoodenDoorTexture('paintedWood'),
    color: 0xc9d2d4,
    roughness: 0.86,
    metalness: 0.03,
  });
  const woodFrameMat = new THREE.MeshStandardMaterial({ color: 0x3b281a, roughness: 0.82, metalness: 0.03, flatShading: true });
  const handleBrassMat = new THREE.MeshStandardMaterial({ color: 0xd4b26a, roughness: 0.3, metalness: 0.85, flatShading: true });
  const kickBronzeMat = new THREE.MeshStandardMaterial({ color: 0x5c4731, roughness: 0.48, metalness: 0.62, flatShading: true });
  const plankWoodMat = new THREE.MeshStandardMaterial({ color: 0x997349, roughness: 0.9, flatShading: true });

  // Realistic Dusty Architectural Window Glass (transparent, tinted, subtle reflection — cracks & shatters!)
  const windowGlassMat = new THREE.MeshStandardMaterial({
    color: 0x9ec4d4,
    emissive: 0x1a313b,
    emissiveIntensity: 0.24,
    roughness: 0.12,
    metalness: 0.42,
    transparent: true,
    opacity: 0.36,
    side: THREE.DoubleSide,
    depthWrite: false,
  });

  // Jagged Remaining Glass Teeth wedged inside smashed window frames (glints realistically in sunlight!)
  const brokenEdgeGlassMat = new THREE.MeshStandardMaterial({
    color: 0xd9f2ff,
    emissive: 0x4b778a,
    emissiveIntensity: 0.32,
    roughness: 0.08,
    metalness: 0.5,
    transparent: true,
    opacity: 0.62,
    side: THREE.DoubleSide,
    depthWrite: false,
    flatShading: true,
  });

  /**
   * Generates authentic jagged broken glass teeth permanently stuck around the 4 corners & edges
   * of a shattered window pane so smashed frames look unmistakably broken!
   */
  const createFrameEdgeShards = (paneW: number, paneH: number, seed: number): THREE.Group => {
    const g = new THREE.Group();
    const hw = paneW / 2;
    const hh = paneH / 2;
    const positions: number[] = [];

    const pushTri = (a: [number, number], b: [number, number], c: [number, number]) => {
      positions.push(a[0], a[1], 0, b[0], b[1], 0, c[0], c[1], 0);
    };
    const rnd = (s: number) => {
      const v = Math.sin((seed + s) * 91.7) * 43758.5453;
      return v - Math.floor(v);
    };

    // 4 Corner Jagged Glass Wedges + 4 Mid-Edge Sharp Teeth!
    const cScale = Math.min(paneW, paneH) * 0.22;
    // Bottom-Left
    pushTri([-hw, -hh], [-hw + cScale * (0.7 + rnd(1) * 0.7), -hh], [-hw, -hh + cScale * (0.7 + rnd(2) * 0.7)]);
    // Bottom-Right
    pushTri([hw, -hh], [hw, -hh + cScale * (0.7 + rnd(3) * 0.7)], [hw - cScale * (0.7 + rnd(4) * 0.7), -hh]);
    // Top-Left
    pushTri([-hw, hh], [-hw, hh - cScale * (0.7 + rnd(5) * 0.7)], [-hw + cScale * (0.7 + rnd(6) * 0.7), hh]);
    // Top-Right
    pushTri([hw, hh], [hw - cScale * (0.7 + rnd(7) * 0.7), hh], [hw, hh - cScale * (0.7 + rnd(8) * 0.7)]);
    // Bottom mid spike
    const bx = (rnd(9) - 0.5) * hw * 0.8;
    pushTri([bx - cScale * 0.4, -hh], [bx + cScale * 0.45, -hh], [bx + (rnd(10) - 0.5) * 0.08, -hh + cScale * (0.45 + rnd(11) * 0.55)]);
    // Top mid spike
    const tx = (rnd(12) - 0.5) * hw * 0.8;
    pushTri([tx - cScale * 0.35, hh], [tx + (rnd(13) - 0.5) * 0.08, hh - cScale * (0.4 + rnd(14) * 0.5)], [tx + cScale * 0.4, hh]);

    const geo = new THREE.BufferGeometry();
    geo.setAttribute('position', new THREE.Float32BufferAttribute(positions, 3));
    geo.computeVertexNormals();
    const mesh = new THREE.Mesh(geo, brokenEdgeGlassMat);
    mesh.userData.isFx = true;
    g.add(mesh);
    g.visible = false;
    return g;
  };

  const containerBlueMat = new THREE.MeshStandardMaterial({ color: 0x2f536e, roughness: 0.72, metalness: 0.35, flatShading: true });
  const vanBodyMat = new THREE.MeshStandardMaterial({ color: 0xbcb8ae, roughness: 0.76, metalness: 0.15, flatShading: true });
  const vanRustMat = new THREE.MeshStandardMaterial({ color: 0x6b4b3b, roughness: 0.85, flatShading: true });
  const crateWoodMat = new THREE.MeshStandardMaterial({ color: 0xae814e, roughness: 0.88, flatShading: true });
  const crateTrimMat = new THREE.MeshStandardMaterial({ color: 0x7f5a32, roughness: 0.9, flatShading: true });
  const barrelRedMat = new THREE.MeshStandardMaterial({ color: 0xc9352b, roughness: 0.52, metalness: 0.28, flatShading: true });
  const barrelStripeMat = new THREE.MeshStandardMaterial({ color: 0xe6c84a, roughness: 0.55, flatShading: true });
  const sandbagMat = new THREE.MeshStandardMaterial({ color: 0x9b8e73, roughness: 0.94, flatShading: true });
  const rubbleMat = new THREE.MeshStandardMaterial({ color: 0x7b8086, roughness: 0.95, flatShading: true });
  const tireMat = new THREE.MeshStandardMaterial({ color: 0x202327, roughness: 0.9, flatShading: true });
  const cityBgMat = new THREE.MeshStandardMaterial({ color: 0x8ea1b0, roughness: 0.94, flatShading: true });
  const weedMat = new THREE.MeshStandardMaterial({ color: 0x678349, roughness: 0.92, flatShading: true });
  const deskMetalMat = new THREE.MeshStandardMaterial({ color: 0x454d55, roughness: 0.72, metalness: 0.42, flatShading: true });
  const couchMat = new THREE.MeshStandardMaterial({ color: 0x5c3e32, roughness: 0.92, flatShading: true });
  const lampGlowMat = new THREE.MeshBasicMaterial({ color: 0xffe4b8 });
  const ledRedMat = new THREE.MeshBasicMaterial({ color: 0xff3b30 });
  const ledGreenMat = new THREE.MeshBasicMaterial({ color: 0x34d399 });

  const addSolidBox = (
    x: number,
    y: number,
    z: number,
    w: number,
    h: number,
    d: number,
    mat: THREE.Material,
    collide = true,
    blocksLos = true,
    padXZ = 0.34
  ) => {
    const mesh = makeTexturedBox(w, h, d, mat, x, y, z);
    group.add(mesh);
    if (blocksLos) losMeshes.push(mesh);
    if (collide) {
      colliders3D.push({
        minX: x - w / 2 - padXZ,
        maxX: x + w / 2 + padXZ,
        minY: y - h / 2,
        maxY: y + h / 2,
        minZ: z - d / 2 - padXZ,
        maxZ: z + d / 2 + padXZ,
      });
    }
    return mesh;
  };

  // =========================================================================
  // ARCHITECTURAL HELPERS: FRAMED MULTI-PANE WINDOWS & INTERACTIVE SWINGING DOORS!
  // =========================================================================
  let glassCounter = 0;

  /**
   * Builds a rich architectural framed multi-pane factory/office window with:
   * - Protruding concrete sill & upper header lintel
   * - Dark steel outer frame + vertical mullions + horizontal transom bar
   * - Real translucent breakable glass panes (each pane shatters individually when shot!)
   * - Optional nailed weathered wooden plank barricade or missing pre-shattered panes
   */
  const addFramedWindow = (opts: {
    x: number;
    yBot: number;
    z: number;
    width: number;
    height: number;
    axis: 'x' | 'z'; // 'x' = spans along X (wall facing ±Z), 'z' = spans along Z (wall facing ±X)
    cols?: number;
    rows?: number;
    wallThick?: number;
    brokenIndices?: number[];
    boarded?: boolean;
    addSill?: boolean;
  }) => {
    const {
      x,
      yBot,
      z,
      width,
      height,
      axis,
      cols = 3,
      rows = 2,
      wallThick = 0.55,
      brokenIndices = [],
      boarded = false,
      addSill = true,
    } = opts;

    const winGroup = new THREE.Group();
    winGroup.position.set(x, yBot + height / 2, z);
    if (axis === 'z') {
      winGroup.rotation.y = Math.PI / 2;
    }
    group.add(winGroup);

    const frameT = 0.085;
    const frameD = wallThick + 0.06;

    // Concrete protruding window sill (bottom) & drip header (top)
    if (addSill) {
      const sill = makeFlatMesh(new THREE.BoxGeometry(width + 0.24, 0.14, wallThick + 0.28), concreteTrimMat);
      sill.position.set(0, -height / 2 - 0.04, 0);
      winGroup.add(sill);

      const header = makeFlatMesh(new THREE.BoxGeometry(width + 0.2, 0.12, wallThick + 0.16), concreteTrimMat);
      header.position.set(0, height / 2 + 0.04, 0);
      winGroup.add(header);
    }

    // Outer Steel Perimeter Frame (Top, Bottom, Left, Right)
    const fTop = makeFlatMesh(new THREE.BoxGeometry(width, frameT, frameD), steelFrameMat);
    fTop.position.set(0, height / 2 - frameT / 2, 0);
    const fBot = makeFlatMesh(new THREE.BoxGeometry(width, frameT, frameD), steelFrameMat);
    fBot.position.set(0, -height / 2 + frameT / 2, 0);
    const fLeft = makeFlatMesh(new THREE.BoxGeometry(frameT, height, frameD), steelFrameMat);
    fLeft.position.set(-width / 2 + frameT / 2, 0, 0);
    const fRight = makeFlatMesh(new THREE.BoxGeometry(frameT, height, frameD), steelFrameMat);
    fRight.position.set(width / 2 - frameT / 2, 0, 0);
    winGroup.add(fTop, fBot, fLeft, fRight);

    const innerW = width - frameT * 2;
    const innerH = height - frameT * 2;
    const cellW = innerW / cols;
    const cellH = innerH / rows;

    // Vertical Steel Mullions
    for (let c = 1; c < cols; c++) {
      const mx = -innerW / 2 + c * cellW;
      const mullion = makeFlatMesh(new THREE.BoxGeometry(0.055, innerH, 0.09), steelFrameMat);
      mullion.position.set(mx, 0, 0);
      winGroup.add(mullion);
    }
    // Horizontal Steel Transoms
    for (let r = 1; r < rows; r++) {
      const my = -innerH / 2 + r * cellH;
      const transom = makeFlatMesh(new THREE.BoxGeometry(innerW, 0.055, 0.09), steelFrameMat);
      transom.position.set(0, my, 0);
      winGroup.add(transom);
    }

    // Individual Shootable / 2-Stage Crackable & Shatterable Translucent Glass Panes!
    let paneIdx = 0;
    for (let r = 0; r < rows; r++) {
      for (let c = 0; c < cols; c++) {
        const isPreBroken = brokenIndices.includes(paneIdx);
        paneIdx++;

        const px = -innerW / 2 + (c + 0.5) * cellW;
        const py = -innerH / 2 + (r + 0.5) * cellH;
        const pw = cellW - 0.03;
        const ph = cellH - 0.03;
        const edgeShardsGroup = createFrameEdgeShards(pw, ph, glassCounter * 7 + r * 3 + c);
        edgeShardsGroup.position.set(px, py, 0);
        winGroup.add(edgeShardsGroup);

        if (isPreBroken) {
          // Even pre-broken abandoned window panes show jagged glass teeth clinging to the frame!
          edgeShardsGroup.visible = true;
          continue;
        }

        const gid = `glass-${glassCounter++}`;
        const pane = new THREE.Mesh(new THREE.PlaneGeometry(pw, ph), windowGlassMat);
        pane.position.set(px, py, 0);
        pane.userData = { glassId: gid };
        winGroup.add(pane);

        const localPt = new THREE.Vector3(px, py, 0);
        if (axis === 'z') localPt.applyAxisAngle(new THREE.Vector3(0, 1, 0), Math.PI / 2);
        const worldCenter = new THREE.Vector3(x + localPt.x, yBot + height / 2 + localPt.y, z + localPt.z);

        glassPanes.push({
          id: gid,
          mesh: pane,
          edgeShardsGroup,
          intactMat: windowGlassMat,
          width: pw,
          height: ph,
          center: worldCenter,
          stage: 0,
          broken: false,
        });
        glassHitMeshes.push(pane);
      }
    }

    // Optional weathered diagonal wooden barricade plank across bottom portion of abandoned factory window
    if (boarded) {
      const plank = makeFlatMesh(new THREE.BoxGeometry(width * 0.92, 0.22, 0.06), plankWoodMat);
      plank.position.set(0, -height * 0.18, wallThick * 0.42);
      plank.rotation.z = 0.14;
      winGroup.add(plank);
    }
  };

  /**
   * Builds a solid concrete wall bay WITH a genuine framed multi-pane window opening cut out of it!
   * Guarantees zero overlapping geometry and exact crouch-height cover beneath the sill!
   */
  const addWallBayWithWindow = (opts: {
    x: number;
    yFloor: number;
    z: number;
    bayLen: number;
    bayHeight: number;
    winWidth: number;
    winSillH: number; // height of solid wall under window (e.g. 1.15m = perfect crouch cover!)
    winHeight: number;
    axis: 'x' | 'z';
    wallMat: THREE.Material;
    wallThick?: number;
    cols?: number;
    rows?: number;
    brokenIndices?: number[];
    boarded?: boolean;
  }) => {
    const {
      x,
      yFloor,
      z,
      bayLen,
      bayHeight,
      winWidth,
      winSillH,
      winHeight,
      axis,
      wallMat,
      wallThick = 0.55,
      cols = 3,
      rows = 2,
      brokenIndices = [],
      boarded = false,
    } = opts;

    const sideW = Math.max(0.25, (bayLen - winWidth) / 2);
    const headerH = Math.max(0.25, bayHeight - winSillH - winHeight);
    const winTopY = yFloor + winSillH + winHeight;

    if (axis === 'x') {
      // Lower wall under window (solid crouch cover!)
      addSolidBox(x, yFloor + winSillH / 2, z, bayLen, winSillH, wallThick, wallMat, true, true, 0.3);
      // Upper header wall above window
      addSolidBox(x, winTopY + headerH / 2, z, bayLen, headerH, wallThick, wallMat, false, true);
      // Left & Right wall piers flanking window
      const pierOffset = winWidth / 2 + sideW / 2;
      addSolidBox(x - pierOffset, yFloor + winSillH + winHeight / 2, z, sideW, winHeight, wallThick, wallMat, true, true, 0.28);
      addSolidBox(x + pierOffset, yFloor + winSillH + winHeight / 2, z, sideW, winHeight, wallThick, wallMat, true, true, 0.28);
    } else {
      addSolidBox(x, yFloor + winSillH / 2, z, wallThick, winSillH, bayLen, wallMat, true, true, 0.3);
      addSolidBox(x, winTopY + headerH / 2, z, wallThick, headerH, bayLen, wallMat, false, true);
      const pierOffset = winWidth / 2 + sideW / 2;
      addSolidBox(x, yFloor + winSillH + winHeight / 2, z - pierOffset, wallThick, winHeight, sideW, wallMat, true, true, 0.28);
      addSolidBox(x, yFloor + winSillH + winHeight / 2, z + pierOffset, wallThick, winHeight, sideW, wallMat, true, true, 0.28);
    }

    addFramedWindow({
      x,
      yBot: yFloor + winSillH,
      z,
      width: winWidth,
      height: winHeight,
      axis,
      cols,
      rows,
      wallThick,
      brokenIndices,
      boarded,
      addSill: true,
    });
  };

  /**
   * Builds a REALISTIC CLASSIC ARCHITECTURAL WOODEN BUILDING DOOR (Pintu Kayu Panel Khas Gedung!):
   * - Stepped solid timber casing & classic upper architrave molding around doorway
   * - True 3D multi-panel carved wood construction: thick outer stiles, top/lock/bottom rails,
   *   and deeply recessed wooden lower panels with natural vertical oak/mahogany/painted wood grain!
   * - Optional classic divided wooden upper window pane (with real 2-stage crackable & shatterable glass!)
   * - Realistic brass mortise lock plate, curved lever handle, keyhole escutcheon, bronze kickplate, & 3 brass hinges!
   * - Supports `hingeSide: 'left' | 'right'` & `omitJamb` for seamless symmetrical Double Entrance Doors!
   */
  const addInteractiveDoor = (opts: {
    id: string;
    x: number;
    yFloor: number;
    z: number;
    width: number;
    height: number;
    axis: 'x' | 'z'; // 'x' = spans X (passage along Z), 'z' = spans Z (passage along X)
    hingeSide?: 'left' | 'right';
    omitJamb?: 'left' | 'right';
    swingDir?: 1 | -1; // +1 = rotates +Y, -1 = rotates -Y
    style?: WoodDoorStyle;
    startOpen?: boolean;
    withWindow?: boolean;
    wallThick?: number;
  }) => {
    const {
      id,
      x,
      yFloor,
      z,
      width,
      height,
      axis,
      hingeSide = 'left',
      omitJamb,
      swingDir = 1,
      style = 'oak',
      startOpen = false,
      withWindow = true,
      wallThick = 0.55,
    } = opts;

    const frameGroup = new THREE.Group();
    frameGroup.position.set(x, yFloor, z);
    if (axis === 'z') frameGroup.rotation.y = Math.PI / 2;
    group.add(frameGroup);

    const jambT = 0.1;
    const frameD = wallThick + 0.08;
    const casingD = wallThick + 0.14;
    const leftGap = omitJamb === 'left' ? 0.01 : jambT;
    const rightGap = omitJamb === 'right' ? 0.01 : jambT;

    // 1. Stepped Solid Timber Door Casing, Architrave Header Molding & Floor Threshold!
    if (omitJamb !== 'left') {
      const jL = makeFlatMesh(new THREE.BoxGeometry(jambT, height, frameD), woodFrameMat);
      jL.position.set(-width / 2 + jambT / 2, height / 2, 0);
      const trimL = makeFlatMesh(new THREE.BoxGeometry(0.065, height + 0.08, casingD), woodFrameMat);
      trimL.position.set(-width / 2 - 0.01, height / 2 + 0.04, 0);
      frameGroup.add(jL, trimL);
    }
    if (omitJamb !== 'right') {
      const jR = makeFlatMesh(new THREE.BoxGeometry(jambT, height, frameD), woodFrameMat);
      jR.position.set(width / 2 - jambT / 2, height / 2, 0);
      const trimR = makeFlatMesh(new THREE.BoxGeometry(0.065, height + 0.08, casingD), woodFrameMat);
      trimR.position.set(width / 2 + 0.01, height / 2 + 0.04, 0);
      frameGroup.add(jR, trimR);
    }
    const jTop = makeFlatMesh(new THREE.BoxGeometry(width, jambT, frameD), woodFrameMat);
    jTop.position.set(0, height - jambT / 2, 0);
    // Protruding classic wooden header architrave cornice molding
    const crownTop = makeFlatMesh(new THREE.BoxGeometry(width + 0.14, 0.095, casingD + 0.04), woodFrameMat);
    crownTop.position.set(0, height + 0.035, 0);
    const thresh = makeFlatMesh(new THREE.BoxGeometry(width, 0.032, frameD + 0.08), kickBronzeMat);
    thresh.position.set(0, 0.016, 0);
    frameGroup.add(jTop, crownTop, thresh);

    // 2. Hinged Wooden Door Leaf Pivot (Left or Right Jamb!)
    const leafW = width - leftGap - rightGap - 0.015;
    const leafH = height - jambT - 0.035;
    const stileT = 0.072; // authentic thick architectural solid-wood door thickness
    const dir = hingeSide === 'left' ? 1 : -1;

    const pivot = new THREE.Group();
    const pivotX = hingeSide === 'left' ? -width / 2 + leftGap + 0.006 : width / 2 - rightGap - 0.006;
    pivot.position.set(pivotX, 0.025, 0);
    frameGroup.add(pivot);

    // Helper: positions a box in leaf-local coordinates (u = 0 at hinge edge, u = leafW at latch edge!)
    const leafMat = style === 'mahogany' ? doorMahoganyMat : style === 'paintedWood' ? doorPaintedMat : doorOakMat;
    const insetMat =
      style === 'mahogany' ? doorMahoganyInsetMat : style === 'paintedWood' ? doorPaintedInsetMat : doorOakInsetMat;
    const panelMeshes: THREE.Object3D[] = [];

    const addDoorWood = (uCenter: number, yCenter: number, w: number, h: number, d: number, mat: THREE.Material, solidLos = true) => {
      const mesh = makeTexturedBox(w, h, d, mat, dir * uCenter, yCenter, 0);
      mesh.userData = { doorId: id };
      pivot.add(mesh);
      panelMeshes.push(mesh);
      doorHitMeshes.push(mesh);
      if (solidLos) losMeshes.push(mesh);
      return mesh;
    };

    // 3. TRUE 3D SCULPTED MULTI-PANEL WOODEN DOOR ARCHITECTURE!
    const stileW = Math.min(0.16, leafW * 0.14);
    const innerW = leafW - stileW * 2;
    const bottomRailH = 0.28;
    const midRailY = 1.08;
    const midRailH = 0.18;
    const topRailH = 0.18;

    // Left & Right Full-Height Vertical Wood Stiles
    addDoorWood(stileW / 2, leafH / 2, stileW, leafH, stileT, leafMat);
    addDoorWood(leafW - stileW / 2, leafH / 2, stileW, leafH, stileT, leafMat);
    // Bottom, Middle (Lock), & Top Horizontal Wood Rails
    addDoorWood(leafW / 2, bottomRailH / 2, innerW, bottomRailH, stileT, leafMat);
    addDoorWood(leafW / 2, midRailY, innerW, midRailH, stileT, leafMat);
    addDoorWood(leafW / 2, leafH - topRailH / 2, innerW, topRailH, stileT, leafMat);

    // Lower Recessed Carved Double Wood Panels (between bottomRail and midRail -> true recessed shadow depth!)
    const lowZoneBot = bottomRailH;
    const lowZoneTop = midRailY - midRailH / 2;
    const lowZoneH = lowZoneTop - lowZoneBot;
    const lowCenterY = (lowZoneBot + lowZoneTop) / 2;
    const centerMullionW = 0.085;
    // Recessed thin backing panel + raised center beveled wooden bosses!
    addDoorWood(leafW / 2, lowCenterY, innerW, lowZoneH, stileT * 0.44, insetMat);
    if (innerW > 0.65) {
      // Classic 2-column recessed lower wood panels with vertical center stile!
      addDoorWood(leafW / 2, lowCenterY, centerMullionW, lowZoneH, stileT * 0.94, leafMat, false);
      const subW = (innerW - centerMullionW) / 2 - 0.07;
      const leftSubU = stileW + (innerW - centerMullionW) * 0.25;
      const rightSubU = leafW - stileW - (innerW - centerMullionW) * 0.25;
      addDoorWood(leftSubU, lowCenterY, subW, lowZoneH - 0.12, stileT * 0.72, leafMat, false);
      addDoorWood(rightSubU, lowCenterY, subW, lowZoneH - 0.12, stileT * 0.72, leafMat, false);
    } else {
      addDoorWood(leafW / 2, lowCenterY, innerW - 0.1, lowZoneH - 0.12, stileT * 0.72, leafMat, false);
    }

    // Upper Door Section: Either Classic 4-Pane Wood-Framed Glass Window OR Carved Recessed Upper Wood Panels!
    const upZoneBot = midRailY + midRailH / 2;
    const upZoneTop = leafH - topRailH;
    const upZoneH = upZoneTop - upZoneBot;
    const upCenterY = (upZoneBot + upZoneTop) / 2;

    if (withWindow) {
      // Classic Wooden Divided-Light Upper Door Window (2x2 wooden mullions + breakable glass panes!)
      const glassCols = innerW > 0.75 ? 2 : 1;
      const glassRows = 2;
      const gCellW = innerW / glassCols;
      const gCellH = upZoneH / glassRows;

      // Wooden inner glazing muntin bars dividing the upper glass into classic panes!
      if (glassCols === 2) {
        addDoorWood(leafW / 2, upCenterY, 0.048, upZoneH, stileT * 0.8, woodFrameMat, false);
      }
      addDoorWood(leafW / 2, upCenterY, innerW, 0.048, stileT * 0.8, woodFrameMat, false);

      for (let gr = 0; gr < glassRows; gr++) {
        for (let gc = 0; gc < glassCols; gc++) {
          const uPane = stileW + (gc + 0.5) * gCellW;
          const yPane = upZoneBot + (gr + 0.5) * gCellH;
          const pw = gCellW - 0.045;
          const ph = gCellH - 0.045;

          const edgeShardsGroup = createFrameEdgeShards(pw, ph, glassCounter * 11 + gr * 5 + gc);
          edgeShardsGroup.position.set(dir * uPane, yPane, 0);
          pivot.add(edgeShardsGroup);

          const gid = `glass-${glassCounter++}`;
          const pane = new THREE.Mesh(new THREE.PlaneGeometry(pw, ph), windowGlassMat);
          pane.position.set(dir * uPane, yPane, 0);
          pane.userData = { glassId: gid };
          pivot.add(pane);

          glassPanes.push({
            id: gid,
            mesh: pane,
            edgeShardsGroup,
            intactMat: windowGlassMat,
            width: pw,
            height: ph,
            center: new THREE.Vector3(x, yFloor + yPane, z),
            stage: 0,
            broken: false,
          });
          glassHitMeshes.push(pane);
        }
      }
    } else {
      // Solid Upper Recessed Carved Wood Panels
      addDoorWood(leafW / 2, upCenterY, innerW, upZoneH, stileT * 0.46, insetMat);
      addDoorWood(leafW / 2, upCenterY, innerW - 0.12, upZoneH - 0.14, stileT * 0.74, leafMat, false);
    }

    // 4. REALISTIC BRASS MORTISE LOCK PLATE, CURVED LEVER HANDLE, BRONZE KICKPLATE & 3 BARREL HINGES!
    const kickPlate = makeFlatMesh(new THREE.BoxGeometry(leafW - 0.04, 0.22, stileT + 0.012), kickBronzeMat);
    kickPlate.position.set(dir * (leafW / 2), 0.13, 0);
    pivot.add(kickPlate);

    // 3 Brass Barrel Hinges along Hinge Edge (u = 0)
    [0.32, leafH * 0.5, leafH - 0.28].forEach((hy) => {
      const hinge = makeFlatMesh(new THREE.CylinderGeometry(0.014, 0.014, 0.11, 6), handleBrassMat);
      hinge.position.set(0, hy, 0);
      pivot.add(hinge);
    });

    // Brass Mortise Backplate + Lever Handle + Spindle on BOTH sides of the latch stile!
    const handleU = leafW - stileW * 0.55;
    [-1, 1].forEach((faceZ) => {
      const escutcheon = makeFlatMesh(new THREE.BoxGeometry(0.048, 0.21, 0.014), handleBrassMat);
      escutcheon.position.set(dir * handleU, 1.04, faceZ * (stileT / 2 + 0.006));
      const spindle = makeFlatMesh(new THREE.CylinderGeometry(0.012, 0.012, 0.048, 6), handleBrassMat);
      spindle.rotation.x = Math.PI / 2;
      spindle.position.set(dir * handleU, 1.07, faceZ * (stileT / 2 + 0.025));
      const lever = makeFlatMesh(new THREE.BoxGeometry(0.135, 0.024, 0.022), handleBrassMat);
      lever.position.set(dir * (handleU - 0.055), 1.07, faceZ * (stileT / 2 + 0.046));
      pivot.add(escutcheon, spindle, lever);
    });

    // Dynamic Door Collider (disabled whenever door swings open!)
    const collider: BoxCollider3D =
      axis === 'x'
        ? {
            minX: x - width / 2 - 0.08,
            maxX: x + width / 2 + 0.08,
            minY: yFloor,
            maxY: yFloor + height,
            minZ: z - 0.34,
            maxZ: z + 0.34,
            disabled: startOpen,
          }
        : {
            minX: x - 0.34,
            maxX: x + 0.34,
            minY: yFloor,
            maxY: yFloor + height,
            minZ: z - width / 2 - 0.08,
            maxZ: z + width / 2 + 0.08,
            disabled: startOpen,
          };
    colliders3D.push(collider);

    const closedAngle = 0;
    const openAngle = swingDir * 1.62;
    const initialProgress = startOpen ? 1.0 : 0.0;
    pivot.rotation.y = closedAngle + (openAngle - closedAngle) * initialProgress;

    doors.push({
      id,
      pivot,
      center: new THREE.Vector3(x, yFloor + 1.2, z),
      closedAngle,
      openAngle,
      isOpen: startOpen,
      openProgress: initialProgress,
      collider,
      panelMeshes,
      floor: yFloor > 2 ? 1 : 0,
    });
  };

  /**
   * Builds a hanging industrial fluorescent tube fixture + soft ceiling point light
   */
  const addHangingLamp = (x: number, ceilingY: number, z: number, colorHex: number, intensity: number, flickers = false) => {
    const rodL = makeFlatMesh(new THREE.BoxGeometry(0.04, 0.52, 0.04), darkIronMat);
    rodL.position.set(x - 0.55, ceilingY - 0.26, z);
    const rodR = makeFlatMesh(new THREE.BoxGeometry(0.04, 0.52, 0.04), darkIronMat);
    rodR.position.set(x + 0.55, ceilingY - 0.26, z);
    const hood = makeFlatMesh(new THREE.BoxGeometry(1.5, 0.1, 0.26), darkIronMat);
    hood.position.set(x, ceilingY - 0.52, z);
    const tube = new THREE.Mesh(new THREE.BoxGeometry(1.36, 0.06, 0.12), lampGlowMat);
    tube.position.set(x, ceilingY - 0.58, z);
    group.add(rodL, rodR, hood, tube);

    const light = new THREE.PointLight(colorHex, intensity, 15, 1.45);
    light.position.set(x, ceilingY - 0.85, z);
    group.add(light);
    if (flickers) flickerLights.push(light);
  };

  // =========================================================================
  // 1. GROUND SLAB, OUTDOOR COURTYARD & PERIMETER WALLS
  // =========================================================================
  const interiorFloor = makeTexturedBox(41, 0.24, 29, concreteFloorMat, 0, -0.12, -4);
  group.add(interiorFloor);

  // Extended Courtyard Asphalt (Z: +10..+32) + Vestibule Concrete Landing Slab
  const yardFloor = makeTexturedBox(56, 0.24, 22, yardAsphaltMat, 0, -0.13, 21);
  group.add(yardFloor);
  const porticoSlab = makeTexturedBox(9.8, 0.16, 3.6, concreteTrimMat, 0, 0.02, 11.6);
  group.add(porticoSlab);

  const apron = makeFlatMesh(
    new THREE.BoxGeometry(120, 0.2, 110),
    new THREE.MeshStandardMaterial({ color: 0x798470, roughness: 0.96, flatShading: true })
  );
  apron.position.set(0, -0.25, 2);
  group.add(apron);

  // Perimeter Broken Concrete Compound Walls + Gate Posts + Street Graffiti!
  addSolidBox(-26, 1.8, 19, 0.65, 3.6, 22, concreteExteriorMat, true, true);
  addSolidBox(26, 1.8, 19, 0.65, 3.6, 22, concreteExteriorMat, true, true);
  addSolidBox(0, 1.8, 30, 52.6, 3.6, 0.65, concreteExteriorMat, true, true);
  addWallGraffitiDecal(group, 'yellowConcrete', -25.66, 1.85, 19.5, 6.2, 2.7, '+x');
  addWallGraffitiDecal(group, 'blueGreenBrick', 25.66, 1.85, 18.5, 6.2, 2.7, '-x');
  addWallGraffitiDecal(group, 'brickStreetTag', -8.0, 1.85, 29.66, 6.4, 2.7, '-z');
  addWallGraffitiDecal(group, 'boldColorWall', 8.5, 1.85, 29.66, 6.4, 2.7, '-z');

  // Distant Urban Concrete Apartment Blocks framing the horizon
  const skyline: [number, number, number, number, number][] = [
    [-46, -24, 16, 24, 14],
    [-48, 8, 14, 18, 16],
    [48, -20, 16, 28, 15],
    [46, 14, 15, 19, 14],
    [-22, -46, 18, 26, 14],
    [16, -50, 22, 32, 15],
    [0, 54, 24, 21, 14],
    [-36, 48, 18, 17, 14],
    [38, 46, 16, 22, 14],
  ];
  skyline.forEach(([bx, bz, bw, bh, bd]) => {
    const b = makeFlatMesh(new THREE.BoxGeometry(bw, bh, bd), cityBgMat);
    b.position.set(bx, bh / 2 - 0.2, bz);
    group.add(b);
  });

  // =========================================================================
  // 2. PROTRUDING SOUTH ENTRANCE VESTIBULE + 2ND FLOOR FRONT BALCONY (Z: +10..+13.0)
  // =========================================================================
  const T = 0.55;
  // Vestibule Front Wall at Z = +13.0 (X: -4.6..+4.6, Y: 0..4.2) with WIDE DOUBLE DOOR ENTRANCE (X: -1.65..+1.65)
  addSolidBox(-3.12, 2.1, 13.0, 2.95, 4.2, T, concreteExteriorMat);
  addSolidBox(3.12, 2.1, 13.0, 2.95, 4.2, T, concreteExteriorMat);
  addSolidBox(0, 3.55, 13.0, 3.5, 1.3, T, concreteExteriorMat, false, true);
  // Protruding Rusted Steel Canopy above Main Vestibule Doors
  const entryCanopy = makeFlatMesh(new THREE.BoxGeometry(5.2, 0.22, 1.75), rustMetalMat);
  entryCanopy.position.set(0, 3.85, 13.85);
  entryCanopy.rotation.x = 0.12;
  group.add(entryCanopy);
  // Steel Canopy Support Cables
  [-2.2, 2.2].forEach((cx) => {
    const cable = makeFlatMesh(new THREE.BoxGeometry(0.05, 0.05, 1.9), darkIronMat);
    cable.position.set(cx, 4.35, 13.75);
    cable.rotation.x = 0.48;
    group.add(cable);
  });

  // MAIN GRAND DOUBLE WOODEN BUILDING ENTRANCE DOORS (Classic Mahogany Panels + Divided Glass + Twin Brass Handles!)
  // Left door hinges on Left Jamb & swings INWARD (+1); Right door hinges on Right Jamb & swings INWARD (-1)!
  addInteractiveDoor({
    id: 'door-main-l',
    x: -0.82,
    yFloor: 0,
    z: 13.0,
    width: 1.64,
    height: 2.85,
    axis: 'x',
    hingeSide: 'left',
    omitJamb: 'right',
    swingDir: 1,
    style: 'mahogany',
    startOpen: false,
    withWindow: true,
  });
  addInteractiveDoor({
    id: 'door-main-r',
    x: 0.82,
    yFloor: 0,
    z: 13.0,
    width: 1.64,
    height: 2.85,
    axis: 'x',
    hingeSide: 'right',
    omitJamb: 'left',
    swingDir: -1,
    style: 'mahogany',
    startOpen: false,
    withWindow: true,
  });

  // Vestibule West & East Side Walls (X = ±4.6, Z: 10..13) WITH FRAMED SIDE WINDOWS!
  addWallBayWithWindow({
    x: -4.6,
    yFloor: 0,
    z: 11.5,
    bayLen: 3.0,
    bayHeight: 4.2,
    winWidth: 1.85,
    winSillH: 1.15,
    winHeight: 1.75,
    axis: 'z',
    wallMat: concreteExteriorMat,
    cols: 2,
    rows: 2,
    brokenIndices: [1],
  });
  addWallBayWithWindow({
    x: 4.6,
    yFloor: 0,
    z: 11.5,
    bayLen: 3.0,
    bayHeight: 4.2,
    winWidth: 1.85,
    winSillH: 1.15,
    winHeight: 1.75,
    axis: 'z',
    wallMat: concreteExteriorMat,
    cols: 2,
    rows: 2,
    brokenIndices: [3],
  });

  // Vestibule Exterior Wall-Fused Pigment Graffiti (chroma-extracted vivid paint ONLY — zero oval blobs!)
  addWallGraffitiDecal(group, 'boldColorWall', -3.12, 1.9, 13.28, 2.55, 2.4, '+z', 0.92);
  addWallGraffitiDecal(group, 'brickStreetTag', 3.12, 1.9, 13.28, 2.55, 2.4, '+z', 0.92);
  addHangingLamp(0, 4.1, 11.5, 0xffd79e, 1.8, false);

  // 2ND FLOOR ACCESSIBLE FRONT BALCONY DECK (Right on top of the South Entrance Vestibule!)
  addSolidBox(0, FLOOR2_Y - 0.14, 11.5, 9.6, 0.28, 3.3, concreteFloorMat, false, true);
  // Concrete Parapet around Front Balcony (Y: 4.2..5.32) + Crisp Transparent Wildstyle Gang Tag Banner!
  addSolidBox(0, FLOOR2_Y + 0.56, 13.0, 9.5, 1.12, 0.34, concreteExteriorMat, true, true, 0.22);
  addSolidBox(-4.6, FLOOR2_Y + 0.56, 11.5, 0.34, 1.12, 3.0, concreteExteriorMat, true, true, 0.22);
  addSolidBox(4.6, FLOOR2_Y + 0.56, 11.5, 0.34, 1.12, 3.0, concreteExteriorMat, true, true, 0.22);
  addSprayTagBanner(group, 'DISTRICT 9', '#f97316', '#0f172a', '#fde047', 0, FLOOR2_Y + 0.56, 13.18, 6.2, 0.94, '+z');

  // =========================================================================
  // 3. MAIN 2-STORY BUILDING EXTERIOR FACADES (REAL WINDOWS & DOORS ON ALL FLOORS!)
  // =========================================================================
  // --- SOUTH FACADE GROUND FLOOR (Z = +10.0, Y: 0..4.2) ---
  // Center Interior Vestibule Portal (X: -3.2..+3.2 open into Atrium; flanking walls X: -4.6..-3.2 and +3.2..+4.6)
  addSolidBox(-3.9, 2.1, 10.0, 1.4, 4.2, T, concreteExteriorMat);
  addSolidBox(3.9, 2.1, 10.0, 1.4, 4.2, T, concreteExteriorMat);
  addSolidBox(0, 3.85, 10.0, 6.6, 0.72, T, concreteExteriorMat, false, true);

  // West Wing South Facade (X: -20.0..-4.6):
  //   Bay 1 (X: -20.0..-14.4, len=5.6): Framed Factory Window #1
  addWallBayWithWindow({
    x: -17.2,
    yFloor: 0,
    z: 10.0,
    bayLen: 5.6,
    bayHeight: 4.2,
    winWidth: 3.1,
    winSillH: 1.15,
    winHeight: 1.85,
    axis: 'x',
    wallMat: concreteExteriorMat,
    cols: 3,
    rows: 2,
    brokenIndices: [2],
    boarded: true,
  });
  //   West Side Paneled Oak Building Door (X: -14.4..-12.6, width=1.8)
  addSolidBox(-13.5, 3.55, 10.0, 1.8, 1.3, T, concreteExteriorMat, false, true);
  addInteractiveDoor({
    id: 'door-south-west',
    x: -13.5,
    yFloor: 0,
    z: 10.0,
    width: 1.8,
    height: 2.85,
    axis: 'x',
    swingDir: 1,
    style: 'oak',
    startOpen: false,
    withWindow: true,
  });
  //   Bay 2 (X: -12.6..-4.6, len=8.0): Framed Guard Office Window #2 + Big Mural!
  addWallBayWithWindow({
    x: -8.6,
    yFloor: 0,
    z: 10.0,
    bayLen: 8.0,
    bayHeight: 4.2,
    winWidth: 3.2,
    winSillH: 1.15,
    winHeight: 1.85,
    axis: 'x',
    wallMat: concreteExteriorMat,
    cols: 3,
    rows: 2,
    brokenIndices: [4],
  });
  addWallGraffitiDecal(group, 'dynamicStreetMural', -6.0, 2.0, 10.28, 2.6, 2.6, '+z', 0.9);
  addSprayTagBanner(group, 'KEEP OUT', '#ef4444', '#0f172a', '#fbbf24', -17.2, 0.58, 10.28, 4.4, 0.82, '+z');

  // East Wing South Facade (X: +4.6..+20.0):
  //   Bay 3 (X: +4.6..+11.4, len=6.8): Framed Factory Window #3 + Mural
  addWallBayWithWindow({
    x: 8.0,
    yFloor: 0,
    z: 10.0,
    bayLen: 6.8,
    bayHeight: 4.2,
    winWidth: 3.0,
    winSillH: 1.15,
    winHeight: 1.85,
    axis: 'x',
    wallMat: concreteExteriorMat,
    cols: 3,
    rows: 2,
    brokenIndices: [0],
  });
  addWallGraffitiDecal(group, 'yellowConcrete', 6.1, 2.0, 10.28, 2.6, 3.2, '+z');
  //   East Loading Bay Garage Roll-Up Shutter Entrance (X: +11.4..+15.6, width=4.2)
  addSolidBox(13.5, 3.65, 10.0, 4.2, 1.1, T, concreteExteriorMat, false, true);
  const shutter = makeFlatMesh(new THREE.BoxGeometry(4.2, 0.92, 0.16), rustMetalMat);
  shutter.position.set(13.5, 2.85, 10.14);
  group.add(shutter);
  losMeshes.push(shutter);
  //   Bay 4 (X: +15.6..+20.0, len=4.4): Framed East Storage Window #4
  addWallBayWithWindow({
    x: 17.8,
    yFloor: 0,
    z: 10.0,
    bayLen: 4.4,
    bayHeight: 4.2,
    winWidth: 2.4,
    winSillH: 1.15,
    winHeight: 1.85,
    axis: 'x',
    wallMat: concreteExteriorMat,
    cols: 2,
    rows: 2,
    brokenIndices: [3],
    boarded: true,
  });

  // --- SOUTH FACADE 2ND FLOOR (Z = +10.0, Y: 4.2..8.6) ---
  // Center 2nd Floor Front Balcony Classic Wooden Door (swings cleanly INWARD +1 into 2nd floor hall!)
  addSolidBox(0, FLOOR2_Y + 3.62, 10.0, 2.0, 1.56, T, concreteExteriorMat, false, true);
  addInteractiveDoor({
    id: 'door-f2-balcony',
    x: 0,
    yFloor: FLOOR2_Y,
    z: 10.0,
    width: 2.0,
    height: 2.85,
    axis: 'x',
    hingeSide: 'left',
    swingDir: 1,
    style: 'oak',
    startOpen: false,
    withWindow: true,
  });
  addSolidBox(-2.85, FLOOR2_Y + 2.2, 10.0, 3.5, 4.4, T, concreteExteriorMat);
  addSolidBox(2.85, FLOOR2_Y + 2.2, 10.0, 3.5, 4.4, T, concreteExteriorMat);

  // 4 Wide Multi-Pane 2nd Floor South Factory Windows (with real iron frames & shootable glass!)
  addWallBayWithWindow({
    x: -15.4,
    yFloor: FLOOR2_Y,
    z: 10.0,
    bayLen: 9.2,
    bayHeight: 4.4,
    winWidth: 5.0,
    winSillH: 1.1,
    winHeight: 2.15,
    axis: 'x',
    wallMat: concreteExteriorMat,
    cols: 4,
    rows: 2,
    brokenIndices: [1, 5],
  });
  addWallBayWithWindow({
    x: -7.7,
    yFloor: FLOOR2_Y,
    z: 10.0,
    bayLen: 6.2,
    bayHeight: 4.4,
    winWidth: 3.6,
    winSillH: 1.1,
    winHeight: 2.15,
    axis: 'x',
    wallMat: concreteExteriorMat,
    cols: 3,
    rows: 2,
    brokenIndices: [2],
  });
  addWallBayWithWindow({
    x: 7.7,
    yFloor: FLOOR2_Y,
    z: 10.0,
    bayLen: 6.2,
    bayHeight: 4.4,
    winWidth: 3.6,
    winSillH: 1.1,
    winHeight: 2.15,
    axis: 'x',
    wallMat: concreteExteriorMat,
    cols: 3,
    rows: 2,
    brokenIndices: [4],
  });
  addWallBayWithWindow({
    x: 15.4,
    yFloor: FLOOR2_Y,
    z: 10.0,
    bayLen: 9.2,
    bayHeight: 4.4,
    winWidth: 5.0,
    winSillH: 1.1,
    winHeight: 2.15,
    axis: 'x',
    wallMat: concreteExteriorMat,
    cols: 4,
    rows: 2,
    brokenIndices: [0, 6],
  });

  // Architectural Facade Relief: Horizontal Floor Belt Beam, Vertical Concrete Pilasters & Roof Cornice!
  addSolidBox(0, 4.2, 10.32, 40.8, 0.34, 0.24, concreteTrimMat, false, false);
  addSolidBox(0, 8.85, 10.22, 40.9, 0.72, 0.72, concreteDarkMat, false, false);
  [-20.0, -10.8, -4.6, 4.6, 10.8, 20.0].forEach((px) => {
    addSolidBox(px, 4.4, 10.3, 0.62, 8.8, 0.28, concreteTrimMat, false, false);
  });
  // Upper South Facade Wildstyle Spray-Tag Banners (100% crisp aspect-native gang lettering — ZERO squished photos!)
  addSprayTagBanner(group, 'VANDALZ CREW', '#38bdf8', '#090d14', '#f43f5e', 0, 7.98, 10.29, 7.6, 1.15, '+z');
  addSprayTagBanner(group, 'WEST BLOCK', '#f59e0b', '#090d14', '#fef08a', -15.4, 7.98, 10.29, 6.2, 1.05, '+z');
  addSprayTagBanner(group, 'NO MERCY', '#22c55e', '#090d14', '#a3e635', 15.4, 7.98, 10.29, 6.2, 1.05, '+z');

  // Exterior Rusty AC Condenser Units & Vertical Steel Drainage Pipes along South Facade!
  [-11.2, 11.2].forEach((ax) => {
    const ac = makeFlatMesh(new THREE.BoxGeometry(0.95, 0.72, 0.56), ductMetalMat);
    ac.position.set(ax, 5.1, 10.55);
    const fan = makeFlatMesh(new THREE.CylinderGeometry(0.24, 0.24, 0.08, 8), darkIronMat);
    fan.rotation.x = Math.PI / 2;
    fan.position.set(ax - 0.14, 5.1, 10.82);
    group.add(ac, fan);
  });
  [-19.5, 19.5].forEach((px) => {
    const drain = makeFlatMesh(new THREE.CylinderGeometry(0.09, 0.09, 8.6, 6), rustMetalMat);
    drain.position.set(px, 4.3, 10.38);
    group.add(drain);
  });

  // --- WEST OUTER WALL (X = -20.0, Z: -18..+10) — REAL FRAMED WINDOWS ON BOTH FLOORS! ---
  // Ground Floor West Bays: South Security Window (Z=+6.2), Center Gang Lounge Window (Z=-4.0), North Stair Wall (Z=-14.0)
  addWallBayWithWindow({
    x: -20.0,
    yFloor: 0,
    z: 6.2,
    bayLen: 7.6,
    bayHeight: 4.2,
    winWidth: 3.4,
    winSillH: 1.15,
    winHeight: 1.85,
    axis: 'z',
    wallMat: concreteWallMat,
    cols: 3,
    rows: 2,
    brokenIndices: [1],
  });
  addWallBayWithWindow({
    x: -20.0,
    yFloor: 0,
    z: -4.0,
    bayLen: 12.8,
    bayHeight: 4.2,
    winWidth: 4.4,
    winSillH: 1.15,
    winHeight: 1.85,
    axis: 'z',
    wallMat: concreteWallMat,
    cols: 4,
    rows: 2,
    brokenIndices: [2, 6],
  });
  addSolidBox(-20.0, 2.1, -14.2, T, 4.2, 7.6, concreteWallMat);
  // 2nd Floor West Bays (3 wide factory windows!)
  addWallBayWithWindow({
    x: -20.0,
    yFloor: FLOOR2_Y,
    z: 5.0,
    bayLen: 10.0,
    bayHeight: 4.4,
    winWidth: 4.8,
    winSillH: 1.1,
    winHeight: 2.1,
    axis: 'z',
    wallMat: concreteWallMat,
    cols: 4,
    rows: 2,
    brokenIndices: [3],
  });
  addWallBayWithWindow({
    x: -20.0,
    yFloor: FLOOR2_Y,
    z: -4.5,
    bayLen: 9.0,
    bayHeight: 4.4,
    winWidth: 4.4,
    winSillH: 1.1,
    winHeight: 2.1,
    axis: 'z',
    wallMat: concreteWallMat,
    cols: 4,
    rows: 2,
    brokenIndices: [1, 5],
  });
  addWallBayWithWindow({
    x: -20.0,
    yFloor: FLOOR2_Y,
    z: -13.5,
    bayLen: 9.0,
    bayHeight: 4.4,
    winWidth: 4.0,
    winSillH: 1.1,
    winHeight: 2.1,
    axis: 'z',
    wallMat: concreteWallMat,
    cols: 3,
    rows: 2,
    brokenIndices: [2],
  });
  // Huge Wall-Integrated Graffiti Murals inside West Wing!
  addBakedMuralPanel(group, 'dynamicStreetMural', -19.72, 2.0, -14.2, 7.2, 3.8, '+x', 0.08);
  addWallGraffitiDecal(group, 'brickWildstyle', -19.72, 2.0, 0.2, 3.8, 3.2, '+x');
  addWallGraffitiDecal(group, 'abstractBrick', -19.72, 2.0, -8.4, 3.8, 3.2, '+x');

  // --- EAST OUTER WALL (X = +20.0, Z: -18..+10) — REAL FRAMED WINDOWS ON BOTH FLOORS! ---
  addWallBayWithWindow({
    x: 20.0,
    yFloor: 0,
    z: 6.2,
    bayLen: 7.6,
    bayHeight: 4.2,
    winWidth: 3.4,
    winSillH: 1.15,
    winHeight: 1.85,
    axis: 'z',
    wallMat: concreteWallMat,
    cols: 3,
    rows: 2,
    brokenIndices: [4],
  });
  addWallBayWithWindow({
    x: 20.0,
    yFloor: 0,
    z: -4.0,
    bayLen: 12.8,
    bayHeight: 4.2,
    winWidth: 4.4,
    winSillH: 1.15,
    winHeight: 1.85,
    axis: 'z',
    wallMat: concreteWallMat,
    cols: 4,
    rows: 2,
    brokenIndices: [0, 5],
  });
  addSolidBox(20.0, 2.1, -14.2, T, 4.2, 7.6, concreteWallMat);
  // 2nd Floor East Bays
  addWallBayWithWindow({
    x: 20.0,
    yFloor: FLOOR2_Y,
    z: 5.0,
    bayLen: 10.0,
    bayHeight: 4.4,
    winWidth: 4.8,
    winSillH: 1.1,
    winHeight: 2.1,
    axis: 'z',
    wallMat: concreteWallMat,
    cols: 4,
    rows: 2,
    brokenIndices: [2],
  });
  addWallBayWithWindow({
    x: 20.0,
    yFloor: FLOOR2_Y,
    z: -4.5,
    bayLen: 9.0,
    bayHeight: 4.4,
    winWidth: 4.4,
    winSillH: 1.1,
    winHeight: 2.1,
    axis: 'z',
    wallMat: concreteWallMat,
    cols: 4,
    rows: 2,
    brokenIndices: [4],
  });
  addWallBayWithWindow({
    x: 20.0,
    yFloor: FLOOR2_Y,
    z: -13.5,
    bayLen: 9.0,
    bayHeight: 4.4,
    winWidth: 4.0,
    winSillH: 1.1,
    winHeight: 2.1,
    axis: 'z',
    wallMat: concreteWallMat,
    cols: 3,
    rows: 2,
    brokenIndices: [1],
  });
  addBakedMuralPanel(group, 'redYellowBrick', 19.72, 2.0, -14.2, 7.2, 3.8, '-x', 0.08);
  addWallGraffitiDecal(group, 'blueGreenBrick', 19.72, 2.0, 0.2, 3.8, 3.2, '-x');
  addWallGraffitiDecal(group, 'brickStreetTag', 19.72, 2.0, -8.4, 3.8, 3.2, '-x');

  // --- NORTH BACK WALL (Z = -18.0, X: -20..+20) WITH HIGH STAIRCASE WINDOWS & MASSIVE MURALS! ---
  addSolidBox(-14.5, 4.35, -18.0, 11.2, 8.7, T, concreteWallMat);
  addSolidBox(14.5, 4.35, -18.0, 11.2, 8.7, T, concreteWallMat);
  addWallBayWithWindow({
    x: -4.5,
    yFloor: 0,
    z: -18.0,
    bayLen: 9.0,
    bayHeight: 4.2,
    winWidth: 3.8,
    winSillH: 1.25,
    winHeight: 1.8,
    axis: 'x',
    wallMat: concreteWallMat,
    cols: 3,
    rows: 2,
    brokenIndices: [2],
  });
  addWallBayWithWindow({
    x: 4.5,
    yFloor: 0,
    z: -18.0,
    bayLen: 9.0,
    bayHeight: 4.2,
    winWidth: 3.8,
    winSillH: 1.25,
    winHeight: 1.8,
    axis: 'x',
    wallMat: concreteWallMat,
    cols: 3,
    rows: 2,
    brokenIndices: [5],
  });
  addSolidBox(0, FLOOR2_Y + 2.2, -18.0, 18.2, 4.4, T, concreteWallMat);
  // Panoramic North Murals!
  addBakedMuralPanel(group, 'yellowConcrete', -14.5, 2.1, -17.72, 10.6, 3.9, '+z', 0.07);
  addBakedMuralPanel(group, 'blueGreenBrick', 14.5, 2.1, -17.72, 10.6, 3.9, '+z', 0.07);
  addBakedMuralPanel(group, 'abandonedInterior', 0, 6.25, -17.72, 16.5, 3.9, '+z', 0.09);
  addWallGraffitiDecal(group, 'redYellowBrick', -14.5, 6.25, -17.72, 9.6, 3.5, '+z', 0.9);
  addWallGraffitiDecal(group, 'dynamicStreetMural', 14.5, 6.25, -17.72, 9.6, 3.5, '+z', 0.9);

  // =========================================================================
  // 4. GROUND FLOOR COMPLEX INTERIOR ROOMS, INTERACTIVE DOORS & OFFICE WINDOWS!
  // =========================================================================
  // --- WEST INTERIOR PARTITION WALL (X = -9.2, Z: -10..+10) ---
  //   Z in [+6.2..+10.0]: Security Guard Booth Interior Observation Window looking into Atrium!
  addWallBayWithWindow({
    x: -9.2,
    yFloor: 0,
    z: 8.1,
    bayLen: 3.8,
    bayHeight: 4.05,
    winWidth: 2.4,
    winSillH: 1.15,
    winHeight: 1.65,
    axis: 'z',
    wallMat: concreteWallMat,
    wallThick: 0.44,
    cols: 2,
    rows: 2,
    brokenIndices: [],
  });
  //   Z in [+4.4..+6.2]: Interactive Door into Security Office!
  addSolidBox(-9.2, 3.45, 5.3, 0.44, 1.2, 1.8, concreteWallMat, false, true);
  addInteractiveDoor({
    id: 'door-w-sec-atrium',
    x: -9.2,
    yFloor: 0,
    z: 5.3,
    width: 1.8,
    height: 2.85,
    axis: 'z',
    swingDir: 1,
    style: 'oak',
    startOpen: false,
    withWindow: true,
    wallThick: 0.44,
  });
  //   Z in [+1.6..+4.4]: Solid concrete pier
  addSolidBox(-9.2, 2.02, 3.0, 0.44, 4.05, 2.8, concreteWallMat);
  //   Z in [-1.6..+1.6]: Breached Waist-High Tactical Peek Wall with shattered window frame above!
  addSolidBox(-9.2, 0.6, 0.0, 0.44, 1.2, 3.2, concreteDarkMat);
  addSolidBox(-9.2, 3.55, 0.0, 0.44, 1.0, 3.2, concreteWallMat, false, true);
  addFramedWindow({
    x: -9.2,
    yBot: 1.2,
    z: 0.0,
    width: 3.1,
    height: 1.85,
    axis: 'z',
    cols: 3,
    rows: 2,
    wallThick: 0.44,
    brokenIndices: [1, 4],
    addSill: true,
  });
  //   Z in [-4.0..-1.6]: Solid pier
  addSolidBox(-9.2, 2.02, -2.8, 0.44, 4.05, 2.4, concreteWallMat);
  //   Z in [-6.0..-4.0]: Interactive Door between Gang Lounge & Central Atrium!
  addSolidBox(-9.2, 3.45, -5.0, 0.44, 1.2, 2.0, concreteWallMat, false, true);
  addInteractiveDoor({
    id: 'door-w-lounge-atrium',
    x: -9.2,
    yFloor: 0,
    z: -5.0,
    width: 2.0,
    height: 2.85,
    axis: 'z',
    swingDir: -1,
    style: 'mahogany',
    startOpen: true,
    withWindow: true,
    wallThick: 0.44,
  });
  //   Z in [-10.0..-6.0]: Solid wall with Gang Mural
  addSolidBox(-9.2, 2.02, -8.0, 0.44, 4.05, 4.0, concreteWallMat);
  addWallGraffitiDecal(group, 'yellowConcrete', -8.96, 1.9, -8.0, 3.6, 2.9, '+x');
  addWallGraffitiDecal(group, 'boldColorWall', -9.44, 1.9, -8.0, 3.6, 2.9, '-x');

  // --- WEST WING CROSS-PARTITION (Z = +2.6, X: -20..-9.2) separating Security Office & Gang Lounge! ---
  addSolidBox(-17.8, 2.02, 2.6, 4.4, 4.05, 0.4, concreteWallMat);
  addSolidBox(-14.6, 3.45, 2.6, 2.0, 1.2, 0.4, concreteWallMat, false, true);
  addInteractiveDoor({
    id: 'door-w-inner',
    x: -14.6,
    yFloor: 0,
    z: 2.6,
    width: 2.0,
    height: 2.85,
    axis: 'x',
    swingDir: 1,
    style: 'oak',
    startOpen: false,
    withWindow: false,
    wallThick: 0.4,
  });
  addWallBayWithWindow({
    x: -11.4,
    yFloor: 0,
    z: 2.6,
    bayLen: 4.4,
    bayHeight: 4.05,
    winWidth: 2.4,
    winSillH: 1.15,
    winHeight: 1.65,
    axis: 'x',
    wallMat: concreteWallMat,
    wallThick: 0.4,
    cols: 2,
    rows: 2,
    brokenIndices: [0],
  });

  // --- EAST INTERIOR PARTITION WALL (X = +9.2, Z: -10..+10) ---
  addWallBayWithWindow({
    x: 9.2,
    yFloor: 0,
    z: 8.1,
    bayLen: 3.8,
    bayHeight: 4.05,
    winWidth: 2.4,
    winSillH: 1.15,
    winHeight: 1.65,
    axis: 'z',
    wallMat: concreteWallMat,
    wallThick: 0.44,
    cols: 2,
    rows: 2,
    brokenIndices: [1],
  });
  addSolidBox(9.2, 3.45, 5.3, 0.44, 1.2, 1.8, concreteWallMat, false, true);
  addInteractiveDoor({
    id: 'door-e-garage-atrium',
    x: 9.2,
    yFloor: 0,
    z: 5.3,
    width: 1.8,
    height: 2.85,
    axis: 'z',
    swingDir: -1,
    style: 'paintedWood',
    startOpen: false,
    withWindow: true,
    wallThick: 0.44,
  });
  addSolidBox(9.2, 2.02, 3.0, 0.44, 4.05, 2.8, concreteWallMat);
  addSolidBox(9.2, 0.6, 0.0, 0.44, 1.2, 3.2, concreteDarkMat);
  addSolidBox(9.2, 3.55, 0.0, 0.44, 1.0, 3.2, concreteWallMat, false, true);
  addFramedWindow({
    x: 9.2,
    yBot: 1.2,
    z: 0.0,
    width: 3.1,
    height: 1.85,
    axis: 'z',
    cols: 3,
    rows: 2,
    wallThick: 0.44,
    brokenIndices: [2, 3],
    addSill: true,
  });
  addSolidBox(9.2, 2.02, -2.8, 0.44, 4.05, 2.4, concreteWallMat);
  addSolidBox(9.2, 3.45, -5.0, 0.44, 1.2, 2.0, concreteWallMat, false, true);
  addInteractiveDoor({
    id: 'door-e-boiler-atrium',
    x: 9.2,
    yFloor: 0,
    z: -5.0,
    width: 2.0,
    height: 2.85,
    axis: 'z',
    swingDir: 1,
    style: 'paintedWood',
    startOpen: true,
    withWindow: true,
    wallThick: 0.44,
  });
  addSolidBox(9.2, 2.02, -8.0, 0.44, 4.05, 4.0, concreteWallMat);
  addWallGraffitiDecal(group, 'redYellowBrick', 8.96, 1.9, -8.0, 3.6, 2.9, '-x');
  addWallGraffitiDecal(group, 'abstractBrick', 9.44, 1.9, -8.0, 3.6, 2.9, '+x');

  // --- EAST WING CROSS-PARTITION (Z = +2.6, X: +9.2..+20) separating Loading Garage & Boiler Room! ---
  addWallBayWithWindow({
    x: 11.4,
    yFloor: 0,
    z: 2.6,
    bayLen: 4.4,
    bayHeight: 4.05,
    winWidth: 2.4,
    winSillH: 1.15,
    winHeight: 1.65,
    axis: 'x',
    wallMat: concreteWallMat,
    wallThick: 0.4,
    cols: 2,
    rows: 2,
    brokenIndices: [3],
  });
  addSolidBox(14.6, 3.45, 2.6, 2.0, 1.2, 0.4, concreteWallMat, false, true);
  addInteractiveDoor({
    id: 'door-e-inner',
    x: 14.6,
    yFloor: 0,
    z: 2.6,
    width: 2.0,
    height: 2.85,
    axis: 'x',
    swingDir: -1,
    style: 'paintedWood',
    startOpen: false,
    withWindow: false,
    wallThick: 0.4,
  });
  addSolidBox(17.8, 2.02, 2.6, 4.4, 4.05, 0.4, concreteWallMat);

  // --- NORTH CORRIDOR PARTITION WALL (Z = -10.0, Y: 0..4.05) WITH DOORS, WINDOWS & MURALS! ---
  addSolidBox(-18.2, 2.02, -10.0, 3.6, 4.05, 0.46, concreteWallMat);
  addSolidBox(-15.3, 3.45, -10.0, 2.2, 1.2, 0.46, concreteWallMat, false, true);
  addInteractiveDoor({
    id: 'door-n-west',
    x: -15.3,
    yFloor: 0,
    z: -10.0,
    width: 2.2,
    height: 2.85,
    axis: 'x',
    swingDir: -1,
    style: 'oak',
    startOpen: true,
    withWindow: true,
    wallThick: 0.46,
  });
  addWallBayWithWindow({
    x: -8.7,
    yFloor: 0,
    z: -10.0,
    bayLen: 11.0,
    bayHeight: 4.05,
    winWidth: 3.0,
    winSillH: 1.2,
    winHeight: 1.65,
    axis: 'x',
    wallMat: concreteWallMat,
    wallThick: 0.46,
    cols: 3,
    rows: 2,
    brokenIndices: [1],
  });
  addSolidBox(0.0, 3.65, -10.0, 6.4, 0.8, 0.46, concreteWallMat, false, true); // Center Grand Archway!
  addWallBayWithWindow({
    x: 8.7,
    yFloor: 0,
    z: -10.0,
    bayLen: 11.0,
    bayHeight: 4.05,
    winWidth: 3.0,
    winSillH: 1.2,
    winHeight: 1.65,
    axis: 'x',
    wallMat: concreteWallMat,
    wallThick: 0.46,
    cols: 3,
    rows: 2,
    brokenIndices: [4],
  });
  addSolidBox(15.3, 3.45, -10.0, 2.2, 1.2, 0.46, concreteWallMat, false, true);
  addInteractiveDoor({
    id: 'door-n-east',
    x: 15.3,
    yFloor: 0,
    z: -10.0,
    width: 2.2,
    height: 2.85,
    axis: 'x',
    swingDir: 1,
    style: 'paintedWood',
    startOpen: true,
    withWindow: true,
    wallThick: 0.46,
  });
  addSolidBox(18.2, 2.02, -10.0, 3.6, 4.05, 0.46, concreteWallMat);
  // Iconic Murals flanking the North Atrium Windows!
  addWallGraffitiDecal(group, 'dynamicStreetMural', -5.2, 2.0, -9.76, 3.6, 3.2, '+z');
  addWallGraffitiDecal(group, 'brickStreetTag', 5.2, 2.0, -9.76, 3.6, 3.2, '+z');

  // =========================================================================
  // 5. FOUR MASSIVE 2-STORY GRAFFITI CONCRETE ATRIUM COLUMNS
  // =========================================================================
  const pillars: [number, number, GraffitiKey, GraffitiKey][] = [
    [-5.2, 3.6, 'boldColorWall', 'yellowConcrete'],
    [5.2, 3.6, 'dynamicStreetMural', 'blueGreenBrick'],
    [-5.2, -4.6, 'redYellowBrick', 'brickStreetTag'],
    [5.2, -4.6, 'brickWildstyle', 'abstractBrick'],
  ];
  pillars.forEach(([px, pz, gFront, gSide]) => {
    addSolidBox(px, 4.2, pz, 1.28, 8.4, 1.28, concreteDarkMat, true, true, 0.34);
    addSolidBox(px, 0.2, pz, 1.5, 0.4, 1.5, rubbleMat, false, false);
    addSolidBox(px, 4.15, pz, 1.46, 0.34, 1.46, rubbleMat, false, false);
    addWallGraffitiDecal(group, gFront, px, 1.85, pz + 0.64, 1.18, 1.9, '+z', 0.94);
    addWallGraffitiDecal(group, gSide, px, 1.85, pz - 0.64, 1.18, 1.9, '-z', 0.94);
    addWallGraffitiDecal(group, gSide, px + 0.64, 1.85, pz, 1.18, 1.9, '+x', 0.94);
    addWallGraffitiDecal(group, gFront, px - 0.64, 1.85, pz, 1.18, 1.9, '-x', 0.94);
  });

  // =========================================================================
  // 6. 2ND FLOOR DECKS, ENCLOSED GLASS OFFICES (BOSS OFFICE & RADIO ROOM) & STAIRS!
  // =========================================================================
  const SLAB_H = 0.28;
  const SLAB_Y = FLOOR2_Y - SLAB_H / 2;

  // West & East 2nd Floor Mezzanine Slabs + South Overlook Catwalk Bridge
  addSolidBox(-14.6, SLAB_Y, -1.6, 10.8, SLAB_H, 23.2, concreteFloorMat, false, true);
  addSolidBox(-16.6, SLAB_Y, -15.6, 6.8, SLAB_H, 4.8, concreteFloorMat, false, true);
  addSolidBox(14.6, SLAB_Y, -1.6, 10.8, SLAB_H, 23.2, concreteFloorMat, false, true);
  addSolidBox(16.6, SLAB_Y, -15.6, 6.8, SLAB_H, 4.8, concreteFloorMat, false, true);
  addSolidBox(0, SLAB_Y, 7.9, 18.4, SLAB_H, 4.2, concreteFloorMat, false, true);

  // --- ENCLOSED 2ND FLOOR WEST: GANG BOSS OFFICE (X: -20..-9.2, Z: +0.5..+10.0) ---
  // North Office Wall at Z = +0.5 with Interactive Door + Interior Window!
  addSolidBox(-18.0, FLOOR2_Y + 2.15, 0.5, 4.0, 4.3, 0.38, concreteWallMat);
  addSolidBox(-14.9, FLOOR2_Y + 3.58, 0.5, 2.2, 1.44, 0.38, concreteWallMat, false, true);
  addInteractiveDoor({
    id: 'door-f2-boss-north',
    x: -14.9,
    yFloor: FLOOR2_Y,
    z: 0.5,
    width: 2.2,
    height: 2.85,
    axis: 'x',
    swingDir: 1,
    style: 'mahogany',
    startOpen: false,
    withWindow: true,
    wallThick: 0.38,
  });
  addWallBayWithWindow({
    x: -11.5,
    yFloor: FLOOR2_Y,
    z: 0.5,
    bayLen: 4.6,
    bayHeight: 4.3,
    winWidth: 2.6,
    winSillH: 1.1,
    winHeight: 1.85,
    axis: 'x',
    wallMat: concreteWallMat,
    wallThick: 0.38,
    cols: 2,
    rows: 2,
    brokenIndices: [],
  });
  // East Glass-Windowed Atrium Overlook Wall of Gang Boss Office (X = -9.2, Z: +0.5..+6.4) + Bridge Doorway (Z: +6.4..+9.6)!
  addWallBayWithWindow({
    x: -9.2,
    yFloor: FLOOR2_Y,
    z: 3.45,
    bayLen: 5.9,
    bayHeight: 4.3,
    winWidth: 4.4,
    winSillH: 1.08,
    winHeight: 2.0,
    axis: 'z',
    wallMat: concreteWallMat,
    wallThick: 0.38,
    cols: 4,
    rows: 2,
    brokenIndices: [2],
  });
  addSolidBox(-9.2, FLOOR2_Y + 3.58, 7.8, 0.38, 1.44, 2.2, concreteWallMat, false, true);
  addSolidBox(-9.2, FLOOR2_Y + 2.15, 9.45, 0.38, 4.3, 1.1, concreteWallMat);
  addInteractiveDoor({
    id: 'door-f2-boss-bridge',
    x: -9.2,
    yFloor: FLOOR2_Y,
    z: 7.8,
    width: 2.2,
    height: 2.85,
    axis: 'z',
    swingDir: 1,
    style: 'mahogany',
    startOpen: true,
    withWindow: true,
    wallThick: 0.38,
  });

  // --- ENCLOSED 2ND FLOOR EAST: RADIO / SNIPER OVERWATCH ROOM (X: +9.2..+20, Z: +0.5..+10.0) ---
  addWallBayWithWindow({
    x: 11.5,
    yFloor: FLOOR2_Y,
    z: 0.5,
    bayLen: 4.6,
    bayHeight: 4.3,
    winWidth: 2.6,
    winSillH: 1.1,
    winHeight: 1.85,
    axis: 'x',
    wallMat: concreteWallMat,
    wallThick: 0.38,
    cols: 2,
    rows: 2,
    brokenIndices: [1],
  });
  addSolidBox(14.9, FLOOR2_Y + 3.58, 0.5, 2.2, 1.44, 0.38, concreteWallMat, false, true);
  addInteractiveDoor({
    id: 'door-f2-radio-north',
    x: 14.9,
    yFloor: FLOOR2_Y,
    z: 0.5,
    width: 2.2,
    height: 2.85,
    axis: 'x',
    swingDir: -1,
    style: 'paintedWood',
    startOpen: false,
    withWindow: true,
    wallThick: 0.38,
  });
  addSolidBox(18.0, FLOOR2_Y + 2.15, 0.5, 4.0, 4.3, 0.38, concreteWallMat);

  addWallBayWithWindow({
    x: 9.2,
    yFloor: FLOOR2_Y,
    z: 3.45,
    bayLen: 5.9,
    bayHeight: 4.3,
    winWidth: 4.4,
    winSillH: 1.08,
    winHeight: 2.0,
    axis: 'z',
    wallMat: concreteWallMat,
    wallThick: 0.38,
    cols: 4,
    rows: 2,
    brokenIndices: [5],
  });
  addSolidBox(9.2, FLOOR2_Y + 3.58, 7.8, 0.38, 1.44, 2.2, concreteWallMat, false, true);
  addSolidBox(9.2, FLOOR2_Y + 2.15, 9.45, 0.38, 4.3, 1.1, concreteWallMat);
  addInteractiveDoor({
    id: 'door-f2-radio-bridge',
    x: 9.2,
    yFloor: FLOOR2_Y,
    z: 7.8,
    width: 2.2,
    height: 2.85,
    axis: 'z',
    swingDir: -1,
    style: 'oak',
    startOpen: true,
    withWindow: true,
    wallThick: 0.38,
  });

  // Balcony Cover Parapets & Rusted Handrails overlooking the Central Atrium
  const addBalconyRailing = (x: number, z: number, w: number, d: number, solidCover = false) => {
    if (solidCover) {
      addSolidBox(x, FLOOR2_Y + 0.56, z, w, 1.12, d, concreteDarkMat, true, true, 0.22);
    } else {
      const topBar = makeFlatMesh(new THREE.BoxGeometry(w, 0.08, d), rustMetalMat);
      topBar.position.set(x, FLOOR2_Y + 1.05, z);
      group.add(topBar);
      const midBar = makeFlatMesh(new THREE.BoxGeometry(w, 0.06, d), rustMetalMat);
      midBar.position.set(x, FLOOR2_Y + 0.55, z);
      group.add(midBar);
      // Vertical iron posts every ~1.8m
      const span = Math.max(w, d);
      const steps = Math.max(2, Math.round(span / 1.8));
      for (let i = 0; i <= steps; i++) {
        const frac = i / steps - 0.5;
        const post = makeFlatMesh(new THREE.BoxGeometry(0.06, 1.05, 0.06), rustMetalMat);
        post.position.set(x + (w > d ? frac * w : 0), FLOOR2_Y + 0.52, z + (d >= w ? frac * d : 0));
        group.add(post);
      }
      colliders3D.push({
        minX: x - w / 2 - 0.18,
        maxX: x + w / 2 + 0.18,
        minY: FLOOR2_Y,
        maxY: FLOOR2_Y + 1.12,
        minZ: z - d / 2 - 0.18,
        maxZ: z + d / 2 + 0.18,
      });
    }
  };
  addBalconyRailing(-9.25, -4.5, 0.16, 7.6, false);
  addBalconyRailing(-9.25, -10.8, 0.24, 4.6, true);
  addBalconyRailing(9.25, -4.5, 0.16, 7.6, false);
  addBalconyRailing(9.25, -10.8, 0.24, 4.6, true);
  addBalconyRailing(-5.2, 5.9, 6.2, 0.22, true);
  addBalconyRailing(0.0, 5.9, 4.2, 0.14, false);
  addBalconyRailing(5.2, 5.9, 6.2, 0.22, true);
  addSprayTagBanner(group, 'GHOST GANG', '#f97316', '#090d14', '#fde047', -5.2, FLOOR2_Y + 0.56, 5.77, 5.4, 0.9, '-z');
  addSprayTagBanner(group, 'EAST SIDE', '#06b6d4', '#090d14', '#67e8f9', 5.2, FLOOR2_Y + 0.56, 5.77, 5.4, 0.9, '-z');

  // --- TWO WIDE WALKABLE CONCRETE STAIRCASES (North Corridor, Z in [-16.8, -13.6]) ---
  const STAIR_STEPS = 14;
  const STAIR_Z_CENTER = -15.2;
  const STAIR_WIDTH = 3.2;
  for (const side of [-1, 1]) {
    for (let i = 0; i < STAIR_STEPS; i++) {
      const frac = (i + 1) / STAIR_STEPS;
      const stepH = frac * FLOOR2_Y;
      const stepRun = 7.0 / STAIR_STEPS;
      const sx = side * (6.2 + (i + 0.5) * stepRun);
      const tread = makeTexturedBox(stepRun + 0.04, stepH, STAIR_WIDTH, concreteDarkMat, sx, stepH / 2, STAIR_Z_CENTER);
      group.add(tread);
      losMeshes.push(tread);
    }
    const railLen = Math.hypot(7.0, FLOOR2_Y);
    const rail = makeFlatMesh(new THREE.BoxGeometry(railLen, 0.12, 0.14), rustMetalMat);
    rail.position.set(side * 9.7, FLOOR2_Y * 0.5 + 0.95, -13.55);
    rail.rotation.z = side * Math.atan2(FLOOR2_Y, 7.0);
    group.add(rail);
    colliders3D.push({
      minX: side < 0 ? -13.3 : 8.2,
      maxX: side < 0 ? -8.2 : 13.3,
      minY: 0,
      maxY: 3.7,
      minZ: -13.75,
      maxZ: -13.25,
    });
  }

  // =========================================================================
  // 7. ROOF STRUCTURE, SKYLIGHT TRUSSES, OVERHEAD HVAC DUCTS, PENTHOUSE & WATER TANK!
  // =========================================================================
  addSolidBox(-14.6, 8.62, -4, 11.2, 0.36, 28.6, concreteDarkMat, false, true);
  addSolidBox(14.6, 8.62, -4, 11.2, 0.36, 28.6, concreteDarkMat, false, true);
  addSolidBox(0, 8.62, -14.2, 18.8, 0.36, 8.2, concreteDarkMat, false, true);
  addSolidBox(0, 8.62, 7.9, 18.8, 0.36, 4.6, concreteDarkMat, false, true);
  // Roof parapet perimeter walls
  addSolidBox(-20.0, 9.1, -4, 0.65, 0.85, 28.8, concreteDarkMat, false, false);
  addSolidBox(20.0, 9.1, -4, 0.65, 0.85, 28.8, concreteDarkMat, false, false);
  addSolidBox(0, 9.1, -18.0, 40.6, 0.85, 0.65, concreteDarkMat, false, false);

  // Corner Rooftop Stairwell Penthouse Tower (NW Roof — gives iconic complex urban skyline!)
  addSolidBox(-15.8, 10.8, -13.8, 7.2, 4.0, 6.8, concreteExteriorMat, false, false);
  addSolidBox(-15.8, 12.95, -13.8, 7.6, 0.35, 7.2, concreteDarkMat, false, false);
  addWallGraffitiDecal(group, 'redYellowBrick', -15.8, 10.9, -10.38, 6.4, 2.8, '+z', 0.92);

  // Rooftop Industrial Steel Water Tank on 4 Stilt Legs (East Roof!)
  const tankX = 14.8;
  const tankZ = -12.6;
  [[-1.3, -1.3], [1.3, -1.3], [-1.3, 1.3], [1.3, 1.3]].forEach(([lx, lz]) => {
    const leg = makeFlatMesh(new THREE.BoxGeometry(0.24, 2.6, 0.24), rustMetalMat);
    leg.position.set(tankX + lx, 10.0, tankZ + lz);
    group.add(leg);
  });
  const tankDrum = makeFlatMesh(new THREE.CylinderGeometry(2.1, 2.1, 3.2, 12), containerBlueMat);
  tankDrum.position.set(tankX, 12.6, tankZ);
  const tankRoof = makeFlatMesh(new THREE.ConeGeometry(2.28, 1.1, 12), rustMetalMat);
  tankRoof.position.set(tankX, 14.75, tankZ);
  group.add(tankDrum, tankRoof);

  // Exposed Steel Roof Trusses & Suspended Galvanized HVAC Air Ducts across Central Atrium!
  [-9.5, -2.5, 4.5].forEach((rz) => {
    const beam = makeFlatMesh(new THREE.BoxGeometry(19.2, 0.55, 1.05), darkIronMat);
    beam.position.set(0, 8.45, rz);
    group.add(beam);
  });
  const hvacMain = makeFlatMesh(new THREE.BoxGeometry(1.15, 0.72, 18.0), ductMetalMat);
  hvacMain.position.set(-7.6, 7.95, -1.5);
  const hvacEast = makeFlatMesh(new THREE.BoxGeometry(0.95, 0.65, 16.5), ductMetalMat);
  hvacEast.position.set(7.7, 7.95, -1.8);
  group.add(hvacMain, hvacEast);

  // AAA Fresnel-Feathered Volumetric Sunbeam God-Rays (aligned precisely with Golden Afternoon Sun (44, 48, 36)!)
  const sunBeamShaderMat = new THREE.ShaderMaterial({
    transparent: true,
    depthWrite: false,
    side: THREE.DoubleSide,
    blending: THREE.AdditiveBlending,
    uniforms: {
      uColor: { value: new THREE.Color(0xffe6b3) },
      uOpacity: { value: 0.14 },
    },
    vertexShader: /* glsl */ `
      varying vec2 vUv;
      varying vec3 vNormalV;
      varying vec3 vViewPos;
      void main() {
        vUv = uv;
        vec4 mvPos = modelViewMatrix * vec4(position, 1.0);
        vViewPos = -mvPos.xyz;
        vNormalV = normalize(normalMatrix * normal);
        gl_Position = projectionMatrix * mvPos;
      }
    `,
    fragmentShader: /* glsl */ `
      uniform vec3 uColor;
      uniform float uOpacity;
      varying vec2 vUv;
      varying vec3 vNormalV;
      varying vec3 vViewPos;
      void main() {
        // Soft edge fade at grazing cylinder edges so shaft looks like true volumetric light, never a tube!
        float fresnel = abs(dot(normalize(vNormalV), normalize(vViewPos)));
        float radialFade = pow(fresnel, 1.85);
        // Smooth vertical fade at top skylight aperture & bottom concrete floor bounce!
        float vFade = smoothstep(0.0, 0.28, vUv.y) * smoothstep(1.0, 0.72, vUv.y);
        float alpha = radialFade * vFade * uOpacity;
        gl_FragColor = vec4(uColor * alpha, alpha);
      }
    `,
  });

  // Compute exact quaternion aligning cylinder Y-axis parallel to Sun Ray vector (-44, -48, -36)!
  const sunRayDir = new THREE.Vector3(-44, -48, -36).normalize();
  const beamQuat = new THREE.Quaternion().setFromUnitVectors(new THREE.Vector3(0, -1, 0), sunRayDir);

  // Diagonal God-Rays streaming down through Broken Roof Skylights & East/South Upper Windows!
  const beamSpecs: [number, number, number, number, number, number][] = [
    [-2.8, 4.6, -0.5, 1.5, 3.1, 10.5], // Skylight shaft 1 across central burn-barrel atrium
    [1.6, 4.6, -6.2, 1.4, 2.9, 10.5], // Skylight shaft 2 into north hall
    [-3.8, 4.6, -7.8, 1.2, 2.5, 10.0], // Skylight shaft 3
    [13.8, 5.1, 4.5, 0.9, 2.0, 6.8], // East 2nd-floor factory window shaft
    [13.8, 5.1, -4.8, 0.9, 2.0, 6.8], // East 2nd-floor factory window shaft 2
    [6.5, 2.1, 7.2, 0.85, 1.8, 5.5], // South ground window shaft
  ];
  beamSpecs.forEach(([bx, by, bz, rTop, rBot, len]) => {
    const shaft = new THREE.Mesh(new THREE.CylinderGeometry(rTop, rBot, len, 14, 1, true), sunBeamShaderMat);
    shaft.position.set(bx, by, bz);
    shaft.quaternion.copy(beamQuat);
    shaft.userData.isFx = true;
    group.add(shaft);
  });

  // Drifting Golden Dust Motes floating lazily inside the sunlit abandoned hall!
  const moteCount = 160;
  const motePos = new Float32Array(moteCount * 3);
  for (let i = 0; i < moteCount; i++) {
    motePos[i * 3] = (Math.sin(i * 19.3) * 0.5 + (Math.random() - 0.5) * 0.5) * 28;
    motePos[i * 3 + 1] = 0.6 + Math.random() * 7.2;
    motePos[i * 3 + 2] = -14 + Math.random() * 23;
  }
  const moteGeo = new THREE.BufferGeometry();
  moteGeo.setAttribute('position', new THREE.BufferAttribute(motePos, 3));
  const moteMat = new THREE.PointsMaterial({
    color: 0xfff0cc,
    size: 0.065,
    transparent: true,
    opacity: 0.42,
    depthWrite: false,
    blending: THREE.AdditiveBlending,
  });
  const dustMotes = new THREE.Points(moteGeo, moteMat);
  dustMotes.userData.isFx = true;
  group.add(dustMotes);

  // =========================================================================
  // 8. ROOM FURNITURE, PIPES, LIGHTING, VEHICLES & DESTRUCTIBLE COVER PROPS
  // =========================================================================
  const addDestructibleCrate = (id: string, x: number, y: number, z: number, size = 1.22) => {
    const g = new THREE.Group();
    g.position.set(x, y, z);
    const body = makeFlatMesh(new THREE.BoxGeometry(size, size, size), crateWoodMat);
    body.position.y = size / 2;
    body.userData = { targetId: id, hitbox: 'crate' };
    g.add(body);
    const edge = size * 0.1;
    const diag = makeFlatMesh(new THREE.BoxGeometry(size * 1.15, edge, size + 0.04), crateTrimMat);
    diag.position.y = size / 2;
    diag.rotation.z = Math.PI / 4;
    g.add(diag);
    group.add(g);
    hitMeshes.push(body);
    targets.push({
      id,
      kind: 'crate',
      group: g,
      pivot: g,
      hp: 65,
      maxHp: 65,
      alive: true,
      respawnTimer: 0,
      knockAngle: 0,
      knockVel: 0,
      basePos: new THREE.Vector3(x, y, z),
      zone: 'compound',
      hitMeshes: [body],
    });
  };

  const addExplosiveBarrel = (id: string, x: number, y: number, z: number) => {
    const g = new THREE.Group();
    g.position.set(x, y, z);
    const pivot = new THREE.Group();
    g.add(pivot);
    const body = makeFlatMesh(new THREE.CylinderGeometry(0.38, 0.38, 1.14, 9), barrelRedMat);
    body.position.y = 0.57;
    body.userData = { targetId: id, hitbox: 'barrel' };
    pivot.add(body);
    const stripe = makeFlatMesh(new THREE.CylinderGeometry(0.395, 0.395, 0.22, 9), barrelStripeMat);
    stripe.position.y = 0.62;
    stripe.userData = { targetId: id, hitbox: 'barrel' };
    pivot.add(stripe);
    group.add(g);
    hitMeshes.push(body, stripe);
    targets.push({
      id,
      kind: 'barrel',
      group: g,
      pivot,
      hp: 38,
      maxHp: 38,
      alive: true,
      respawnTimer: 0,
      knockAngle: 0,
      knockVel: 0,
      basePos: new THREE.Vector3(x, y, z),
      zone: 'compound',
      hitMeshes: [body, stripe],
    });
  };

  // --- OUTDOOR COURTYARD PROPS ---
  // Graffiti Shipping Container (West Courtyard)
  addSolidBox(-15.5, 1.45, 19.2, 2.8, 2.9, 6.4, containerBlueMat);
  addWallGraffitiDecal(group, 'yellowConcrete', -14.09, 1.45, 19.2, 5.2, 2.3, '+x', 0.94);
  addWallGraffitiDecal(group, 'redYellowBrick', -15.5, 1.45, 22.42, 2.3, 2.1, '+z', 0.92);

  // Abandoned Derelict Utility Van (Center-Left Courtyard)
  const vanGroup = new THREE.Group();
  vanGroup.position.set(-7.6, 0, 17.6);
  vanGroup.rotation.y = 0.38;
  const vanLower = makeFlatMesh(new THREE.BoxGeometry(2.15, 1.15, 4.7), vanBodyMat);
  vanLower.position.y = 0.88;
  const vanRoof = makeFlatMesh(new THREE.BoxGeometry(2.05, 0.82, 3.3), vanBodyMat);
  vanRoof.position.set(0, 1.82, -0.45);
  const vanRustPatch = makeFlatMesh(new THREE.BoxGeometry(2.2, 0.32, 4.74), vanRustMat);
  vanRustPatch.position.y = 0.48;
  vanGroup.add(vanLower, vanRoof, vanRustPatch);
  [[-1.02, 1.45], [1.02, 1.45], [-1.02, -1.45], [1.02, -1.45]].forEach(([wx, wz]) => {
    const wheel = makeFlatMesh(new THREE.CylinderGeometry(0.42, 0.42, 0.28, 8), tireMat);
    wheel.rotation.z = Math.PI / 2;
    wheel.position.set(wx, 0.42, wz);
    vanGroup.add(wheel);
  });
  group.add(vanGroup);
  losMeshes.push(vanLower, vanRoof);
  colliders3D.push({ minX: -9.5, maxX: -5.6, minY: 0, maxY: 2.3, minZ: 15.1, maxZ: 20.1 });

  // Courtyard Jersey Barriers, Crates, Barrels & Weeds
  addSolidBox(7.8, 0.58, 17.4, 3.6, 1.16, 0.65, concreteDarkMat, true, true, 0.25);
  addSolidBox(13.0, 0.58, 15.0, 3.2, 1.16, 0.65, concreteDarkMat, true, true, 0.25);
  addDestructibleCrate('cmp-c1', 9.8, 0, 18.8, 1.25);
  addExplosiveBarrel('cmp-b1', 11.4, 0, 16.8);
  [[-11.2, 11.4], [5.8, 11.6], [17.0, 12.2], [-19.0, 15.6], [19.0, 22.0]].forEach(([wx, wz]) => {
    const tuft = makeFlatMesh(new THREE.ConeGeometry(0.42, 0.65, 5), weedMat);
    tuft.position.set(wx, 0.28, wz);
    group.add(tuft);
  });

  // --- CENTRAL ATRIUM COVER ISLAND & BURN BARREL ---
  addSolidBox(-1.1, 0.64, 0.5, 2.4, 1.28, 0.72, rubbleMat, true, true, 0.25);
  addSolidBox(1.3, 0.58, -0.9, 2.2, 1.16, 0.72, sandbagMat, true, true, 0.25);
  const burnBarrel = makeFlatMesh(new THREE.CylinderGeometry(0.38, 0.4, 1.08, 8), darkIronMat);
  burnBarrel.position.set(0.15, 0.54, 0.25);
  const embers = new THREE.Mesh(
    new THREE.IcosahedronGeometry(0.32, 0),
    new THREE.MeshBasicMaterial({ color: 0xff7b1a })
  );
  embers.position.set(0.15, 1.06, 0.25);
  group.add(burnBarrel, embers);
  const burnLight = new THREE.PointLight(0xff842b, 3.4, 18, 1.45);
  burnLight.position.set(0.15, 1.8, 0.25);
  group.add(burnLight);

  addDestructibleCrate('cmp-c2', -3.6, 0, 4.4, 1.22);
  addDestructibleCrate('cmp-c3', 3.6, 0, -3.8, 1.22);
  addExplosiveBarrel('cmp-b2', -4.2, 0, -3.2);
  addExplosiveBarrel('cmp-b3', 4.3, 0, 2.4);

  // --- ROOM W1 (SECURITY OFFICE) & ROOM W2 (GANG LOUNGE) INTERIOR PROPS & LAMPS ---
  // Guard Desk inside Security Office
  addSolidBox(-16.8, 0.46, 6.2, 2.2, 0.92, 0.95, deskMetalMat, true, true, 0.22);
  addHangingLamp(-14.6, 4.05, 6.4, 0xbfe8ff, 2.0, true);
  // Overturned Couch & Cover inside Gang Lounge
  addSolidBox(-15.4, 0.55, -2.0, 2.5, 1.1, 0.95, couchMat, true, true, 0.24);
  addSolidBox(-16.2, 0.62, -6.5, 0.75, 1.24, 2.6, concreteDarkMat, true, true, 0.24);
  addDestructibleCrate('cmp-c4', -13.0, 0, -0.5, 1.18);
  addExplosiveBarrel('cmp-b4', -17.2, 0, -4.2);
  addHangingLamp(-14.5, 4.05, -3.6, 0xffcb85, 2.3, false);

  // --- ROOM E1 (LOADING BAY) & ROOM E2 (BOILER/GENERATOR ROOM) INTERIOR PROPS & PIPES ---
  addDestructibleCrate('cmp-c5', 16.5, 0, 6.5, 1.25);
  addDestructibleCrate('cmp-c6', 16.5, 1.25, 6.5, 0.95);
  addHangingLamp(14.5, 4.05, 6.2, 0xffe0b2, 2.0, false);
  // Heavy Industrial Generator & Overhead Rusty Steam Pipes in Boiler Room
  addSolidBox(15.6, 1.12, -1.6, 2.8, 2.24, 1.6, rustMetalMat, true, true, 0.26);
  const steamPipe = makeFlatMesh(new THREE.CylinderGeometry(0.24, 0.24, 11.2, 8), rustMetalMat);
  steamPipe.rotation.x = Math.PI / 2;
  steamPipe.position.set(18.6, 3.25, -3.6);
  group.add(steamPipe);
  addSolidBox(15.4, 0.68, -6.4, 2.6, 1.36, 1.0, concreteDarkMat, true, true, 0.24);
  addExplosiveBarrel('cmp-b5', 17.4, 0, -4.0);
  addHangingLamp(14.5, 4.05, -3.6, 0xaad6ff, 2.2, true);

  // --- NORTH STAIR CORRIDOR PROPS & LIGHTING ---
  addSolidBox(0, 0.62, -13.8, 2.6, 1.24, 0.72, sandbagMat, true, true, 0.25);
  addHangingLamp(0, 4.05, -14.2, 0xffb86b, 2.1, false);

  // --- 2ND FLOOR ENCLOSED OFFICES PROPS & LIGHTING ---
  // Boss Office Desk & Lamp (2nd Floor West)
  addSolidBox(-15.5, FLOOR2_Y + 0.48, 5.6, 2.6, 0.96, 1.1, deskMetalMat, true, true, 0.24);
  addSolidBox(-14.2, FLOOR2_Y + 0.62, -6.5, 2.2, 1.24, 0.85, concreteDarkMat, true, true, 0.24);
  addHangingLamp(-14.6, 8.4, 5.2, 0xffd291, 2.3, false);
  addExplosiveBarrel('cmp-b6', -11.6, FLOOR2_Y, -4.5);

  // Radio Overwatch Console Rack with Glowing LEDs (2nd Floor East)
  addSolidBox(16.2, FLOOR2_Y + 0.78, 5.6, 1.2, 1.56, 2.6, deskMetalMat, true, true, 0.24);
  const led1 = new THREE.Mesh(new THREE.BoxGeometry(0.08, 0.08, 0.14), ledRedMat);
  led1.position.set(15.56, FLOOR2_Y + 1.15, 5.2);
  const led2 = new THREE.Mesh(new THREE.BoxGeometry(0.08, 0.08, 0.14), ledGreenMat);
  led2.position.set(15.56, FLOOR2_Y + 1.15, 5.65);
  group.add(led1, led2);
  addSolidBox(14.2, FLOOR2_Y + 0.62, -6.5, 2.2, 1.24, 0.85, concreteDarkMat, true, true, 0.24);
  addHangingLamp(14.6, 8.4, 5.2, 0xb8e2ff, 2.2, true);
  addExplosiveBarrel('cmp-b7', 11.6, FLOOR2_Y, -4.5);
  addDestructibleCrate('cmp-c7', -11.4, FLOOR2_Y, 6.2, 1.12);
  addDestructibleCrate('cmp-c8', 11.4, FLOOR2_Y, 6.2, 1.12);

  // =========================================================================
  // 9. COMPLETE 3D TACTICAL NAVGRAPH (Routes through ALL Doors, Rooms, Stairs & Front Balcony!)
  // =========================================================================
  const rawNodes: { x: number; y: number; z: number; cover: boolean; floor: 0 | 1; tag: string }[] = [
    // Courtyard & Entrances (0..3)
    { x: 0, y: 0, z: 15.6, cover: false, floor: 0, tag: 'yard_center' }, // 0
    { x: -13.5, y: 0, z: 12.6, cover: true, floor: 0, tag: 'yard_west' }, // 1
    { x: 13.5, y: 0, z: 12.6, cover: true, floor: 0, tag: 'yard_east' }, // 2
    { x: 0, y: 0, z: 11.4, cover: false, floor: 0, tag: 'vestibule' }, // 3
    // Central Atrium Pillars & Center Island (4..9)
    { x: -3.2, y: 0, z: 4.8, cover: true, floor: 0, tag: 'pillar_sw' }, // 4
    { x: 3.2, y: 0, z: 4.8, cover: true, floor: 0, tag: 'pillar_se' }, // 5
    { x: -2.4, y: 0, z: -0.6, cover: true, floor: 0, tag: 'atrium_mid_w' }, // 6
    { x: 2.4, y: 0, z: 0.4, cover: true, floor: 0, tag: 'atrium_mid_e' }, // 7
    { x: -3.2, y: 0, z: -4.8, cover: true, floor: 0, tag: 'pillar_nw' }, // 8
    { x: 3.2, y: 0, z: -4.8, cover: true, floor: 0, tag: 'pillar_ne' }, // 9
    // West Security Office & Gang Lounge (10..12)
    { x: -13.5, y: 0, z: 5.3, cover: true, floor: 0, tag: 'west_sec_office' }, // 10
    { x: -12.6, y: 0, z: -1.4, cover: true, floor: 0, tag: 'west_lounge_mid' }, // 11
    { x: -13.6, y: 0, z: -5.2, cover: true, floor: 0, tag: 'west_lounge_n' }, // 12
    // East Garage & Boiler Room (13..15)
    { x: 13.5, y: 0, z: 5.3, cover: true, floor: 0, tag: 'east_garage' }, // 13
    { x: 12.6, y: 0, z: -1.4, cover: true, floor: 0, tag: 'east_boiler_mid' }, // 14
    { x: 13.6, y: 0, z: -5.2, cover: true, floor: 0, tag: 'east_boiler_n' }, // 15
    // North Flank Corridor & Stair Bottoms (16..20)
    { x: -15.3, y: 0, z: -12.0, cover: true, floor: 0, tag: 'north_w' }, // 16
    { x: -5.2, y: 0, z: -15.2, cover: false, floor: 0, tag: 'stair_w_bot' }, // 17
    { x: 0.0, y: 0, z: -11.8, cover: true, floor: 0, tag: 'north_center' }, // 18
    { x: 5.2, y: 0, z: -15.2, cover: false, floor: 0, tag: 'stair_e_bot' }, // 19
    { x: 15.3, y: 0, z: -12.0, cover: true, floor: 0, tag: 'north_e' }, // 20
    // West & East Stair Midpoints & 2nd Floor Landings (21..24)
    { x: -9.7, y: 2.1, z: -15.2, cover: false, floor: 1, tag: 'stair_w_mid' }, // 21
    { x: -15.2, y: FLOOR2_Y, z: -15.2, cover: false, floor: 1, tag: 'f2_w_top' }, // 22
    { x: 9.7, y: 2.1, z: -15.2, cover: false, floor: 1, tag: 'stair_e_mid' }, // 23
    { x: 15.2, y: FLOOR2_Y, z: -15.2, cover: false, floor: 1, tag: 'f2_e_top' }, // 24
    // 2nd Floor Balconies, Enclosed Offices & Front Exterior Balcony (25..34)
    { x: -11.6, y: FLOOR2_Y, z: -9.5, cover: true, floor: 1, tag: 'f2_w_north' }, // 25
    { x: -14.8, y: FLOOR2_Y, z: -2.5, cover: true, floor: 1, tag: 'f2_w_mid' }, // 26
    { x: -14.0, y: FLOOR2_Y, z: 3.4, cover: true, floor: 1, tag: 'f2_boss_office' }, // 27
    { x: -5.2, y: FLOOR2_Y, z: 7.8, cover: true, floor: 1, tag: 'f2_bridge_w' }, // 28
    { x: 0.0, y: FLOOR2_Y, z: 7.8, cover: true, floor: 1, tag: 'f2_bridge_c' }, // 29
    { x: 5.2, y: FLOOR2_Y, z: 7.8, cover: true, floor: 1, tag: 'f2_bridge_e' }, // 30
    { x: 14.0, y: FLOOR2_Y, z: 3.4, cover: true, floor: 1, tag: 'f2_radio_room' }, // 31
    { x: 14.8, y: FLOOR2_Y, z: -2.5, cover: true, floor: 1, tag: 'f2_e_mid' }, // 32
    { x: 11.6, y: FLOOR2_Y, z: -9.5, cover: true, floor: 1, tag: 'f2_e_north' }, // 33
    { x: 0.0, y: FLOOR2_Y, z: 11.6, cover: true, floor: 1, tag: 'f2_front_balcony' }, // 34
    // Clean Hallway / Doorway Alignment Waypoints (35..43)
    { x: -5.2, y: 0, z: -11.8, cover: false, floor: 0, tag: 'north_mid_w' }, // 35
    { x: 5.2, y: 0, z: -11.8, cover: false, floor: 0, tag: 'north_mid_e' }, // 36
    { x: -15.2, y: FLOOR2_Y, z: -11.4, cover: false, floor: 1, tag: 'f2_w_turn' }, // 37
    { x: 15.2, y: FLOOR2_Y, z: -11.4, cover: false, floor: 1, tag: 'f2_e_turn' }, // 38
    { x: -11.6, y: FLOOR2_Y, z: 7.8, cover: false, floor: 1, tag: 'f2_boss_door' }, // 39
    { x: 11.6, y: FLOOR2_Y, z: 7.8, cover: false, floor: 1, tag: 'f2_radio_door' }, // 40
    { x: 0.0, y: 0, z: 7.8, cover: false, floor: 0, tag: 'atrium_south_c' }, // 41
    { x: -14.6, y: 0, z: 2.6, cover: false, floor: 0, tag: 'w_inner_door' }, // 42
    { x: 14.6, y: 0, z: 2.6, cover: false, floor: 0, tag: 'e_inner_door' }, // 43
  ];

  const navNodes: NavNode[] = rawNodes.map((n, i) => ({
    id: i,
    pos: new THREE.Vector3(n.x, n.y, n.z),
    neighbors: [],
    isCover: n.cover,
    floor: n.floor,
    tag: n.tag,
  }));

  const link = (a: number, b: number) => {
    if (!navNodes[a].neighbors.includes(b)) navNodes[a].neighbors.push(b);
    if (!navNodes[b].neighbors.includes(a)) navNodes[b].neighbors.push(a);
  };

  // Courtyard -> Vestibule / Side Door / Garage Shutter
  link(0, 1); link(0, 2); link(0, 3);
  link(1, 10); link(2, 13); link(3, 41);
  // Central Atrium & Side Doorways
  link(41, 4); link(41, 5);
  link(4, 5); link(4, 6); link(4, 10);
  link(5, 7); link(5, 13);
  link(6, 7); link(6, 8);
  link(7, 9);
  link(8, 9); link(8, 12); link(8, 18);
  link(9, 15); link(9, 18);
  // West Rooms via Inner Door (42) & North Door (16)
  link(10, 42); link(42, 11); link(11, 12); link(12, 16);
  // East Rooms via Inner Door (43) & North Door (20)
  link(13, 43); link(43, 14); link(14, 15); link(15, 20);
  // North Corridor & Stair Bottoms
  link(16, 35); link(35, 18); link(35, 17);
  link(20, 36); link(36, 18); link(36, 19);
  // 2nd Floor Loop (Stairs -> Mezzanines -> Enclosed Boss Office & Radio Room -> Bridge -> Front Balcony!)
  link(17, 21); link(21, 22); link(22, 37); link(37, 25);
  link(25, 26); link(26, 27); link(27, 39); link(39, 28);
  link(28, 29); link(29, 34); link(29, 30); link(30, 40);
  link(40, 31); link(31, 32); link(32, 33); link(33, 38);
  link(38, 24); link(24, 23); link(23, 19);

  // =========================================================================
  // 10. MULTI-LEVEL FLOOR HEIGHT (INCLUDING 2ND FLOOR FRONT BALCONY!) & INDOOR DARKNESS
  // =========================================================================
  const getFloorHeight = (x: number, z: number, currentFootY: number): number => {
    // 1. Walkable West Staircase: X in [-13.2, -6.2], Z in [-16.9, -13.5]
    if (z >= -16.9 && z <= -13.5 && x >= -13.3 && x <= -6.1) {
      const t = THREE.MathUtils.clamp((-6.2 - x) / 7.0, 0, 1);
      const stairY = t * FLOOR2_Y;
      if (currentFootY >= stairY - 1.15) return stairY;
    }
    // 2. Walkable East Staircase: X in [+6.2, +13.2], Z in [-16.9, -13.5]
    if (z >= -16.9 && z <= -13.5 && x >= 6.1 && x <= 13.3) {
      const t = THREE.MathUtils.clamp((x - 6.2) / 7.0, 0, 1);
      const stairY = t * FLOOR2_Y;
      if (currentFootY >= stairY - 1.15) return stairY;
    }
    // 3. 2nd Floor Mezzanine Decks, Enclosed Offices, South Bridge & Exterior Front Balcony!
    if (currentFootY >= 2.75) {
      const onWestDeck =
        x >= -20.0 &&
        x <= -9.1 &&
        z >= -18.0 &&
        z <= 10.0 &&
        !(x > -13.2 && z < -13.2);
      const onEastDeck =
        x >= 9.1 &&
        x <= 20.0 &&
        z >= -18.0 &&
        z <= 10.0 &&
        !(x < 13.2 && z < -13.2);
      const onSouthBridge = x >= -9.3 && x <= 9.3 && z >= 5.75 && z <= 10.0;
      const onFrontBalcony = x >= -4.7 && x <= 4.7 && z >= 9.8 && z <= 13.1;

      if (onWestDeck || onEastDeck || onSouthBridge || onFrontBalcony) {
        return FLOOR2_Y;
      }
    }
    return 0;
  };

  const getIndoorDarkness = (x: number, y: number, z: number): number => {
    // 2nd Floor Front Exterior Balcony is outdoors in full sunlight!
    if (y > 3.5 && z > 10.2) return 0.0;
    // Ground Floor Entrance Vestibule is transitional shade
    if (y <= 3.5 && Math.abs(x) < 4.7 && z > 10.0 && z < 13.1) return 0.48;
    if (z > 10.4 || Math.abs(x) > 20.4 || z < -18.4) return 0.0;

    const insideDepthZ = THREE.MathUtils.clamp((10.4 - z) / 3.2, 0, 1);
    const inCentralSkylight =
      Math.abs(x) < 8.5 && z > -9.2 && z < 5.6
        ? 1.0 - THREE.MathUtils.clamp((Math.abs(x) - 5.5) / 3.0, 0, 1)
        : 0.0;
    const roofDark = y > 3.5 ? 0.58 : 0.78;
    const skylightBright = y > 3.5 ? 0.28 : 0.38;
    return insideDepthZ * THREE.MathUtils.lerp(roofDark, skylightBright, inCentralSkylight);
  };

  return {
    colliders3D,
    losMeshes,
    doors,
    doorHitMeshes,
    glassPanes,
    glassHitMeshes,
    navNodes,
    targets,
    hitMeshes,
    burnLight,
    flickerLights,
    dustMotes,
    getFloorHeight,
    getIndoorDarkness,
  };
}
