import { useEffect, useRef, useState } from 'react';
import {
  Bot,
  Camera,
  Crosshair,
  Eye,
  EyeOff,
  Gauge,
  Heart,
  MapPin,
  Play,
  RotateCcw,
  SlidersHorizontal,
  Sun,
  Target,
  Timer,
  Volume2,
  VolumeX,
  Wrench,
  Zap,
} from 'lucide-react';
import { PolyBallisticsEngine } from './game/engine';
import {
  DEFAULT_FILTER_SETTINGS,
  HudSnapshot,
  WEAPON_SPECS,
  WeaponAnimState,
  WeaponId,
  ZONES,
  ZoneId,
} from './game/types';
import { soundEngine } from './game/audio';
import { MechanicsOverlay } from './components/MechanicsOverlay';

const INITIAL_HUD: HudSnapshot = {
  weaponId: 'rifle',
  ammo: WEAPON_SPECS.rifle.magSize,
  magSize: WEAPON_SPECS.rifle.magSize,
  animState: 'ready',
  isAds: false,
  isCrouching: false,
  isSprinting: false,
  sniperScoped: false,
  scopeRangeMeters: null,
  crosshairSpread: 0.45,
  isPointerLocked: false,
  showUi: false, // Default: 100% ZERO UI — pure bodycam gameplay! Toggle via `P`
  bodycamEnabled: true,
  filterSettings: { ...DEFAULT_FILTER_SETTINGS },
  exposureGain: 1.06,
  focusDistance: 14.0,
  isIndoors: false,
  freeAimScreenX: 0,
  freeAimScreenY: 0,
  slowMo: false,
  showMechanics: false,
  zoneId: 'compound',
  gameMode: 'range',
  drillActive: false,
  drillTimeLeft: 60,
  drillFinished: false,
  score: 0,
  streak: 0,
  shotsFired: 0,
  shotsHit: 0,
  headshots: 0,
  playerHp: 100,
  botsAlive: 6,
  botKills: 0,
  wave: 1,
  botsEnabled: true,
  lastEventText: 'Gedung Geng Graffiti — Tekan P kapan saja untuk menampilkan / menyembunyikan UI',
  reloadProgress: 0,
  boltProgress: 0,
  calloutPins: [],
  hitFeedback: null,
};

function getStateBadge(state: WeaponAnimState, ammo: number, weaponId: WeaponId) {
  if (state === 'reloading') {
    return { text: 'MENGISI AMMO • POSE GAMBAR 1', cls: 'bg-amber-500/90 text-slate-950' };
  }
  if (state === 'bolt_cycle') {
    return { text: 'KOKANG BOLT • BUANG SELONSONG', cls: 'bg-sky-400/90 text-slate-950' };
  }
  if (state === 'inspecting') {
    return { text: 'INSPEKSI POLYGON • GAMBAR 1', cls: 'bg-purple-400/90 text-slate-950' };
  }
  if (ammo === 0 && weaponId === 'pistol') {
    return { text: 'SLIDE LOCKED • TEKAN R RELOAD', cls: 'bg-red-500/90 text-white' };
  }
  if (ammo === 0) {
    return { text: 'AMMO HABIS • TEKAN R RELOAD', cls: 'bg-red-500/90 text-white' };
  }
  if (state === 'ads') {
    return { text: 'BIDIK PRESISI (ADS)', cls: 'bg-emerald-400/90 text-slate-950' };
  }
  return { text: 'SIAP NEMBAK • POSE GAMBAR 2', cls: 'bg-white/90 text-slate-950' };
}

export function App() {
  const mountRef = useRef<HTMLDivElement | null>(null);
  const engineRef = useRef<PolyBallisticsEngine | null>(null);
  const [hud, setHud] = useState<HudSnapshot>(INITIAL_HUD);
  const [muted, setMuted] = useState(false);
  const [showFilterPanel, setShowFilterPanel] = useState(true);

  useEffect(() => {
    if (!mountRef.current) return;
    const engine = new PolyBallisticsEngine(mountRef.current, (snapshot) => {
      setHud(snapshot);
    });
    engineRef.current = engine;
    return () => {
      engine.dispose();
      engineRef.current = null;
    };
  }, []);

  const spec = WEAPON_SPECS[hud.weaponId];
  const accuracy = hud.shotsFired > 0 ? Math.round((hud.shotsHit / hud.shotsFired) * 100) : 100;
  const badge = getStateBadge(hud.animState, hud.ammo, hud.weaponId);

  const toggleMute = () => {
    const next = !muted;
    setMuted(next);
    soundEngine.setMuted(next);
  };

  // Dynamic crosshair gap in px (only visible when UI is toggled ON via `P`)
  const gapPx = Math.round(6 + hud.crosshairSpread * 16);

  return (
    <div className="relative h-screen w-screen overflow-hidden bg-black select-none">
      {/* 100% Full-Viewport Three.js Bodycam 3D Canvas — Zero UI clutter by default! */}
      <div
        ref={mountRef}
        onClick={() => {
          if (!hud.isPointerLocked && !hud.drillFinished) {
            engineRef.current?.requestPointerLock();
          }
        }}
        className={`h-full w-full ${hud.isPointerLocked ? 'cursor-none' : 'cursor-crosshair'}`}
      />

      {/* =================================================================== */}
      {/* ALL UI BELOW IS 100% HIDDEN BY DEFAULT — TOGGLE WITH `P` KEY!       */}
      {/* (Sniper zooms natively through its real 3D magnifying glass lens!)  */}
      {/* =================================================================== */}
      {hud.showUi && (
        <>
          {/* Optional Non-Blocking Rangefinder Chip below the 3D Sniper Magnifying Glass (only when UI is ON) */}
          {hud.sniperScoped && (
            <div className="pointer-events-none fixed bottom-[20%] left-1/2 z-20 -translate-x-1/2 rounded-full border border-emerald-400/35 bg-slate-950/75 px-3 py-1 font-mono text-[11px] font-bold tracking-wider text-emerald-300 backdrop-blur-sm">
              4.7x GLASS • JARAK {hud.scopeRangeMeters !== null ? `${hud.scopeRangeMeters}m` : '---'}
            </div>
          )}
          {/* Live 3D-Tracked Mechanics & Ballistics Overlay (`B` key) */}
          {hud.showMechanics && !hud.sniperScoped && (
            <MechanicsOverlay
              weaponId={hud.weaponId}
              pins={hud.calloutPins}
              lastEventText={hud.lastEventText}
            />
          )}

          {/* Free-Aim Tracking Dynamic Crosshair & Hitmarker */}
          {hud.isPointerLocked && !hud.sniperScoped && (
            <div className="pointer-events-none fixed inset-0 z-20 flex items-center justify-center">
              <div
                style={{
                  transform: `translate(${Math.round(hud.freeAimScreenX)}px, ${Math.round(hud.freeAimScreenY)}px)`,
                  opacity: hud.isAds ? 0.32 : 0.92,
                }}
                className="relative transition-opacity duration-100"
              >
                {/* Center Dot */}
                <div className="h-1 w-1 rounded-full bg-white shadow-[0_0_4px_rgba(0,0,0,0.95)]" />
                <div
                  style={{ bottom: gapPx }}
                  className="absolute left-1/2 h-2.5 w-[2px] -translate-x-1/2 rounded-full bg-white shadow-[0_0_3px_rgba(0,0,0,0.9)]"
                />
                <div
                  style={{ top: gapPx }}
                  className="absolute left-1/2 h-2.5 w-[2px] -translate-x-1/2 rounded-full bg-white shadow-[0_0_3px_rgba(0,0,0,0.9)]"
                />
                <div
                  style={{ right: gapPx }}
                  className="absolute top-1/2 h-[2px] w-2.5 -translate-y-1/2 rounded-full bg-white shadow-[0_0_3px_rgba(0,0,0,0.9)]"
                />
                <div
                  style={{ left: gapPx }}
                  className="absolute top-1/2 h-[2px] w-2.5 -translate-y-1/2 rounded-full bg-white shadow-[0_0_3px_rgba(0,0,0,0.9)]"
                />
              </div>

              {/* Crisp Hitmarker X */}
              {hud.hitFeedback && (
                <div
                  key={`hm-${hud.hitFeedback.id}`}
                  style={{
                    marginLeft: Math.round(hud.freeAimScreenX),
                    marginTop: Math.round(hud.freeAimScreenY),
                  }}
                  className="animate-hit-pop absolute left-1/2 top-1/2 h-7 w-7"
                >
                  <svg viewBox="0 0 32 32" className="h-full w-full drop-shadow-[0_0_4px_rgba(0,0,0,0.85)]">
                    <g
                      stroke={hud.hitFeedback.isHeadshot ? '#facc15' : '#ffffff'}
                      strokeWidth={hud.hitFeedback.isHeadshot ? '3.2' : '2.4'}
                      strokeLinecap="round"
                    >
                      <line x1="6" y1="6" x2="12" y2="12" />
                      <line x1="26" y1="6" x2="20" y2="12" />
                      <line x1="6" y1="26" x2="12" y2="20" />
                      <line x1="26" y1="26" x2="20" y2="20" />
                    </g>
                  </svg>
                </div>
              )}

              {/* Hit Feed Popup */}
              {hud.hitFeedback && (
                <div
                  key={`feed-${hud.hitFeedback.id}`}
                  className="animate-feed-slide absolute top-[56%] flex items-center gap-2 rounded-full bg-slate-950/75 px-3 py-1 text-xs font-black tracking-wide backdrop-blur-sm"
                >
                  <span className={hud.hitFeedback.isHeadshot ? 'text-amber-300' : 'text-white'}>
                    {hud.hitFeedback.label}
                  </span>
                  <span className="text-emerald-300">+{hud.hitFeedback.points}</span>
                  <span className="font-mono text-[10px] text-slate-300">
                    {hud.hitFeedback.distance}m
                  </span>
                </div>
              )}
            </div>
          )}

          {/* TOP-LEFT SCOREBOARD, HP, SMART BOT WAVE & LIVE BODYCAM SENSOR TELEMETRY */}
          <div className="pointer-events-none fixed left-4 top-4 z-30 flex flex-wrap items-center gap-2">
            <div className="flex items-center gap-3 rounded-xl border border-white/15 bg-slate-950/78 px-3.5 py-2 text-white shadow-lg backdrop-blur-md">
              <div className="flex items-center gap-1.5">
                <Heart
                  className={`h-4 w-4 ${
                    hud.playerHp < 35 ? 'animate-pulse text-red-400' : 'text-emerald-400'
                  }`}
                />
                <span className="font-mono text-sm font-black">{hud.playerHp}</span>
              </div>
              <div className="h-4 w-px bg-white/15" />
              <div className="flex items-center gap-1.5 text-[11px] font-semibold text-slate-300">
                <Bot className="h-3.5 w-3.5 text-orange-400" />
                <span>W{hud.wave}</span>
                <span className="font-mono font-black text-orange-300">{hud.botsAlive} BOT</span>
                <span className="text-white/25">•</span>
                <span className="font-mono font-black text-emerald-300">{hud.botKills} KILL</span>
              </div>
              <div className="h-4 w-px bg-white/15" />
              <div className="flex items-center gap-1.5">
                <Target className="h-3.5 w-3.5 text-amber-400" />
                <span className="font-mono text-sm font-black">{hud.score.toLocaleString()}</span>
              </div>
              <div className="h-4 w-px bg-white/15" />
              <div className="text-[11px] font-semibold text-slate-300">
                <span className="font-mono font-black text-sky-300">{accuracy}%</span>
              </div>
              {hud.gameMode === 'drill' && (
                <>
                  <div className="h-4 w-px bg-white/15" />
                  <div className="flex items-center gap-1 text-amber-300">
                    <Timer className="h-3.5 w-3.5" />
                    <span className="font-mono text-sm font-black">{hud.drillTimeLeft}s</span>
                  </div>
                </>
              )}
            </div>

            <div className="flex items-center gap-2 rounded-xl border border-white/15 bg-slate-950/75 px-3 py-2 text-[11px] font-bold text-white shadow-lg backdrop-blur-md">
              <MapPin className="h-3.5 w-3.5 text-emerald-400" />
              <span>{ZONES[hud.zoneId].name}</span>
              <span className="text-white/25">|</span>
              <span className="font-mono text-[10px] text-amber-300">
                EXP {hud.exposureGain.toFixed(2)}x
              </span>
              <span className="font-mono text-[10px] text-sky-300">
                AF {hud.focusDistance < 10 ? hud.focusDistance.toFixed(1) : Math.round(hud.focusDistance)}m
              </span>
              {hud.isIndoors && (
                <span className="rounded bg-amber-500/25 px-1.5 py-0.5 font-mono text-[9px] text-amber-200">
                  INDOOR ISO+
                </span>
              )}
            </div>
          </div>

          {/* TOP-RIGHT SIMULATION & BODYCAM CONTROLS */}
          <div className="fixed right-4 top-4 z-30 flex flex-wrap items-center justify-end gap-2">
            <button
              onClick={(e) => {
                e.stopPropagation();
                engineRef.current?.toggleBots();
              }}
              className={`flex items-center gap-1.5 rounded-xl border px-3 py-2 text-xs font-bold shadow-lg backdrop-blur-md transition ${
                hud.botsEnabled
                  ? 'border-orange-300 bg-orange-400 text-slate-950'
                  : 'border-white/15 bg-slate-950/75 text-white hover:bg-slate-900'
              }`}
            >
              <Bot className="h-3.5 w-3.5" />
              <span>[G] Bot {hud.botsEnabled ? 'ON' : 'OFF'}</span>
            </button>

            <button
              onClick={(e) => {
                e.stopPropagation();
                setShowFilterPanel((v) => !v);
              }}
              className={`flex items-center gap-1.5 rounded-xl border px-3 py-2 text-xs font-bold shadow-lg backdrop-blur-md transition ${
                showFilterPanel
                  ? 'border-indigo-300 bg-indigo-400 text-slate-950'
                  : 'border-white/15 bg-slate-950/75 text-white hover:bg-slate-900'
              }`}
            >
              <SlidersHorizontal className="h-3.5 w-3.5" />
              <span>Atur Filter</span>
            </button>

            <button
              onClick={(e) => {
                e.stopPropagation();
                engineRef.current?.toggleBodycam();
              }}
              className={`flex items-center gap-1.5 rounded-xl border px-3 py-2 text-xs font-bold shadow-lg backdrop-blur-md transition ${
                hud.bodycamEnabled
                  ? 'border-emerald-300 bg-emerald-400 text-slate-950'
                  : 'border-white/15 bg-slate-950/75 text-white hover:bg-slate-900'
              }`}
            >
              <Camera className="h-3.5 w-3.5" />
              <span>[O] Bodycam {hud.bodycamEnabled ? 'ON' : 'OFF'}</span>
            </button>

            <button
              onClick={(e) => {
                e.stopPropagation();
                engineRef.current?.toggleSlowMo();
              }}
              className={`flex items-center gap-1.5 rounded-xl border px-3 py-2 text-xs font-bold shadow-lg backdrop-blur-md transition ${
                hud.slowMo
                  ? 'border-amber-300 bg-amber-400 text-slate-950'
                  : 'border-white/15 bg-slate-950/75 text-white hover:bg-slate-900'
              }`}
            >
              <Gauge className="h-3.5 w-3.5" />
              <span>[T] Slow-Mo {hud.slowMo ? '0.25x' : '1.0x'}</span>
            </button>

            <button
              onClick={(e) => {
                e.stopPropagation();
                engineRef.current?.toggleMechanics();
              }}
              className={`flex items-center gap-1.5 rounded-xl border px-3 py-2 text-xs font-bold shadow-lg backdrop-blur-md transition ${
                hud.showMechanics
                  ? 'border-sky-300 bg-sky-400 text-slate-950'
                  : 'border-white/15 bg-slate-950/75 text-white hover:bg-slate-900'
              }`}
            >
              <Wrench className="h-3.5 w-3.5" />
              <span>[B] Titik Peluru</span>
            </button>

            <button
              onClick={(e) => {
                e.stopPropagation();
                toggleMute();
              }}
              title="Suara"
              className="flex h-9 w-9 items-center justify-center rounded-xl border border-white/15 bg-slate-950/75 text-white shadow-lg backdrop-blur-md transition hover:bg-slate-900"
            >
              {muted ? <VolumeX className="h-4 w-4 text-red-400" /> : <Volume2 className="h-4 w-4" />}
            </button>

            <button
              onClick={(e) => {
                e.stopPropagation();
                engineRef.current?.toggleUi();
              }}
              title="Sembunyikan UI (P)"
              className="flex items-center gap-1.5 rounded-xl border border-white/20 bg-slate-950/85 px-3 py-2 text-xs font-bold text-slate-200 shadow-lg backdrop-blur-md transition hover:bg-slate-800 hover:text-white"
            >
              <EyeOff className="h-3.5 w-3.5" />
              <span>[P] Hide UI</span>
            </button>
          </div>

          {/* RIGHT-SIDE LIVE BODYCAM FILTER & BRIGHTNESS STUDIO (Adjust Sebelumnya <-> Setelahnya!) */}
          {showFilterPanel && !hud.sniperScoped && (
            <div
              onClick={(e) => e.stopPropagation()}
              className="fixed right-4 top-16 z-30 w-[275px] rounded-2xl border border-white/15 bg-slate-950/82 p-3.5 text-white shadow-2xl backdrop-blur-md"
            >
              <div className="flex items-center justify-between border-b border-white/10 pb-2">
                <div className="flex items-center gap-1.5">
                  <SlidersHorizontal className="h-3.5 w-3.5 text-indigo-300" />
                  <span className="text-[11px] font-black uppercase tracking-wider">
                    Filter Bodycam & Cahaya
                  </span>
                </div>
                <span className="font-mono text-[10px] text-slate-400">[ / ]</span>
              </div>

              {/* MASTER PRESET MORPH: VERSI 1 (0%) <-> VERSI 2 DEFAULT (100%) */}
              <div className="mt-2.5">
                <div className="flex items-center justify-between text-[10px] font-bold">
                  <span className="text-amber-300">Versi 1</span>
                  <span className="font-mono text-white">
                    {Math.round(hud.filterSettings.styleBlend * 100)}%
                  </span>
                  <span className="text-emerald-300">Versi 2 (Default)</span>
                </div>
                <input
                  type="range"
                  min={0}
                  max={1}
                  step={0.01}
                  value={hud.filterSettings.styleBlend}
                  onChange={(e) => engineRef.current?.setFilterPresetBlend(parseFloat(e.target.value))}
                  className="mt-1 h-1.5 w-full cursor-pointer accent-indigo-400"
                />
                <div className="mt-1.5 grid grid-cols-3 gap-1">
                  {[
                    { label: 'Versi 1', val: 0 },
                    { label: 'Seimbang', val: 0.5 },
                    { label: 'Versi 2', val: 1 },
                  ].map((preset) => {
                    const isNear = Math.abs(hud.filterSettings.styleBlend - preset.val) < 0.08;
                    return (
                      <button
                        key={preset.label}
                        onClick={() => engineRef.current?.setFilterPresetBlend(preset.val)}
                        className={`rounded-md border py-1 text-[10px] font-bold transition ${
                          isNear
                            ? 'border-indigo-300 bg-indigo-400/25 text-indigo-100'
                            : 'border-white/10 bg-white/5 text-slate-300 hover:bg-white/15 hover:text-white'
                        }`}
                      >
                        {preset.label}
                      </button>
                    );
                  })}
                </div>
              </div>

              {/* BRIGHTNESS / KECERAHAN (Restored bright daylight default 1.18x!) */}
              <div className="mt-3 space-y-2 border-t border-white/10 pt-2.5 text-[10px]">
                <div>
                  <div className="flex items-center justify-between font-bold text-amber-200">
                    <span className="flex items-center gap-1">
                      <Sun className="h-3 w-3 text-amber-300" />
                      Kecerahan
                    </span>
                    <span className="font-mono">{Math.round(hud.filterSettings.brightness * 100)}%</span>
                  </div>
                  <input
                    type="range"
                    min={0.7}
                    max={1.6}
                    step={0.02}
                    value={hud.filterSettings.brightness}
                    onChange={(e) =>
                      engineRef.current?.updateFilterSettings({ brightness: parseFloat(e.target.value) })
                    }
                    className="mt-0.5 h-1.5 w-full cursor-pointer accent-amber-400"
                  />
                </div>

                {/* FINE-TUNE OPTICAL SLIDERS */}
                <div>
                  <div className="flex items-center justify-between text-slate-200">
                    <span>Fisheye / Lengkung</span>
                    <span className="font-mono">{Math.round(hud.filterSettings.fisheye * 100)}%</span>
                  </div>
                  <input
                    type="range"
                    min={0}
                    max={1}
                    step={0.02}
                    value={hud.filterSettings.fisheye}
                    onChange={(e) =>
                      engineRef.current?.updateFilterSettings({ fisheye: parseFloat(e.target.value) })
                    }
                    className="mt-0.5 h-1.5 w-full cursor-pointer accent-sky-400"
                  />
                </div>

                <div>
                  <div className="flex items-center justify-between text-slate-200">
                    <span>Batas Hitam & Vignette</span>
                    <span className="font-mono">{Math.round(hud.filterSettings.blackFrame * 100)}%</span>
                  </div>
                  <input
                    type="range"
                    min={0}
                    max={1}
                    step={0.02}
                    value={hud.filterSettings.blackFrame}
                    onChange={(e) =>
                      engineRef.current?.updateFilterSettings({ blackFrame: parseFloat(e.target.value) })
                    }
                    className="mt-0.5 h-1.5 w-full cursor-pointer accent-sky-400"
                  />
                </div>

                <div>
                  <div className="flex items-center justify-between text-slate-200">
                    <span>Blur / Depth of Field</span>
                    <span className="font-mono">{Math.round(hud.filterSettings.blurDof * 100)}%</span>
                  </div>
                  <input
                    type="range"
                    min={0}
                    max={1}
                    step={0.02}
                    value={hud.filterSettings.blurDof}
                    onChange={(e) =>
                      engineRef.current?.updateFilterSettings({ blurDof: parseFloat(e.target.value) })
                    }
                    className="mt-0.5 h-1.5 w-full cursor-pointer accent-sky-400"
                  />
                </div>

                <div>
                  <div className="flex items-center justify-between text-slate-200">
                    <span>Chromatic & Grain</span>
                    <span className="font-mono">{Math.round(hud.filterSettings.chromaticGrain * 100)}%</span>
                  </div>
                  <input
                    type="range"
                    min={0}
                    max={1}
                    step={0.02}
                    value={hud.filterSettings.chromaticGrain}
                    onChange={(e) =>
                      engineRef.current?.updateFilterSettings({ chromaticGrain: parseFloat(e.target.value) })
                    }
                    className="mt-0.5 h-1.5 w-full cursor-pointer accent-sky-400"
                  />
                </div>

                <div className="border-t border-white/10 pt-2">
                  <div className="flex items-center justify-between font-bold text-emerald-200">
                    <span>Guncangan Lari</span>
                    <span className="font-mono">
                      {hud.filterSettings.cameraShake <= 0.22
                        ? 'SMOOTH'
                        : `${Math.round(hud.filterSettings.cameraShake * 100)}%`}
                    </span>
                  </div>
                  <input
                    type="range"
                    min={0}
                    max={1}
                    step={0.02}
                    value={hud.filterSettings.cameraShake}
                    onChange={(e) =>
                      engineRef.current?.updateFilterSettings({ cameraShake: parseFloat(e.target.value) })
                    }
                    className="mt-0.5 h-1.5 w-full cursor-pointer accent-emerald-400"
                  />
                </div>
              </div>
            </div>
          )}

          {/* BOTTOM-LEFT KEYCAP STRIP */}
          <div className="pointer-events-none fixed bottom-4 left-4 z-30 hidden items-center gap-2 rounded-xl border border-white/12 bg-slate-950/78 px-3 py-2 text-[11px] text-slate-200 shadow-lg backdrop-blur-md md:flex">
            {[
              ['WASD', 'Gerak'],
              ['Shift', 'Lari'],
              ['C / Ctrl', 'Crouch'],
              ['E', 'Pintu'],
              ['Spasi', 'Lompat'],
              ['LMB', 'Tembak'],
              ['RMB', 'Ngeker'],
              ['R', 'Reload'],
              ['P', 'Toggle UI'],
            ].map(([key, label]) => (
              <div key={key} className="flex items-center gap-1">
                <kbd className="rounded border border-white/25 bg-white/10 px-1.5 py-0.5 font-mono text-[10px] font-bold text-white">
                  {key}
                </kbd>
                <span className="text-slate-300">{label}</span>
              </div>
            ))}
          </div>

          {/* BOTTOM-RIGHT WEAPON & AMMO PANEL */}
          <div className="fixed bottom-4 right-4 z-30 flex flex-col items-end gap-2">
            <div className="flex flex-col items-end gap-1">
              <div className="flex items-center gap-1.5">
                {hud.isCrouching && (
                  <span className="rounded-md bg-sky-400/90 px-2 py-0.5 text-[10px] font-black tracking-wider text-slate-950 shadow">
                    CROUCH
                  </span>
                )}
                {hud.isSprinting && !hud.isCrouching && (
                  <span className="rounded-md bg-emerald-400/90 px-2 py-0.5 text-[10px] font-black tracking-wider text-slate-950 shadow">
                    SPRINT
                  </span>
                )}
                <span
                  className={`rounded-md px-2.5 py-0.5 text-[10px] font-black tracking-wider shadow ${badge.cls}`}
                >
                  {badge.text}
                </span>
              </div>
              {(hud.animState === 'reloading' || hud.animState === 'bolt_cycle') && (
                <div className="h-1.5 w-44 overflow-hidden rounded-full bg-slate-950/80 ring-1 ring-white/15">
                  <div
                    style={{
                      width: `${Math.round(
                        (hud.animState === 'reloading' ? hud.reloadProgress : hud.boltProgress) * 100
                      )}%`,
                    }}
                    className={`h-full transition-all duration-75 ${
                      hud.animState === 'reloading' ? 'bg-amber-400' : 'bg-sky-400'
                    }`}
                  />
                </div>
              )}
            </div>

            <div className="flex items-center gap-4 rounded-2xl border border-white/15 bg-slate-950/82 px-4 py-2.5 text-white shadow-xl backdrop-blur-md">
              <div className="flex flex-col">
                <span className="text-[10px] font-bold uppercase tracking-widest text-slate-400">
                  {spec.fireMode} • {spec.caliber}
                </span>
                <span className="text-base font-black tracking-wide">{spec.label}</span>
              </div>
              <div className="h-8 w-px bg-white/15" />
              <div className="flex items-baseline gap-1 font-mono">
                <span
                  className={`text-3xl font-black leading-none ${
                    hud.ammo === 0
                      ? 'text-red-400'
                      : hud.ammo <= Math.ceil(hud.magSize * 0.25)
                        ? 'text-amber-300'
                        : 'text-white'
                  }`}
                >
                  {hud.ammo}
                </span>
                <span className="text-sm font-bold text-slate-400">/ {hud.magSize}</span>
              </div>
            </div>

            <div className="flex items-center gap-1.5">
              {(['pistol', 'rifle', 'sniper'] as WeaponId[]).map((id, idx) => {
                const active = hud.weaponId === id;
                return (
                  <button
                    key={id}
                    onClick={(e) => {
                      e.stopPropagation();
                      engineRef.current?.switchWeapon(id);
                    }}
                    className={`flex items-center gap-1.5 rounded-lg border px-2.5 py-1 text-[11px] font-black tracking-wider transition ${
                      active
                        ? 'border-white bg-white text-slate-950 shadow-md'
                        : 'border-white/15 bg-slate-950/75 text-slate-300 hover:border-white/40 hover:text-white'
                    }`}
                  >
                    <span className="font-mono opacity-70">{idx + 1}</span>
                    <span>{WEAPON_SPECS[id].label}</span>
                  </button>
                );
              })}
            </div>
          </div>

          {/* INTERACTIVE TACTICAL CONTROL MENU (Only shown when UI is ON via `P` AND mouse is unlocked!) */}
          {!hud.isPointerLocked && (
            <div className="pointer-events-none fixed inset-0 z-40 flex flex-col items-center justify-between px-4 py-16">
              <div className="pointer-events-auto mt-2 flex w-full max-w-xl flex-col items-center rounded-2xl border border-white/20 bg-slate-950/74 p-5 text-center text-white shadow-2xl backdrop-blur-md">
                <div className="inline-flex items-center gap-1.5 rounded-full border border-emerald-400/35 bg-emerald-400/15 px-3 py-0.5 text-[10px] font-black uppercase tracking-widest text-emerald-300">
                  <Zap className="h-3 w-3" />
                  Chest-Mounted Bodycam • 3D Low-Poly Weapon Sim
                </div>

                <h1 className="mt-2 text-2xl font-black tracking-tight sm:text-3xl">
                  {hud.drillFinished ? 'TANTANGAN 60 DETIK SELESAI!' : 'POLYBALLISTICS BODYCAM'}
                </h1>

                {hud.drillFinished ? (
                  <div className="mt-3 grid w-full grid-cols-3 gap-2 rounded-xl bg-white/8 p-3 font-mono">
                    <div>
                      <div className="text-[10px] text-slate-400">SKOR AKHIR</div>
                      <div className="text-xl font-black text-amber-300">{hud.score}</div>
                    </div>
                    <div>
                      <div className="text-[10px] text-slate-400">HEADSHOT</div>
                      <div className="text-xl font-black text-emerald-300">{hud.headshots}</div>
                    </div>
                    <div>
                      <div className="text-[10px] text-slate-400">AKURASI</div>
                      <div className="text-xl font-black text-sky-300">{accuracy}%</div>
                    </div>
                  </div>
                ) : (
                  <p className="mt-1.5 max-w-md text-xs leading-relaxed text-slate-200">
                    Map baru <strong className="text-amber-300">Gedung Geng Graffiti 2 Lantai</strong> dengan mural graffiti asli menempel di tembok beton, tangga & balkon lantai 2, serta <strong className="text-orange-300">Bot Cerdas</strong> yang bisa berlindung, mendengar tembakan, dan mengepung!
                  </p>
                )}

                <div className="mt-4 flex flex-wrap items-center justify-center gap-2.5">
                  <button
                    onClick={() => {
                      if (hud.drillFinished) {
                        engineRef.current?.startDrill();
                      }
                      engineRef.current?.toggleUi();
                      engineRef.current?.requestPointerLock();
                    }}
                    className="flex items-center gap-2 rounded-xl bg-amber-400 px-5 py-2.5 text-sm font-black tracking-wide text-slate-950 shadow-lg shadow-amber-500/25 transition hover:scale-[1.03] hover:bg-amber-300 active:scale-95"
                  >
                    <Play className="h-4 w-4 fill-current" />
                    {hud.drillFinished ? 'MAIN LAGI (RAW MODE)' : 'LANJUT TANPA UI (RAW)'}
                  </button>

                  <button
                    onClick={() => {
                      engineRef.current?.resetBotWave();
                      engineRef.current?.toggleUi();
                      engineRef.current?.requestPointerLock();
                    }}
                    className="flex items-center gap-1.5 rounded-xl border border-orange-400/40 bg-orange-500/20 px-4 py-2.5 text-xs font-bold text-orange-200 transition hover:bg-orange-500/30"
                  >
                    <Bot className="h-3.5 w-3.5 text-orange-300" />
                    Reset Wave Bot (W1)
                  </button>
                </div>

                {/* Zone Teleporters (Primary: Abandoned Graffiti Gang Building + Classic 3 Ranges!) */}
                <div className="mt-3.5 flex flex-wrap items-center justify-center gap-1.5">
                  {(['compound', 'courtyard', 'alpine', 'ridge'] as ZoneId[]).map((zid) => {
                    const active = hud.zoneId === zid;
                    const z = ZONES[zid];
                    return (
                      <button
                        key={zid}
                        onClick={() => engineRef.current?.teleportToZone(zid, true)}
                        className={`rounded-lg border px-2.5 py-1 text-[11px] font-bold transition ${
                          active
                            ? 'border-emerald-300 bg-emerald-400/20 text-emerald-200'
                            : 'border-white/15 bg-white/5 text-slate-300 hover:bg-white/15 hover:text-white'
                        }`}
                      >
                        {z.name} ({WEAPON_SPECS[z.recommendedWeapon].label})
                      </button>
                    );
                  })}
                </div>

                {/* Instant Preview Controls */}
                <div className="mt-3 flex flex-wrap items-center justify-center gap-2 border-t border-white/10 pt-3">
                  <button
                    onClick={() => engineRef.current?.fireDemoShot()}
                    className="flex items-center gap-1.5 rounded-lg bg-orange-500/90 px-3 py-1.5 text-[11px] font-black text-white transition hover:bg-orange-400"
                  >
                    <Crosshair className="h-3.5 w-3.5" />
                    Uji Tembak
                  </button>
                  <button
                    onClick={() => engineRef.current?.toggleAds()}
                    className={`flex items-center gap-1.5 rounded-lg border px-3 py-1.5 text-[11px] font-bold transition ${
                      hud.isAds
                        ? 'border-emerald-300 bg-emerald-400 text-slate-950'
                        : 'border-emerald-400/40 bg-emerald-500/20 text-emerald-200 hover:bg-emerald-500/30'
                    }`}
                  >
                    <Target className="h-3.5 w-3.5" />
                    Bidik / ADS
                  </button>
                  <button
                    onClick={() => engineRef.current?.triggerReload()}
                    className="flex items-center gap-1.5 rounded-lg border border-amber-400/40 bg-amber-500/20 px-3 py-1.5 text-[11px] font-bold text-amber-200 transition hover:bg-amber-500/30"
                  >
                    <RotateCcw className="h-3.5 w-3.5" />
                    Reload (Gambar 1)
                  </button>
                  <button
                    onClick={() => engineRef.current?.triggerInspect()}
                    className="flex items-center gap-1.5 rounded-lg border border-purple-400/40 bg-purple-500/20 px-3 py-1.5 text-[11px] font-bold text-purple-200 transition hover:bg-purple-500/30"
                  >
                    <Eye className="h-3.5 w-3.5" />
                    Inspect Polygon
                  </button>
                </div>
              </div>
              <div />
            </div>
          )}
        </>
      )}
    </div>
  );
}

export default App;
