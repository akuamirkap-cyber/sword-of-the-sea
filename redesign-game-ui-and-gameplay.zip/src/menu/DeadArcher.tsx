import { useEffect, useRef } from 'react';
import { v } from '../game/util';
import { BowId, Slab2, drawArrow, drawBow, impulse, makeStick, stepStick } from '../game/ragdoll/stick';
import { HeadStyle, makeHair, stepHair } from '../game/ragdoll/head';
import { drawSkinFigure } from '../SkinModal';

/* The real in-game archer on a transparent canvas, replaying his own defeat: he stands ready, gets hit,
   crumples with the same ragdoll physics as in a fight and ends up lying on the grass beside his bow
   and the arrows he planted. */

const STEP = 1 / 120;
const SLAB: Slab2[] = [{ x0: -500, x1: 500, top: 0, bot: 60 }];

interface Props {
  skin: HeadStyle;
  bow: BowId;
  /** seconds before the fatal hit lands */
  delay?: number;
  /** world units that fit in the canvas height */
  units?: number;
  ox?: number;
  oy?: number;
  className?: string;
}

export default function DeadArcher({ skin, bow, delay = 0.7, units = 84, ox = 0.5, oy = 0.96, className }: Props) {
  const ref = useRef<HTMLCanvasElement>(null);
  const live = useRef({ skin, bow, units, ox, oy });
  live.current = { skin, bow, units, ox, oy };

  useEffect(() => {
    const canvas = ref.current;
    const ctx = canvas?.getContext('2d');
    if (!canvas || !ctx) return;
    const k = makeStick(v(0, 0), 1, 1, false, true);
    const hair = makeHair(live.current.skin, k);
    let t = 0; let dead = false; let acc = 0; let prev = 0; let raf = 0;
    const step = () => {
      t += STEP;
      if (!dead) {
        k.base = v(0, 0); k.vigor = 1; k.muscle = Math.min(1, k.muscle + STEP * 1.1);
        k.aiming = Math.min(1, k.aiming + STEP * 2.2); k.aim = -0.2;
        if (t > delay) {
          dead = true;
          k.alive = false; k.muscle = 0; k.pull = 0; k.hasBow = false; k.fade = 0.38; k.hurt = 1;
          impulse(k, 0, v(-150, -230)); impulse(k, 1, v(-120, -110)); impulse(k, 2, v(-70, -40));
        }
      }
      k.lookAt = null;
      stepStick(k, SLAB);
      if (hair) stepHair(k, hair);
    };
    // let him settle into his stance before the first frame
    for (let i = 0; i < 70; i++) { t = 0; step(); }
    t = 0;

    const paint = (rt: number) => {
      const o = live.current;
      const r = canvas.getBoundingClientRect();
      const dpr = Math.min(window.devicePixelRatio || 1, 2);
      const w = Math.max(8, r.width); const h = Math.max(8, r.height);
      const cw = Math.round(w * dpr); const ch = Math.round(h * dpr);
      if (canvas.width !== cw || canvas.height !== ch) { canvas.width = cw; canvas.height = ch; }
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
      ctx.clearRect(0, 0, w, h);
      const Z = h / o.units;
      ctx.translate(w * o.ox, h * o.oy);
      ctx.scale(Z, Z);
      ctx.lineCap = 'round';
      // the arrows he planted, one at each side
      drawArrow(ctx, v(-58, 3), Math.PI / 2 + 0.22, 1, true, o.bow, rt, false);
      drawArrow(ctx, v(44, 3), Math.PI / 2 - 0.2, 1, true, o.bow, rt, false);
      // his bow, dropped beside him once the blow lands
      if (dead) drawBow(ctx, v(124, -5), -0.2, 1, null, 0, false, o.bow, rt);
      drawSkinFigure(ctx, k, o.skin, hair, rt, dead ? null : o.bow);
    };

    let rt = 0;
    const loop = (now: number) => {
      const dt = Math.min(0.05, prev ? (now - prev) / 1000 : 0.016);
      prev = now; rt += dt; acc += dt;
      let guard = 0;
      while (acc >= STEP && guard++ < 10) { step(); acc -= STEP; }
      if (guard >= 10) acc = 0;
      paint(rt);
      raf = requestAnimationFrame(loop);
    };
    raf = requestAnimationFrame(loop);
    return () => cancelAnimationFrame(raf);
  }, [delay]);

  return <canvas ref={ref} className={className} aria-hidden="true" />;
}
