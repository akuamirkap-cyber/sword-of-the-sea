import * as THREE from 'three';
import {
  buildSmoothOutlineGeometry,
  createMat,
  getOutlineMaterial,
} from './materials';
import {
  createBeveledBoxGeometry,
  createLoftGeometry,
  createStylizedHeadGeometry,
  LoftRing,
} from './common';
import { AnimMode } from './types';

function mulberry32(seed: number) {
  let a = seed >>> 0;
  return () => {
    a |= 0;
    a = (a + 0x6d2b79f5) | 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

let cachedZombieFaceTex: THREE.CanvasTexture | null = null;
let cachedTornClothTex: THREE.CanvasTexture | null = null;
let cachedTornPantsTex: THREE.CanvasTexture | null = null;

/**
 * Stylized low-poly World War Z infected face texture:
 * Gaunt hollow eye sockets with crazed pale eyes, bruised cheeks, and gaping blood-stained screaming jaws.
 */
function getZombieFaceTexture(): THREE.CanvasTexture {
  if (cachedZombieFaceTex) return cachedZombieFaceTex;
  const size = 512;
  const canvas = document.createElement('canvas');
  canvas.width = size;
  canvas.height = size;
  const ctx = canvas.getContext('2d')!;

  // Neutral pale base (multiplied per-instance by undead skin color!)
  ctx.fillStyle = '#e8ece6';
  ctx.fillRect(0, 0, size, size);

  // Subtle gaunt cheek hollows & grime smudges around front face (u near 0 and 1!)
  const drawFrontFeature = (drawFn: (ox: number) => void) => {
    drawFn(0);
    drawFn(size);
  };

  drawFrontFeature((ox) => {
    // Sunken dark bruised eye sockets calibrated to exact Golden-Ratio head UV (y=254px)
    for (const s of [-1, 1]) {
      const ex = ox + s * 38;
      const ey = 254;
      ctx.fillStyle = '#241c1f';
      ctx.beginPath();
      ctx.ellipse(ex, ey, 22, 17, s * 0.14, 0, Math.PI * 2);
      ctx.fill();

      // Crazed pale milky infected eye staring intently!
      ctx.fillStyle = '#f2f7cc';
      ctx.beginPath();
      ctx.arc(ex, ey, 6.5, 0, Math.PI * 2);
      ctx.fill();
    }

    // Hollow dark nostril shadow
    ctx.fillStyle = '#473d3d';
    ctx.fillRect(ox - 7, 302, 14, 10);

    // Gaping World War Z screaming dark-crimson mouth + ragged snapping white teeth (y=376px)!
    ctx.fillStyle = '#330a0d';
    ctx.beginPath();
    ctx.ellipse(ox, 376, 44, 35, 0, 0, Math.PI * 2);
    ctx.fill();

    // Crimson blood smears dripping down chin
    ctx.fillStyle = 'rgba(138, 18, 20, 0.78)';
    ctx.fillRect(ox - 24, 396, 10, 48);
    ctx.fillRect(ox + 10, 398, 12, 42);
    ctx.fillRect(ox - 4, 404, 8, 56);

    // Ragged upper & lower snapping teeth
    ctx.fillStyle = '#ece8d8';
    for (let t = -30; t <= 30; t += 12) {
      ctx.fillRect(ox + t - 4, 346, 7, 14);
      ctx.fillRect(ox + t - 3, 390, 6, 12);
    }
  });

  const tex = new THREE.CanvasTexture(canvas);
  tex.colorSpace = THREE.SRGBColorSpace;
  tex.wrapS = THREE.RepeatWrapping;
  tex.wrapT = THREE.ClampToEdgeWrapping;
  tex.anisotropy = 4;
  cachedZombieFaceTex = tex;
  return tex;
}

/**
 * Torn, shredded, blood-and-grime stained cloth texture for zombie shirts/jackets/suits!
 * Bright neutral base lets `InstancedMesh.setColorAt` give every zombie a unique vivid costume color
 * while jagged rips, frayed tears, and dark stains stand out unmistakably!
 */
function getTornClothTexture(): THREE.CanvasTexture {
  if (cachedTornClothTex) return cachedTornClothTex;
  const size = 512;
  const canvas = document.createElement('canvas');
  canvas.width = size;
  canvas.height = size;
  const ctx = canvas.getContext('2d')!;
  const rand = mulberry32(42119);

  // Clean light-neutral fabric base
  ctx.fillStyle = '#e6e6e4';
  ctx.fillRect(0, 0, size, size);

  // Dirty weathered fabric patches & folds
  for (let i = 0; i < 24; i++) {
    ctx.fillStyle = i % 2 === 0 ? 'rgba(65, 58, 50, 0.24)' : 'rgba(255,255,255,0.14)';
    ctx.fillRect(rand() * size, rand() * size, 32 + rand() * 88, 48 + rand() * 110);
  }

  // Jagged horizontal & diagonal rips revealing dark shadow & frayed fabric edges!
  for (let i = 0; i < 11; i++) {
    const cx = 30 + rand() * (size - 60);
    const cy = 60 + rand() * (size - 120);
    const rw = 46 + rand() * 68;
    const rh = 16 + rand() * 24;

    ctx.fillStyle = '#2d2321';
    ctx.beginPath();
    ctx.moveTo(cx - rw * 0.5, cy);
    ctx.lineTo(cx - rw * 0.2, cy - rh * 0.55);
    ctx.lineTo(cx + rw * 0.15, cy - rh * 0.3);
    ctx.lineTo(cx + rw * 0.5, cy + rh * 0.1);
    ctx.lineTo(cx + rw * 0.18, cy + rh * 0.6);
    ctx.lineTo(cx - rw * 0.25, cy + rh * 0.4);
    ctx.closePath();
    ctx.fill();

    // Frayed bright cloth threads spanning across rip!
    ctx.strokeStyle = '#d4cec6';
    ctx.lineWidth = 3;
    for (let k = -2; k <= 2; k++) {
      ctx.beginPath();
      ctx.moveTo(cx - rw * 0.35, cy + k * 4);
      ctx.lineTo(cx + rw * 0.35, cy + k * 3 + 2);
      ctx.stroke();
    }
  }

  // Dark blood/grime splatters on front chest & torn bottom hem
  for (let i = 0; i < 14; i++) {
    ctx.fillStyle = 'rgba(85, 22, 22, 0.52)';
    const x = rand() * size;
    const y = 80 + rand() * (size - 100);
    ctx.beginPath();
    ctx.ellipse(x, y, 14 + rand() * 28, 18 + rand() * 34, rand() * Math.PI, 0, Math.PI * 2);
    ctx.fill();
  }

  // Dark shredded jagged shadow along lower garment hem (y near 450..512)
  ctx.fillStyle = '#332926';
  ctx.beginPath();
  ctx.moveTo(0, 512);
  for (let x = 0; x <= size; x += 24) {
    const jag = 468 + ((x * 37) % 38);
    ctx.lineTo(x, jag);
  }
  ctx.lineTo(size, 512);
  ctx.closePath();
  ctx.fill();

  const tex = new THREE.CanvasTexture(canvas);
  tex.colorSpace = THREE.SRGBColorSpace;
  tex.wrapS = THREE.RepeatWrapping;
  tex.wrapT = THREE.RepeatWrapping;
  tex.anisotropy = 4;
  cachedTornClothTex = tex;
  return tex;
}

/**
 * Torn distressed zombie trousers texture with ragged knee holes & grime.
 */
function getTornPantsTexture(): THREE.CanvasTexture {
  if (cachedTornPantsTex) return cachedTornPantsTex;
  const size = 256;
  const canvas = document.createElement('canvas');
  canvas.width = size;
  canvas.height = size;
  const ctx = canvas.getContext('2d')!;
  const rand = mulberry32(88317);

  ctx.fillStyle = '#dfdfdc';
  ctx.fillRect(0, 0, size, size);

  for (let i = 0; i < 14; i++) {
    ctx.fillStyle = 'rgba(55, 48, 42, 0.28)';
    ctx.fillRect(rand() * size, rand() * size, 24 + rand() * 52, 40 + rand() * 90);
  }
  // Ragged knee tear rips
  for (let i = 0; i < 5; i++) {
    const x = 20 + rand() * (size - 40);
    const y = 55 + rand() * (size - 110);
    ctx.fillStyle = '#322624';
    ctx.fillRect(x, y, 36 + rand() * 34, 14 + rand() * 14);
    ctx.strokeStyle = '#d0cbc4';
    ctx.lineWidth = 2;
    ctx.beginPath();
    ctx.moveTo(x + 2, y + 6);
    ctx.lineTo(x + 32, y + 6);
    ctx.stroke();
  }

  const tex = new THREE.CanvasTexture(canvas);
  tex.colorSpace = THREE.SRGBColorSpace;
  tex.wrapS = THREE.RepeatWrapping;
  tex.wrapT = THREE.RepeatWrapping;
  cachedTornPantsTex = tex;
  return tex;
}

/**
 * Merges an array of non-indexed or indexed BufferGeometries (position + normal + uv)
 * into a single static BufferGeometry so each costume archetype stays 1 draw call!
 */
function mergeSimpleGeometries(geoms: THREE.BufferGeometry[]): THREE.BufferGeometry {
  const nonIndexed = geoms.map((g) => (g.index ? g.toNonIndexed() : g.clone()));
  let totalVerts = 0;
  for (const g of nonIndexed) {
    totalVerts += g.getAttribute('position').count;
  }

  const posArr = new Float32Array(totalVerts * 3);
  const uvArr = new Float32Array(totalVerts * 2);

  let vOffset = 0;
  for (const g of nonIndexed) {
    const p = g.getAttribute('position') as THREE.BufferAttribute;
    const uv = g.getAttribute('uv') as THREE.BufferAttribute | undefined;
    for (let i = 0; i < p.count; i++) {
      posArr[(vOffset + i) * 3] = p.getX(i);
      posArr[(vOffset + i) * 3 + 1] = p.getY(i);
      posArr[(vOffset + i) * 3 + 2] = p.getZ(i);
      if (uv) {
        uvArr[(vOffset + i) * 2] = uv.getX(i);
        uvArr[(vOffset + i) * 2 + 1] = uv.getY(i);
      }
    }
    vOffset += p.count;
    g.dispose();
  }

  const out = new THREE.BufferGeometry();
  out.setAttribute('position', new THREE.BufferAttribute(posArr, 3));
  out.setAttribute('uv', new THREE.BufferAttribute(uvArr, 2));
  out.computeVertexNormals();
  return out;
}

/**
 * Builds 4 distinctly sculpted TORN & TATTERED zombie costume torso geometries (centered around local y=0..0.52):
 *  0: Torn Office Commuter Suit (ripped blazer lapels + jagged trailing tails + crooked tie!)
 *  1: Shredded Street Hoodie (saw-tooth torn bottom hem + bunched ragged hood collar + torn shoulder!)
 *  2: Tattered Tactical / Security Vest (broken chest plates + asymmetrical ripped pockets + dangling strap!)
 *  3: Ripped Sleeveless / Torn Civilian Tee (jagged diagonal hem tear + dangling torn cloth strips!)
 */
function createZombieTorsoArchetype(archetype: 0 | 1 | 2 | 3): THREE.BufferGeometry {
  const parts: THREE.BufferGeometry[] = [];

  // Saw-tooth jagged torn bottom edge helper!
  const jaggedHem = (seedShift: number, amp = 0.036) => (angle: number) => ({
    dyAdd: Math.sin(angle * 4 + seedShift) * amp + Math.cos(angle * 3 - seedShift) * (amp * 0.55),
  });

  if (archetype === 0) {
    // 0: TORN OFFICE SUIT BLAZER + CROOKED TIE
    const rings: LoftRing[] = [
      { y: -0.04, rx: 0.168, rz: 0.112, shape: jaggedHem(0.4, 0.042) }, // Shredded suit tails!
      { y: 0.12, rx: 0.162, rz: 0.106 },
      { y: 0.32, rx: 0.198, rz: 0.120 },
      { y: 0.45, rx: 0.208, rz: 0.120 },
      { y: 0.51, rx: 0.095, rz: 0.088 },
    ];
    parts.push(createLoftGeometry(rings, 8, true, true));

    // Torn suit lapels jutting sharply outward
    for (const s of [-1, 1]) {
      const lapel = createBeveledBoxGeometry(0.056, 0.22, 0.022, 0.004);
      lapel.rotateZ(s * -0.26);
      lapel.translate(s * 0.068, 0.37, 0.122);
      parts.push(lapel);
    }
    // Crooked dangling necktie swinging askew!
    const tie = createBeveledBoxGeometry(0.036, 0.24, 0.014, 0.003);
    tie.rotateZ(0.28);
    tie.translate(0.024, 0.34, 0.128);
    parts.push(tie);
  } else if (archetype === 1) {
    // 1: SHREDDED STREET HOODIE (baggy jagged hem + bunched torn hood around back of neck!)
    const rings: LoftRing[] = [
      { y: -0.05, rx: 0.184, rz: 0.124, shape: jaggedHem(1.7, 0.052) },
      { y: 0.14, rx: 0.182, rz: 0.120 },
      { y: 0.34, rx: 0.212, rz: 0.130 },
      { y: 0.46, rx: 0.214, rz: 0.126 },
      { y: 0.52, rx: 0.112, rz: 0.104 },
    ];
    parts.push(createLoftGeometry(rings, 8, true, true));

    // Bunched ragged hoodie cowl behind neck
    const hood = createLoftGeometry(
      [
        { y: 0.45, rx: 0.136, rz: 0.132, oz: -0.022 },
        { y: 0.54, rx: 0.122, rz: 0.120, oz: -0.028 },
      ],
      8,
      false,
      true
    );
    parts.push(hood);

    // Torn half-detached front kangaroo pocket flap
    const pocket = createBeveledBoxGeometry(0.16, 0.10, 0.028, 0.005);
    pocket.rotateZ(-0.18);
    pocket.translate(-0.02, 0.12, 0.132);
    parts.push(pocket);
  } else if (archetype === 2) {
    // 2: TATTERED TACTICAL / SECURITY VEST (broken armor plate + ripped pockets + dangling strap!)
    const rings: LoftRing[] = [
      { y: -0.02, rx: 0.166, rz: 0.112, shape: jaggedHem(3.1, 0.036) },
      { y: 0.14, rx: 0.172, rz: 0.116 },
      { y: 0.33, rx: 0.208, rz: 0.128 },
      { y: 0.45, rx: 0.212, rz: 0.124 },
      { y: 0.51, rx: 0.096, rz: 0.090 },
    ];
    parts.push(createLoftGeometry(rings, 8, true, true));

    // Crooked cracked front chest vest plate
    const plate = createBeveledBoxGeometry(0.26, 0.28, 0.048, 0.008);
    plate.rotateZ(0.06);
    plate.translate(0, 0.27, 0.124);
    parts.push(plate);

    // Asymmetric surviving torn pouches (one missing/ripped off!)
    const p1 = createBeveledBoxGeometry(0.072, 0.11, 0.044, 0.005);
    p1.rotateZ(-0.12);
    p1.translate(-0.082, 0.17, 0.156);
    parts.push(p1);

    const p2 = createBeveledBoxGeometry(0.078, 0.095, 0.044, 0.005);
    p2.rotateZ(0.24);
    p2.translate(0.078, 0.15, 0.152);
    parts.push(p2);
  } else {
    // 3: SHREDDED RAGGED CIVILIAN T-SHIRT / WORKER TANK (heavily jagged bottom + dangling cloth tatters!)
    const rings: LoftRing[] = [
      { y: 0.02, rx: 0.158, rz: 0.104, shape: jaggedHem(4.9, 0.056) }, // Deep torn belly cut!
      { y: 0.16, rx: 0.162, rz: 0.108 },
      { y: 0.34, rx: 0.198, rz: 0.122 },
      { y: 0.45, rx: 0.202, rz: 0.118 },
      { y: 0.51, rx: 0.092, rz: 0.086 },
    ];
    parts.push(createLoftGeometry(rings, 8, true, true));

    // 3 hanging jagged ripped shirt tatter strips fluttering off the torn waist!
    const strips = [
      { x: -0.11, y: -0.04, z: 0.092, rz: -0.22 },
      { x: 0.04, y: -0.05, z: 0.102, rz: 0.16 },
      { x: 0.12, y: -0.03, z: -0.088, rz: 0.28 },
    ];
    for (const st of strips) {
      const rag = createBeveledBoxGeometry(0.048, 0.135, 0.016, 0.003);
      rag.rotateZ(st.rz);
      rag.translate(st.x, st.y, st.z);
      parts.push(rag);
    }
  }

  // Short integrated torn-collar neck connector so frantic head snapping never leaves a gap!
  parts.push(
    createLoftGeometry(
      [
        { y: 0.48, rx: 0.068, rz: 0.066 },
        { y: 0.56, rx: 0.056, rz: 0.056 },
      ],
      8,
      false,
      true
    )
  );

  return mergeSimpleGeometries(parts);
}

/**
 * Builds a ragged disheveled zombie hair cap (offset cleanly above skull so zero z-fighting!).
 */
function createRaggedHairGeometry(): THREE.BufferGeometry {
  const hairShape = (angle: number) => {
    const front = Math.cos(angle);
    const jag = Math.sin(angle * 5) * 0.012 + Math.cos(angle * 3) * 0.008;
    return {
      dyAdd: front < 0.15 ? -0.068 * ((0.15 - front) / 1.15) + jag : 0.014 + jag * 0.6,
    };
  };
  return createLoftGeometry(
    [
      { y: 0.064, rx: 0.102, rz: 0.118, oz: -0.004, shape: hairShape },
      { y: 0.115, rx: 0.096, rz: 0.112, oz: -0.006 },
      { y: 0.152, rx: 0.064, rz: 0.076, oz: -0.008 },
      { y: 0.164, rx: 0.024, rz: 0.028, oz: -0.008 },
    ],
    8,
    false,
    true
  );
}

/**
 * Builds a single-bone upper limb segment extending from local y = 0 down to y = -length.
 */
function createLimbSegmentGeometry(
  length: number,
  rTop: number,
  rBot: number,
  tatteredCuff = false
): THREE.BufferGeometry {
  const cuffShape = tatteredCuff
    ? (ang: number) => ({ dyAdd: Math.sin(ang * 4) * 0.018 })
    : undefined;
  return createLoftGeometry(
    [
      { y: -length, rx: rBot, rz: rBot * 1.02, shape: cuffShape },
      { y: -length * 0.5, rx: (rTop + rBot) * 0.52, rz: (rTop + rBot) * 0.52 },
      { y: 0.02, rx: rTop, rz: rTop * 1.02 },
    ],
    7,
    true,
    true
  );
}

/**
 * Builds forearm + reaching clawed zombie hand extending from elbow y = 0 down to y = -0.34.
 */
function createZombieForearmClawGeometry(): THREE.BufferGeometry {
  const parts: THREE.BufferGeometry[] = [];
  parts.push(createLimbSegmentGeometry(0.24, 0.048, 0.036, false));

  // Clawed reaching zombie palm + curled talon fingers
  const palm = createBeveledBoxGeometry(0.068, 0.076, 0.030, 0.008);
  palm.translate(0, -0.268, 0.006);
  parts.push(palm);

  const claws = createBeveledBoxGeometry(0.066, 0.056, 0.026, 0.007);
  claws.rotateX(-0.55);
  claws.translate(0, -0.312, 0.024);
  parts.push(claws);

  return mergeSimpleGeometries(parts);
}

/**
 * Builds lower zombie shin + tattered shoe extending from knee y = 0 down to floor y = -0.49.
 */
function createZombieShinFootGeometry(): THREE.BufferGeometry {
  const parts: THREE.BufferGeometry[] = [];
  parts.push(createLimbSegmentGeometry(0.39, 0.068, 0.050, false));

  // Stylized torn shoe grounded cleanly at y = -0.49
  const foot = createBeveledBoxGeometry(0.098, 0.095, 0.215, 0.014);
  foot.translate(0, -0.442, 0.045);
  parts.push(foot);

  return mergeSimpleGeometries(parts);
}

type ZombieBehavior = 'lunger' | 'sprinter' | 'flailer' | 'leaper';

interface ZombieAgent {
  index: number;
  archetype: 0 | 1 | 2 | 3;
  archetypeSlot: number;
  behavior: ZombieBehavior;

  // Spatial swarm position behind squad
  baseX: number;
  baseZ: number;
  curX: number;
  curY: number;
  curZ: number;
  scale: number;

  // Dynamic rabid motion parameters
  stridePhase: number;
  speedRate: number;
  surgeSeed: number;
  weaveSeed: number;
  headTiltZ: number;
  headTwitchFreq: number;
  leapTimer: number;
  leapDuration: number;
  isLeaping: boolean;

  // Appearance diversity (asymmetric torn sleeves/pants!)
  hasHair: boolean;
  hairSlot: number;
  leftSleeveTorn: boolean;
  rightSleeveTorn: boolean;
  leftPantTorn: boolean;
  rightPantTorn: boolean;

  // Interactive gunshot knockback state!
  kbActive: boolean;
  kbTimer: number;
  kbPos: THREE.Vector3;
  kbVel: THREE.Vector3;
  kbRot: THREE.Euler;
  kbSpin: THREE.Vector3;
}

const SKIN_PALETTE = [
  0x8b9b82, // Sickly pale olive-green undead
  0x9aa494, // Ashy corpse grey-green
  0x7e8a7e, // Bruised slate infected
  0xa4a18f, // Pale jaundiced survivor
  0x8c8a86, // Pale concrete grey
  0x958d80, // Weathered ash tan
];

const COSTUME_COLORS = [
  0x3b4859, // Torn navy office suit / jacket
  0x6b3230, // Stained burgundy hoodie
  0x4f5a3e, // Shredded olive fatigues
  0x9a958b, // Soiled dirty white dress shirt
  0x2c3038, // Charcoal ripped jacket
  0x7d653c, // Torn mustard/khaki worker shirt
  0x3c5b5c, // Faded teal tattered polo
  0x574238, // Weathered brown commuter coat
  0x6e4444, // Dusty crimson torn tee
  0x4d4c5c, // Faded plum-slate hoodie
  0x7a7f76, // Pale soiled hazmat/work jacket
  0x334b68, // Denim blue ripped overshirt
];

const PANTS_COLORS = [
  0x29384d, // Faded torn blue jeans
  0x25272d, // Charcoal office slacks
  0x4c483b, // Dirty khaki cargo pants
  0x33392e, // Torn olive work pants
  0x3a322d, // Dusty brown trousers
  0x1d1f24, // Dark torn sweatpants
];

const HAIR_COLORS = [0x1c1816, 0x33261e, 0x4b4642, 0x2a211c, 0x523929];

export interface ZombieShootResult {
  hit: boolean;
  worldPoint: THREE.Vector3;
}

/**
 * High-performance GPU-Instanced World War Z Zombie Horde (~84 fully articulated,
 * cel-outlined infected with 4 distinct torn costume silhouettes & zero-lag rendering!).
 */
export class WorldWarZHorde {
  public readonly group = new THREE.Group();
  public readonly count: number;
  public readonly hitMeshes: THREE.InstancedMesh[] = [];

  private readonly agents: ZombieAgent[] = [];

  // InstancedMeshes (all static ~22 draw calls total!)
  private readonly headMesh: THREE.InstancedMesh;
  private readonly headOutline: THREE.InstancedMesh;
  private readonly hairMesh: THREE.InstancedMesh;

  private readonly torsoMeshes: THREE.InstancedMesh[] = [];
  private readonly torsoOutlines: THREE.InstancedMesh[] = [];
  private readonly pelvisMesh: THREE.InstancedMesh;

  private readonly upperArmMesh: THREE.InstancedMesh;
  private readonly upperArmOutline: THREE.InstancedMesh;
  private readonly forearmMesh: THREE.InstancedMesh;
  private readonly forearmOutline: THREE.InstancedMesh;

  private readonly thighMesh: THREE.InstancedMesh;
  private readonly thighOutline: THREE.InstancedMesh;
  private readonly shinMesh: THREE.InstancedMesh;
  private readonly shinOutline: THREE.InstancedMesh;

  private readonly allInstanced: THREE.InstancedMesh[] = [];
  private readonly ownedGeoms: THREE.BufferGeometry[] = [];
  private readonly ownedMats: THREE.Material[] = [];

  // Zero-GC scratch transform objects for 60fps per-frame animation
  private readonly _mRoot = new THREE.Matrix4();
  private readonly _mTorso = new THREE.Matrix4();
  private readonly _mHead = new THREE.Matrix4();
  private readonly _mPart = new THREE.Matrix4();
  private readonly _mSub = new THREE.Matrix4();
  private readonly _mLocal = new THREE.Matrix4();
  private readonly _qTemp = new THREE.Quaternion();
  private readonly _eTemp = new THREE.Euler(0, 0, 0, 'YXZ');
  private readonly _vPos = new THREE.Vector3();
  private readonly _vScale = new THREE.Vector3(1, 1, 1);

  constructor(zombieCount = 84) {
    this.count = zombieCount;
    this.group.name = 'WorldWarZ_ZombieHorde';
    this.group.userData.isObstacle = true; // Automatically excluded from 9-skin GLB/OBJ export!

    const rand = mulberry32(20130621); // World War Z release seed!
    const outlineMat = getOutlineMaterial();

    // Shared flat-shaded stylized materials
    const headMat = createMat({
      color: 0xffffff,
      map: getZombieFaceTexture(),
      roughness: 0.84,
    });
    const hairMat = createMat({ color: 0xffffff, roughness: 0.90 });
    const tornClothMat = createMat({
      color: 0xffffff,
      map: getTornClothTexture(),
      roughness: 0.88,
    });
    const tornPantsMat = createMat({
      color: 0xffffff,
      map: getTornPantsTexture(),
      roughness: 0.88,
    });
    this.ownedMats.push(headMat, hairMat, tornClothMat, tornPantsMat);

    const makePair = (
      geom: THREE.BufferGeometry,
      mat: THREE.Material,
      cap: number,
      outlineThick: number,
      castShadow = true
    ): [THREE.InstancedMesh, THREE.InstancedMesh] => {
      this.ownedGeoms.push(geom);
      const mesh = new THREE.InstancedMesh(geom, mat, cap);
      mesh.castShadow = castShadow;
      mesh.receiveShadow = true;
      mesh.frustumCulled = false;
      mesh.userData.isZombieHorde = true;
      mesh.userData.isObstacle = true;
      this.group.add(mesh);
      this.allInstanced.push(mesh);

      const olGeom = buildSmoothOutlineGeometry(geom, outlineThick);
      this.ownedGeoms.push(olGeom);
      const olMesh = new THREE.InstancedMesh(olGeom, outlineMat, cap);
      olMesh.castShadow = false;
      olMesh.receiveShadow = false;
      olMesh.frustumCulled = false;
      olMesh.userData.isOutline = true;
      olMesh.userData.isObstacle = true;
      olMesh.renderOrder = 1;
      this.group.add(olMesh);
      this.allInstanced.push(olMesh);

      return [mesh, olMesh];
    };

    // 1. Head + Ragged Hair InstancedMeshes
    const headGeom = createStylizedHeadGeometry({ scale: 0.96, slimX: 0.96, noseRidge: 0.016 });
    [this.headMesh, this.headOutline] = makePair(headGeom, headMat, zombieCount, 0.0046, true);
    this.hitMeshes.push(this.headMesh);

    const hairGeom = createRaggedHairGeometry();
    this.ownedGeoms.push(hairGeom);
    this.hairMesh = new THREE.InstancedMesh(hairGeom, hairMat, zombieCount);
    this.hairMesh.castShadow = false;
    this.hairMesh.receiveShadow = true;
    this.hairMesh.frustumCulled = false;
    this.hairMesh.userData.isObstacle = true;
    this.group.add(this.hairMesh);
    this.allInstanced.push(this.hairMesh);

    // 2. Pelvis InstancedMesh
    const pelvisGeom = createLoftGeometry(
      [
        { y: -0.07, rx: 0.148, rz: 0.100 },
        { y: 0.04, rx: 0.162, rz: 0.108 },
      ],
      8,
      true,
      true
    );
    this.ownedGeoms.push(pelvisGeom);
    this.pelvisMesh = new THREE.InstancedMesh(pelvisGeom, tornPantsMat, zombieCount);
    this.pelvisMesh.castShadow = false;
    this.pelvisMesh.receiveShadow = true;
    this.pelvisMesh.frustumCulled = false;
    this.pelvisMesh.userData.isObstacle = true;
    this.group.add(this.pelvisMesh);
    this.allInstanced.push(this.pelvisMesh);

    // 3. Generate all 84 unique World War Z horde agents FIRST so we know exact counts per costume archetype!
    const archCounts = [0, 0, 0, 0];
    let hairCount = 0;

    for (let i = 0; i < zombieCount; i++) {
      const archetype = (i % 4) as 0 | 1 | 2 | 3;
      const archetypeSlot = archCounts[archetype]++;

      // World War Z Funnel Formation behind the 9-skin squad:
      // Row 0 (front lungers): z = -1.65..-2.65, closely stalking right behind the 9 heroes!
      // Mid rows: dense surging rabid pack z = -2.7..-7.5, fanning wider (-5.2..+5.2)
      // Back wave: massive tidal horde z = -7.5..-12.8, fanning wide (-7.8..+7.8) with leapers!
      const depthNorm = Math.pow(i / Math.max(1, zombieCount - 1), 0.92);
      const baseZ = -1.65 - depthNorm * 10.6 + (rand() - 0.5) * 0.65;
      const halfSpreadX = 3.15 + depthNorm * 4.4;
      // Organic golden-angle + jitter distribution so there are zero artificial grid rows!
      const golden = ((i * 0.6180339887) % 1) * 2 - 1;
      const baseX = THREE.MathUtils.clamp(
        golden * halfSpreadX + (rand() - 0.5) * 0.95,
        -halfSpreadX,
        halfSpreadX
      );

      // Assign rabid World War Z behavioral personality!
      let behavior: ZombieBehavior;
      if (i < 16) {
        behavior = i % 3 === 0 ? 'flailer' : 'lunger';
      } else if (i % 5 === 0) {
        behavior = 'leaper';
      } else if (i % 3 === 0) {
        behavior = 'flailer';
      } else {
        behavior = 'sprinter';
      }

      const hasHair = rand() < 0.72;
      const hairSlot = hasHair ? hairCount++ : -1;

      this.agents.push({
        index: i,
        archetype,
        archetypeSlot,
        behavior,
        baseX,
        baseZ,
        curX: baseX,
        curY: 0,
        curZ: baseZ,
        scale: 0.90 + rand() * 0.17,
        stridePhase: rand(),
        speedRate: 1.55 + rand() * 0.55, // Frantic uneven rabid infected cadence!
        surgeSeed: rand() * Math.PI * 2,
        weaveSeed: rand() * Math.PI * 2,
        headTiltZ: (rand() - 0.5) * 0.62,
        headTwitchFreq: 3.5 + rand() * 5.0,
        leapTimer: 0.6 + rand() * 3.8,
        leapDuration: 0.68 + rand() * 0.18,
        isLeaping: false,
        hasHair,
        hairSlot,
        leftSleeveTorn: archetype === 3 || rand() < 0.36,
        rightSleeveTorn: archetype === 3 || rand() < 0.36,
        leftPantTorn: rand() < 0.32,
        rightPantTorn: rand() < 0.32,
        kbActive: false,
        kbTimer: 0,
        kbPos: new THREE.Vector3(),
        kbVel: new THREE.Vector3(),
        kbRot: new THREE.Euler(),
        kbSpin: new THREE.Vector3(),
      });
    }

    this.hairMesh.count = hairCount;

    // 4. Create the 4 distinct Torn Costume Torso InstancedMeshes!
    for (let a = 0; a < 4; a++) {
      const cap = Math.max(1, archCounts[a]);
      const geom = createZombieTorsoArchetype(a as 0 | 1 | 2 | 3);
      const [mesh, ol] = makePair(geom, tornClothMat, cap, 0.0052, true);
      mesh.userData.zombieArchetype = a;
      this.torsoMeshes.push(mesh);
      this.torsoOutlines.push(ol);
      this.hitMeshes.push(mesh);
    }

    // 5. Shared Left+Right Limb InstancedMeshes (2 * zombieCount instances each = ONLY 8 draw calls!)
    const upperArmGeom = createLimbSegmentGeometry(0.24, 0.062, 0.048, true);
    [this.upperArmMesh, this.upperArmOutline] = makePair(
      upperArmGeom,
      tornClothMat,
      zombieCount * 2,
      0.0040,
      false
    );

    const forearmGeom = createZombieForearmClawGeometry();
    [this.forearmMesh, this.forearmOutline] = makePair(
      forearmGeom,
      tornClothMat,
      zombieCount * 2,
      0.0036,
      false
    );

    const thighGeom = createLimbSegmentGeometry(0.37, 0.088, 0.068, true);
    [this.thighMesh, this.thighOutline] = makePair(
      thighGeom,
      tornPantsMat,
      zombieCount * 2,
      0.0042,
      false
    );

    const shinGeom = createZombieShinFootGeometry();
    [this.shinMesh, this.shinOutline] = makePair(
      shinGeom,
      tornPantsMat,
      zombieCount * 2,
      0.0040,
      false
    );

    // 6. Paint unique per-instance colors (skin, varied torn costumes, torn bare sleeves/calves, hair!)
    const col = new THREE.Color();
    const skinCol = new THREE.Color();
    const shirtCol = new THREE.Color();
    const pantsCol = new THREE.Color();
    const hairCol = new THREE.Color();

    for (const ag of this.agents) {
      const i = ag.index;
      skinCol.setHex(SKIN_PALETTE[Math.floor(rand() * SKIN_PALETTE.length)]);
      skinCol.offsetHSL((rand() - 0.5) * 0.03, (rand() - 0.5) * 0.05, (rand() - 0.5) * 0.08);

      shirtCol.setHex(COSTUME_COLORS[Math.floor(rand() * COSTUME_COLORS.length)]);
      shirtCol.offsetHSL((rand() - 0.5) * 0.04, (rand() - 0.5) * 0.08, (rand() - 0.5) * 0.10);

      pantsCol.setHex(PANTS_COLORS[Math.floor(rand() * PANTS_COLORS.length)]);
      pantsCol.offsetHSL((rand() - 0.5) * 0.02, (rand() - 0.5) * 0.06, (rand() - 0.5) * 0.08);

      hairCol.setHex(HAIR_COLORS[Math.floor(rand() * HAIR_COLORS.length)]);

      this.headMesh.setColorAt(i, skinCol);
      this.pelvisMesh.setColorAt(i, pantsCol);
      this.torsoMeshes[ag.archetype].setColorAt(ag.archetypeSlot, shirtCol);

      if (ag.hasHair && ag.hairSlot >= 0) {
        this.hairMesh.setColorAt(ag.hairSlot, hairCol);
      }

      // Asymmetric Torn Sleeves: torn arm exposes bare undead zombie skin, intact arm uses tattered shirt!
      this.upperArmMesh.setColorAt(i * 2, ag.leftSleeveTorn ? skinCol : shirtCol);
      this.upperArmMesh.setColorAt(i * 2 + 1, ag.rightSleeveTorn ? skinCol : shirtCol);
      // Forearms & claw hands mostly bare bloodied undead skin (or torn sleeve cuff)
      this.forearmMesh.setColorAt(i * 2, skinCol);
      this.forearmMesh.setColorAt(i * 2 + 1, skinCol);

      // Asymmetric Torn Pants: ripped shin exposes pale scarred undead calf!
      this.thighMesh.setColorAt(i * 2, pantsCol);
      this.thighMesh.setColorAt(i * 2 + 1, pantsCol);
      this.shinMesh.setColorAt(
        i * 2,
        ag.leftPantTorn ? col.copy(skinCol).lerp(pantsCol, 0.25) : pantsCol
      );
      this.shinMesh.setColorAt(
        i * 2 + 1,
        ag.rightPantTorn ? col.copy(skinCol).lerp(pantsCol, 0.25) : pantsCol
      );
    }

    for (const m of this.allInstanced) {
      if (m.instanceColor) m.instanceColor.needsUpdate = true;
    }

    // Run one initial layout frame so horde starts posed cleanly on frame 0
    this.update(0.016, 0, 'chase', 1.15);
  }

  public setOutlinesVisible(show: boolean): void {
    this.headOutline.visible = show;
    this.upperArmOutline.visible = show;
    this.forearmOutline.visible = show;
    this.thighOutline.visible = show;
    this.shinOutline.visible = show;
    this.torsoOutlines.forEach((m) => {
      m.visible = show;
    });
  }

  public setWireframe(wire: boolean): void {
    for (const mat of this.ownedMats) {
      if ('wireframe' in mat) {
        (mat as THREE.MeshStandardMaterial).wireframe = wire;
      }
    }
  }

  /**
   * Resolves a raycast hit on ANY zombie InstancedMesh into a blast-back knockback ragdoll!
   */
  public handleRaycastShoot(hit: THREE.Intersection): ZombieShootResult {
    const obj = hit.object as THREE.InstancedMesh;
    const instId = hit.instanceId;
    if (instId === undefined) {
      return { hit: false, worldPoint: hit.point };
    }

    let agent: ZombieAgent | undefined;
    if (obj === this.headMesh) {
      agent = this.agents[instId];
    } else if (typeof obj.userData.zombieArchetype === 'number') {
      const arch = obj.userData.zombieArchetype as number;
      agent = this.agents.find((a) => a.archetype === arch && a.archetypeSlot === instId);
    }

    if (!agent) return { hit: false, worldPoint: hit.point };

    // Launch zombie dramatically backward through the horde!
    agent.kbActive = true;
    agent.kbTimer = 0;
    agent.kbPos.set(agent.curX, agent.curY + 0.88 * agent.scale, agent.curZ);
    agent.kbVel.set(
      (Math.random() - 0.5) * 3.4,
      2.6 + Math.random() * 1.4,
      -5.8 - Math.random() * 2.4
    );
    agent.kbRot.set(-0.5, (Math.random() - 0.5) * 0.6, (Math.random() - 0.5) * 0.5);
    agent.kbSpin.set(
      -5.5 - Math.random() * 3.0,
      (Math.random() - 0.5) * 5.0,
      (Math.random() - 0.5) * 4.5
    );

    return { hit: true, worldPoint: hit.point.clone() };
  }

  /**
   * Updates all 84 World War Z zombies with zero per-frame allocations!
   */
  public update(dt: number, elapsed: number, squadAnimMode: AnimMode, squadSpeedMult: number): void {
    if (!this.group.visible) return;

    const isChasing = squadAnimMode === 'chase';
    const isWalking = squadAnimMode === 'walk';
    const paceFactor = isChasing
      ? 1.05 * squadSpeedMult
      : isWalking
        ? 0.55
        : 0.36; // Snarling agitated twitching horde even in idle/crouch!

    const setMat = (mesh: THREE.InstancedMesh, ol: THREE.InstancedMesh | null, idx: number, m: THREE.Matrix4) => {
      mesh.setMatrixAt(idx, m);
      if (ol) ol.setMatrixAt(idx, m);
    };

    for (let i = 0; i < this.agents.length; i++) {
      const ag = this.agents[i];
      const sc = ag.scale;

      // 1. Handle knocked-back blasted zombies flying backwards before scrambling back into the swarm!
      if (ag.kbActive) {
        ag.kbTimer += dt;
        ag.kbVel.y -= 11.5 * dt;
        ag.kbPos.addScaledVector(ag.kbVel, dt);
        if (ag.kbPos.y < 0.18 * sc) {
          ag.kbPos.y = 0.18 * sc;
          ag.kbVel.y *= -0.25;
          ag.kbVel.x *= 0.78;
          ag.kbVel.z *= 0.78;
          ag.kbSpin.multiplyScalar(0.65);
        }
        ag.kbRot.x += ag.kbSpin.x * dt;
        ag.kbRot.y += ag.kbSpin.y * dt;
        ag.kbRot.z += ag.kbSpin.z * dt;

        this._qTemp.setFromEuler(ag.kbRot);
        this._vScale.setScalar(sc);
        this._mRoot.compose(ag.kbPos, this._qTemp, this._vScale);

        // Pose entire ragdolled zombie cleanly relative to _mRoot
        setMat(this.pelvisMesh, null, i, this._mRoot);

        this._eTemp.set(-0.35, 0, 0);
        this._qTemp.setFromEuler(this._eTemp);
        this._vPos.set(0, 0.04, 0);
        this._vScale.set(1, 1, 1);
        this._mTorso.compose(this._vPos, this._qTemp, this._vScale).premultiply(this._mRoot);
        setMat(this.torsoMeshes[ag.archetype], this.torsoOutlines[ag.archetype], ag.archetypeSlot, this._mTorso);

        this._vPos.set(0, 0.62, 0.01);
        this._eTemp.set(-0.5, 0.3, 0.2);
        this._qTemp.setFromEuler(this._eTemp);
        this._mHead.compose(this._vPos, this._qTemp, this._vScale).premultiply(this._mTorso);
        setMat(this.headMesh, this.headOutline, i, this._mHead);
        if (ag.hasHair) this.hairMesh.setMatrixAt(ag.hairSlot, this._mHead);

        for (let sIdx = 0; sIdx < 2; sIdx++) {
          const s = sIdx === 0 ? 1 : -1;
          this._vPos.set(s * 0.20, 0.43, 0);
          this._eTemp.set(-1.1, 0, s * 0.85);
          this._qTemp.setFromEuler(this._eTemp);
          this._mPart.compose(this._vPos, this._qTemp, this._vScale).premultiply(this._mTorso);
          setMat(this.upperArmMesh, this.upperArmOutline, i * 2 + sIdx, this._mPart);

          this._vPos.set(0, -0.23, 0);
          this._eTemp.set(-0.4, 0, 0);
          this._qTemp.setFromEuler(this._eTemp);
          this._mSub.compose(this._vPos, this._qTemp, this._vScale).premultiply(this._mPart);
          setMat(this.forearmMesh, this.forearmOutline, i * 2 + sIdx, this._mSub);

          this._vPos.set(s * 0.10, -0.02, 0);
          this._eTemp.set(-0.5 + sIdx * 0.25, 0, s * 0.24);
          this._qTemp.setFromEuler(this._eTemp);
          this._mPart.compose(this._vPos, this._qTemp, this._vScale).premultiply(this._mRoot);
          setMat(this.thighMesh, this.thighOutline, i * 2 + sIdx, this._mPart);

          this._vPos.set(0, -0.36, 0);
          this._eTemp.set(0.65, 0, 0);
          this._qTemp.setFromEuler(this._eTemp);
          this._mSub.compose(this._vPos, this._qTemp, this._vScale).premultiply(this._mPart);
          setMat(this.shinMesh, this.shinOutline, i * 2 + sIdx, this._mSub);
        }

        if (ag.kbTimer > 1.85) {
          ag.kbActive = false;
          ag.curZ = ag.baseZ - 1.2;
        }
        continue;
      }

      // 2. Advance frantic World War Z horde stride, surging & periodic pile-up leaps!
      ag.stridePhase = (ag.stridePhase + dt * ag.speedRate * paceFactor) % 1;
      const ph = ag.stridePhase * Math.PI * 2;
      const sWave = Math.sin(ph);
      const cWave = Math.cos(ph);

      // Surging forward/back wave + lateral swarm jostling (classic World War Z liquid-wave feel!)
      const surgeZ = isChasing
        ? Math.sin(elapsed * 1.45 + ag.surgeSeed) * 0.42 +
          Math.sin(elapsed * 2.8 + ag.weaveSeed) * 0.16
        : Math.sin(elapsed * 0.9 + ag.surgeSeed) * 0.22;
      const weaveX = Math.sin(elapsed * 1.15 + ag.weaveSeed) * (isChasing ? 0.34 : 0.14);

      // Periodic World War Z frantic pile-up leaps for leaper zombies while chasing!
      let leapArc = 0;
      let leapEnv = 0;
      if (isChasing && ag.behavior === 'leaper') {
        ag.leapTimer -= dt;
        if (!ag.isLeaping && ag.leapTimer <= 0) {
          ag.isLeaping = true;
          ag.leapTimer = ag.leapDuration;
        } else if (ag.isLeaping) {
          const lp = 1 - Math.max(0, ag.leapTimer / ag.leapDuration);
          leapArc = Math.sin(lp * Math.PI) * 0.72;
          leapEnv = Math.sin(lp * Math.PI);
          if (ag.leapTimer <= 0) {
            ag.isLeaping = false;
            ag.leapTimer = 1.6 + ((i * 0.37) % 2.4);
          }
        }
      } else {
        ag.isLeaping = false;
      }

      ag.curX = ag.baseX + weaveX;
      ag.curZ = ag.baseZ + surgeZ + leapEnv * 0.65;

      // Grounded stride height + springy sprint bounce + leap height (strictly >= 0, zero floor clip!)
      const strideLift = isChasing ? Math.abs(sWave) * 0.082 : isWalking ? Math.abs(sWave) * 0.025 : 0;
      const hipBaseY = (isChasing ? 0.878 : 0.888) * sc;
      ag.curY = leapArc;

      // Aggressive rabid forward torso pitch & chaotic jerky yaw/roll!
      const isLunger = ag.behavior === 'lunger';
      const isFlailer = ag.behavior === 'flailer';
      const hipsRotY = sWave * (isChasing ? 0.18 : 0.08) + Math.sin(elapsed * 1.6 + ag.weaveSeed) * 0.12;
      const hipsRotZ = -sWave * (isFlailer ? 0.11 : 0.055);
      const hipsRotX = leapEnv * 0.32;

      this._vPos.set(ag.curX, hipBaseY + (strideLift + leapArc) * sc, ag.curZ);
      this._eTemp.set(hipsRotX, hipsRotY, hipsRotZ);
      this._qTemp.setFromEuler(this._eTemp);
      this._vScale.setScalar(sc);
      this._mRoot.compose(this._vPos, this._qTemp, this._vScale);
      setMat(this.pelvisMesh, null, i, this._mRoot);

      // Upper Torso: feral hunched World War Z forward charge!
      const torsoPitch =
        (isChasing ? (isLunger ? 0.56 : 0.46) : 0.28) +
        Math.abs(cWave) * 0.06 +
        leapEnv * 0.28;
      const torsoTwist = -sWave * (isFlailer ? 0.34 : 0.24);
      const torsoRoll = isFlailer ? Math.sin(elapsed * 5.2 + ag.surgeSeed) * 0.16 : sWave * 0.05;

      this._vPos.set(0, 0.02, 0);
      this._eTemp.set(torsoPitch, torsoTwist, torsoRoll);
      this._qTemp.setFromEuler(this._eTemp);
      this._vScale.set(1, 1, 1);
      this._mTorso.compose(this._vPos, this._qTemp, this._vScale).premultiply(this._mRoot);
      setMat(
        this.torsoMeshes[ag.archetype],
        this.torsoOutlines[ag.archetype],
        ag.archetypeSlot,
        this._mTorso
      );

      // Rabid twitching zombie head snapping wildly while staring forward at the 9 heroes!
      const twitch =
        Math.sin(elapsed * ag.headTwitchFreq + ag.surgeSeed) * 0.18 +
        Math.sin(elapsed * ag.headTwitchFreq * 2.3) * 0.07;
      const headPitch = -torsoPitch * 0.72 + Math.sin(elapsed * 7.5 + i) * 0.09;
      const headYaw = -(hipsRotY + torsoTwist) * 0.65 + twitch * 0.65;
      const headRoll = ag.headTiltZ + twitch * 0.55;

      this._vPos.set(0, 0.635, 0.012);
      this._eTemp.set(headPitch, headYaw, headRoll);
      this._qTemp.setFromEuler(this._eTemp);
      this._mHead.compose(this._vPos, this._qTemp, this._vScale).premultiply(this._mTorso);
      setMat(this.headMesh, this.headOutline, i, this._mHead);
      if (ag.hasHair && ag.hairSlot >= 0) {
        this.hairMesh.setMatrixAt(ag.hairSlot, this._mHead);
      }

      // Rabid Reaching / Clawing / Flailing Arms!
      for (let sIdx = 0; sIdx < 2; sIdx++) {
        const s = sIdx === 0 ? 1 : -1;
        const armPhase = sIdx === 0 ? sWave : -sWave;
        let armX: number;
        let armZ: number;
        let elbowX: number;

        if (leapEnv > 0.15) {
          // Diving superman-claw lunge over the horde!
          armX = -2.15 + armPhase * 0.18;
          armZ = s * 0.24;
          elbowX = -0.35;
        } else if (isLunger) {
          // Desperate outstretched World War Z clawing hands reaching straight for the squad's backs!
          armX = -1.58 + armPhase * 0.36;
          armZ = s * (0.14 + Math.sin(elapsed * 6.5 + i + sIdx) * 0.08);
          elbowX = -0.42 - Math.max(0, -armPhase) * 0.38;
        } else if (isFlailer) {
          // Chaotic manic thrashing infected arms!
          armX = -1.25 + armPhase * 0.85;
          armZ = s * (0.38 + Math.abs(armPhase) * 0.32);
          elbowX = -0.78 - Math.abs(armPhase) * 0.45;
        } else {
          // Ferocious rabid predator sprint pump!
          armX = -0.58 + armPhase * (isChasing ? 0.92 : 0.42);
          armZ = s * 0.16;
          elbowX = -1.08 - Math.max(0, -armPhase) * 0.46;
        }

        this._vPos.set(s * 0.205, 0.435, 0.01);
        this._eTemp.set(armX, s * -0.14, armZ);
        this._qTemp.setFromEuler(this._eTemp);
        this._mPart.compose(this._vPos, this._qTemp, this._vScale).premultiply(this._mTorso);
        setMat(this.upperArmMesh, this.upperArmOutline, i * 2 + sIdx, this._mPart);

        this._vPos.set(0, -0.23, 0);
        this._eTemp.set(elbowX, 0, 0);
        this._qTemp.setFromEuler(this._eTemp);
        this._mSub.compose(this._vPos, this._qTemp, this._vScale).premultiply(this._mPart);
        setMat(this.forearmMesh, this.forearmOutline, i * 2 + sIdx, this._mSub);
      }

      // Frantic Sprinting / Leaping Zombie Legs!
      for (let sIdx = 0; sIdx < 2; sIdx++) {
        const s = sIdx === 0 ? 1 : -1;
        const lPhase = sIdx === 0 ? ph : ph + Math.PI;
        const ls = Math.sin(lPhase);
        const lc = Math.cos(lPhase);

        let hipX: number;
        let kneeX: number;
        if (leapEnv > 0.15) {
          hipX = sIdx === 0 ? -0.95 * leapEnv : 0.42 * leapEnv;
          kneeX = sIdx === 0 ? 1.42 * leapEnv : 0.72 * leapEnv;
        } else if (isChasing) {
          hipX = -ls * 0.92 - 0.14;
          kneeX = 0.20 + Math.max(0, lc) * 1.48 + Math.max(0, ls) * 0.28;
        } else if (isWalking) {
          hipX = -ls * 0.46;
          kneeX = 0.14 + Math.max(0, lc) * 0.78;
        } else {
          // Agitated prowling squat ready to pounce!
          hipX = -0.34 + ls * 0.14;
          kneeX = 0.62 - ls * 0.14;
        }

        this._vPos.set(s * 0.102, -0.02, 0);
        this._eTemp.set(hipX, 0, s * 0.04);
        this._qTemp.setFromEuler(this._eTemp);
        this._mLocal.compose(this._vPos, this._qTemp, this._vScale);
        this._mPart.multiplyMatrices(this._mRoot, this._mLocal);
        setMat(this.thighMesh, this.thighOutline, i * 2 + sIdx, this._mPart);

        this._vPos.set(0, -0.36, 0);
        this._eTemp.set(kneeX, 0, 0);
        this._qTemp.setFromEuler(this._eTemp);
        this._mSub.compose(this._vPos, this._qTemp, this._vScale).premultiply(this._mPart);
        setMat(this.shinMesh, this.shinOutline, i * 2 + sIdx, this._mSub);
      }
    }

    // Mark all instance matrix buffers updated in one clean pass
    for (const m of this.allInstanced) {
      m.instanceMatrix.needsUpdate = true;
    }
  }

  public dispose(): void {
    this.ownedGeoms.forEach((g) => g.dispose());
    this.ownedMats.forEach((m) => m.dispose());
  }
}
