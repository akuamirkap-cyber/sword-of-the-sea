import * as THREE from 'three';
import { AnimMode, HitZone, SkinId } from './types';
import { ArticulatedLegNodes } from './parts/pantsAndShoes';

export interface CombatAnimState {
  hp: number;
  maxHp: number;
  activeHitZone: HitZone | null;
  hitTimer: number;
  hitDuration: number;
  hitDirSign: number;
  isDead: boolean;
  deathTimer: number;
  deathZone: HitZone;
  deathSpinDir: number;
  floorSlamFired: boolean;
  hitFlashTimer: number;
}

export interface LocomotionState {
  stridePhase: number;
  speedMult: number;
  speedSeed: number;
  postVaultBoost: number;
}

export interface ParkourAnimState {
  boxActive: boolean;
  boxZ: number;
  vaultSide: 1 | -1;
  vaultProgress: number;
  vaulting: boolean;
  crateHeight: number;
  handTapFired: boolean;
  strideSynced: boolean;
}

export interface ArmIKChain {
  side: 'left' | 'right';
  shoulderPivot: THREE.Group;
  elbowPivot: THREE.Group;
  handGroup: THREE.Group | null;
  handRestQuat: THREE.Quaternion;
  shoulderPos: THREE.Vector3;
  uRest: THREE.Vector3;
  fRest: THREE.Vector3;
  L1: number;
  L2: number;
  attachedToWeapon: boolean;
  ikWeight: number;
}

export interface CharacterRig {
  root: THREE.Group;
  hipsPivot: THREE.Group;
  baseHipsY: number;
  upperBodyPivot: THREE.Group;
  headPivot: THREE.Group;
  leftArmPivot: THREE.Group | null;
  rightArmPivot: THREE.Group | null;
  leftElbowPivot: THREE.Group | null;
  rightElbowPivot: THREE.Group | null;
  leftArmIK: ArmIKChain | null;
  rightArmIK: ArmIKChain | null;
  weaponRig: THREE.Group | null;
  leftLeg: ArticulatedLegNodes;
  rightLeg: ArticulatedLegNodes;
  torsoId: SkinId;
  combat: CombatAnimState;
  loco: LocomotionState;
  parkour: ParkourAnimState;
}

export function createCombatState(): CombatAnimState {
  return {
    hp: 3,
    maxHp: 3,
    activeHitZone: null,
    hitTimer: 99,
    hitDuration: 0.84,
    hitDirSign: 1,
    isDead: false,
    deathTimer: 0,
    deathZone: 'chest',
    deathSpinDir: 1,
    floorSlamFired: false,
    hitFlashTimer: 0,
  };
}

export function createLocomotionState(slotIndex: number): LocomotionState {
  return {
    stridePhase: slotIndex * 0.19,
    speedMult: 1.0 + (slotIndex % 3) * 0.14,
    speedSeed: slotIndex * 2.17 + 0.85,
    postVaultBoost: 0,
  };
}

export function createParkourState(slotIndex: number): ParkourAnimState {
  return {
    boxActive: false,
    boxZ: 99,
    vaultSide: slotIndex % 2 === 0 ? 1 : -1,
    vaultProgress: 0,
    vaulting: false,
    crateHeight: 0.78,
    handTapFired: false,
    strideSynced: false,
  };
}

export function triggerCharacterHit(
  combat: CombatAnimState,
  zone: HitZone
): { applied: boolean; isFatal: boolean; hpRemaining: number } {
  if (combat.isDead) {
    combat.hitFlashTimer = 0.10;
    return { applied: false, isFatal: false, hpRemaining: 0 };
  }

  combat.hp = Math.max(0, combat.hp - 1);
  combat.activeHitZone = zone;
  combat.hitFlashTimer = 0.14;

  if (zone === 'leftArm' || zone === 'leftLeg') {
    combat.hitDirSign = 1;
  } else if (zone === 'rightArm' || zone === 'rightLeg') {
    combat.hitDirSign = -1;
  } else {
    combat.hitDirSign = combat.hitDirSign * -1;
  }

  if (combat.hp === 0) {
    combat.isDead = true;
    combat.deathTimer = 0;
    combat.deathZone = zone;
    combat.deathSpinDir = combat.hitDirSign;
    combat.floorSlamFired = false;
    return { applied: true, isFatal: true, hpRemaining: 0 };
  }

  combat.hitTimer = 0;
  combat.hitDuration = zone === 'leftLeg' || zone === 'rightLeg' ? 0.90 : 0.82;
  return { applied: true, isFatal: false, hpRemaining: combat.hp };
}

export function reviveCharacterState(combat: CombatAnimState): void {
  combat.hp = combat.maxHp;
  combat.isDead = false;
  combat.deathTimer = 0;
  combat.activeHitZone = null;
  combat.hitTimer = 99;
  combat.floorSlamFired = false;
  combat.hitFlashTimer = 0;
}

function damp(current: number, target: number, lambda: number, dt: number): number {
  return THREE.MathUtils.lerp(current, target, 1 - Math.exp(-lambda * dt));
}

function smoothstep01(x: number): number {
  const c = THREE.MathUtils.clamp(x, 0, 1);
  return c * c * (3 - 2 * c);
}

function easeOutQuad(x: number): number {
  const c = THREE.MathUtils.clamp(x, 0, 1);
  return 1 - (1 - c) * (1 - c);
}

function easeInQuad(x: number): number {
  const c = THREE.MathUtils.clamp(x, 0, 1);
  return c * c;
}

function hitSnapEnvelope(u: number): number {
  if (u <= 0 || u >= 1) return 0;
  if (u < 0.11) return easeOutQuad(u / 0.11);
  if (u < 0.27) return 1.0 - (u - 0.11) * 0.38;
  const r = (u - 0.27) / 0.73;
  return 0.94 * Math.pow(1 - r, 1.85);
}

function hitFollowEnvelope(u: number): number {
  if (u < 0.14 || u >= 1) return 0;
  if (u < 0.42) return smoothstep01((u - 0.14) / 0.28);
  return 1 - smoothstep01((u - 0.42) / 0.58);
}

/**
 * Smooth periodic Catmull-Rom spline evaluator for looping Walk/Run cycles (u in [0, 1)).
 */
function samplePeriodic(keys: readonly number[], uRaw: number): number {
  const n = keys.length;
  const u = ((uRaw % 1) + 1) % 1;
  const scaled = u * n;
  const i1 = Math.floor(scaled) % n;
  const t = scaled - Math.floor(scaled);

  const p0 = keys[(i1 - 1 + n) % n];
  const p1 = keys[i1];
  const p2 = keys[(i1 + 1) % n];
  const p3 = keys[(i1 + 2) % n];

  const t2 = t * t;
  const t3 = t2 * t;

  return (
    0.5 *
    (2 * p1 +
      (-p0 + p2) * t +
      (2 * p0 - 5 * p1 + 4 * p2 - p3) * t2 +
      (-p0 + 3 * p1 - 3 * p2 + p3) * t3)
  );
}

/**
 * Smooth non-periodic Catmull-Rom spline evaluator for organic one-shot actions (Speed Vault!),
 * completely eliminating rigid piecewise linear joints!
 */
function sampleClampedSpline(keys: readonly number[], uRaw: number): number {
  const n = keys.length;
  const u = THREE.MathUtils.clamp(uRaw, 0, 1);
  const scaled = u * (n - 1);
  const i1 = Math.min(n - 2, Math.floor(scaled));
  const t = scaled - i1;

  const p0 = keys[Math.max(0, i1 - 1)];
  const p1 = keys[i1];
  const p2 = keys[Math.min(n - 1, i1 + 1)];
  const p3 = keys[Math.min(n - 1, i1 + 2)];

  const t2 = t * t;
  const t3 = t2 * t;

  return (
    0.5 *
    (2 * p1 +
      (-p0 + p2) * t +
      (2 * p0 - 5 * p1 + 4 * p2 - p3) * t2 +
      (-p0 + 3 * p1 - 3 * p2 + p3) * t3)
  );
}

// ============================================================================
// MOCAP-INSPIRED NATURAL RUNNING & SPRINT 12-KEYFRAME GAIT TABLES
// u = 0.00 Strike | 0.08 Cushion | 0.17 Mid-Stance | 0.25 Push-Start | 0.33 Toe-Off
//     0.42 Flight | 0.50 Heel-Fold | 0.58 Mid-Fold | 0.67 Pass | 0.75 High-Knee | 0.83 Reach | 0.92 Paw-Back
// ============================================================================
const RUN_CRUISE_HIP = [
  -0.40, -0.22, -0.02, 0.22, 0.42, 0.48, 0.26, -0.14, -0.54, -0.78, -0.76, -0.58,
] as const;
const RUN_CRUISE_KNEE = [
  0.22, 0.42, 0.52, 0.36, 0.16, 0.68, 1.38, 1.62, 1.42, 0.96, 0.46, 0.24,
] as const;
const RUN_CRUISE_ANKLE = [
  -0.12, -0.18, -0.26, -0.08, 0.34, 0.28, 0.12, 0.02, -0.10, -0.18, -0.18, -0.14,
] as const;
const RUN_CRUISE_ARM = [
  0.48, 0.26, -0.06, -0.44, -0.74, -0.76, -0.48, -0.08, 0.32, 0.60, 0.68, 0.62,
] as const;
const RUN_CRUISE_ELBOW = [
  -0.96, -1.10, -1.24, -1.36, -1.44, -1.40, -1.26, -1.08, -0.92, -0.82, -0.82, -0.88,
] as const;

const SPRINT_BURST_HIP = [
  -0.48, -0.26, -0.04, 0.28, 0.54, 0.64, 0.34, -0.22, -0.74, -1.04, -0.96, -0.68,
] as const;
const SPRINT_BURST_KNEE = [
  0.26, 0.50, 0.58, 0.34, 0.12, 0.88, 1.68, 1.94, 1.66, 1.06, 0.50, 0.26,
] as const;
const SPRINT_BURST_ANKLE = [
  -0.14, -0.22, -0.32, -0.04, 0.44, 0.34, 0.14, 0.02, -0.14, -0.22, -0.22, -0.16,
] as const;
const SPRINT_BURST_ARM = [
  0.60, 0.32, -0.12, -0.62, -0.98, -0.96, -0.58, -0.06, 0.44, 0.80, 0.90, 0.80,
] as const;
const SPRINT_BURST_ELBOW = [
  -1.12, -1.28, -1.44, -1.56, -1.62, -1.56, -1.38, -1.18, -1.00, -0.88, -0.90, -1.00,
] as const;

// --- CLEAN TACTICAL WALK (8-Keyframe) ---
const WALK_HIP = [-0.42, -0.20, 0.04, 0.28, 0.42, 0.14, -0.24, -0.46] as const;
const WALK_KNEE = [0.10, 0.22, 0.10, 0.14, 0.46, 0.92, 0.64, 0.16] as const;
const WALK_ANKLE = [-0.18, 0.02, -0.04, -0.14, 0.28, 0.12, -0.06, -0.14] as const;
const WALK_ARM_X = [0.34, 0.18, -0.04, -0.28, -0.42, -0.24, 0.10, 0.36] as const;
const WALK_ELBOW_X = [-0.22, -0.28, -0.36, -0.46, -0.52, -0.38, -0.24, -0.18] as const;

// ============================================================================
// FLUID 9-KEYFRAME PARKOUR SPEED VAULT SPLINE (vp = 0.000, 0.125, ..., 1.000)
// 0.00 Approach | 0.125 Takeoff | 0.25 Hand Plant & Whip | 0.375 Apex Horizontal Sail
// 0.50 Mid-Clear | 0.625 Hand Push-Off | 0.75 Step-Out Touchdown | 0.875 Drive-Out | 1.00 Full Run!
// ============================================================================
const SV_HIPS_X_MAG = [0.00, 0.08, 0.28, 0.42, 0.44, 0.28, 0.10, 0.02, 0.00] as const; // * -vs
const SV_HIPS_Y = [0.00, 0.08, 0.20, 0.27, 0.25, 0.15, 0.03, 0.00, 0.02] as const;
const SV_HIPS_Z = [0.03, 0.07, 0.08, 0.04, 0.00, 0.02, 0.06, 0.05, 0.04] as const;
const SV_HIPS_ROTZ_MAG = [0.00, 0.24, 0.68, 0.98, 0.92, 0.54, 0.16, 0.02, 0.00] as const; // * -vs
const SV_HIPS_ROTX = [0.00, 0.14, 0.20, 0.16, 0.10, 0.06, 0.04, 0.02, 0.00] as const;
const SV_HIPS_ROTY_MAG = [0.00, 0.12, 0.24, 0.26, 0.20, 0.12, 0.04, 0.00, 0.00] as const; // * vs

const SV_TORSO_PITCH = [0.32, 0.38, 0.28, 0.18, 0.18, 0.26, 0.34, 0.34, 0.32] as const;
const SV_TORSO_TWIST_MAG = [0.00, -0.08, -0.18, -0.22, -0.16, -0.06, 0.06, 0.08, 0.00] as const; // * vs
const SV_HEAD_PITCH = [-0.14, 0.14, 0.16, 0.04, -0.08, -0.16, -0.16, -0.14, -0.14] as const;
const SV_HEAD_ROLL_MAG = [0.00, 0.20, 0.58, 0.84, 0.78, 0.44, 0.12, 0.00, 0.00] as const; // * vs

// FLUID SCISSORING LEGS (Zero stiff parallel bricks!)
// Lead leg (side === vs): drives high on takeoff -> sweeps forward-open past crate -> drops FIRST to land!
const SV_LEAD_HIP_X = [-0.52, -1.04, -1.24, -1.16, -0.90, -0.54, -0.22, 0.22, 0.44] as const;
const SV_LEAD_KNEE_X = [0.42, 1.38, 1.02, 0.46, 0.34, 0.24, 0.48, 0.24, 0.16] as const;
const SV_LEAD_ANKLE_X = [-0.14, -0.16, 0.16, 0.22, 0.18, -0.08, -0.22, 0.18, 0.34] as const;
const SV_LEAD_HIP_Z_MAG = [0.00, 0.06, 0.14, 0.16, 0.12, 0.06, 0.02, 0.00, 0.00] as const; // * vs

// Trail leg (side === -vs): pushes explosively off floor -> folds gracefully behind -> whips forward into next sprint stride!
const SV_TRAIL_HIP_X = [0.16, 0.46, 0.28, -0.16, -0.58, -0.92, -1.02, -0.68, -0.44] as const;
const SV_TRAIL_KNEE_X = [0.46, 0.16, 1.24, 1.62, 1.48, 1.18, 0.92, 0.42, 0.24] as const;
const SV_TRAIL_ANKLE_X = [-0.18, 0.38, 0.32, 0.24, 0.10, -0.10, -0.20, -0.18, -0.14] as const;
const SV_TRAIL_HIP_Z_MAG = [0.00, -0.02, -0.12, -0.18, -0.14, -0.08, -0.02, 0.00, 0.00] as const; // * vs

// Free counter-balance arm (sweeps dynamically up & out to balance the sideways whip, then pumps into sprint!)
const SV_FREE_ARM_X = [-0.40, -0.78, -0.64, -0.46, -0.34, 0.14, 0.56, 0.46, -0.12] as const;
const SV_FREE_ARM_Z_MAG = [0.00, -0.34, -0.82, -0.96, -0.78, -0.42, -0.14, -0.04, 0.00] as const; // * vs
const SV_FREE_ELBOW_X = [-1.18, -1.32, -0.92, -0.76, -0.84, -1.06, -1.14, -1.18, -1.24] as const;

// Smooth 1-hand IK plant contact weight (0 -> fast reach -> 1.0 solid palm plant -> push-off release -> 0)
const SV_IK_WEIGHT = [0.00, 0.55, 1.00, 1.00, 1.00, 0.96, 0.28, 0.00, 0.00] as const;

// Reusable scratch objects for zero-GC exact ground clamping & 2-Bone Analytical Arm IK
const _mHips = new THREE.Matrix4();
const _mHipsInner = new THREE.Matrix4();
const _mHip = new THREE.Matrix4();
const _mThighInner = new THREE.Matrix4();
const _mKnee = new THREE.Matrix4();
const _mShinInner = new THREE.Matrix4();
const _mAnkle = new THREE.Matrix4();
const _mCombined = new THREE.Matrix4();
const _vTest = new THREE.Vector3();

const _ikParentMat = new THREE.Matrix4();
const _ikParentInv = new THREE.Matrix4();
const _ikTargetLocal = new THREE.Vector3();
const _ikD = new THREE.Vector3();
const _ikDir = new THREE.Vector3();
const _ikPole = new THREE.Vector3();
const _ikBend = new THREE.Vector3();
const _ikElbowDes = new THREE.Vector3();
const _ikUDes = new THREE.Vector3();
const _ikFDes = new THREE.Vector3();
const _ikFDesLocal = new THREE.Vector3();
const _ikURestDir = new THREE.Vector3();
const _ikUDesDir = new THREE.Vector3();
const _ikFRestDir = new THREE.Vector3();
const _ikFDesDir = new THREE.Vector3();
const _ikQShoulder = new THREE.Quaternion();
const _ikQShoulderInv = new THREE.Quaternion();
const _ikQElbow = new THREE.Quaternion();
const _ikQHandParentRoot = new THREE.Quaternion();
const _ikQHandTarget = new THREE.Quaternion();
const _ikTempMat = new THREE.Matrix4();

// Desired flat-palm-down-fingers-forward rotation in rig.root space:
const _PALM_FLAT_FORWARD_QUAT = new THREE.Quaternion().setFromRotationMatrix(
  new THREE.Matrix4().makeBasis(
    new THREE.Vector3(-1, 0, 0),
    new THREE.Vector3(0, 0, -1),
    new THREE.Vector3(0, -1, 0)
  )
);

function computeMatrixRelativeToRoot(
  node: THREE.Object3D,
  root: THREE.Object3D,
  out: THREE.Matrix4
): THREE.Matrix4 {
  const chain: THREE.Object3D[] = [];
  let cur: THREE.Object3D | null = node;
  while (cur && cur !== root) {
    cur.updateMatrix();
    chain.push(cur);
    cur = cur.parent;
  }
  out.identity();
  for (let i = chain.length - 1; i >= 0; i--) {
    out.multiply(chain[i].matrix);
  }
  return out;
}

/**
 * Exact 2-Bone Analytical Law-of-Cosines Arm IK Solver!
 * Plants palm squarely flat on the moving crate top with fingers pointing straight forward (+Z).
 */
function applyTwoBoneArmPlantIK(
  rig: CharacterRig,
  chain: ArmIKChain,
  targetInRoot: THREE.Vector3,
  weight: number
): void {
  const parent = chain.shoulderPivot.parent;
  if (!parent || weight <= 0.001) return;

  computeMatrixRelativeToRoot(parent, rig.root, _ikParentMat);
  _ikParentInv.copy(_ikParentMat).invert();
  _ikTargetLocal.copy(targetInRoot).applyMatrix4(_ikParentInv);

  const S = chain.shoulderPos;
  const L1 = chain.L1;
  const L2 = chain.L2;

  _ikD.subVectors(_ikTargetLocal, S);
  const rawDist = _ikD.length();
  const minDist = Math.abs(L1 - L2) + 0.04;
  const maxDist = L1 + L2 - 0.006;
  const d = THREE.MathUtils.clamp(rawDist, minDist, maxDist);

  if (rawDist < 1e-5) return;
  _ikDir.copy(_ikD).divideScalar(rawDist);

  const cosA = THREE.MathUtils.clamp((L1 * L1 + d * d - L2 * L2) / (2 * L1 * d), -1, 1);
  const a = L1 * cosA;
  const h = Math.sqrt(Math.max(0, L1 * L1 - a * a));

  const sideSign = chain.side === 'left' ? 1 : -1;
  _ikPole.set(sideSign * 0.28, 0.22, -0.94);
  _ikBend.copy(_ikPole).addScaledVector(_ikDir, -_ikPole.dot(_ikDir));
  if (_ikBend.lengthSq() < 1e-5) {
    _ikBend.set(0, 0, -1);
  } else {
    _ikBend.normalize();
  }

  _ikElbowDes.copy(S).addScaledVector(_ikDir, a).addScaledVector(_ikBend, h);

  _ikUDes.subVectors(_ikElbowDes, S);
  _ikURestDir.copy(chain.uRest).normalize();
  _ikUDesDir.copy(_ikUDes).normalize();
  _ikQShoulder.setFromUnitVectors(_ikURestDir, _ikUDesDir);

  _ikFDes.subVectors(_ikTargetLocal, _ikElbowDes);
  _ikQShoulderInv.copy(_ikQShoulder).invert();
  _ikFDesLocal.copy(_ikFDes).applyQuaternion(_ikQShoulderInv);
  _ikFRestDir.copy(chain.fRest).normalize();
  _ikFDesDir.copy(_ikFDesLocal).normalize();
  _ikQElbow.setFromUnitVectors(_ikFRestDir, _ikFDesDir);

  chain.shoulderPivot.quaternion.slerp(_ikQShoulder, weight);
  chain.elbowPivot.quaternion.slerp(_ikQElbow, weight);

  if (chain.handGroup && chain.handGroup.parent) {
    chain.shoulderPivot.updateMatrix();
    chain.elbowPivot.updateMatrix();
    computeMatrixRelativeToRoot(chain.handGroup.parent, rig.root, _ikTempMat);
    _ikQHandParentRoot.setFromRotationMatrix(_ikTempMat);
    _ikQHandTarget.copy(_ikQHandParentRoot).invert().multiply(_PALM_FLAT_FORWARD_QUAT);
    chain.handGroup.quaternion.copy(chain.handRestQuat).slerp(_ikQHandTarget, weight);
  }
}

function computeExactMinSoleY(rig: CharacterRig): number {
  rig.hipsPivot.updateMatrix();
  _mHips.copy(rig.hipsPivot.matrix);
  _mHipsInner.makeTranslation(0, -rig.baseHipsY, 0);

  let minY = Infinity;
  const legs = [rig.leftLeg, rig.rightLeg];

  for (const leg of legs) {
    leg.hipPivot.updateMatrix();
    leg.kneePivot.updateMatrix();
    leg.anklePivot.updateMatrix();

    _mHip.copy(leg.hipPivot.matrix);
    _mThighInner.makeTranslation(-leg.hipWorld.x, -leg.hipWorld.y, -leg.hipWorld.z);
    _mKnee.copy(leg.kneePivot.matrix);
    _mShinInner.makeTranslation(-leg.kneeWorld.x, -leg.kneeWorld.y, -leg.kneeWorld.z);
    _mAnkle.copy(leg.anklePivot.matrix);

    _mCombined
      .copy(_mHips)
      .multiply(_mHipsInner)
      .multiply(_mHip)
      .multiply(_mThighInner)
      .multiply(_mKnee)
      .multiply(_mShinInner)
      .multiply(_mAnkle);

    for (const pt of leg.solePoints) {
      _vTest.copy(pt).applyMatrix4(_mCombined);
      if (_vTest.y < minY) minY = _vTest.y;
    }
  }

  return minY;
}

export interface AnimStepResult {
  justSlammedFloor: boolean;
  justPlantedVaultHand: THREE.Vector3 | null;
  liveSpeedMult: number;
}

/**
 * Full procedural character animation engine:
 *  - Mocap-smooth 12-keyframe natural running with organic `1.0x – 1.4x` pacing, elastic cushioning,
 *    pelvic tilt, relaxed arm pendulum & natural head inertia lag
 *  - Fluid 9-keyframe Catmull-Rom **Parkour Speed Vault** with scissored legs, exact 2-bone palm-on-box
 *    IK, push-off step-out landing, and seamless `loco.stridePhase` sprint handoff!
 *  - 16-point exact 3D sole-perimeter ground solver (zero floor penetration)
 *  - 3-HP zone-specific hit reactions & 3rd-shot knockback KO acting
 */
export function updateCharacterAnimation(
  rig: CharacterRig,
  mode: AnimMode,
  elapsed: number,
  phaseOffset: number,
  dt: number
): AnimStepResult {
  const combat = rig.combat;
  const loco = rig.loco;
  const parkour = rig.parkour;
  let justSlammedFloor = false;
  let justPlantedVaultHand: THREE.Vector3 | null = null;

  if (combat.hitFlashTimer > 0) {
    combat.hitFlashTimer = Math.max(0, combat.hitFlashTimer - dt);
  }
  if (loco.postVaultBoost > 0) {
    loco.postVaultBoost = Math.max(0, loco.postVaultBoost - dt * 0.45);
  }

  // Organic dynamic running speed multiplier in [1.0, 1.4]
  const seed = loco.speedSeed;
  const organicWave =
    0.50 +
    0.30 * Math.sin(elapsed * 0.65 + seed) +
    0.20 * Math.sin(elapsed * 1.38 + seed * 1.7);
  const targetSpeedMult = THREE.MathUtils.clamp(
    1.0 + organicWave * 0.38 + loco.postVaultBoost * 0.16,
    1.0,
    1.4
  );
  loco.speedMult = damp(loco.speedMult, targetSpeedMult, 3.0, dt);

  if (!combat.isDead) {
    if (mode === 'walk') {
      loco.stridePhase += dt * 1.02;
    } else if (mode === 'chase') {
      // Natural human stride cadence: 1.0x = 1.38 cycles/s (~165 spm jog/run) -> 1.4x = 1.93 cycles/s (~232 spm sprint!)
      loco.stridePhase += dt * 1.38 * loco.speedMult;
    }
  }

  let blendSpeed = 12.0;

  let hipsXOffset = 0;
  let hipsYOffset = 0;
  let hipsZOffset = 0;
  let hipsRotX = 0;
  let hipsRotY = 0;
  let hipsRotZ = 0;

  let torsoPitchX = 0;
  let torsoTwistY = 0;
  let torsoRollZ = 0;

  let headPitchX = 0;
  let headYawY = 0;
  let headRollZ = 0;

  let lHipX = 0;
  let lHipZ = 0;
  let lKneeX = 0;
  let lAnkleX = 0;

  let rHipX = 0;
  let rHipZ = 0;
  let rKneeX = 0;
  let rAnkleX = 0;

  let lArmX = 0;
  let lArmY = 0;
  let lArmZ = 0;
  let lElbowX = 0;
  let lElbowZ = 0;

  let rArmX = 0;
  let rArmY = 0;
  let rArmZ = 0;
  let rElbowX = 0;

  let wepPitchX = 0;
  let wepYawY = 0;
  let wepRollZ = 0;
  let wepBobY = 0;
  let wepSwayX = 0;

  const isGunner = rig.torsoId === 'gunner';
  const isSkill = rig.torsoId === 'skill';
  const leftArmAttachedToRifle = Boolean(rig.leftArmIK?.attachedToWeapon);

  let lockGroundedFloor = true;

  let ikPlantChain: ArmIKChain | null = null;
  let ikTargetWeight = 0;
  const ikTargetPosRoot = new THREE.Vector3();

  // =========================================================================
  // BRANCH A: HP === 0 — 3RD-SHOT KNOCKBACK & "GAKUAT" KO ACTING
  // =========================================================================
  if (combat.isDead) {
    lockGroundedFloor = false;
    parkour.vaulting = false;
    combat.deathTimer += dt;
    const t = combat.deathTimer;
    const spin = combat.deathSpinDir;
    const isLegKill = combat.deathZone === 'leftLeg' || combat.deathZone === 'rightLeg';
    const isHeadKill = combat.deathZone === 'head';
    const isArmKill = combat.deathZone === 'leftArm' || combat.deathZone === 'rightArm';

    blendSpeed = t < 0.35 ? 20.0 : 12.0;

    const supineHipY =
      rig.torsoId === 'venom' || rig.torsoId === 'spetsnaz' ? 0.185 : 0.148;
    const supineOffset = supineHipY - rig.baseHipsY;

    if (isLegKill) {
      const s = combat.deathZone === 'leftLeg' ? 1 : -1;
      if (t < 0.48) {
        const p = easeOutQuad(t / 0.48);
        hipsYOffset = -0.44 * p;
        hipsZOffset = -0.22 * p;
        hipsRotX = 0.18 * p;
        hipsRotY = s * 0.25 * p;
        hipsRotZ = s * 0.18 * p;

        torsoPitchX = 0.56 * p;
        headPitchX = 0.38 * p;
        headYawY = -s * 0.35 * p;

        lHipX = -0.35 * p;
        lKneeX = 2.02 * p;
        lAnkleX = -0.65 * p;
        rHipX = -0.52 * p;
        rKneeX = 2.08 * p;
        rAnkleX = -0.55 * p;

        lArmX = -0.82 * p;
        lArmZ = 0.22 * p;
        lElbowX = -0.78 * p;
        rArmX = -0.76 * p;
        rArmZ = -0.22 * p;
        rElbowX = -0.72 * p;

        wepPitchX = 0.42 * p;
        wepRollZ = s * 0.28 * p;
      } else if (t < 0.88) {
        const p = smoothstep01((t - 0.48) / 0.40);
        const tremble = Math.sin(t * 28) * 0.04;
        hipsYOffset = -0.44 + 0.04 * Math.sin(p * Math.PI);
        hipsZOffset = -0.22 - 0.10 * p;
        hipsRotX = 0.18 - 0.55 * p;
        hipsRotY = s * (0.25 + 0.22 * p);
        hipsRotZ = s * 0.22 + tremble;

        torsoPitchX = 0.56 - 0.92 * p;
        headPitchX = 0.38 - 0.96 * p;
        headYawY = -s * 0.25;

        lHipX = -0.35;
        lKneeX = 2.02 - 0.45 * p;
        lAnkleX = -0.45;
        rHipX = -0.52;
        rKneeX = 2.08 - 0.55 * p;
        rAnkleX = -0.40;

        lArmX = -0.82 - 0.38 * p;
        lArmZ = 0.22 + 0.58 * p;
        lElbowX = -0.78 + 0.38 * p;
        rArmX = -0.76 - 0.35 * p;
        rArmZ = -0.22 - 0.58 * p;
        rElbowX = -0.72 + 0.38 * p;

        wepPitchX = 0.42 - 0.78 * p;
        wepRollZ = s * 0.42;
      } else {
        const slamP = easeInQuad((t - 0.88) / 0.32);
        if (t >= 1.20 && !combat.floorSlamFired) {
          combat.floorSlamFired = true;
          justSlammedFloor = true;
        }
        const postT = Math.max(0, t - 1.20);
        const bounce = postT < 0.28 ? Math.sin((postT / 0.28) * Math.PI) * 0.048 * (1 - postT / 0.28) : 0;
        const lastTry =
          t > 1.28 && t < 2.25
            ? Math.sin(smoothstep01((t - 1.28) / 0.97) * Math.PI)
            : 0;
        const deadSettle = smoothstep01((t - 1.80) / 0.45);

        hipsXOffset = s * 0.14 * slamP;
        hipsYOffset = THREE.MathUtils.lerp(-0.44, supineOffset, slamP) + bounce;
        hipsZOffset = THREE.MathUtils.lerp(-0.32, -0.74, slamP);
        hipsRotX = THREE.MathUtils.lerp(-0.37, -1.55, slamP);
        hipsRotY = s * (0.47 + 0.18 * slamP);
        hipsRotZ = s * 0.14 * (1 - slamP);

        torsoPitchX = THREE.MathUtils.lerp(-0.36, 0.04, slamP) + lastTry * 0.14;
        headPitchX = THREE.MathUtils.lerp(-0.58, -0.04, slamP) + lastTry * 0.42;
        headYawY = s * (0.15 + 0.62 * deadSettle);
        headRollZ = s * 0.24 * deadSettle;

        lHipX = THREE.MathUtils.lerp(-0.35, -0.14, slamP);
        lHipZ = 0.22 * slamP;
        lKneeX = THREE.MathUtils.lerp(1.57, 0.34, slamP);
        lAnkleX = 0.28 * slamP;

        rHipX = THREE.MathUtils.lerp(-0.52, -0.26, slamP);
        rHipZ = -0.24 * slamP;
        rKneeX = THREE.MathUtils.lerp(1.53, 0.56, slamP);
        rAnkleX = 0.26 * slamP;

        lArmX = THREE.MathUtils.lerp(-1.20, -0.18, slamP) - lastTry * 1.12;
        lArmZ = THREE.MathUtils.lerp(0.80, 0.96, slamP) - lastTry * 0.62;
        lElbowX = -0.28 - lastTry * 0.24;
        if (isSkill) lElbowZ = 0.56 * slamP;

        rArmX = THREE.MathUtils.lerp(-1.11, -0.32, slamP);
        rArmZ = THREE.MathUtils.lerp(-0.80, -1.04, slamP);
        rElbowX = -0.36;

        wepPitchX = THREE.MathUtils.lerp(-0.36, -0.12, slamP) - lastTry * 0.18;
        wepYawY = s * 0.35 * slamP;
        wepRollZ = s * 0.48 * slamP;
      }
    } else {
      const blastPower = isHeadKill ? 1.15 : 1.0;

      if (t < 0.36) {
        const p = easeOutQuad(t / 0.36);
        const arcLift = Math.sin(p * Math.PI) * 0.19 * blastPower;

        hipsXOffset = isArmKill ? spin * 0.18 * p : spin * 0.06 * p;
        hipsYOffset = arcLift - 0.16 * p;
        hipsZOffset = -0.62 * blastPower * p;
        hipsRotX = -0.96 * p;
        hipsRotY = spin * (isArmKill ? 0.58 : isHeadKill ? 0.38 : 0.22) * p;
        hipsRotZ = spin * 0.16 * p;

        torsoPitchX = -0.58 * p;
        torsoTwistY = spin * (isArmKill ? 0.48 : 0.20) * p;
        headPitchX = (isHeadKill ? -0.92 : -0.68) * p;
        headYawY = spin * 0.35 * p;

        lHipX = -0.72 * p;
        lHipZ = 0.14 * p;
        lKneeX = 0.58 * p;
        lAnkleX = 0.38 * p;

        rHipX = -0.46 * p;
        rHipZ = -0.14 * p;
        rKneeX = 0.96 * p;
        rAnkleX = 0.42 * p;

        lArmX = -1.42 * p;
        lArmZ = 0.88 * p;
        lElbowX = -0.32 * p;

        rArmX = -1.28 * p;
        rArmZ = -0.88 * p;
        rElbowX = -0.38 * p;

        wepPitchX = -0.68 * p;
        wepYawY = spin * 0.42 * p;
        wepRollZ = spin * 0.38 * p;
      } else if (t < 0.72) {
        const p = easeInQuad((t - 0.36) / 0.36);

        hipsXOffset = spin * (isArmKill ? 0.18 + 0.12 * p : 0.06 + 0.06 * p);
        hipsYOffset = THREE.MathUtils.lerp(-0.16, supineOffset, p);
        hipsZOffset = THREE.MathUtils.lerp(-0.62 * blastPower, -0.94 * blastPower, p);
        hipsRotX = THREE.MathUtils.lerp(-0.96, -1.55, p);
        hipsRotY = spin * (isArmKill ? 0.58 + 0.20 * p : isHeadKill ? 0.38 + 0.14 * p : 0.22 + 0.08 * p);
        hipsRotZ = spin * 0.16 * (1 - p);

        torsoPitchX = THREE.MathUtils.lerp(-0.58, 0.04, p);
        torsoTwistY = spin * (isArmKill ? 0.48 : 0.20) * (1 - p * 0.7);
        headPitchX = THREE.MathUtils.lerp(isHeadKill ? -0.92 : -0.68, -0.12, p);
        headYawY = spin * 0.35;

        lHipX = THREE.MathUtils.lerp(-0.72, -0.18, p);
        lHipZ = 0.14 + 0.10 * p;
        lKneeX = THREE.MathUtils.lerp(0.58, 0.38, p);
        lAnkleX = 0.32;

        rHipX = THREE.MathUtils.lerp(-0.46, -0.28, p);
        rHipZ = -0.14 - 0.12 * p;
        rKneeX = THREE.MathUtils.lerp(0.96, 0.56, p);
        rAnkleX = 0.30;

        lArmX = THREE.MathUtils.lerp(-1.42, -0.58, p);
        lArmZ = THREE.MathUtils.lerp(0.88, 0.72, p);
        lElbowX = -0.35;

        rArmX = THREE.MathUtils.lerp(-1.28, -0.36, p);
        rArmZ = THREE.MathUtils.lerp(-0.88, -0.98, p);
        rElbowX = -0.38;

        wepPitchX = THREE.MathUtils.lerp(-0.68, -0.22, p);
        wepYawY = spin * 0.42;
        wepRollZ = spin * 0.48;
      } else {
        if (!combat.floorSlamFired) {
          combat.floorSlamFired = true;
          justSlammedFloor = true;
        }
        const postT = t - 0.72;
        const slamBounce =
          postT < 0.28 ? Math.sin((postT / 0.28) * Math.PI) * 0.062 * (1 - postT / 0.28) : 0;
        const headBounce =
          postT < 0.25 ? Math.sin((postT / 0.25) * Math.PI) * 0.32 : 0;
        const reachCurve =
          t > 0.96 && t < 1.88
            ? Math.sin(smoothstep01((t - 0.96) / 0.92) * Math.PI)
            : 0;
        const tremble = reachCurve > 0.1 ? Math.sin(t * 28) * 0.035 * reachCurve : 0;
        const limpDrop = smoothstep01((t - 1.62) / 0.42);
        const armDropBounce =
          t > 1.96 && t < 2.20
            ? Math.sin(((t - 1.96) / 0.24) * Math.PI) * 0.14
            : 0;

        hipsXOffset = spin * (isArmKill ? 0.30 : 0.12);
        hipsYOffset = supineOffset + slamBounce;
        hipsZOffset = -0.94 * blastPower;
        hipsRotX = -1.55;
        hipsRotY = spin * (isArmKill ? 0.78 : isHeadKill ? 0.52 : 0.30);
        hipsRotZ = 0;

        torsoPitchX = 0.04 + reachCurve * 0.18;
        torsoTwistY = spin * 0.14 * (1 - limpDrop);

        headPitchX = -0.06 + headBounce + reachCurve * 0.48;
        headYawY = THREE.MathUtils.lerp(spin * 0.28, spin * 0.76, limpDrop) + tremble;
        headRollZ = spin * 0.24 * limpDrop;

        lHipX = -0.14 - slamBounce * 1.4;
        lHipZ = 0.26;
        lKneeX = 0.28 + slamBounce * 1.6;
        lAnkleX = 0.32;

        rHipX = -0.22 - slamBounce * 1.1;
        rHipZ = -0.28;
        rKneeX = 0.50 + slamBounce * 1.2;
        rAnkleX = 0.28;

        lArmX = -0.18 - reachCurve * 1.28 - armDropBounce;
        lArmZ = 0.94 - reachCurve * 0.64 + tremble * 1.4;
        lElbowX = -0.24 - reachCurve * 0.22;
        if (isSkill) lElbowZ = 0.58;

        rArmX = -0.32 - slamBounce * 1.6;
        rArmZ = -1.04;
        rElbowX = -0.36;

        wepPitchX = -0.14 - reachCurve * 0.22;
        wepYawY = spin * (0.38 + 0.14 * limpDrop);
        wepRollZ = spin * (0.48 + 0.12 * limpDrop);
      }
    }
  } else {
    // =========================================================================
    // BRANCH B: ALIVE LOCOMOTION (Idle / Walk / Mocap-Fluid 1.0x–1.4x Run / Crouch)
    // =========================================================================
    if (mode === 'idle') {
      lockGroundedFloor = true;
      const breath = Math.sin(elapsed * 2.2 + phaseOffset);
      torsoPitchX = breath * 0.014;
      headPitchX = -breath * 0.012;
      wepBobY = breath * 0.005;
    } else if (mode === 'walk') {
      lockGroundedFloor = true;
      const uR = loco.stridePhase % 1;
      const uL = (uR + 0.5) % 1;

      rHipX = samplePeriodic(WALK_HIP, uR);
      rKneeX = samplePeriodic(WALK_KNEE, uR);
      rAnkleX = samplePeriodic(WALK_ANKLE, uR);

      lHipX = samplePeriodic(WALK_HIP, uL);
      lKneeX = samplePeriodic(WALK_KNEE, uL);
      lAnkleX = samplePeriodic(WALK_ANKLE, uL);

      const strideWave = Math.sin(uR * Math.PI * 2);
      const doubleWave = Math.cos(uR * Math.PI * 4);

      hipsRotY = -strideWave * 0.095;
      hipsRotZ = strideWave * 0.024;
      torsoPitchX = 0.10 + doubleWave * 0.014;
      torsoTwistY = strideWave * 0.13;
      torsoRollZ = -strideWave * 0.018;

      headPitchX = -0.042 + doubleWave * 0.015;
      headYawY = -(hipsRotY + torsoTwistY) * 0.72;

      if (isSkill) {
        rArmX = 1.04 - strideWave * 0.07;
        rArmY = 0.26 + strideWave * 0.06;
        rArmZ = 0.10;

        lArmX = samplePeriodic(WALK_ARM_X, uL) * 0.72 - 0.10;
        lArmY = -0.18;
        lArmZ = -0.08;
        lElbowX = -0.12;
        lElbowZ = 0.56;
      } else {
        rArmX = samplePeriodic(WALK_ARM_X, uR);
        rElbowX = samplePeriodic(WALK_ELBOW_X, uR);

        lArmX = samplePeriodic(WALK_ARM_X, uL);
        lElbowX = samplePeriodic(WALK_ELBOW_X, uL);
      }

      wepPitchX = isGunner ? -0.08 + doubleWave * 0.02 : -0.06 + doubleWave * 0.022;
      wepYawY = strideWave * 0.085;
      wepRollZ = -strideWave * 0.032;
      wepBobY = (doubleWave + 1) * 0.005;
      wepSwayX = -strideWave * 0.010;
    } else if (mode === 'chase') {
      // =====================================================================
      // MOCAP-FLUID NATURAL HUMAN RUNNING (1.0x Relaxed Athletic <-> 1.4x Chase!)
      // =====================================================================
      lockGroundedFloor = false;
      const energy = THREE.MathUtils.clamp((loco.speedMult - 1.0) / 0.4, 0, 1);

      const uR = loco.stridePhase % 1;
      const uL = (uR + 0.5) % 1;

      const lerpTable = (a: readonly number[], b: readonly number[], u: number) =>
        THREE.MathUtils.lerp(samplePeriodic(a, u), samplePeriodic(b, u), energy);

      rHipX = lerpTable(RUN_CRUISE_HIP, SPRINT_BURST_HIP, uR);
      rKneeX = lerpTable(RUN_CRUISE_KNEE, SPRINT_BURST_KNEE, uR);
      rAnkleX = lerpTable(RUN_CRUISE_ANKLE, SPRINT_BURST_ANKLE, uR);

      lHipX = lerpTable(RUN_CRUISE_HIP, SPRINT_BURST_HIP, uL);
      lKneeX = lerpTable(RUN_CRUISE_KNEE, SPRINT_BURST_KNEE, uL);
      lAnkleX = lerpTable(RUN_CRUISE_ANKLE, SPRINT_BURST_ANKLE, uL);

      // Natural human center-of-mass spring arc:
      // Lowest at mid-stance absorption (u=0.17, 0.67), peaks gracefully on flight (u=0.42, 0.92)!
      const comBounce = -Math.sin((uR - 0.295) * Math.PI * 4); // -1 at mid-stance, +1 at flight!
      const flightPhase = Math.max(0, comBounce);
      hipsYOffset = -0.026 + (0.044 + 0.030 * energy) * (0.5 + 0.5 * comBounce);
      hipsZOffset = 0.032 + 0.024 * energy;

      // Natural Trendelenburg pelvic lateral shift & elastic spine lag (0.04 cycle behind hips!)
      const hipWave = Math.sin((uR - 0.25) * Math.PI * 2);
      const spineLagWave = Math.sin((uR - 0.29) * Math.PI * 2);
      const headLagWave = Math.sin((uR - 0.36) * Math.PI * 4);

      hipsXOffset = -hipWave * (0.014 + 0.008 * energy);
      hipsRotY = -hipWave * (0.12 + 0.06 * energy);
      hipsRotZ = hipWave * (0.042 + 0.016 * energy); // Subtle natural pelvic drop on swing leg!

      // Relaxed athletic forward lean (~14° at 1.0x -> ~22° at 1.4x) with elastic push-off breath!
      torsoPitchX = 0.24 + 0.14 * energy + comBounce * (0.020 + 0.012 * energy);
      torsoTwistY = spineLagWave * (0.19 + 0.08 * energy);
      torsoRollZ = -spineLagWave * (0.044 + 0.018 * energy);

      // Natural stabilized head with realistic inertial lag (glides smoothly like real running footage!)
      headPitchX = -(0.11 + 0.07 * energy) + headLagWave * 0.026;
      headYawY = -(hipsRotY + torsoTwistY) * 0.80;
      headRollZ = -torsoRollZ * 0.72;

      if (isSkill) {
        rArmX = 0.98 + comBounce * 0.045;
        rArmY = 0.30 + spineLagWave * 0.12;
        rArmZ = 0.12 - spineLagWave * 0.04;

        lArmX = lerpTable(RUN_CRUISE_ARM, SPRINT_BURST_ARM, uL) * 0.74;
        lArmY = -0.18;
        lArmZ = -0.08;
        lElbowX = -0.52;
        lElbowZ = 0.58;
      } else {
        // Supple, relaxed natural human arm pendulum (opens gracefully on back-swing, closes on front punch!)
        rArmX = lerpTable(RUN_CRUISE_ARM, SPRINT_BURST_ARM, uR);
        rElbowX = lerpTable(RUN_CRUISE_ELBOW, SPRINT_BURST_ELBOW, uR);
        rArmZ = Math.max(0, -rArmX) * 0.12 - 0.045;
        rArmY = Math.max(0, -rArmX) * 0.15;

        lArmX = lerpTable(RUN_CRUISE_ARM, SPRINT_BURST_ARM, uL);
        lElbowX = lerpTable(RUN_CRUISE_ELBOW, SPRINT_BURST_ELBOW, uL);
        lArmZ = -Math.max(0, -lArmX) * 0.12 + 0.045;
        lArmY = -Math.max(0, -lArmX) * 0.15;
      }

      wepPitchX = isGunner
        ? -(0.16 + 0.05 * energy) + comBounce * 0.036
        : -(0.16 + 0.06 * energy) + comBounce * 0.032;
      wepYawY = spineLagWave * (0.12 + 0.05 * energy);
      wepRollZ = -spineLagWave * (0.055 + 0.026 * energy);
      wepBobY = flightPhase * (0.014 + 0.008 * energy);
      wepSwayX = -spineLagWave * (0.014 + 0.008 * energy);

      // =====================================================================
      // FLUID 9-KEYFRAME CATMULL-ROM PARKOUR SPEED VAULT + EXACT 2-BONE IK!
      // =====================================================================
      if (parkour.boxActive) {
        // 1. Visual anticipation glance onto box approaching from front (+3.1m -> +1.05m)
        if (parkour.boxZ > 1.05 && parkour.boxZ < 3.10) {
          const spotFactor = smoothstep01((3.10 - parkour.boxZ) / 2.05);
          headPitchX += 0.22 * spotFactor;
          torsoPitchX += 0.06 * spotFactor;
        }

        // 2. Active fluid Speed Vault across crate window (+1.05m -> -0.88m)
        if (parkour.vaulting) {
          blendSpeed = 19.0; // Fluid agile flow (not jittery, not sluggish!)
          const vp = THREE.MathUtils.clamp(parkour.vaultProgress, 0, 1);
          const vs: 1 | -1 = leftArmAttachedToRifle || isGunner || isSkill ? 1 : parkour.vaultSide;

          // Seamless C2-continuous bell blend into and out of the running gait
          const wVault =
            vp < 0.12
              ? smoothstep01(vp / 0.12)
              : vp > 0.86
                ? 1.0 - smoothstep01((vp - 0.86) / 0.14)
                : 1.0;

          // Sample continuous 9-keyframe Speed Vault biomechanics!
          const vHipsX = -vs * sampleClampedSpline(SV_HIPS_X_MAG, vp);
          const vHipsY = sampleClampedSpline(SV_HIPS_Y, vp);
          const vHipsZ = sampleClampedSpline(SV_HIPS_Z, vp);
          const vHipsRotZ = -vs * sampleClampedSpline(SV_HIPS_ROTZ_MAG, vp);
          const vHipsRotX = sampleClampedSpline(SV_HIPS_ROTX, vp);
          const vHipsRotY = vs * sampleClampedSpline(SV_HIPS_ROTY_MAG, vp);

          const vTorsoPitch = sampleClampedSpline(SV_TORSO_PITCH, vp);
          const vTorsoTwist = vs * sampleClampedSpline(SV_TORSO_TWIST_MAG, vp);
          const vHeadPitch = sampleClampedSpline(SV_HEAD_PITCH, vp);
          const vHeadRoll = vs * sampleClampedSpline(SV_HEAD_ROLL_MAG, vp);

          // Fluid scissoring legs (Lead leg sweeps out & lands FIRST; trail leg tucks & drives into sprint!)
          const leadHipX = sampleClampedSpline(SV_LEAD_HIP_X, vp);
          const leadKneeX = sampleClampedSpline(SV_LEAD_KNEE_X, vp);
          const leadAnkleX = sampleClampedSpline(SV_LEAD_ANKLE_X, vp);
          const leadHipZ = vs * sampleClampedSpline(SV_LEAD_HIP_Z_MAG, vp);

          const trailHipX = sampleClampedSpline(SV_TRAIL_HIP_X, vp);
          const trailKneeX = sampleClampedSpline(SV_TRAIL_KNEE_X, vp);
          const trailAnkleX = sampleClampedSpline(SV_TRAIL_ANKLE_X, vp);
          const trailHipZ = vs * sampleClampedSpline(SV_TRAIL_HIP_Z_MAG, vp);

          const vLHipX = vs === 1 ? leadHipX : trailHipX;
          const vLKneeX = vs === 1 ? leadKneeX : trailKneeX;
          const vLAnkleX = vs === 1 ? leadAnkleX : trailAnkleX;
          const vLHipZ = vs === 1 ? leadHipZ : trailHipZ;

          const vRHipX = vs === 1 ? trailHipX : leadHipX;
          const vRKneeX = vs === 1 ? trailKneeX : leadKneeX;
          const vRAnkleX = vs === 1 ? trailAnkleX : leadAnkleX;
          const vRHipZ = vs === 1 ? trailHipZ : leadHipZ;

          hipsXOffset = THREE.MathUtils.lerp(hipsXOffset, vHipsX, wVault);
          hipsYOffset = THREE.MathUtils.lerp(hipsYOffset, vHipsY, wVault);
          hipsZOffset = THREE.MathUtils.lerp(hipsZOffset, vHipsZ, wVault);
          hipsRotX = THREE.MathUtils.lerp(hipsRotX, vHipsRotX, wVault);
          hipsRotY = THREE.MathUtils.lerp(hipsRotY, vHipsRotY, wVault);
          hipsRotZ = THREE.MathUtils.lerp(hipsRotZ, vHipsRotZ, wVault);

          torsoPitchX = THREE.MathUtils.lerp(torsoPitchX, vTorsoPitch, wVault);
          torsoTwistY = THREE.MathUtils.lerp(torsoTwistY, vTorsoTwist, wVault);
          torsoRollZ = THREE.MathUtils.lerp(torsoRollZ, -vs * 0.05 * wVault, wVault);

          headPitchX = THREE.MathUtils.lerp(headPitchX, vHeadPitch, wVault);
          headYawY = THREE.MathUtils.lerp(headYawY, -vs * 0.10, wVault);
          headRollZ = THREE.MathUtils.lerp(headRollZ, vHeadRoll, wVault);

          lHipX = THREE.MathUtils.lerp(lHipX, vLHipX, wVault);
          lHipZ = THREE.MathUtils.lerp(lHipZ, vLHipZ, wVault);
          lKneeX = THREE.MathUtils.lerp(lKneeX, vLKneeX, wVault);
          lAnkleX = THREE.MathUtils.lerp(lAnkleX, vLAnkleX, wVault);

          rHipX = THREE.MathUtils.lerp(rHipX, vRHipX, wVault);
          rHipZ = THREE.MathUtils.lerp(rHipZ, vRHipZ, wVault);
          rKneeX = THREE.MathUtils.lerp(rKneeX, vRKneeX, wVault);
          rAnkleX = THREE.MathUtils.lerp(rAnkleX, vRAnkleX, wVault);

          // Fluid free opposite arm counterweight arc
          const vFreeArmX = sampleClampedSpline(SV_FREE_ARM_X, vp);
          const vFreeArmZ = vs * sampleClampedSpline(SV_FREE_ARM_Z_MAG, vp);
          const vFreeElbowX = sampleClampedSpline(SV_FREE_ELBOW_X, vp);

          if (vs === 1) {
            if (!isGunner && !isSkill && !leftArmAttachedToRifle) {
              rArmX = THREE.MathUtils.lerp(rArmX, vFreeArmX, wVault);
              rArmY = THREE.MathUtils.lerp(rArmY, -0.18, wVault);
              rArmZ = THREE.MathUtils.lerp(rArmZ, vFreeArmZ, wVault);
              rElbowX = THREE.MathUtils.lerp(rElbowX, vFreeElbowX, wVault);
            } else if (isSkill) {
              rArmX = THREE.MathUtils.lerp(rArmX, 0.72, wVault);
              rArmZ = THREE.MathUtils.lerp(rArmZ, -0.40, wVault);
            }
          } else {
            lArmX = THREE.MathUtils.lerp(lArmX, vFreeArmX, wVault);
            lArmY = THREE.MathUtils.lerp(lArmY, 0.18, wVault);
            lArmZ = THREE.MathUtils.lerp(lArmZ, vFreeArmZ, wVault);
            lElbowX = THREE.MathUtils.lerp(lElbowX, vFreeElbowX, wVault);
          }

          if (rig.weaponRig) {
            const horizFactor = sampleClampedSpline(SV_HIPS_ROTZ_MAG, vp);
            wepPitchX = THREE.MathUtils.lerp(wepPitchX, isGunner ? -0.24 : -0.30, wVault);
            wepYawY = THREE.MathUtils.lerp(wepYawY, vs * 0.22 * horizFactor, wVault);
            wepRollZ = THREE.MathUtils.lerp(wepRollZ, -vs * 0.26 * horizFactor, wVault);
          }

          // --- EXACT 2-BONE ANALYTICAL HAND-ON-BOX PLANT IK ---
          const plantW = THREE.MathUtils.clamp(sampleClampedSpline(SV_IK_WEIGHT, vp), 0, 1);
          const chosenChain = vs === 1 ? rig.leftArmIK : rig.rightArmIK;
          if (chosenChain && plantW > 0.01) {
            ikPlantChain = chosenChain;
            ikTargetWeight = plantW;
            const crateTopY = parkour.crateHeight + 0.020;
            const crateCenterX = vs * 0.08;
            // Tracks crate Z cleanly across its rubberized top pad as the box passes underneath!
            const plantZ = THREE.MathUtils.clamp(parkour.boxZ, -0.28, 0.30);
            const approachLift = (1 - plantW) * 0.08;
            ikTargetPosRoot.set(crateCenterX, crateTopY + approachLift, plantZ);

            if (!parkour.handTapFired && vp >= 0.18 && vp <= 0.44) {
              parkour.handTapFired = true;
              justPlantedVaultHand = new THREE.Vector3(crateCenterX, parkour.crateHeight + 0.02, plantZ);
            }
          }

          // SEAMLESS STRIDE PHASE HANDOFF: align running phase with exact step-out foot so exit has ZERO snap!
          if (vp >= 0.80 && !parkour.strideSynced) {
            parkour.strideSynced = true;
            // At vp = 0.85, Lead leg is pushing off (u ≈ 0.26) & Trail leg is swinging forward (u ≈ 0.76)!
            const targetUR = vs === 1 ? 0.78 : 0.28;
            loco.stridePhase = Math.floor(loco.stridePhase) + targetUR;
            loco.postVaultBoost = 1.0;
          }
        }
      }
    } else {
      // GROUNDED TACTICAL COMBAT CROUCH ("Jongkok")
      lockGroundedFloor = true;
      const breath = Math.sin(elapsed * 2.6 + phaseOffset);

      rHipX = -1.30 + breath * 0.015;
      rKneeX = 1.76 - breath * 0.015;
      rAnkleX = -(rHipX + rKneeX);

      lHipX = -0.78 + breath * 0.015;
      lKneeX = 1.92 - breath * 0.015;
      lAnkleX = -0.82;

      hipsZOffset = -0.04;
      hipsRotY = 0.14;
      torsoPitchX = 0.35 + breath * 0.016;
      torsoTwistY = -0.11;
      headPitchX = -0.21 + breath * 0.010;
      headYawY = -0.03;

      if (isSkill) {
        rArmX = 1.12 + breath * 0.014;
        rArmY = 0.38;
        rArmZ = 0.14;

        lArmX = -0.56 + breath * 0.014;
        lArmY = -0.32;
        lArmZ = -0.06;
        lElbowX = -0.38;
        lElbowZ = 0.42;
      } else {
        lArmX = -0.50 + breath * 0.02;
        lArmZ = 0.12;
        lElbowX = -0.68;
        rArmX = -0.44 + breath * 0.02;
        rArmZ = -0.12;
        rElbowX = -0.64;
      }

      wepPitchX = isGunner ? -0.26 + breath * 0.012 : -0.30 + breath * 0.014;
      wepYawY = 0.08;
      wepRollZ = 0.02;
    }

    // CRITICAL WOUNDED ENDURANCE (HP === 1)
    if (combat.hp === 1) {
      const pant = Math.sin(elapsed * 5.6 + phaseOffset);
      torsoPitchX += 0.08 + pant * 0.022;
      torsoRollZ += combat.hitDirSign * 0.04;
      headPitchX += 0.04 - pant * 0.016;
    }

    // ADDITIVE ZONE-SPECIFIC ALIVE HIT REACTIONS (HITS 1 & 2)
    if (combat.activeHitZone && combat.hitTimer < combat.hitDuration) {
      combat.hitTimer += dt;
      const u = combat.hitTimer / combat.hitDuration;
      const snap = hitSnapEnvelope(u);
      const follow = hitFollowEnvelope(u);
      const dir = combat.hitDirSign;
      const intensity = combat.hp === 1 ? 1.18 : 1.0;

      if (u < 0.25) blendSpeed = 24.0;
      const z = combat.activeHitZone;

      if (z === 'head') {
        const shakeOff = u > 0.34 ? Math.sin((u - 0.34) * 28) * 0.34 * follow : 0;
        headPitchX += -0.92 * snap * intensity + 0.18 * follow;
        headYawY += 0.44 * dir * snap * intensity + shakeOff;
        headRollZ += 0.32 * dir * snap * intensity;

        torsoPitchX += -0.36 * snap * intensity + 0.14 * follow;
        torsoTwistY += 0.22 * dir * snap;
        hipsZOffset += -0.15 * snap * intensity;
        hipsRotX += -0.10 * snap;

        lKneeX += 0.34 * snap;
        rKneeX += 0.28 * snap;
        lHipX -= 0.16 * snap;
        rHipX -= 0.14 * snap;

        lArmX += -0.78 * snap * intensity;
        lArmZ += 0.32 * snap;
        lElbowX += -0.98 * snap;
        rArmX += -0.68 * snap * intensity;
        rArmZ += -0.32 * snap;
        rElbowX += -0.92 * snap;

        wepPitchX += -0.40 * snap * intensity;
        wepRollZ += 0.22 * dir * snap;
      } else if (z === 'chest') {
        const backJolt = u < 0.26 ? snap : 0;
        hipsZOffset += -0.20 * snap * intensity;
        hipsRotX += -0.14 * backJolt;

        torsoPitchX += -0.44 * backJolt * intensity + 0.54 * follow * intensity;
        torsoTwistY += 0.24 * dir * snap;
        headPitchX += 0.38 * snap * intensity + 0.22 * follow;

        lKneeX += 0.44 * (snap * 0.5 + follow * 0.8);
        rKneeX += 0.38 * (snap * 0.5 + follow * 0.8);
        lHipX -= 0.22 * (snap * 0.5 + follow * 0.8);
        rHipX -= 0.18 * (snap * 0.5 + follow * 0.8);

        lArmX += -0.24 * backJolt - 0.72 * follow * intensity;
        lArmZ += 0.42 * backJolt - 0.34 * follow;
        lElbowX += -1.08 * follow * intensity;

        rArmX += -0.20 * backJolt - 0.64 * follow * intensity;
        rArmZ += -0.42 * backJolt + 0.34 * follow;
        rElbowX += -1.02 * follow * intensity;

        wepPitchX += -0.32 * backJolt + 0.46 * follow * intensity;
        wepYawY += 0.18 * dir * snap;
        wepBobY += -0.04 * follow;
      } else if (z === 'leftArm' || z === 'rightArm') {
        const s = z === 'leftArm' ? 1 : -1;
        hipsZOffset += -0.11 * snap * intensity;
        hipsRotY += s * 0.34 * snap * intensity;
        torsoTwistY += s * 0.72 * snap * intensity;
        torsoRollZ += -s * 0.16 * snap;
        torsoPitchX += -0.16 * snap + 0.18 * follow;

        headYawY += -s * 0.58 * (snap * 0.85 + follow * 0.65);
        headPitchX += 0.26 * follow;
        headRollZ += s * 0.22 * snap;

        if (z === 'leftArm') {
          lArmX += 1.05 * snap * intensity - 0.54 * follow;
          lArmZ += 0.66 * snap * intensity - 0.26 * follow;
          lElbowX += -1.28 * (snap * 0.4 + follow * 0.9);
          rArmX += -0.42 * snap;
          rElbowX += -0.55 * snap;
        } else {
          rArmX += 1.05 * snap * intensity - 0.54 * follow;
          rArmZ += -0.66 * snap * intensity + 0.26 * follow;
          rElbowX += -1.28 * (snap * 0.4 + follow * 0.9);
          lArmX += -0.42 * snap;
          lElbowX += -0.55 * snap;
        }

        wepYawY += s * 0.54 * snap * intensity;
        wepRollZ += s * 0.42 * snap * intensity;
        wepPitchX += 0.28 * follow;
      } else {
        const s = z === 'leftLeg' ? 1 : -1;
        hipsZOffset += -0.11 * snap;
        hipsRotZ += s * 0.26 * snap * intensity;
        hipsRotY += -s * 0.24 * snap;

        torsoPitchX += 0.46 * snap * intensity + 0.18 * follow;
        torsoRollZ += -s * 0.16 * snap;
        headPitchX += 0.34 * snap;
        headYawY += -s * 0.28 * follow;

        if (z === 'leftLeg') {
          lHipX += -0.78 * snap * intensity;
          lKneeX += 1.54 * snap * intensity;
          lAnkleX += -0.46 * snap;
          rHipX += -0.34 * snap;
          rKneeX += 0.68 * snap;
        } else {
          rHipX += -0.78 * snap * intensity;
          rKneeX += 1.54 * snap * intensity;
          rAnkleX += -0.46 * snap;
          lHipX += -0.34 * snap;
          lKneeX += 0.68 * snap;
        }

        lArmX += -0.48 * snap;
        lArmZ += 0.62 * snap * intensity;
        lElbowX += -0.44 * snap;
        rArmX += -0.48 * snap;
        rArmZ += -0.62 * snap * intensity;
        rElbowX += -0.44 * snap;

        wepPitchX += 0.36 * snap * intensity;
        wepRollZ += s * 0.28 * snap;
      }
    }
  }

  // =========================================================================
  // 1. APPLY SMOOTH EXPONENTIAL DAMPING TO ALL FK BONES
  // =========================================================================
  rig.hipsPivot.position.x = damp(rig.hipsPivot.position.x, hipsXOffset, blendSpeed, dt);
  rig.hipsPivot.position.y = damp(
    rig.hipsPivot.position.y,
    rig.baseHipsY + hipsYOffset,
    blendSpeed,
    dt
  );
  rig.hipsPivot.position.z = damp(rig.hipsPivot.position.z, hipsZOffset, blendSpeed, dt);
  rig.hipsPivot.rotation.x = damp(rig.hipsPivot.rotation.x, hipsRotX, blendSpeed, dt);
  rig.hipsPivot.rotation.y = damp(rig.hipsPivot.rotation.y, hipsRotY, blendSpeed, dt);
  rig.hipsPivot.rotation.z = damp(rig.hipsPivot.rotation.z, hipsRotZ, blendSpeed, dt);

  rig.upperBodyPivot.rotation.x = damp(rig.upperBodyPivot.rotation.x, torsoPitchX, blendSpeed, dt);
  rig.upperBodyPivot.rotation.y = damp(rig.upperBodyPivot.rotation.y, torsoTwistY, blendSpeed, dt);
  rig.upperBodyPivot.rotation.z = damp(rig.upperBodyPivot.rotation.z, torsoRollZ, blendSpeed, dt);

  rig.headPivot.rotation.x = damp(rig.headPivot.rotation.x, headPitchX, blendSpeed, dt);
  rig.headPivot.rotation.y = damp(rig.headPivot.rotation.y, headYawY, blendSpeed, dt);
  rig.headPivot.rotation.z = damp(rig.headPivot.rotation.z, headRollZ, blendSpeed, dt);

  rig.leftLeg.hipPivot.rotation.x = damp(rig.leftLeg.hipPivot.rotation.x, lHipX, blendSpeed, dt);
  rig.leftLeg.hipPivot.rotation.z = damp(rig.leftLeg.hipPivot.rotation.z, lHipZ, blendSpeed, dt);
  rig.leftLeg.kneePivot.rotation.x = damp(rig.leftLeg.kneePivot.rotation.x, lKneeX, blendSpeed, dt);
  rig.leftLeg.anklePivot.rotation.x = damp(rig.leftLeg.anklePivot.rotation.x, lAnkleX, blendSpeed, dt);

  rig.rightLeg.hipPivot.rotation.x = damp(rig.rightLeg.hipPivot.rotation.x, rHipX, blendSpeed, dt);
  rig.rightLeg.hipPivot.rotation.z = damp(rig.rightLeg.hipPivot.rotation.z, rHipZ, blendSpeed, dt);
  rig.rightLeg.kneePivot.rotation.x = damp(rig.rightLeg.kneePivot.rotation.x, rKneeX, blendSpeed, dt);
  rig.rightLeg.anklePivot.rotation.x = damp(
    rig.rightLeg.anklePivot.rotation.x,
    rAnkleX,
    blendSpeed,
    dt
  );

  if (rig.leftArmPivot) {
    const tX = leftArmAttachedToRifle ? 0 : lArmX;
    const tY = leftArmAttachedToRifle ? 0 : lArmY;
    const tZ = leftArmAttachedToRifle ? 0 : lArmZ;
    rig.leftArmPivot.rotation.x = damp(rig.leftArmPivot.rotation.x, tX, blendSpeed, dt);
    rig.leftArmPivot.rotation.y = damp(rig.leftArmPivot.rotation.y, tY, blendSpeed, dt);
    rig.leftArmPivot.rotation.z = damp(rig.leftArmPivot.rotation.z, tZ, blendSpeed, dt);
  }
  if (rig.rightArmPivot) {
    rig.rightArmPivot.rotation.x = damp(rig.rightArmPivot.rotation.x, rArmX, blendSpeed, dt);
    rig.rightArmPivot.rotation.y = damp(rig.rightArmPivot.rotation.y, rArmY, blendSpeed, dt);
    rig.rightArmPivot.rotation.z = damp(rig.rightArmPivot.rotation.z, rArmZ, blendSpeed, dt);
  }
  if (rig.leftElbowPivot) {
    const tEX = leftArmAttachedToRifle ? 0 : lElbowX;
    const tEZ = leftArmAttachedToRifle ? 0 : lElbowZ;
    rig.leftElbowPivot.rotation.x = damp(rig.leftElbowPivot.rotation.x, tEX, blendSpeed, dt);
    rig.leftElbowPivot.rotation.z = damp(rig.leftElbowPivot.rotation.z, tEZ, blendSpeed, dt);
  }
  if (rig.rightElbowPivot) {
    rig.rightElbowPivot.rotation.x = damp(rig.rightElbowPivot.rotation.x, rElbowX, blendSpeed, dt);
  }
  if (rig.weaponRig) {
    rig.weaponRig.rotation.x = damp(rig.weaponRig.rotation.x, wepPitchX, blendSpeed, dt);
    rig.weaponRig.rotation.y = damp(rig.weaponRig.rotation.y, wepYawY, blendSpeed, dt);
    rig.weaponRig.rotation.z = damp(rig.weaponRig.rotation.z, wepRollZ, blendSpeed, dt);

    const baseX = rig.weaponRig.userData.basePosX ?? rig.weaponRig.position.x;
    const baseY = rig.weaponRig.userData.basePosY ?? rig.weaponRig.position.y;
    rig.weaponRig.userData.basePosX = baseX;
    rig.weaponRig.userData.basePosY = baseY;

    rig.weaponRig.position.x = damp(rig.weaponRig.position.x, baseX + wepSwayX, blendSpeed, dt);
    rig.weaponRig.position.y = damp(rig.weaponRig.position.y, baseY + wepBobY, blendSpeed, dt);
  }

  // =========================================================================
  // 2. EXACT POST-FK 16-POINT 3D SOLE-PERIMETER GROUND SOLVER (ZERO CLIP!)
  // =========================================================================
  const minSoleY = computeExactMinSoleY(rig);
  const floorClearance = 0.005;

  if (!combat.isDead) {
    if (lockGroundedFloor) {
      rig.hipsPivot.position.y += floorClearance - minSoleY;
    } else if (minSoleY < floorClearance) {
      rig.hipsPivot.position.y += floorClearance - minSoleY;
    }
  } else {
    if (minSoleY < floorClearance) {
      rig.hipsPivot.position.y += floorClearance - minSoleY;
    }
    if (rig.hipsPivot.position.y < 0.145) {
      rig.hipsPivot.position.y = 0.145;
    }
  }

  // =========================================================================
  // 3. POST-GROUND EXACT 2-BONE ANALYTICAL HAND-TO-CRATE IK (SPEED VAULT!)
  // =========================================================================
  const allChains = [rig.leftArmIK, rig.rightArmIK];
  for (const chain of allChains) {
    if (!chain) continue;
    const desiredW = chain === ikPlantChain ? ikTargetWeight : 0;
    chain.ikWeight = damp(chain.ikWeight, desiredW, 24.0, dt);

    if (chain.ikWeight > 0.01 && chain === ikPlantChain) {
      applyTwoBoneArmPlantIK(rig, chain, ikTargetPosRoot, chain.ikWeight);
    } else if (chain.handGroup) {
      chain.handGroup.quaternion.slerp(chain.handRestQuat, 1 - Math.exp(-16.0 * dt));
    }
  }

  return {
    justSlammedFloor,
    justPlantedVaultHand,
    liveSpeedMult: loco.speedMult,
  };
}
