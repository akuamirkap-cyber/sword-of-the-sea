import * as THREE from 'three';
import { GLTFExporter } from 'three/examples/jsm/exporters/GLTFExporter.js';
import { OBJExporter } from 'three/examples/jsm/exporters/OBJExporter.js';
import { CharacterLoadout, HitZone, MeshStats, PartSlot } from './types';
import { buildHeadById } from './parts/heads';
import { buildTorsoById } from './parts/torsos';
import { buildArticulatedPantsAndShoes } from './parts/pantsAndShoes';
import {
  ArmIKChain,
  CharacterRig,
  createCombatState,
  createLocomotionState,
  createParkourState,
} from './animation';
import { createMat, makeStylizedMesh } from './materials';
import { createBeveledBoxGeometry } from './common';

export type {
  ArmIKChain,
  CharacterRig,
  CombatAnimState,
  LocomotionState,
  ParkourAnimState,
} from './animation';
export {
  createCombatState,
  createLocomotionState,
  createParkourState,
  triggerCharacterHit,
  reviveCharacterState,
  updateCharacterAnimation,
} from './animation';
export { WorldWarZHorde } from './zombieHorde';

export interface SquadSlotTransform {
  x: number;
  z: number;
  rotY: number;
}

/**
 * Full 9-character side-by-side ("Jejer 9") lineup with clean spacing & staggered depth
 * so weapons and dynamic running/crouching animations have zero collision!
 */
export const SQUAD9_TRANSFORMS: SquadSlotTransform[] = [
  { x: -3.04, z: -0.05, rotY: 0.10 }, // 01 Captain Boonie
  { x: -2.28, z: 0.08, rotY: 0.12 },  // 02 Venom Fang Ops
  { x: -1.52, z: 0.12, rotY: 0.04 },  // 03 Golden Enforcer
  { x: -0.76, z: -0.04, rotY: -0.02 }, // 04 Red-Eye Trooper
  { x: 0.00, z: -0.05, rotY: 0.08 },  // 05 SWAT Police Marksman
  { x: 0.76, z: 0.14, rotY: 0.02 },   // 06 Heavy LMG Gunner
  { x: 1.52, z: 0.10, rotY: -0.06 },  // 07 Skill Issue Agent
  { x: 2.28, z: -0.04, rotY: -0.08 }, // 08 Level-3 Spetsnaz Survivor
  { x: 3.04, z: 0.08, rotY: -0.14 },  // 09 Silat Striker (Southeast Asian Martial Artist!)
];

/**
 * Centered 4-character lineup for Set 1 (Skins 1–4).
 */
export const WAVE1_TRANSFORMS: SquadSlotTransform[] = [
  { x: -1.08, z: -0.04, rotY: 0.10 },
  { x: -0.36, z: 0.10, rotY: 0.08 },
  { x: 0.36, z: 0.11, rotY: -0.06 },
  { x: 1.08, z: -0.05, rotY: -0.10 },
];

/**
 * Centered 5-character lineup for Set 2 (Skins 5–9, including Silat Striker!).
 */
export const WAVE2_TRANSFORMS: SquadSlotTransform[] = [
  { x: -1.48, z: -0.04, rotY: 0.12 }, // 05 Police
  { x: -0.74, z: 0.12, rotY: 0.04 },  // 06 Gunner
  { x: 0.00, z: 0.10, rotY: -0.02 },  // 07 Skill Issue
  { x: 0.74, z: -0.04, rotY: -0.08 }, // 08 Level-3
  { x: 1.48, z: 0.08, rotY: -0.14 },  // 09 Silat Striker
];

function tagPartSubtree(
  obj: THREE.Object3D,
  slotIndex: number,
  partSlot: PartSlot,
  hitZone?: HitZone
) {
  obj.userData.slotIndex = slotIndex;
  obj.userData.partSlot = partSlot;
  if (hitZone) obj.userData.hitZone = hitZone;
  obj.traverse((child) => {
    child.userData.slotIndex = slotIndex;
    child.userData.partSlot = partSlot;
    if (hitZone) child.userData.hitZone = hitZone;
  });
}

function tagHitZoneOnly(obj: THREE.Object3D, hitZone: HitZone) {
  obj.userData.hitZone = hitZone;
  obj.traverse((child) => {
    child.userData.hitZone = hitZone;
  });
}

/**
 * Builds a complete hierarchically rigged, modular stylized character supporting
 * smooth Walk, Run Chase, Crouch, Idle, Zone-Specific Hit Reactions, and 3rd-Shot Knockback Acting!
 */
export function buildModularCharacterRig(
  loadout: CharacterLoadout,
  slotIndex: number
): CharacterRig {
  const root = new THREE.Group();
  root.name = `SkinSlot${slotIndex + 1}_H-${loadout.head}_F-${loadout.face}_T-${loadout.torso}_P-${loadout.pants}_S-${loadout.shoes}`;
  root.userData.slotIndex = slotIndex;

  // Root animated hips pivot seated at true anatomical center of mass (y = 0.92)!
  // Ensures knockback launches ("terpental") & floor falls pivot cleanly around hips with zero clipping.
  const baseHipsY = 0.92;
  const hipsPivot = new THREE.Group();
  hipsPivot.name = 'Rig_Hips';
  hipsPivot.position.set(0, baseHipsY, 0);
  hipsPivot.rotation.order = 'YXZ';
  root.add(hipsPivot);

  const hipsInner = new THREE.Group();
  hipsInner.position.set(0, -baseHipsY, 0);
  hipsPivot.add(hipsInner);

  // 1. Articulated Pants + Shoes (pelvis + leftLeg + rightLeg nested cleanly inside hipsInner)
  const lower = buildArticulatedPantsAndShoes(loadout.pants, loadout.shoes, slotIndex);
  tagHitZoneOnly(lower.pelvisGroup, 'chest');
  tagHitZoneOnly(lower.leftLeg.hipPivot, 'leftLeg');
  tagHitZoneOnly(lower.rightLeg.hipPivot, 'rightLeg');
  hipsInner.add(lower.pelvisGroup);
  hipsInner.add(lower.leftLeg.hipPivot);
  hipsInner.add(lower.rightLeg.hipPivot);

  // 2. Upper Body Waist Pivot (at y = 0.94 so forward sprint/crouch & hit recoil lean from waist!)
  const upperBodyPivot = new THREE.Group();
  upperBodyPivot.name = 'Rig_UpperBody';
  upperBodyPivot.position.set(0, 0.94, 0);
  upperBodyPivot.rotation.order = 'YXZ';

  const upperBodyInner = new THREE.Group();
  upperBodyInner.position.set(0, -0.94, 0);
  upperBodyPivot.add(upperBodyInner);
  hipsInner.add(upperBodyPivot);

  // Build torso + discover articulated arm & weapon pivots
  const torsoGroup = buildTorsoById(loadout.torso);
  tagPartSubtree(torsoGroup, slotIndex, 'torso', 'chest');
  upperBodyInner.add(torsoGroup);

  let leftArmPivot: THREE.Group | null = null;
  let rightArmPivot: THREE.Group | null = null;
  let leftElbowPivot: THREE.Group | null = null;
  let rightElbowPivot: THREE.Group | null = null;
  let leftHand: THREE.Group | null = null;
  let rightHand: THREE.Group | null = null;
  let weaponRig: THREE.Group | null = null;

  torsoGroup.traverse((node) => {
    const role = node.userData.rigRole;
    if (role === 'leftArmPivot') {
      leftArmPivot = node as THREE.Group;
      tagHitZoneOnly(leftArmPivot, 'leftArm');
    } else if (role === 'rightArmPivot') {
      rightArmPivot = node as THREE.Group;
      tagHitZoneOnly(rightArmPivot, 'rightArm');
    } else if (role === 'leftElbowPivot') {
      leftElbowPivot = node as THREE.Group;
    } else if (role === 'rightElbowPivot') {
      rightElbowPivot = node as THREE.Group;
    } else if (role === 'leftHand') {
      leftHand = node as THREE.Group;
    } else if (role === 'rightHand') {
      rightHand = node as THREE.Group;
    } else if (role === 'weaponRig') {
      weaponRig = node as THREE.Group;
    }
  });

  const makeArmIK = (
    side: 'left' | 'right',
    sh: THREE.Group | null,
    elb: THREE.Group | null,
    hand: THREE.Group | null
  ): ArmIKChain | null => {
    if (!sh || !elb) return null;
    const meta = sh.userData.ikMeta as
      | { shoulder: THREE.Vector3; elbow: THREE.Vector3; wrist: THREE.Vector3 }
      | undefined;
    if (!meta) return null;
    const uRest = new THREE.Vector3().subVectors(meta.elbow, meta.shoulder);
    const fRest = new THREE.Vector3().subVectors(meta.wrist, meta.elbow);
    return {
      side,
      shoulderPivot: sh,
      elbowPivot: elb,
      handGroup: hand,
      handRestQuat: hand ? hand.quaternion.clone() : new THREE.Quaternion(),
      shoulderPos: meta.shoulder.clone(),
      uRest,
      fRest,
      L1: uRest.length(),
      L2: fRest.length(),
      attachedToWeapon: Boolean(sh.userData.attachedToWeapon),
      ikWeight: 0,
    };
  };

  const leftArmIK = makeArmIK('left', leftArmPivot, leftElbowPivot, leftHand);
  const rightArmIK = makeArmIK('right', rightArmPivot, rightElbowPivot, rightHand);

  // 3. Head Neck-Base Pivot (at y = 1.49 for natural head nod, sprint focus & headshot whiplash!)
  const headPivot = new THREE.Group();
  headPivot.name = 'Rig_Head';
  headPivot.position.set(0, 1.49, 0);
  headPivot.rotation.order = 'YXZ';

  const headInner = new THREE.Group();
  headInner.position.set(0, -1.49, 0);
  headPivot.add(headInner);

  const headGroup = buildHeadById(loadout.head, loadout.face);
  tagPartSubtree(headGroup, slotIndex, 'head', 'head');
  headInner.add(headGroup);
  upperBodyInner.add(headPivot);

  return {
    root,
    hipsPivot,
    baseHipsY,
    upperBodyPivot,
    headPivot,
    leftArmPivot,
    rightArmPivot,
    leftElbowPivot,
    rightElbowPivot,
    leftArmIK,
    rightArmIK,
    weaponRig,
    leftLeg: lower.leftLeg,
    rightLeg: lower.rightLeg,
    torsoId: loadout.torso,
    combat: createCombatState(),
    loco: createLocomotionState(slotIndex),
    parkour: createParkourState(slotIndex),
  };
}

/**
 * Builds a stylized low-poly tactical parkour vault crate grounded cleanly at y = 0
 * (width 0.54m, height 0.78m, depth 0.60m) with crisp hazard trim & cel outline.
 */
export function createParkourCrateMesh(): THREE.Group {
  const g = new THREE.Group();
  g.name = 'Obstacle_ParkourCrate';

  const bodyMat = createMat({ color: 0x4b5346, roughness: 0.82, metalness: 0.12 });
  const frameMat = createMat({ color: 0x26292e, roughness: 0.66, metalness: 0.28 });
  const topGripMat = createMat({ color: 0x353940, roughness: 0.78, metalness: 0.15 });
  const hazardYellow = createMat({ color: 0xeab32c, roughness: 0.60, metalness: 0.08 });

  // Main reinforced crate core (grounded from y = 0.02 to y = 0.76)
  const core = makeStylizedMesh(
    createBeveledBoxGeometry(0.50, 0.72, 0.56, 0.012),
    bodyMat,
    { outline: 0.0055, edgeThreshold: 32, subtleEdges: true }
  );
  core.position.set(0, 0.39, 0);
  g.add(core);

  // Heavy top rubberized hand-plant vaulting pad (exact y = 0.78 top surface!)
  const topPad = makeStylizedMesh(
    createBeveledBoxGeometry(0.54, 0.055, 0.60, 0.008),
    topGripMat,
    { outline: 0.0046 }
  );
  topPad.position.set(0, 0.752, 0);
  g.add(topPad);

  // Heavy bottom steel skid base resting squarely at y = 0.00
  const baseSkid = makeStylizedMesh(
    createBeveledBoxGeometry(0.54, 0.048, 0.60, 0.006),
    frameMat,
    { outline: 0.0044 }
  );
  baseSkid.position.set(0, 0.024, 0);
  g.add(baseSkid);

  // 4 Vertical steel corner reinforcement bumpers
  for (const sx of [-1, 1]) {
    for (const sz of [-1, 1]) {
      const post = makeStylizedMesh(
        createBeveledBoxGeometry(0.056, 0.74, 0.056, 0.006),
        frameMat,
        { outline: 0.0036 }
      );
      post.position.set(sx * 0.242, 0.39, sz * 0.272);
      g.add(post);
    }
  }

  // Crisp yellow tactical hazard stripe bands on front & back upper faces (instantly visible!)
  for (const sz of [-1, 1]) {
    const stripe = makeStylizedMesh(
      createBeveledBoxGeometry(0.42, 0.068, 0.018, 0.003),
      hazardYellow,
      { outline: 0.0024 }
    );
    stripe.position.set(0, 0.64, sz * 0.282);
    g.add(stripe);

    const crossbar = makeStylizedMesh(
      createBeveledBoxGeometry(0.42, 0.042, 0.020, 0.003),
      frameMat,
      { outline: 0.0022 }
    );
    crossbar.position.set(0, 0.36, sz * 0.282);
    g.add(crossbar);
  }

  return g;
}

export function disposeSubtreeGeometries(root: THREE.Object3D) {
  root.traverse((node) => {
    if (node instanceof THREE.Mesh || node instanceof THREE.LineSegments) {
      node.geometry?.dispose();
    }
  });
}

export function computeMeshStats(object: THREE.Object3D): MeshStats {
  let triangles = 0;
  let vertices = 0;
  let meshes = 0;
  const matSet = new Set<THREE.Material>();

  object.traverse((child) => {
    if (!child.visible) return;
    if (child.userData.isOutline || child.userData.isObstacle) return;
    if (child instanceof THREE.Mesh) {
      let p: THREE.Object3D | null = child.parent;
      while (p) {
        if (!p.visible) return;
        p = p.parent;
      }
      meshes++;
      const geom = child.geometry;
      const pos = geom.getAttribute('position');
      if (pos) vertices += pos.count;
      if (geom.index) {
        triangles += Math.floor(geom.index.count / 3);
      } else if (pos) {
        triangles += Math.floor(pos.count / 3);
      }
      if (Array.isArray(child.material)) {
        child.material.forEach((m) => matSet.add(m));
      } else if (child.material) {
        matSet.add(child.material);
      }
    }
  });

  return {
    triangles,
    vertices,
    meshes,
    materials: matSet.size,
  };
}

function prepareExportClone(source: THREE.Object3D, includeOutlineHull: boolean): THREE.Object3D {
  const clone = source.clone(true);
  const isGroupExport = source.name === 'StylizedPolygonSquad_9Skins';
  if (!isGroupExport) {
    clone.position.set(0, 0, 0);
    clone.rotation.set(0, 0, 0);
  }

  const toRemove: THREE.Object3D[] = [];
  clone.traverse((node) => {
    if (!node.visible || node.userData.isObstacle) {
      toRemove.push(node);
    } else if (node.userData.isEdgeLine) {
      toRemove.push(node);
    } else if (node.userData.isOutline && !includeOutlineHull) {
      toRemove.push(node);
    }
  });
  toRemove.forEach((node) => node.parent?.remove(node));
  clone.updateMatrixWorld(true);
  return clone;
}

function triggerDownload(blob: Blob, filename: string) {
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  setTimeout(() => URL.revokeObjectURL(url), 1500);
}

export async function exportAsGLB(
  source: THREE.Object3D,
  filename: string,
  includeOutlineHull = false
): Promise<void> {
  const exporter = new GLTFExporter();
  const cleanRoot = prepareExportClone(source, includeOutlineHull);

  return new Promise((resolve, reject) => {
    exporter.parse(
      cleanRoot,
      (result) => {
        if (result instanceof ArrayBuffer) {
          triggerDownload(new Blob([result], { type: 'model/gltf-binary' }), filename);
        } else {
          const json = JSON.stringify(result, null, 2);
          triggerDownload(
            new Blob([json], { type: 'application/json' }),
            filename.replace(/\.glb$/i, '.gltf')
          );
        }
        resolve();
      },
      (err) => reject(err),
      { binary: true }
    );
  });
}

export function exportAsOBJ(
  source: THREE.Object3D,
  filename: string,
  includeOutlineHull = false
): void {
  const exporter = new OBJExporter();
  const cleanRoot = prepareExportClone(source, includeOutlineHull);
  const objText = exporter.parse(cleanRoot);
  triggerDownload(new Blob([objText], { type: 'text/plain;charset=utf-8' }), filename);
}
