import React, {
  forwardRef,
  useEffect,
  useImperativeHandle,
  useRef,
} from 'react';
import * as THREE from 'three';
import { OrbitControls } from 'three/examples/jsm/controls/OrbitControls.js';
import { RoomEnvironment } from 'three/examples/jsm/environments/RoomEnvironment.js';
import {
  buildModularCharacterRig,
  CharacterRig,
  computeMeshStats,
  createParkourCrateMesh,
  disposeSubtreeGeometries,
  exportAsGLB,
  exportAsOBJ,
  reviveCharacterState,
  SQUAD9_TRANSFORMS,
  triggerCharacterHit,
  updateCharacterAnimation,
  WAVE1_TRANSFORMS,
  WAVE2_TRANSFORMS,
  WorldWarZHorde,
} from '../models';
import {
  AnimMode,
  CameraPreset,
  CharacterHealthSummary,
  CharacterLoadout,
  HitTargetGroup,
  HitZone,
  MeshStats,
  PartSlot,
  StudioBgMode,
  ViewSelection,
} from '../models/types';
import { playFloorSlamSound, playHitSound } from '../utils/soundFx';

export interface HitFeedbackEvent {
  slotIndex: number;
  zone: HitZone;
  hpRemaining: number;
  isFatal: boolean;
}

export interface SceneViewportHandle {
  exportGLB: (includeOutlines: boolean) => Promise<void>;
  exportOBJ: (includeOutlines: boolean) => void;
  capturePNG: (transparent: boolean) => void;
  resetCamera: () => void;
  shootTarget: (target: number | 'all', group: HitTargetGroup) => void;
  reviveTarget: (target: number | 'all') => void;
  spawnObstacleWave: () => void;
}

interface SceneViewportProps {
  loadouts: CharacterLoadout[];
  selection: ViewSelection;
  activeSlotIndex: number;
  highlightActiveSlot: boolean;
  shootMode: boolean;
  parkourEnabled: boolean;
  zombieHordeEnabled: boolean;
  soundEnabled: boolean;
  bgMode: StudioBgMode;
  cameraPreset: CameraPreset;
  cameraPresetTick: number;
  animMode: AnimMode;
  showOutlines: boolean;
  wireframe: boolean;
  turntable: boolean;
  onPickCharacterPart: (slotIndex: number, partSlot: PartSlot) => void;
  onHitEvent: (ev: HitFeedbackEvent) => void;
  onHealthChange: (summaries: CharacterHealthSummary[]) => void;
  onStatsChange: (stats: MeshStats) => void;
}

interface BurstParticle {
  mesh: THREE.Mesh;
  vel: THREE.Vector3;
  age: number;
  life: number;
  gravity: number;
  baseScale: number;
}

function getCameraGoal(
  selection: ViewSelection,
  preset: CameraPreset,
  aspect = 1.6
): {
  pos: THREE.Vector3;
  target: THREE.Vector3;
} {
  const safeAspect = Math.max(aspect, 0.45);

  if (selection === 'squad9') {
    const distScale = Math.max(1, 1.82 / safeAspect);
    if (preset === 'closeup') {
      return {
        pos: new THREE.Vector3(0, 1.62, 6.4 * distScale),
        target: new THREE.Vector3(0, 1.56, 0),
      };
    }
    if (preset === 'threeQuarter') {
      return {
        pos: new THREE.Vector3(4.4 * distScale, 1.54, 8.2 * distScale),
        target: new THREE.Vector3(0, 0.96, 0),
      };
    }
    if (preset === 'back') {
      return {
        pos: new THREE.Vector3(0, 1.24, -9.2 * distScale),
        target: new THREE.Vector3(0, 0.96, 0),
      };
    }
    return {
      pos: new THREE.Vector3(0, 1.12, 9.0 * distScale),
      target: new THREE.Vector3(0, 0.96, 0),
    };
  }

  if (selection === 'wave1') {
    const distScale = Math.max(1, 1.24 / safeAspect);
    if (preset === 'closeup') {
      return {
        pos: new THREE.Vector3(0, 1.62, 2.85 * distScale),
        target: new THREE.Vector3(0, 1.58, 0),
      };
    }
    if (preset === 'threeQuarter') {
      return {
        pos: new THREE.Vector3(2.35 * distScale, 1.24, 4.45 * distScale),
        target: new THREE.Vector3(0, 0.96, 0),
      };
    }
    if (preset === 'back') {
      return {
        pos: new THREE.Vector3(0, 1.15, -5.0 * distScale),
        target: new THREE.Vector3(0, 0.96, 0),
      };
    }
    return {
      pos: new THREE.Vector3(0, 1.06, 5.05 * distScale),
      target: new THREE.Vector3(0, 0.98, 0),
    };
  }

  if (selection === 'wave2') {
    const distScale = Math.max(1, 1.44 / safeAspect);
    if (preset === 'closeup') {
      return {
        pos: new THREE.Vector3(0, 1.62, 3.55 * distScale),
        target: new THREE.Vector3(0, 1.58, 0),
      };
    }
    if (preset === 'threeQuarter') {
      return {
        pos: new THREE.Vector3(2.85 * distScale, 1.30, 5.15 * distScale),
        target: new THREE.Vector3(0, 0.96, 0),
      };
    }
    if (preset === 'back') {
      return {
        pos: new THREE.Vector3(0, 1.18, -5.9 * distScale),
        target: new THREE.Vector3(0, 0.96, 0),
      };
    }
    return {
      pos: new THREE.Vector3(0, 1.08, 5.95 * distScale),
      target: new THREE.Vector3(0, 0.98, 0),
    };
  }

  const distScale = Math.max(1, 0.72 / safeAspect);
  if (preset === 'closeup') {
    return {
      pos: new THREE.Vector3(0.16, 1.66, 1.12 * distScale),
      target: new THREE.Vector3(0, 1.64, 0.02),
    };
  }
  if (preset === 'threeQuarter') {
    return {
      pos: new THREE.Vector3(1.52 * distScale, 1.15, 2.82 * distScale),
      target: new THREE.Vector3(0, 0.96, 0),
    };
  }
  if (preset === 'back') {
    return {
      pos: new THREE.Vector3(0.14, 1.08, -3.2 * distScale),
      target: new THREE.Vector3(0, 0.96, 0),
    };
  }
  return {
    pos: new THREE.Vector3(0, 1.05, 3.3 * distScale),
    target: new THREE.Vector3(0, 0.98, 0),
  };
}

function applyRenderFlags(obj: THREE.Object3D, showOutlines: boolean, wireframe: boolean) {
  obj.traverse((node) => {
    if (node.userData.isOutline) {
      node.visible = showOutlines;
      return;
    }
    if (node instanceof THREE.Mesh) {
      const mats = Array.isArray(node.material) ? node.material : [node.material];
      mats.forEach((m) => {
        if ('wireframe' in m) {
          (m as THREE.MeshStandardMaterial).wireframe = wireframe;
        }
      });
    }
  });
}

function estimateZoneWorldPos(holder: THREE.Group, rig: CharacterRig, zone: HitZone): THREE.Vector3 {
  const local = new THREE.Vector3(0, 1.25, 0.14);
  if (zone === 'head') local.set(0, 1.68, 0.10);
  else if (zone === 'chest') local.set(0, 1.26, 0.16);
  else if (zone === 'leftArm') local.set(0.27, 1.22, 0.08);
  else if (zone === 'rightArm') local.set(-0.27, 1.22, 0.08);
  else if (zone === 'leftLeg') local.set(0.13, 0.56, 0.08);
  else if (zone === 'rightLeg') local.set(-0.13, 0.56, 0.08);

  // Adjust relative to current animated hips offset
  local.y += rig.hipsPivot.position.y - rig.baseHipsY;
  local.z += rig.hipsPivot.position.z;
  return local.applyMatrix4(holder.matrixWorld);
}

export const SceneViewport = forwardRef<SceneViewportHandle, SceneViewportProps>(
  function SceneViewport(
    {
      loadouts,
      selection,
      activeSlotIndex,
      highlightActiveSlot,
      shootMode,
      parkourEnabled,
      zombieHordeEnabled,
      soundEnabled,
      bgMode,
      cameraPreset,
      cameraPresetTick,
      animMode,
      showOutlines,
      wireframe,
      turntable,
      onPickCharacterPart,
      onHitEvent,
      onHealthChange,
      onStatsChange,
    },
    ref
  ) {
    const containerRef = useRef<HTMLDivElement | null>(null);
    const rendererRef = useRef<THREE.WebGLRenderer | null>(null);
    const sceneRef = useRef<THREE.Scene | null>(null);
    const cameraRef = useRef<THREE.PerspectiveCamera | null>(null);
    const controlsRef = useRef<OrbitControls | null>(null);
    const squadRootRef = useRef<THREE.Group | null>(null);
    const slotHoldersRef = useRef<THREE.Group[]>([]);
    const crateMeshesRef = useRef<THREE.Group[]>([]);
    const hordeRef = useRef<WorldWarZHorde | null>(null);
    const obstacleTimerRef = useRef<number>(0.45);
    const rigsRef = useRef<(CharacterRig | null)[]>(Array.from({ length: 9 }, () => null));
    const prevLoadoutsRef = useRef<(CharacterLoadout | null)[]>(
      Array.from({ length: 9 }, () => null)
    );
    const shadowPlaneRef = useRef<THREE.Mesh | null>(null);
    const gridHelperRef = useRef<THREE.GridHelper | null>(null);
    const selectRingRef = useRef<THREE.Mesh | null>(null);
    const motionTrackRef = useRef<THREE.Group | null>(null);
    const vfxGroupRef = useRef<THREE.Group | null>(null);
    const particlesRef = useRef<BurstParticle[]>([]);
    const shakeRef = useRef({ intensity: 0, offset: new THREE.Vector3() });
    const altSideCounterRef = useRef(0);

    // Shared VFX geometries & materials
    const sharedVfxRef = useRef<{
      shardGeom: THREE.BufferGeometry;
      sparkMat: THREE.MeshBasicMaterial;
      bloodMat: THREE.MeshBasicMaterial;
      dustMat: THREE.MeshBasicMaterial;
      ringGeom: THREE.BufferGeometry;
    } | null>(null);

    const animGoalRef = useRef<{
      pos: THREE.Vector3;
      target: THREE.Vector3;
      active: boolean;
    }>({
      pos: new THREE.Vector3(0, 1.12, 9.0),
      target: new THREE.Vector3(0, 0.96, 0),
      active: false,
    });

    const propsRef = useRef({
      selection,
      activeSlotIndex,
      highlightActiveSlot,
      shootMode,
      parkourEnabled,
      zombieHordeEnabled,
      soundEnabled,
      bgMode,
      animMode,
      showOutlines,
      wireframe,
      turntable,
      onPickCharacterPart,
      onHitEvent,
      onHealthChange,
    });
    propsRef.current = {
      selection,
      activeSlotIndex,
      highlightActiveSlot,
      shootMode,
      parkourEnabled,
      zombieHordeEnabled,
      soundEnabled,
      bgMode,
      animMode,
      showOutlines,
      wireframe,
      turntable,
      onPickCharacterPart,
      onHitEvent,
      onHealthChange,
    };

    /**
     * Spawns random approaching Parkour Vault Crates from the front (+Z) for several
     * alive visible running targets (or the solo target in Solo view)!
     */
    const triggerRandomObstacleWave = (forceImmediate = false) => {
      const holders = slotHoldersRef.current;
      const rigs = rigsRef.current;
      const crates = crateMeshesRef.current;
      if (holders.length !== 9 || crates.length !== 9) return;

      const eligible: number[] = [];
      for (let i = 0; i < 9; i++) {
        const h = holders[i];
        const r = rigs[i];
        if (!h || !h.visible || !r || r.combat.isDead) continue;
        if (!r.parkour.boxActive) {
          eligible.push(i);
        }
      }
      if (eligible.length === 0) return;

      // Fisher-Yates shuffle so obstacle selection is truly random every wave!
      for (let i = eligible.length - 1; i > 0; i--) {
        const j = Math.floor(Math.random() * (i + 1));
        [eligible[i], eligible[j]] = [eligible[j], eligible[i]];
      }

      const maxPick =
        eligible.length === 1
          ? 1
          : forceImmediate
            ? Math.min(eligible.length, 3)
            : Math.min(eligible.length, 2 + Math.floor(Math.random() * 2));

      let spawned = 0;
      for (let k = 0; k < eligible.length && spawned < maxPick; k++) {
        const idx = eligible[k];
        // Avoid spawning simultaneous boxes on directly adjacent lanes so horizontal Speed Vault legs stay 100% clear!
        if (
          eligible.length > 2 &&
          ((idx > 0 && rigs[idx - 1]?.parkour.boxActive) ||
            (idx < 8 && rigs[idx + 1]?.parkour.boxActive))
        ) {
          continue;
        }

        const rig = rigs[idx]!;
        const crate = crates[idx];
        const isLeftOnly =
          rig.torsoId === 'gunner' ||
          rig.torsoId === 'skill' ||
          Boolean(rig.leftArmIK?.attachedToWeapon);
        const vSide: 1 | -1 = isLeftOnly ? 1 : Math.random() < 0.5 ? 1 : -1;

        rig.parkour.boxActive = true;
        rig.parkour.vaultSide = vSide;
        rig.parkour.boxZ = (forceImmediate ? 3.15 : 4.05) + spawned * 0.65 + Math.random() * 0.40;
        rig.parkour.vaulting = false;
        rig.parkour.vaultProgress = 0;
        rig.parkour.handTapFired = false;
        rig.parkour.strideSynced = false;

        crate.position.set(vSide * 0.08, 0, rig.parkour.boxZ);
        crate.visible = true;
        spawned++;
      }
    };

    const emitHealthSummaries = () => {
      const summaries: CharacterHealthSummary[] = rigsRef.current.map((r) => ({
        hp: r?.combat.hp ?? 3,
        maxHp: r?.combat.maxHp ?? 3,
        lastHitZone: r?.combat.activeHitZone ?? null,
        knockedOut: r?.combat.isDead ?? false,
      }));
      propsRef.current.onHealthChange(summaries);
    };

    const spawnHitBurst = (worldPos: THREE.Vector3, isFatal: boolean) => {
      const vfxGroup = vfxGroupRef.current;
      const shared = sharedVfxRef.current;
      if (!vfxGroup || !shared) return;

      const count = isFatal ? 16 : 8;
      for (let i = 0; i < count; i++) {
        const isSpark = i % 2 === 0;
        const mesh = new THREE.Mesh(
          shared.shardGeom,
          isSpark ? shared.sparkMat : shared.bloodMat
        );
        mesh.position.copy(worldPos);
        const scale = (isFatal ? 0.044 : 0.028) * (0.75 + Math.random() * 0.7);
        mesh.scale.setScalar(scale);
        mesh.rotation.set(Math.random() * 6, Math.random() * 6, Math.random() * 6);
        vfxGroup.add(mesh);

        const speed = (isFatal ? 2.8 : 1.7) * (0.6 + Math.random() * 0.9);
        const theta = Math.random() * Math.PI * 2;
        const phi = (Math.random() - 0.3) * Math.PI;
        particlesRef.current.push({
          mesh,
          vel: new THREE.Vector3(
            Math.cos(theta) * Math.cos(phi) * speed,
            Math.abs(Math.sin(phi)) * speed + (isFatal ? 1.1 : 0.55),
            Math.sin(theta) * Math.cos(phi) * speed + 0.55
          ),
          age: 0,
          life: isFatal ? 0.48 : 0.30,
          gravity: 7.5,
          baseScale: scale,
        });
      }

      // Stylized radial impact shockwave flash ring facing camera!
      const ring = new THREE.Mesh(
        shared.ringGeom,
        isFatal ? shared.sparkMat : shared.bloodMat
      );
      ring.position.copy(worldPos).add(new THREE.Vector3(0, 0, 0.04));
      if (cameraRef.current) ring.lookAt(cameraRef.current.position);
      const rScale = isFatal ? 0.24 : 0.14;
      ring.scale.setScalar(rScale);
      vfxGroup.add(ring);
      particlesRef.current.push({
        mesh: ring,
        vel: new THREE.Vector3(0, 0, 0),
        age: 0,
        life: isFatal ? 0.22 : 0.14,
        gravity: 0,
        baseScale: rScale * 2.2,
      });
    };

    const spawnFloorDust = (worldPos: THREE.Vector3) => {
      const vfxGroup = vfxGroupRef.current;
      const shared = sharedVfxRef.current;
      if (!vfxGroup || !shared) return;

      for (let i = 0; i < 10; i++) {
        const ang = (i / 10) * Math.PI * 2 + Math.random() * 0.35;
        const mesh = new THREE.Mesh(shared.shardGeom, shared.dustMat);
        mesh.position.set(
          worldPos.x + Math.cos(ang) * 0.16,
          0.05,
          worldPos.z + Math.sin(ang) * 0.22
        );
        const scale = 0.055 + Math.random() * 0.035;
        mesh.scale.setScalar(scale);
        vfxGroup.add(mesh);

        const spd = 0.75 + Math.random() * 0.75;
        particlesRef.current.push({
          mesh,
          vel: new THREE.Vector3(Math.cos(ang) * spd, 0.55 + Math.random() * 0.4, Math.sin(ang) * spd),
          age: 0,
          life: 0.52,
          gravity: 1.6,
          baseScale: scale,
        });
      }
    };

    const applyShotToSlot = (
      slotIndex: number,
      zone: HitZone,
      hitPointWorld?: THREE.Vector3,
      silent = false
    ) => {
      const rig = rigsRef.current[slotIndex];
      const holder = slotHoldersRef.current[slotIndex];
      if (!rig || !holder || !holder.visible) return;

      const res = triggerCharacterHit(rig.combat, zone);
      const burstPos = hitPointWorld ?? estimateZoneWorldPos(holder, rig, zone);
      spawnHitBurst(burstPos, res.isFatal);

      if (res.applied) {
        shakeRef.current.intensity = Math.max(
          shakeRef.current.intensity,
          res.isFatal ? 0.055 : 0.022
        );
        if (!silent && propsRef.current.soundEnabled) {
          playHitSound(zone, res.isFatal);
        }
        propsRef.current.onHitEvent({
          slotIndex,
          zone,
          hpRemaining: res.hpRemaining,
          isFatal: res.isFatal,
        });
        emitHealthSummaries();
      } else if (!silent && propsRef.current.soundEnabled) {
        playHitSound(zone, false);
      }
    };

    // Initialize Three.js Studio Scene once
    useEffect(() => {
      const container = containerRef.current;
      if (!container) return;

      const scene = new THREE.Scene();
      sceneRef.current = scene;

      const width = container.clientWidth || window.innerWidth;
      const height = container.clientHeight || window.innerHeight;
      const aspect = width / height;

      const camera = new THREE.PerspectiveCamera(32, aspect, 0.1, 90);
      const initGoal = getCameraGoal('squad9', 'front', aspect);
      camera.position.copy(initGoal.pos);
      cameraRef.current = camera;

      const renderer = new THREE.WebGLRenderer({
        antialias: true,
        alpha: true,
        preserveDrawingBuffer: true,
      });
      renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
      renderer.setSize(width, height);
      renderer.shadowMap.enabled = true;
      renderer.shadowMap.type = THREE.PCFSoftShadowMap;
      renderer.toneMapping = THREE.ACESFilmicToneMapping;
      renderer.toneMappingExposure = 1.06;
      renderer.outputColorSpace = THREE.SRGBColorSpace;
      container.appendChild(renderer.domElement);
      rendererRef.current = renderer;

      const pmrem = new THREE.PMREMGenerator(renderer);
      const envRT = pmrem.fromScene(new RoomEnvironment(), 0.04);
      scene.environment = envRT.texture;
      scene.environmentIntensity = 0.55;
      pmrem.dispose();

      const controls = new OrbitControls(camera, renderer.domElement);
      controls.enableDamping = true;
      controls.dampingFactor = 0.08;
      controls.target.set(0, 0.96, 0);
      controls.minDistance = 0.78;
      controls.maxDistance = 20.0;
      controls.maxPolarAngle = Math.PI * 0.51;
      controls.minPolarAngle = 0.15;
      controls.update();
      controlsRef.current = controls;

      const onUserInteract = () => {
        animGoalRef.current.active = false;
      };
      controls.addEventListener('start', onUserInteract);

      // --- STUDIO LIGHTING ---
      const hemi = new THREE.HemisphereLight(0xfff7ee, 0xc77e4b, 1.08);
      hemi.position.set(0, 7, 0);
      scene.add(hemi);

      const keyLight = new THREE.DirectionalLight(0xfff7ed, 2.25);
      keyLight.position.set(-4.6, 6.2, 5.2);
      keyLight.castShadow = true;
      keyLight.shadow.mapSize.set(2048, 2048);
      keyLight.shadow.camera.near = 0.5;
      keyLight.shadow.camera.far = 28;
      keyLight.shadow.camera.left = -7.6;
      keyLight.shadow.camera.right = 7.6;
      keyLight.shadow.camera.top = 7.2;
      keyLight.shadow.camera.bottom = -3.4;
      keyLight.shadow.bias = -0.0005;
      keyLight.shadow.normalBias = 0.018;
      scene.add(keyLight);

      const fillLight = new THREE.DirectionalLight(0xffe1c4, 0.74);
      fillLight.position.set(5.0, 2.2, 3.2);
      scene.add(fillLight);

      const rimLight = new THREE.DirectionalLight(0xffdfbf, 0.95);
      rimLight.position.set(0.6, 4.2, -5.6);
      scene.add(rimLight);

      const shadowPlane = new THREE.Mesh(
        new THREE.PlaneGeometry(28, 28),
        new THREE.ShadowMaterial({ color: 0x3b1e0e, opacity: 0.22 })
      );
      shadowPlane.rotation.x = -Math.PI / 2;
      shadowPlane.position.y = 0.0;
      shadowPlane.receiveShadow = true;
      scene.add(shadowPlane);
      shadowPlaneRef.current = shadowPlane;

      const grid = new THREE.GridHelper(14, 32, 0x6b5344, 0x342a24);
      grid.position.y = 0.001;
      grid.visible = false;
      (grid.material as THREE.Material).transparent = true;
      (grid.material as THREE.Material).opacity = 0.35;
      scene.add(grid);
      gridHelperRef.current = grid;

      // Ground speed-track streaks during Walk & Run Chase
      const motionTrack = new THREE.Group();
      motionTrack.visible = false;
      const dashGeom = new THREE.PlaneGeometry(0.055, 0.42);
      dashGeom.rotateX(-Math.PI / 2);
      const dashMat = new THREE.MeshBasicMaterial({
        color: 0xfff0dc,
        transparent: true,
        opacity: 0.28,
        depthWrite: false,
      });
      for (let lane = -4; lane <= 4; lane++) {
        for (let row = 0; row < 6; row++) {
          const dash = new THREE.Mesh(dashGeom, dashMat);
          dash.position.set(lane * 0.85, 0.003, -3.0 + row * 1.2 + (lane % 2) * 0.4);
          motionTrack.add(dash);
        }
      }
      scene.add(motionTrack);
      motionTrackRef.current = motionTrack;

      const selectRing = new THREE.Mesh(
        new THREE.RingGeometry(0.28, 0.328, 32),
        new THREE.MeshBasicMaterial({
          color: 0xffd27d,
          transparent: true,
          opacity: 0.75,
          side: THREE.DoubleSide,
        })
      );
      selectRing.rotation.x = -Math.PI / 2;
      selectRing.position.y = 0.004;
      selectRing.visible = false;
      scene.add(selectRing);
      selectRingRef.current = selectRing;

      // Shared VFX container & reusable low-poly shard resources
      const vfxGroup = new THREE.Group();
      scene.add(vfxGroup);
      vfxGroupRef.current = vfxGroup;

      sharedVfxRef.current = {
        shardGeom: new THREE.OctahedronGeometry(1, 0),
        sparkMat: new THREE.MeshBasicMaterial({ color: 0xffd35c }),
        bloodMat: new THREE.MeshBasicMaterial({ color: 0xe62b24 }),
        dustMat: new THREE.MeshBasicMaterial({ color: 0xe8b58a }),
        ringGeom: new THREE.RingGeometry(0.42, 0.95, 10),
      };

      // Root squad group + 9 reusable character slot holders
      const squadRoot = new THREE.Group();
      squadRoot.name = 'StylizedPolygonSquad_9Skins';
      scene.add(squadRoot);
      squadRootRef.current = squadRoot;

      const holders: THREE.Group[] = [];
      const crates: THREE.Group[] = [];
      SQUAD9_TRANSFORMS.forEach((tr, i) => {
        const holder = new THREE.Group();
        holder.name = `SquadSlot_${i + 1}`;
        holder.position.set(tr.x, 0, tr.z);
        holder.rotation.y = tr.rotY;
        squadRoot.add(holder);
        holders.push(holder);

        // Per-lane reusable stylized Parkour Vault Crate (excluded from raycast shooting & GLB export!)
        const crate = createParkourCrateMesh();
        crate.visible = false;
        crate.userData.isObstacle = true;
        crate.traverse((c) => {
          c.userData.isObstacle = true;
        });
        holder.add(crate);
        crates.push(crate);
      });
      slotHoldersRef.current = holders;
      crateMeshesRef.current = crates;

      // High-performance GPU-Instanced World War Z Zombie Horde (~84 chasing zombies, ~22 draw calls!)
      const horde = new WorldWarZHorde(84);
      horde.group.visible = propsRef.current.zombieHordeEnabled;
      horde.setOutlinesVisible(propsRef.current.showOutlines);
      horde.setWireframe(propsRef.current.wireframe);
      squadRoot.add(horde.group);
      hordeRef.current = horde;

      // Raycaster: EITHER Shoot Mode (shoots heroes OR blasts zombies flying!) OR Edit Skin Mode!
      const raycaster = new THREE.Raycaster();
      const pointer = new THREE.Vector2();
      let downPos = { x: 0, y: 0 };

      const handlePointerDown = (e: PointerEvent) => {
        downPos = { x: e.clientX, y: e.clientY };
      };

      const handlePointerUp = (e: PointerEvent) => {
        const dist = Math.hypot(e.clientX - downPos.x, e.clientY - downPos.y);
        if (dist > 6) return;

        const rect = renderer.domElement.getBoundingClientRect();
        pointer.x = ((e.clientX - rect.left) / rect.width) * 2 - 1;
        pointer.y = -((e.clientY - rect.top) / rect.height) * 2 + 1;
        raycaster.setFromCamera(pointer, camera);

        const visibleHolders = holders.filter((h) => h.visible);
        const hits = raycaster
          .intersectObjects(visibleHolders, true)
          .filter((h) => !h.object.userData.isObstacle);
        if (hits.length > 0) {
          const bestHit = hits.find((h) => !h.object.userData.isOutline) ?? hits[0];
          const slotIndex = bestHit.object.userData.slotIndex;
          const partSlot = (bestHit.object.userData.partSlot as PartSlot | undefined) ?? 'head';

          if (typeof slotIndex !== 'number') return;

          if (propsRef.current.shootMode) {
            // Resolve exact HitZone from both metadata tag AND local 3D hit point!
            const holder = holders[slotIndex];
            const taggedZone = bestHit.object.userData.hitZone as HitZone | undefined;
            const localPt = holder.worldToLocal(bestHit.point.clone());

            let resolvedZone: HitZone = taggedZone ?? 'chest';
            if (taggedZone === 'chest') {
              // Refine arms on characters whose arms live inside `weaponRig` (Police, Venom, Gold, Gunner)
              if (localPt.x > 0.175) resolvedZone = 'leftArm';
              else if (localPt.x < -0.175) resolvedZone = 'rightArm';
            }

            applyShotToSlot(slotIndex, resolvedZone, bestHit.point.clone());
          } else {
            propsRef.current.onPickCharacterPart(slotIndex, partSlot);
          }
        } else if (propsRef.current.shootMode && hordeRef.current && hordeRef.current.group.visible) {
          // Missed heroes -> check if user shot one of the chasing World War Z zombies!
          const zHits = raycaster.intersectObjects(hordeRef.current.hitMeshes, false);
          if (zHits.length > 0) {
            const zRes = hordeRef.current.handleRaycastShoot(zHits[0]);
            if (zRes.hit) {
              spawnHitBurst(zRes.worldPoint, true);
              shakeRef.current.intensity = Math.max(shakeRef.current.intensity, 0.036);
              if (propsRef.current.soundEnabled) {
                playHitSound('chest', true);
              }
            }
          }
        }
      };

      renderer.domElement.addEventListener('pointerdown', handlePointerDown);
      renderer.domElement.addEventListener('pointerup', handlePointerUp);

      const handleResize = () => {
        if (!container) return;
        const w = container.clientWidth || window.innerWidth;
        const h = container.clientHeight || window.innerHeight;
        camera.aspect = w / h;
        camera.updateProjectionMatrix();
        renderer.setSize(w, h);
      };
      window.addEventListener('resize', handleResize);

      let rafId = 0;
      const clock = new THREE.Clock();

      const animate = () => {
        rafId = requestAnimationFrame(animate);
        const dt = Math.min(clock.getDelta(), 0.05);
        const elapsed = clock.getElapsedTime();

        // Remove previous frame's micro camera shake cleanly before OrbitControls update
        camera.position.sub(shakeRef.current.offset);

        if (animGoalRef.current.active) {
          const factor = 1 - Math.exp(-dt * 7.5);
          camera.position.lerp(animGoalRef.current.pos, factor);
          controls.target.lerp(animGoalRef.current.target, factor);
          if (
            camera.position.distanceTo(animGoalRef.current.pos) < 0.008 &&
            controls.target.distanceTo(animGoalRef.current.target) < 0.008
          ) {
            camera.position.copy(animGoalRef.current.pos);
            controls.target.copy(animGoalRef.current.target);
            animGoalRef.current.active = false;
          }
        }

        if (propsRef.current.turntable && squadRootRef.current) {
          squadRootRef.current.rotation.y += dt * 0.52;
        }

        // --- RANDOM PARKOUR OBSTACLE CRATE SCHEDULER & SPEED-VAULT SYNC ---
        const activeAnim = propsRef.current.animMode;
        const allowParkour = activeAnim === 'chase' && propsRef.current.parkourEnabled;

        if (allowParkour) {
          obstacleTimerRef.current -= dt;
          if (obstacleTimerRef.current <= 0) {
            triggerRandomObstacleWave(false);
            obstacleTimerRef.current =
              typeof propsRef.current.selection === 'number'
                ? 2.0 + Math.random() * 0.7
                : 1.55 + Math.random() * 1.05;
          }
        } else {
          // Reset timer quickly so entering Lari Kejar spawns first random boxes almost immediately!
          obstacleTimerRef.current = 0.35;
        }

        const flashColor = new THREE.Color(0xc92a1e);
        let avgLiveSpeed = 1.0;
        let visibleRunnerCount = 0;

        rigsRef.current.forEach((rig, i) => {
          const holder = holders[i];
          const crate = crateMeshesRef.current[i];
          if (!rig || !holder || !holder.visible) {
            if (crate) crate.visible = false;
            return;
          }

          // Advance approaching crate in this character's lane & synchronize exact Speed Vault window!
          const pk = rig.parkour;
          if (pk.boxActive) {
            if (!allowParkour || rig.combat.isDead) {
              pk.boxActive = false;
              pk.vaulting = false;
              pk.vaultProgress = 0;
              if (crate) crate.visible = false;
            } else {
              const wasVaulting = pk.vaulting;
              const laneSpeed = 3.25 * rig.loco.speedMult;
              pk.boxZ -= dt * laneSpeed;

              // Fluid Speed Vault active window: takeoff at +1.05m -> step-out drive at -0.88m (~0.56s natural flow!)
              const startZ = 1.05;
              const endZ = -0.88;
              if (pk.boxZ <= startZ && pk.boxZ >= endZ) {
                pk.vaulting = true;
                pk.vaultProgress = THREE.MathUtils.clamp(
                  (startZ - pk.boxZ) / (startZ - endZ),
                  0,
                  1
                );
              } else {
                pk.vaulting = false;
                pk.vaultProgress = 0;
                if (wasVaulting && pk.boxZ < endZ) {
                  const landPos = new THREE.Vector3(0, 0.04, 0.14).applyMatrix4(holder.matrixWorld);
                  spawnFloorDust(landPos);
                }
              }

              if (crate) {
                crate.visible = true;
                crate.position.set(pk.vaultSide * 0.08, 0, pk.boxZ);
                // Smooth graceful pop-in at far front & fade-shrink far behind!
                const enterScale = THREE.MathUtils.clamp((5.2 - pk.boxZ) / 0.65, 0.01, 1);
                const exitScale = THREE.MathUtils.clamp((pk.boxZ + 3.6) / 0.65, 0.01, 1);
                crate.scale.setScalar(Math.min(enterScale, exitScale));
              }

              if (pk.boxZ < -3.65) {
                pk.boxActive = false;
                pk.vaulting = false;
                if (crate) crate.visible = false;
              }
            }
          } else if (crate) {
            crate.visible = false;
          }

          const prevFlash = rig.combat.hitFlashTimer;
          const step = updateCharacterAnimation(rig, activeAnim, elapsed, i * 0.62, dt);
          if (!rig.combat.isDead) {
            avgLiveSpeed += step.liveSpeedMult;
            visibleRunnerCount++;
          }

          // Crisp non-destructive brief crimson impact flash on gunshot hit
          const curFlash = rig.combat.hitFlashTimer;
          if (curFlash > 0 || prevFlash > 0) {
            const flashAlpha = curFlash > 0 ? Math.min(1, curFlash / 0.14) : 0;
            rig.root.traverse((node) => {
              if (node.userData.isOutline || !(node instanceof THREE.Mesh)) return;
              const mats = Array.isArray(node.material) ? node.material : [node.material];
              mats.forEach((m) => {
                if (!('emissive' in m)) return;
                const std = m as THREE.MeshStandardMaterial;
                if (std.userData.origEmissiveHex === undefined) {
                  std.userData.origEmissiveHex = std.emissive.getHex();
                  std.userData.origEmissiveInt = std.emissiveIntensity;
                }
                if (flashAlpha > 0) {
                  std.emissive.setHex(std.userData.origEmissiveHex).lerp(flashColor, flashAlpha * 0.72);
                  std.emissiveIntensity = Math.max(
                    std.userData.origEmissiveInt,
                    flashAlpha * 0.58
                  );
                } else {
                  std.emissive.setHex(std.userData.origEmissiveHex);
                  std.emissiveIntensity = std.userData.origEmissiveInt;
                }
              });
            });
          }

          if (step.justPlantedVaultHand) {
            // Subtle tactile dust tap right where palm slaps top of the Parkour Crate!
            const tapWorld = step.justPlantedVaultHand.clone().applyMatrix4(holder.matrixWorld);
            const vfxGroup = vfxGroupRef.current;
            const shared = sharedVfxRef.current;
            if (vfxGroup && shared) {
              for (let k = 0; k < 5; k++) {
                const ang = (k / 5) * Math.PI * 2 + Math.random() * 0.4;
                const mesh = new THREE.Mesh(shared.shardGeom, shared.dustMat);
                mesh.position.copy(tapWorld);
                const sc = 0.026 + Math.random() * 0.016;
                mesh.scale.setScalar(sc);
                vfxGroup.add(mesh);
                particlesRef.current.push({
                  mesh,
                  vel: new THREE.Vector3(Math.cos(ang) * 0.65, 0.35 + Math.random() * 0.25, Math.sin(ang) * 0.65),
                  age: 0,
                  life: 0.28,
                  gravity: 2.0,
                  baseScale: sc,
                });
              }
            }
          }

          if (step.justSlammedFloor) {
            const worldHip = new THREE.Vector3();
            rig.hipsPivot.getWorldPosition(worldHip);
            spawnFloorDust(worldHip);
            if (propsRef.current.soundEnabled) {
              playFloorSlamSound();
            }
          }
        });

        // Update stylized 3D hit-burst & dust particles
        const parts = particlesRef.current;
        for (let i = parts.length - 1; i >= 0; i--) {
          const p = parts[i];
          p.age += dt;
          if (p.age >= p.life) {
            p.mesh.parent?.remove(p.mesh);
            parts.splice(i, 1);
          } else {
            const frac = p.age / p.life;
            p.vel.y -= p.gravity * dt;
            p.mesh.position.addScaledVector(p.vel, dt);
            if (p.mesh.position.y < 0.02) {
              p.mesh.position.y = 0.02;
              p.vel.y *= -0.35;
            }
            if (p.gravity === 0) {
              // Shockwave ring expands & shrinks out
              const sc = p.baseScale * (0.4 + frac * 1.1) * (1 - frac);
              p.mesh.scale.setScalar(Math.max(0.001, sc));
            } else {
              p.mesh.rotation.x += dt * 9;
              p.mesh.rotation.y += dt * 7;
              p.mesh.scale.setScalar(Math.max(0.001, p.baseScale * (1 - frac)));
            }
          }
        }

        const meanMult = visibleRunnerCount > 0 ? avgLiveSpeed / visibleRunnerCount : 1.15;

        // Update 84-zombie World War Z horde in <0.3ms (zero allocations!)
        if (hordeRef.current && hordeRef.current.group.visible) {
          hordeRef.current.update(dt, elapsed, activeAnim, meanMult);
        }

        // Ground speed-track streaks synced to live dynamic 1.0x–1.4x squad speed!
        if (motionTrackRef.current) {
          const isMoving = activeAnim === 'walk' || activeAnim === 'chase';
          motionTrackRef.current.visible = isMoving && propsRef.current.bgMode !== 'transparent';
          if (isMoving) {
            const speed = activeAnim === 'chase' ? 3.25 * meanMult : 2.0;
            const scaleZ = activeAnim === 'chase' ? 1.35 * meanMult : 0.85;
            motionTrackRef.current.children.forEach((dash) => {
              dash.position.z -= dt * speed;
              dash.scale.z = scaleZ;
              if (dash.position.z < -3.6) dash.position.z += 7.2;
            });
          }
        }

        // Active floor selection ring
        if (selectRingRef.current) {
          const isGroupView = typeof propsRef.current.selection !== 'number';
          const idx = propsRef.current.activeSlotIndex;
          const holder = holders[idx];
          const showRing =
            isGroupView &&
            (propsRef.current.highlightActiveSlot || propsRef.current.shootMode) &&
            Boolean(holder?.visible);
          selectRingRef.current.visible = showRing;
          if (showRing && holder) {
            const worldPos = new THREE.Vector3();
            holder.getWorldPosition(worldPos);
            selectRingRef.current.position.set(worldPos.x, 0.004, worldPos.z);
            const pulse = 1 + Math.sin(elapsed * 4.0) * 0.035;
            selectRingRef.current.scale.set(pulse, pulse, 1);
            (selectRingRef.current.material as THREE.MeshBasicMaterial).color.setHex(
              propsRef.current.shootMode ? 0xff4d42 : 0xffd27d
            );
          }
        }

        controls.update();

        // Apply crisp decayed impact camera micro-shake right before render
        if (shakeRef.current.intensity > 0.001) {
          const amp = shakeRef.current.intensity;
          shakeRef.current.offset.set(
            (Math.random() - 0.5) * amp,
            (Math.random() - 0.5) * amp,
            0
          );
          camera.position.add(shakeRef.current.offset);
          shakeRef.current.intensity *= Math.exp(-16 * dt);
        } else {
          shakeRef.current.offset.set(0, 0, 0);
          shakeRef.current.intensity = 0;
        }

        renderer.render(scene, camera);
      };
      animate();

      return () => {
        cancelAnimationFrame(rafId);
        window.removeEventListener('resize', handleResize);
        controls.removeEventListener('start', onUserInteract);
        renderer.domElement.removeEventListener('pointerdown', handlePointerDown);
        renderer.domElement.removeEventListener('pointerup', handlePointerUp);
        holders.forEach((h) => disposeSubtreeGeometries(h));
        hordeRef.current?.dispose();
        if (sharedVfxRef.current) {
          sharedVfxRef.current.shardGeom.dispose();
          sharedVfxRef.current.ringGeom.dispose();
          sharedVfxRef.current.sparkMat.dispose();
          sharedVfxRef.current.bloodMat.dispose();
          sharedVfxRef.current.dustMat.dispose();
        }
        dashGeom.dispose();
        dashMat.dispose();
        envRT.dispose();
        controls.dispose();
        renderer.dispose();
        if (renderer.domElement.parentNode === container) {
          container.removeChild(renderer.domElement);
        }
      };
    }, []);

    // Live incremental modular rebuild whenever ANY of the 9 character loadouts change!
    useEffect(() => {
      const holders = slotHoldersRef.current;
      const squadRoot = squadRootRef.current;
      if (!squadRoot || holders.length !== 9) return;

      let changed = false;
      for (let i = 0; i < 9; i++) {
        const next = loadouts[i];
        const prev = prevLoadoutsRef.current[i];
        if (
          !prev ||
          prev.head !== next.head ||
          prev.face !== next.face ||
          prev.torso !== next.torso ||
          prev.pants !== next.pants ||
          prev.shoes !== next.shoes
        ) {
          changed = true;
          const prevRig = rigsRef.current[i];
          const holder = holders[i];
          // Remove only character children, preserving the lane's reusable Parkour Crate!
          const toRemove = holder.children.filter((ch) => !ch.userData.isObstacle);
          toRemove.forEach((child) => {
            holder.remove(child);
            disposeSubtreeGeometries(child);
          });
          const rig = buildModularCharacterRig(next, i);
          if (prevRig) {
            rig.combat = { ...prevRig.combat };
            rig.loco = { ...prevRig.loco };
            rig.parkour = { ...prevRig.parkour };
          }
          applyRenderFlags(rig.root, propsRef.current.showOutlines, propsRef.current.wireframe);
          holder.add(rig.root);
          rigsRef.current[i] = rig;
          prevLoadoutsRef.current[i] = { ...next };
        }
      }

      if (changed) {
        onStatsChange(computeMeshStats(squadRoot));
        emitHealthSummaries();
      }
    }, [loadouts, onStatsChange]);

    // Sync Squad9 / Wave1 (1-4) / Wave2 (5-9) / Solo layout & camera framing
    useEffect(() => {
      const squadRoot = squadRootRef.current;
      const holders = slotHoldersRef.current;
      if (!squadRoot || holders.length !== 9) return;

      squadRoot.rotation.y = 0;

      if (selection === 'squad9') {
        holders.forEach((holder, i) => {
          const tr = SQUAD9_TRANSFORMS[i];
          holder.visible = true;
          holder.position.set(tr.x, 0, tr.z);
          holder.rotation.y = tr.rotY;
        });
      } else if (selection === 'wave1') {
        holders.forEach((holder, i) => {
          const inWave = i < 4;
          holder.visible = inWave;
          if (inWave) {
            const tr = WAVE1_TRANSFORMS[i];
            holder.position.set(tr.x, 0, tr.z);
            holder.rotation.y = tr.rotY;
          }
        });
      } else if (selection === 'wave2') {
        holders.forEach((holder, i) => {
          const inWave = i >= 4;
          holder.visible = inWave;
          if (inWave) {
            const tr = WAVE2_TRANSFORMS[i - 4];
            holder.position.set(tr.x, 0, tr.z);
            holder.rotation.y = tr.rotY;
          }
        });
      } else {
        holders.forEach((holder, i) => {
          const isTarget = i === selection;
          holder.visible = isTarget;
          if (isTarget) {
            holder.position.set(0, 0, 0);
            holder.rotation.y = 0;
          }
        });
      }

      onStatsChange(computeMeshStats(squadRoot));

      const aspect = cameraRef.current?.aspect ?? 1.6;
      const goal = getCameraGoal(selection, cameraPreset, aspect);
      animGoalRef.current = { pos: goal.pos, target: goal.target, active: true };
    }, [selection, onStatsChange]);

    useEffect(() => {
      const aspect = cameraRef.current?.aspect ?? 1.6;
      const goal = getCameraGoal(selection, cameraPreset, aspect);
      animGoalRef.current = { pos: goal.pos, target: goal.target, active: true };
    }, [cameraPreset, cameraPresetTick, selection]);

    useEffect(() => {
      const squadRoot = squadRootRef.current;
      if (!squadRoot) return;
      applyRenderFlags(squadRoot, showOutlines, wireframe);
      hordeRef.current?.setOutlinesVisible(showOutlines);
      hordeRef.current?.setWireframe(wireframe);
    }, [showOutlines, wireframe]);

    useEffect(() => {
      if (hordeRef.current) {
        hordeRef.current.group.visible = zombieHordeEnabled;
      }
    }, [zombieHordeEnabled]);

    useEffect(() => {
      const shadowPlane = shadowPlaneRef.current;
      const grid = gridHelperRef.current;
      if (shadowPlane) {
        const sm = shadowPlane.material as THREE.ShadowMaterial;
        if (bgMode === 'terracotta') {
          shadowPlane.visible = true;
          sm.color.setHex(0x41200d);
          sm.opacity = 0.22;
        } else if (bgMode === 'dark') {
          shadowPlane.visible = true;
          sm.color.setHex(0x000000);
          sm.opacity = 0.45;
        } else if (bgMode === 'clay') {
          shadowPlane.visible = true;
          sm.color.setHex(0x1e2024);
          sm.opacity = 0.22;
        } else {
          shadowPlane.visible = false;
        }
      }
      if (grid) {
        grid.visible = bgMode === 'dark';
      }
    }, [bgMode]);

    // Expose GLB / OBJ / PNG export + Direct Combat Test triggers!
    useImperativeHandle(ref, () => ({
      shootTarget: (target: number | 'all', group: HitTargetGroup) => {
        altSideCounterRef.current++;
        const pickZone = (idxOffset: number): HitZone => {
          if (group === 'head') return 'head';
          if (group === 'chest') return 'chest';
          const isLeft = (altSideCounterRef.current + idxOffset) % 2 === 0;
          if (group === 'arm') return isLeft ? 'leftArm' : 'rightArm';
          return isLeft ? 'leftLeg' : 'rightLeg';
        };

        if (target === 'all') {
          let playedAudio = false;
          slotHoldersRef.current.forEach((holder, i) => {
            if (!holder.visible) return;
            applyShotToSlot(i, pickZone(i), undefined, playedAudio);
            playedAudio = true;
          });
        } else {
          applyShotToSlot(target, pickZone(0));
        }
      },
      reviveTarget: (target: number | 'all') => {
        if (target === 'all') {
          rigsRef.current.forEach((r) => {
            if (r) reviveCharacterState(r.combat);
          });
        } else {
          const r = rigsRef.current[target];
          if (r) reviveCharacterState(r.combat);
        }
        emitHealthSummaries();
      },
      spawnObstacleWave: () => {
        triggerRandomObstacleWave(true);
      },
      exportGLB: async (includeOutlines: boolean) => {
        const squadRoot = squadRootRef.current;
        const holders = slotHoldersRef.current;
        if (!squadRoot) return;
        const sel = propsRef.current.selection;
        if (typeof sel === 'number') {
          const target = holders[sel]?.children.find((ch) => !ch.userData.isObstacle);
          if (target) {
            await exportAsGLB(target, `${target.name}.glb`, includeOutlines);
          }
        } else {
          await exportAsGLB(squadRoot, `stylized-polygon-${sel}.glb`, includeOutlines);
        }
      },
      exportOBJ: (includeOutlines: boolean) => {
        const squadRoot = squadRootRef.current;
        const holders = slotHoldersRef.current;
        if (!squadRoot) return;
        const sel = propsRef.current.selection;
        if (typeof sel === 'number') {
          const target = holders[sel]?.children.find((ch) => !ch.userData.isObstacle);
          if (target) {
            exportAsOBJ(target, `${target.name}.obj`, includeOutlines);
          }
        } else {
          exportAsOBJ(squadRoot, `stylized-polygon-${sel}.obj`, includeOutlines);
        }
      },
      capturePNG: (transparent: boolean) => {
        const renderer = rendererRef.current;
        const scene = sceneRef.current;
        const camera = cameraRef.current;
        if (!renderer || !scene || !camera) return;

        const shadowPlane = shadowPlaneRef.current;
        const selectRing = selectRingRef.current;
        const motionTrack = motionTrackRef.current;
        const hordeGroup = hordeRef.current?.group;
        const prevShadowVis = shadowPlane?.visible ?? true;
        const prevRingVis = selectRing?.visible ?? false;
        const prevTrackVis = motionTrack?.visible ?? false;
        const prevHordeVis = hordeGroup?.visible ?? false;
        if (selectRing) selectRing.visible = false;
        if (transparent && shadowPlane) shadowPlane.visible = false;
        if (transparent && motionTrack) motionTrack.visible = false;
        if (transparent && hordeGroup) hordeGroup.visible = false;

        renderer.render(scene, camera);

        const webglCanvas = renderer.domElement;
        const outCanvas = document.createElement('canvas');
        outCanvas.width = webglCanvas.width;
        outCanvas.height = webglCanvas.height;
        const ctx = outCanvas.getContext('2d')!;

        if (!transparent) {
          const mode = propsRef.current.bgMode;
          if (mode === 'terracotta') {
            const grad = ctx.createRadialGradient(
              outCanvas.width * 0.5,
              outCanvas.height * 0.45,
              outCanvas.width * 0.06,
              outCanvas.width * 0.5,
              outCanvas.height * 0.5,
              outCanvas.width * 0.78
            );
            grad.addColorStop(0, '#e69f68');
            grad.addColorStop(0.55, '#ce844f');
            grad.addColorStop(1, '#ad643a');
            ctx.fillStyle = grad;
            ctx.fillRect(0, 0, outCanvas.width, outCanvas.height);
          } else if (mode === 'dark') {
            const grad = ctx.createRadialGradient(
              outCanvas.width * 0.5,
              outCanvas.height * 0.42,
              40,
              outCanvas.width * 0.5,
              outCanvas.height * 0.5,
              outCanvas.width * 0.75
            );
            grad.addColorStop(0, '#2a2420');
            grad.addColorStop(1, '#121010');
            ctx.fillStyle = grad;
            ctx.fillRect(0, 0, outCanvas.width, outCanvas.height);
          } else if (mode === 'clay') {
            ctx.fillStyle = '#d4d6d9';
            ctx.fillRect(0, 0, outCanvas.width, outCanvas.height);
          }
        }

        ctx.drawImage(webglCanvas, 0, 0);

        if (selectRing) selectRing.visible = prevRingVis;
        if (transparent && shadowPlane) shadowPlane.visible = prevShadowVis;
        if (transparent && motionTrack) motionTrack.visible = prevTrackVis;
        if (transparent && hordeGroup) hordeGroup.visible = prevHordeVis;
        renderer.render(scene, camera);

        const sel = propsRef.current.selection;
        const tag = typeof sel === 'number' ? `slot${sel + 1}` : sel;
        const link = document.createElement('a');
        link.download = `stylized-skin-${tag}${transparent ? '-alpha' : ''}.png`;
        link.href = outCanvas.toDataURL('image/png');
        link.click();
      },
      resetCamera: () => {
        if (squadRootRef.current) squadRootRef.current.rotation.y = 0;
        const aspect = cameraRef.current?.aspect ?? 1.6;
        const goal = getCameraGoal(propsRef.current.selection, 'front', aspect);
        animGoalRef.current = { pos: goal.pos, target: goal.target, active: true };
      },
    }));

    const backdropStyle: React.CSSProperties =
      bgMode === 'terracotta'
        ? {
            background:
              'radial-gradient(ellipse 72% 64% at 50% 44%, #e59f69 0%, #cf8550 56%, #ad643a 100%)',
          }
        : bgMode === 'dark'
          ? {
              background:
                'radial-gradient(ellipse 70% 65% at 50% 42%, #2c2522 0%, #171413 65%, #0e0c0c 100%)',
            }
          : bgMode === 'clay'
            ? {
                background:
                  'radial-gradient(ellipse 75% 70% at 50% 44%, #e6e7ea 0%, #c8cbd1 68%, #aeb2ba 100%)',
              }
            : {
                backgroundImage:
                  'linear-gradient(45deg, #2a2726 25%, transparent 25%), linear-gradient(-45deg, #2a2726 25%, transparent 25%), linear-gradient(45deg, transparent 75%, #2a2726 75%), linear-gradient(-45deg, transparent 75%, #2a2726 75%)',
                backgroundSize: '28px 28px',
                backgroundPosition: '0 0, 0 14px, 14px -14px, -14px 0px',
                backgroundColor: '#1f1c1b',
              };

    return (
      <div
        ref={containerRef}
        style={backdropStyle}
        className={`relative w-full h-full ${
          shootMode ? 'cursor-crosshair' : 'cursor-grab active:cursor-grabbing'
        }`}
      />
    );
  }
);
