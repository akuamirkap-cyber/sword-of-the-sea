import { Component, lazy, Suspense, useCallback, useEffect, useState, type ComponentType, type ReactNode } from 'react';
import { ArrowRight, Car, Compass, Flag, Gauge, Mountain } from 'lucide-react';
import rallyPreview from './arenas/rc-drift/pigeon/assets/drive-preview.jpg';

function lazyWithRetry<T extends ComponentType<any>>(loader: () => Promise<{ default: T }>) {
  return lazy(async () => {
    let lastError: unknown;
    for (let attempt = 0; attempt < 3; attempt++) {
      try {
        return await loader();
      } catch (err) {
        lastError = err;
        await new Promise((r) => setTimeout(r, 250 * (attempt + 1)));
      }
    }
    throw lastError;
  });
}

const DriftSimGame = lazyWithRetry(() => import('./arenas/drift-sim/DriftSimGame'));
const RmxGame = lazyWithRetry(() => import('./arenas/rc-drift/RmxGame'));
const RallyGame = lazyWithRetry(() => import('./arenas/rc-drift/pigeon/RallyGame'));
const HarunaRoute33Game = lazyWithRetry(() => import('./arenas/haruna-route33/HarunaRoute33Game'));
const HarunaDownhillGame = lazyWithRetry(() => import('./arenas/haruna-downhill/HarunaDownhillGame'));

type ArenaId = 'menu' | 'drift-sim' | 'rc-arena' | 'rally-groupb' | 'haruna-route33' | 'haruna-downhill';

interface ArenaOption {
  id: Exclude<ArenaId, 'menu'>;
  index: string;
  sourceLabel: string;
  title: string;
  subtitle: string;
  description: string;
  specs: string;
  accent: string;
  gradient: string;
  icon: typeof Car;
  previewImage?: string;
}

const ARENAS: ArenaOption[] = [
  {
    id: 'drift-sim',
    index: '01',
    sourceLabel: '3D Car Drift Simulator · Arena Utama',
    title: 'Drift Park 8 Manuver',
    subtitle: 'Arena Latihan & Kombo Trik Real-Time',
    description:
      'Kuasai 8 teknik drift (Power Over, E-Brake, Feint, Manji, 360° Spin, Donut, Figure-8, dan Wall Tap) dengan detektor manuver dan radar sirkuit.',
    specs: 'W A S D · Spasi Handbrake · C Kamera · R Reset',
    accent: 'text-cyan-300',
    gradient: 'from-slate-900 via-[#0e1b2e] to-rose-950/80',
    icon: Gauge,
  },
  {
    id: 'rc-arena',
    index: '02',
    sourceLabel: '3D RC Drift Simulation · Mode 1/10',
    title: 'RMX 2.5 RC Arena',
    subtitle: 'MST RMX 2.5 RTR · Indoor P-Tile',
    description:
      'Simulasi mobil RC drift 1/10 dengan kontrol full proportional, Gyro MGX, pilihan RWD/AWD, serta panel tuning suspensi dan sudut roda lengkap.',
    specs: 'Tab Setup · H Bantuan · Backspace Kembali',
    accent: 'text-amber-300',
    gradient: 'from-red-950/90 via-slate-900 to-blue-950/90',
    icon: Car,
  },
  {
    id: 'rally-groupb',
    index: '03',
    sourceLabel: 'Rally Lab × Fisika 3D Car Drift Simulator',
    title: 'Rally Group B Lab',
    subtitle: 'Sirkuit Pinus & Mt. Haruna · Fisika Drift Sim 100%',
    description:
      'Bodi, roda & asap 3D ikonik Rally Group B Lab dengan gerak mobil, handbrake E-Brake, power-over, manji, 360° spin & auto counter-steer 100% meniru 3D Car Drift Simulator.',
    specs: 'W A S D · Spasi Handbrake · C Kamera · R Reset · F2 Menu',
    accent: 'text-orange-300',
    gradient: 'from-stone-900 via-slate-900 to-amber-950/80',
    icon: Flag,
    previewImage: rallyPreview,
  },
  {
    id: 'haruna-route33',
    index: '04',
    sourceLabel: 'Haruna Track R3F · Gunma Route 33',
    title: 'Haruna Touge Route 33',
    subtitle: 'Rekonstruksi 7,1 km · Siang & Malam',
    description:
      'Lintasan low-poly Prefektur Route 33 Gunung Haruna dengan 30 tikungan, mode siang/malam, mobil rival, dan kamera drone bebas.',
    specs: 'N Malam · F Drone · C Kamera · R Ulang',
    accent: 'text-amber-200',
    gradient: 'from-[#2e241b] via-[#1c1712] to-[#3f291c]',
    icon: Compass,
  },
  {
    id: 'haruna-downhill',
    index: '05',
    sourceLabel: 'Haruna Track · Akina Touge',
    title: 'Mt. Haruna Downhill',
    subtitle: '5 Hairpin · Gutter & Terowongan Sakura',
    description:
      'Turunan puncak Akina dengan gutter beton, efek kelopak sakura, asisten gyro drift, kontrol sentuh, serta penanda waktu dan peringkat S–C.',
    specs: 'Shift Clutch Kick · T Cuaca/Waktu · P Jeda',
    accent: 'text-orange-400',
    gradient: 'from-[#16223a] via-[#1a2c4a] to-[#4a2618]',
    icon: Mountain,
  },
];

function ArenaLoadingFallback() {
  return (
    <div className="fixed inset-0 bg-[#07090f] text-slate-100 flex flex-col items-center justify-center gap-3">
      <div className="font-title text-2xl font-black tracking-wider text-amber-400">MEMUAT ARENA 3D</div>
      <div className="text-sm text-slate-400">Menyiapkan lintasan dan mesin fisika...</div>
    </div>
  );
}

class ArenaErrorBoundary extends Component<
  { children: ReactNode; arenaKey: string; onExit: () => void },
  { hasError: boolean; retryKey: number }
> {
  state = { hasError: false, retryKey: 0 };

  static getDerivedStateFromError() {
    return { hasError: true };
  }

  componentDidUpdate(prevProps: { arenaKey: string }) {
    if (prevProps.arenaKey !== this.props.arenaKey && this.state.hasError) {
      this.setState({ hasError: false });
    }
  }

  render() {
    if (this.state.hasError) {
      return (
        <div className="fixed inset-0 bg-[#07090f] text-slate-100 flex flex-col items-center justify-center gap-4 px-6 text-center">
          <div className="font-title text-2xl font-black tracking-wider text-amber-400">ARENA GAGAL DIMUAT</div>
          <p className="text-sm text-slate-400 max-w-md">
            Koneksi modul arena sempat terputus. Coba muat ulang arena atau kembali ke menu utama.
          </p>
          <div className="flex items-center gap-3">
            <button
              type="button"
              onClick={() => window.location.reload()}
              className="px-4 py-2 rounded-md bg-amber-500 text-slate-950 font-racing font-bold text-sm uppercase tracking-wider cursor-pointer"
            >
              Muat Ulang
            </button>
            <button
              type="button"
              onClick={() => {
                this.setState({ hasError: false });
                this.props.onExit();
              }}
              className="px-4 py-2 rounded-md bg-white/10 text-white font-racing font-bold text-sm uppercase tracking-wider cursor-pointer"
            >
              Kembali ke Menu
            </button>
          </div>
        </div>
      );
    }
    return this.props.children;
  }
}

export default function App() {
  const [activeArena, setActiveArena] = useState<ArenaId>('menu');
  const [selectedIdx, setSelectedIdx] = useState(2);

  const exitToMenu = useCallback(() => {
    setActiveArena('menu');
  }, []);

  useEffect(() => {
    if (activeArena !== 'menu') {
      const onEsc = (e: KeyboardEvent) => {
        if (e.code === 'Escape' && activeArena === 'drift-sim') {
          e.preventDefault();
          exitToMenu();
        }
      };
      window.addEventListener('keydown', onEsc);
      return () => window.removeEventListener('keydown', onEsc);
    }

    const onKey = (e: KeyboardEvent) => {
      if (e.code === 'ArrowRight' || e.code === 'KeyD' || e.code === 'ArrowDown' || e.code === 'KeyS') {
        e.preventDefault();
        setSelectedIdx((i) => (i + 1) % ARENAS.length);
      } else if (e.code === 'ArrowLeft' || e.code === 'KeyA' || e.code === 'ArrowUp' || e.code === 'KeyW') {
        e.preventDefault();
        setSelectedIdx((i) => (i - 1 + ARENAS.length) % ARENAS.length);
      } else if (e.code === 'Digit1') setActiveArena(ARENAS[0].id);
      else if (e.code === 'Digit2') setActiveArena(ARENAS[1].id);
      else if (e.code === 'Digit3') setActiveArena(ARENAS[2].id);
      else if (e.code === 'Digit4') setActiveArena(ARENAS[3].id);
      else if (e.code === 'Digit5') setActiveArena(ARENAS[4].id);
      else if (e.code === 'Enter' || e.code === 'Space') {
        e.preventDefault();
        setActiveArena(ARENAS[selectedIdx].id);
      }
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, [activeArena, selectedIdx, exitToMenu]);

  if (activeArena !== 'menu') {
    return (
      <ArenaErrorBoundary arenaKey={activeArena} onExit={exitToMenu}>
        <Suspense fallback={<ArenaLoadingFallback />}>
          {activeArena === 'drift-sim' && <DriftSimGame onExit={exitToMenu} />}
          {activeArena === 'rc-arena' && <RmxGame onExit={exitToMenu} />}
          {activeArena === 'rally-groupb' && <RallyGame onExit={exitToMenu} />}
          {activeArena === 'haruna-route33' && <HarunaRoute33Game onExit={exitToMenu} />}
          {activeArena === 'haruna-downhill' && <HarunaDownhillGame onExit={exitToMenu} />}
        </Suspense>
      </ArenaErrorBoundary>
    );
  }

  const focused = ARENAS[selectedIdx];

  return (
    <div className="fixed inset-0 overflow-y-auto bg-[#07090f] text-slate-100 select-none">
      <div
        className="pointer-events-none fixed inset-0"
        style={{
          background:
            'radial-gradient(ellipse 75% 50% at 50% 0%, rgba(245, 158, 11, 0.12), transparent 65%), radial-gradient(ellipse 60% 45% at 85% 90%, rgba(6, 182, 212, 0.1), transparent 60%)',
        }}
      />

      <div className="relative mx-auto max-w-[1280px] min-h-full flex flex-col justify-between px-6 py-8 md:px-10 md:py-10 gap-8">
        <header className="flex flex-col md:flex-row md:items-end justify-between gap-4 border-b border-white/10 pb-6">
          <div>
            <div className="text-xs font-medium tracking-[0.24em] text-amber-400 uppercase">
              Koleksi Terpadu 4 Paket Drift
            </div>
            <h1 className="font-title mt-1.5 text-3xl sm:text-5xl font-black italic tracking-tight text-white text-balance">
              3D CAR DRIFT SIMULATOR
            </h1>
          </div>
          <div className="text-xs sm:text-sm text-slate-400 flex flex-wrap items-center gap-x-3 gap-y-1">
            <span>5 Arena Aktif</span>
            <span aria-hidden="true">·</span>
            <span>Pilih 1–5 atau Panah + Enter</span>
          </div>
        </header>

        <section className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
          {ARENAS.map((arena, idx) => {
            const Icon = arena.icon;
            const isSelected = idx === selectedIdx;
            return (
              <button
                key={arena.id}
                type="button"
                onClick={() => {
                  if (isSelected) setActiveArena(arena.id);
                  else setSelectedIdx(idx);
                }}
                onDoubleClick={() => setActiveArena(arena.id)}
                className={`group relative flex flex-col justify-between overflow-hidden rounded-xl border text-left transition-all duration-150 cursor-pointer focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-amber-400 ${
                  isSelected
                    ? 'border-amber-400 bg-[#0e1422] shadow-[0_0_32px_rgba(245,158,11,0.18)]'
                    : 'border-white/10 bg-[#0b0f19] hover:border-white/25 hover:bg-[#0e1422]'
                }`}
              >
                <div className={`relative h-36 w-full overflow-hidden bg-gradient-to-br ${arena.gradient}`}>
                  {arena.previewImage ? (
                    <img
                      src={arena.previewImage}
                      alt={arena.title}
                      referrerPolicy="no-referrer"
                      className="h-full w-full object-cover opacity-80 group-hover:scale-105 transition-transform duration-300"
                    />
                  ) : (
                    <div className="h-full w-full flex items-center justify-between px-6">
                      <span className="font-title text-5xl font-black italic text-white/15 tracking-tighter">
                        {arena.index}
                      </span>
                      <Icon className={`w-11 h-11 ${arena.accent} opacity-85`} strokeWidth={1.6} />
                    </div>
                  )}
                  <div className="absolute inset-0 bg-gradient-to-t from-[#0b0f19] via-transparent to-transparent" />
                </div>

                <div className="p-5 flex-1 flex flex-col justify-between gap-4">
                  <div>
                    <div className="text-[11px] font-medium tracking-wider text-slate-400">
                      {arena.index} · {arena.sourceLabel}
                    </div>
                    <h2 className="font-racing mt-1 text-2xl font-bold text-white tracking-tight">
                      {arena.title}
                    </h2>
                    <div className={`text-xs font-semibold mt-0.5 ${arena.accent}`}>{arena.subtitle}</div>
                    <p className="mt-2.5 text-sm text-slate-300 leading-relaxed">{arena.description}</p>
                  </div>

                  <div className="pt-3 border-t border-white/10 flex items-center justify-between gap-3">
                    <span className="text-[11px] text-slate-400 truncate">{arena.specs}</span>
                    <span
                      onClick={(e) => {
                        e.stopPropagation();
                        setActiveArena(arena.id);
                      }}
                      className={`inline-flex items-center gap-1.5 px-3.5 py-1.5 rounded-md text-xs font-racing font-bold uppercase tracking-wider whitespace-nowrap shrink-0 transition-colors ${
                        isSelected
                          ? 'bg-amber-500 text-slate-950'
                          : 'bg-white/10 text-white group-hover:bg-white/20'
                      }`}
                    >
                      Mainkan <ArrowRight className="w-3.5 h-3.5" />
                    </span>
                  </div>
                </div>
              </button>
            );
          })}
        </section>

        <footer className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-t border-white/10 pt-5 text-xs text-slate-400">
          <div>
            Terpilih: <strong className="text-white font-semibold">{focused.title}</strong> — tekan{' '}
            <kbd className="px-1.5 py-0.5 bg-white/10 border border-white/15 rounded text-white">Enter</kbd> atau klik
            kartu untuk langsung bermain.
          </div>
          <div>Setiap arena dapat ditutup kapan saja lewat tombol Menu untuk ganti lintasan.</div>
        </footer>
      </div>
    </div>
  );
}
