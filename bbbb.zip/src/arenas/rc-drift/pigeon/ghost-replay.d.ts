import type { DriftState, DriverInput } from './drift-physics.js';
import type { RallyTrack } from './rally-road.js';
import type { Telemetry } from './rally-course';

export type GhostMode = 'off' | 'follow' | 'watch';
export type GhostCue = 'brake' | 'trailBrake' | 'handbrake' | 'turnIn' | 'link' | 'counter' | 'hold' | 'exit' | 'accelerate' | 'line' | 'finish' | 'bonus';
export type GhostFrame = { time:number; state:DriftState; input:DriverInput; telemetry:Telemetry; heading:number; bonusZone:number; bonusSeconds:number; bonusCoverage:number };
type GhostClip = { time:number; zone:number };
export type GhostReference = { frames:GhostFrame[]; duration:number; result:Telemetry; impact:number; activeDrift:number; bonusSeconds:number;
  zoneSeconds:number[]; clips:GhostClip[]; timeAtDistance(distance:number):number };
export type GhostHudData = {
  mode:Exclude<GhostMode,'off'>; playing:boolean; time:number; duration:number; rate:number; cue:GhostCue;
  telemetry:Telemetry; gas:number; brake:number; handbrake:boolean; steering:number; ended:boolean;
  lapTarget:number; bonusSeconds:number; bonusCoverage:number; zoneCount:number; clips:GhostClip[]; paceDelta:number|null;
};
export function buildGhostReference(track:RallyTrack):GhostReference;
export function createGhostPlayback(reference:GhostReference):{
  readonly time:number;readonly rate:number;readonly ended:boolean;readonly frame:GhostFrame;readonly heading:number;readonly distance:number;
  seek(time:number):void;setRate(rate:number):void;advance(dt:number,watching:boolean):void;
  sample():DriftState;
  pose():{x:number;z:number;yaw:number};
};
export function ghostFollowTime(lapTime:number,offset:number,alpha:number,timedStep?:number):number;
export function coachingCue(frame:GhostFrame):GhostCue;