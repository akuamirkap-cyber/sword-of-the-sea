import type * as Three from 'three';
import type { DriftState, DriverInput } from './drift-physics.js';
import type { DriftZone, Telemetry, RunMode } from './rally-course';

export type RoadFrame = { x:number; z:number; tx:number; tz:number };
export type RoadRun = {
  state:DriftState; step(dt:number,input:DriverInput):void; reset(next?:RunMode):void; snapshot():Telemetry;
  readonly time:number; readonly lap:number; readonly heading:number; readonly impact:number; readonly finished:boolean; readonly progress:number; readonly lane:number; readonly scoringZone:number;
};
export type RallyTrack = {
  length:number; start:number; segments:number; roadWidth:number; barrier:number; frames:RoadFrame[]; at(distance:number,target?:RoadFrame):RoadFrame;
  origin:RoadFrame; startMarker:{x:number;y:number}; zones:DriftZone[]; route:string; createRun(physics?:'rmx'|'classic'|'ghost', opts?:{settings?:import('../game/settings').Settings}):RoadRun; scale:number; laneScale:number; runoff:number;
};
export const TRACK_SCALE:number; export const BARRIER:number; export const ROAD_WIDTH:number; export const RUNOFF:number; export const LANE_SCALE:number;
export function createTrack(T:typeof Three, opts?:{scale?:number}):RallyTrack;