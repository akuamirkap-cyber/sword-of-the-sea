import type { CSSProperties } from 'react';
import { skins, themes } from './rally-config';
import type { RallyBuild } from './rally-config';

type PartId = RallyBuild['nose'] | RallyBuild['rear'] | RallyBuild['wing'] | RallyBuild['vinyl'];

const parts = {
  nose: [{ id: 'evo', label: 'Evo Rally' }, { id: 'classic', label: 'Klasik' }],
  rear: [{ id: 's1', label: 'S1 Quattro' }, { id: 'standard', label: 'Standar' }],
  wing: [{ id: 'works', label: 'Works Putih' }, { id: 'high', label: 'High Mount' }],
  vinyl: [{ id: 'heritage', label: 'Heritage' }, { id: 'rally', label: 'Rally 12' }],
} as const;
const combinationCount = Object.values(parts).reduce((total, options) => total * options.length, themes.length * skins.length);

function PartDrawing({ id }: { id: PartId }) {
  if (id === 'heritage' || id === 'rally') {
    return <svg className="part-drawing vinyl-drawing" width="62" height="27" viewBox="0 0 62 27" aria-hidden="true">
      <path d="M6 3h50a2 2 0 0 1 2 2v17a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2Z" fill="#e6e4df"/>
      {id === 'heritage' ? <><path d="M22 24 31 3h12L34 24Z" fill="#292b33"/><path d="M16 24 25 3h4l-9 21Z" fill="#c82939"/><path d="m12 24 9-21h2l-9 21Z" fill="#b79248"/><ellipse cx="31.5" cy="9" rx="6.9" ry="3.6" fill="#c82939"/><path d="M28.2 9h6.6" stroke="#fff5ea" strokeWidth="1.15" strokeLinecap="round"/></> : <>
        <path d="M23 3h33a2 2 0 0 1 2 2v17a2 2 0 0 1-2 2H46Z" fill="#252731"/><path d="M15 3h7l23 21h-7Z" fill="#ca2738"/>
        <path d="M12 8h15v13H12Z" fill="#24252b"/><text x="19.4" y="18.6" fill="#fff4eb" fontSize="11" fontWeight="900" fontFamily="Arial,sans-serif" textAnchor="middle">12</text>
      </>}
    </svg>;
  }
  return <svg className="part-drawing" width="62" height="26" viewBox="0 0 62 26" aria-hidden="true" fill="none" stroke="currentColor" strokeWidth="1.45" strokeLinecap="round" strokeLinejoin="round">
    {id === 'evo' && <><path d="M4 12.6 15 8l22-1.1 15 4 4 4.3v4H4.3L3 17Z" fill="currentColor" fillOpacity=".08"/><path d="m10 11.8 8 2.3h25l9-2.8M18.5 10.2l4.3-.4m16.8.1 4.3 1M6 20h51M8.3 17h8m6.7 0H39m6 0h6.7"/><path d="M20 14.3h20" strokeWidth="2.5"/></>}
    {id === 'classic' && <><path d="m5 14 4-4 15-3.1h16L53 10l5 4-1 5.1H5Z" fill="currentColor" fillOpacity=".08"/><path d="M11 12.8h40M5 20.4h52"/><circle cx="19" cy="14.5" r="2.45"/><circle cx="27" cy="17.1" r="2.45"/><circle cx="35" cy="17.1" r="2.45"/><circle cx="43" cy="14.5" r="2.45"/></>}
    {id === 's1' && <><path d="M11 5h40M16 5v4m30-4v4M7 13l4-4.5h40l4 4.5v7l-2 1.6H9L7 20Z" fill="currentColor" fillOpacity=".10"/><rect x="13" y="12" width="16" height="5.4" rx="1.3"/><rect x="33" y="12" width="16" height="5.4" rx="1.3"/><path d="M7.5 12.6h2.3v6.9H7.5m47-6.9h-2.3v6.9h2.3M18 19.6h26M9.5 22v2h5m38-2v2h-5"/></>}
    {id === 'standard' && <><path d="M11 7h40l3.5 6.1v7.6H7.5v-7.6L11 7Z" fill="currentColor" fillOpacity=".10"/><path d="M12 11.5h10v4.2H12Zm28 0h10v4.2H40ZM9 18.3h44m-26 0 1 2.6h6l1-2.6M9 21v2.7h4m40-2.7v2.7h-4"/></>}
    {id === 'works' && <><path d="M5 10c6 0 8 1.6 12 1.5h29c4 .1 6.6-1.4 11-1.5l-4.3 5.2-43.4.3Z" fill="currentColor" fillOpacity=".24"/><path d="m15.4 15.3 2.6 5.5h5l-1.2-5.5m24.6 0-2.6 5.5h-5l1.2-5.5M5 9v1m52-1v1M10 21h42"/></>}
    {id === 'high' && <><path d="M7 5.8h48v3.6H7Z" fill="currentColor" fillOpacity=".22"/><path d="M9 4.3H6.5v9.8H9Zm44 0h2.5v9.8H53Z" fill="currentColor"/><path d="m21 9.4 3 12m17-12-3 12M17.5 21.4h27"/></>}
  </svg>;
}

export function BuildPanel({ build, onPart, onReset, onPreview }: {
  build: RallyBuild;
  onPart: <K extends keyof RallyBuild>(part: K, value: RallyBuild[K]) => void;
  onReset: () => void;
  onPreview: () => void;
}) {
  const groups = [
    { key: 'nose', title: 'Bodi depan', num: '01' },
    { key: 'rear', title: 'Bodi belakang', num: '02' },
    { key: 'wing', title: 'Spoiler', num: '03' },
    { key: 'vinyl', title: 'Stiker vinyl', num: '04' },
  ] as const;
  return <aside className="build-panel" aria-labelledby="parts-title">
    <div className="build-header">
      <div><div className="build-kicker">PILIH PART &amp; LIVERY</div><h2 id="parts-title">Modifikasi</h2></div>
      <button type="button" className="build-reset" onClick={onReset} aria-label="Reset modifikasi" title="Kembalikan semua part ke bawaan">
        <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.7" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true"><path d="M5.2 9a7 7 0 1 1 .8 7.5M5.2 4.5V9h4.5"/></svg><span>Reset</span>
      </button>
    </div>
    <div className="build-sections">
      {groups.map(({ key, title, num }) => <div className="part-section" role="group" aria-labelledby={`part-${key}`} key={key}>
        <h3 id={`part-${key}`}><span>{num}</span>{title}</h3>
        <div className="part-options">
          {parts[key].map(item => <button type="button" className="part-option" aria-pressed={build[key] === item.id} key={item.id} onClick={() => onPart(key, item.id)}>
            <PartDrawing id={item.id}/><span>{item.label}</span>
          </button>)}
        </div>
      </div>)}
      <div className="part-section part-theme" role="group" aria-labelledby="part-theme">
        <h3 id="part-theme"><span>05</span>Tema warna</h3>
        <div className="part-options theme-options">
          {themes.map(theme => <button type="button" className="part-option theme-option" aria-pressed={build.theme === theme.id} key={theme.id} onClick={() => onPart('theme', theme.id)} aria-label={theme.label} title={theme.label}>
            <span className="swatch" style={{ '--swatch-color': theme.accent } as CSSProperties}><i/><i/><i/></span><span>{theme.name}</span>
          </button>)}
        </div>
      </div>
      <div className="part-section part-theme" role="group" aria-labelledby="part-skin">
        <h3 id="part-skin"><span>06</span>Warna tangan</h3>
        <div className="part-options theme-options">
          {skins.map(skin => <button type="button" className="part-option theme-option" aria-pressed={build.skin === skin.id} key={skin.id} onClick={() => onPart('skin', skin.id)} aria-label={skin.label} title={skin.label}>
            <span className="skin-swatch" style={{ '--skin-tone': skin.tone, '--skin-shade': skin.shade } as CSSProperties}/><span>{skin.name}</span>
          </button>)}
        </div>
      </div>
    </div>
    <div className="build-footer"><span><i/>{combinationCount} kombinasi</span><button type="button" className="build-preview" onClick={onPreview}>Lihat mobil <span aria-hidden="true">&#8593;</span></button></div>
  </aside>;
}