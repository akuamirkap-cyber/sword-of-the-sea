import * as THREE from 'three';
import type { CarPhysics } from './physics';
import type { Settings } from './settings';
import { makeCarbonTexture, makeLabelTexture, makeTextTexture } from './textures';

// Local car frame: X forward, Y up, Z right. Origin = ground below CG.
const DEG = Math.PI / 180;
const R_WHEEL = 0.0325;

export interface WheelVisual {
  corner: THREE.Group;
  steer: THREE.Group;
  camber: THREE.Group;
  spin: THREE.Group;
  left: boolean;
  front: boolean;
}

export interface CarVisual {
  root: THREE.Group;
  sprung: THREE.Group;
  bodyShell: THREE.Group;
  chassis: THREE.Group;
  paint: THREE.MeshPhysicalMaterial;
  wheels: WheelVisual[];
  tailMat: THREE.MeshStandardMaterial;
  headMat: THREE.MeshStandardMaterial;
  gyroLed: THREE.MeshStandardMaterial;
  spur: THREE.Object3D;
  pinion: THREE.Object3D;
  fan: THREE.Object3D;
  springs: { mesh: THREE.Object3D; wheel: number }[];
  hCG: number;
}

class Helix extends THREE.Curve<THREE.Vector3> {
  constructor(
    private r: number,
    private h: number,
    private turns: number,
  ) {
    super();
  }
  getPoint(t: number, target = new THREE.Vector3()) {
    const a = t * Math.PI * 2 * this.turns;
    return target.set(Math.cos(a) * this.r, t * this.h - this.h / 2, Math.sin(a) * this.r);
  }
}

function mesh(geo: THREE.BufferGeometry, mat: THREE.Material | THREE.Material[], x = 0, y = 0, z = 0, shadow = true) {
  const m = new THREE.Mesh(geo, mat);
  m.position.set(x, y, z);
  m.castShadow = shadow;
  m.receiveShadow = shadow;
  return m;
}
const box = (w: number, h: number, d: number, mat: THREE.Material | THREE.Material[], x = 0, y = 0, z = 0, sh = true) =>
  mesh(new THREE.BoxGeometry(w, h, d), mat, x, y, z, sh);

function cylZ(r: number, len: number, mat: THREE.Material | THREE.Material[], x = 0, y = 0, z = 0, seg = 20) {
  const g = new THREE.CylinderGeometry(r, r, len, seg);
  g.rotateX(Math.PI / 2);
  return mesh(g, mat, x, y, z);
}

function gearGeometry(r: number, teeth: number, depth: number, thick: number) {
  const s = new THREE.Shape();
  const n = teeth * 4;
  for (let i = 0; i <= n; i++) {
    const a = (i / n) * Math.PI * 2;
    const ph = i % 4;
    const rr = ph === 0 || ph === 1 ? r : r - depth;
    const x = Math.cos(a) * rr;
    const y = Math.sin(a) * rr;
    if (i === 0) s.moveTo(x, y);
    else s.lineTo(x, y);
  }
  const hole = new THREE.Path();
  hole.absarc(0, 0, r * 0.18, 0, Math.PI * 2, true);
  s.holes.push(hole);
  const g = new THREE.ExtrudeGeometry(s, { depth: thick, bevelEnabled: false });
  g.translate(0, 0, -thick / 2);
  return g;
}

// ------------------------------------------------------------------
//  Body shell (86RB "Rocket Bunny" inspired wide-body coupe)
// ------------------------------------------------------------------
function lowerBodyGeometry(xr: number, xf: number) {
  const s = new THREE.Shape();
  const ar = 0.0445;
  const ay = 0.034;
  const by = 0.028;
  const dx = Math.sqrt(ar * ar - (ay - by) * (ay - by));
  const a0 = Math.asin((ay - by) / ar);
  s.moveTo(-0.203, 0.034);
  s.lineTo(xr - dx, by);
  s.absarc(xr, ay, ar, Math.PI + a0, -a0, true);
  s.lineTo(xf - dx, by);
  s.absarc(xf, ay, ar, Math.PI + a0, -a0, true);
  s.lineTo(0.214, 0.03);
  s.quadraticCurveTo(0.226, 0.033, 0.227, 0.047);
  s.quadraticCurveTo(0.227, 0.06, 0.212, 0.064);
  s.quadraticCurveTo(0.14, 0.076, 0.07, 0.083);
  s.lineTo(-0.11, 0.086);
  s.quadraticCurveTo(-0.165, 0.088, -0.196, 0.09);
  s.lineTo(-0.204, 0.095);
  s.quadraticCurveTo(-0.209, 0.07, -0.203, 0.034);
  const g = new THREE.ExtrudeGeometry(s, {
    depth: 0.186,
    bevelEnabled: true,
    bevelThickness: 0.007,
    bevelSize: 0.007,
    bevelSegments: 3,
    curveSegments: 18,
  });
  g.translate(0, 0, -0.093);
  const p = g.attributes.position;
  for (let i = 0; i < p.count; i++) {
    const x = p.getX(i);
    const y = p.getY(i);
    let k = 1;
    if (x > 0.15) k -= 0.2 * ((x - 0.15) / 0.085) ** 2;
    if (x < -0.14) k -= 0.15 * ((-0.14 - x) / 0.07) ** 2;
    if (y > 0.07) k -= 0.12 * Math.min(1, (y - 0.07) / 0.025);
    p.setZ(i, p.getZ(i) * k);
  }
  g.computeVertexNormals();
  return g;
}

function cabinGeometry() {
  const s = new THREE.Shape();
  s.moveTo(0.072, 0.082);
  s.lineTo(0.008, 0.113);
  s.quadraticCurveTo(-0.025, 0.118, -0.058, 0.114);
  s.lineTo(-0.128, 0.087);
  s.lineTo(-0.128, 0.08);
  s.lineTo(0.072, 0.08);
  const g = new THREE.ExtrudeGeometry(s, {
    depth: 0.13,
    bevelEnabled: true,
    bevelThickness: 0.012,
    bevelSize: 0.006,
    bevelSegments: 3,
    curveSegments: 10,
  });
  g.translate(0, 0, -0.065);
  const p = g.attributes.position;
  for (let i = 0; i < p.count; i++) {
    const k = 1 - 0.22 * Math.min(1, Math.max(0, (p.getY(i) - 0.082) / 0.035));
    p.setZ(i, p.getZ(i) * k);
  }
  g.computeVertexNormals();
  return g;
}

function roofGeometry() {
  const s = new THREE.Shape();
  s.moveTo(0.004, 0.1195);
  s.quadraticCurveTo(-0.026, 0.1248, -0.056, 0.1205);
  s.lineTo(-0.052, 0.1155);
  s.quadraticCurveTo(-0.026, 0.119, 0.004, 0.1145);
  s.lineTo(0.004, 0.1195);
  const g = new THREE.ExtrudeGeometry(s, {
    depth: 0.1,
    bevelEnabled: true,
    bevelThickness: 0.006,
    bevelSize: 0.0015,
    bevelSegments: 2,
    curveSegments: 10,
  });
  g.translate(0, 0, -0.05);
  g.computeVertexNormals();
  return g;
}

function decal(tex: THREE.Texture, w: number, h: number) {
  const m = new THREE.Mesh(
    new THREE.PlaneGeometry(w, h),
    new THREE.MeshStandardMaterial({
      map: tex,
      transparent: true,
      roughness: 0.35,
      metalness: 0.1,
      polygonOffset: true,
      polygonOffsetFactor: -2,
      depthWrite: false,
    }),
  );
  return m;
}

function buildBody(paint: THREE.Material, mats: Record<string, THREE.Material>, xr: number, xf: number) {
  const g = new THREE.Group();
  g.add(mesh(lowerBodyGeometry(xr, xf), paint));
  g.add(mesh(cabinGeometry(), mats.glass));
  g.add(mesh(roofGeometry(), paint));

  // Rocket-bunny over fenders
  const flareGeo = new THREE.TorusGeometry(0.0405, 0.0058, 8, 22, Math.PI);
  for (const ax of [xr, xf])
    for (const side of [-1, 1]) {
      const f = mesh(flareGeo, paint, ax, 0.034, side * 0.097);
      f.scale.set(1, 1, 1.9);
      g.add(f);
    }
  // lights
  const head = mats.head;
  const tail = mats.tail;
  for (const side of [-1, 1]) {
    const h = box(0.024, 0.009, 0.04, head, 0.207, 0.061, side * 0.064, false);
    h.rotation.z = -0.33;
    h.rotation.y = side * -0.12;
    g.add(h);
    const t = box(0.006, 0.012, 0.05, tail, -0.205, 0.078, side * 0.064, false);
    g.add(t);
    // mirrors
    g.add(box(0.012, 0.008, 0.016, paint, 0.058, 0.093, side * 0.088));
    // side skirts
    g.add(box(0.16, 0.007, 0.012, mats.black, 0.01, 0.023, side * 0.096));
    // wing stands & end plates
    g.add(box(0.012, 0.03, 0.004, mats.black, -0.188, 0.106, side * 0.055));
    g.add(box(0.046, 0.022, 0.003, mats.carbon, -0.196, 0.12, side * 0.1));
  }
  // grille, lip, diffuser, wing blade, exhaust
  g.add(box(0.006, 0.014, 0.1, mats.black, 0.226, 0.041, 0));
  g.add(box(0.022, 0.005, 0.19, mats.black, 0.221, 0.022, 0));
  g.add(box(0.025, 0.012, 0.15, mats.black, -0.2, 0.03, 0));
  const wing = box(0.042, 0.0035, 0.2, mats.carbon, -0.196, 0.122, 0);
  wing.rotation.z = 0.09;
  g.add(wing);
  const ex = cylZ(0.006, 0.022, mats.chrome, -0.208, 0.03, 0.055);
  ex.rotation.set(0, Math.PI / 2, 0);
  g.add(ex);

  // decals
  const sideTex = makeTextTexture('RMX 2.5', { w: 512, h: 128, fg: '#ffffff', stripe: '#ffcc00', sub: 'MST  •  DRIFT', subColor: '#ffcc00' });
  const dR = decal(sideTex, 0.11, 0.0275);
  dR.position.set(-0.004, 0.052, 0.1006);
  g.add(dR);
  const dL = decal(sideTex, 0.11, 0.0275);
  dL.position.set(-0.004, 0.052, -0.1006);
  dL.rotation.y = Math.PI;
  g.add(dL);
  const bannerTex = makeTextTexture('MST', { w: 512, h: 64, bg: '#0b0b0b', fg: '#ffffff' });
  const banner = decal(bannerTex, 0.11, 0.013);
  const n = new THREE.Vector3(0.436, 0.9, 0).normalize();
  const xA = new THREE.Vector3(0, 0, -1);
  const yA = new THREE.Vector3().crossVectors(n, xA);
  banner.quaternion.setFromRotationMatrix(new THREE.Matrix4().makeBasis(xA, yA, n));
  banner.position.set(0.0236, 0.1128, 0);
  g.add(banner);
  const plateTex = makeTextTexture('RMX·25', { w: 256, h: 96, bg: '#f4f4f4', fg: '#111' });
  const pf = decal(plateTex, 0.034, 0.012);
  pf.position.set(0.2275, 0.036, 0);
  pf.rotation.y = Math.PI / 2;
  g.add(pf);
  const pr = decal(plateTex, 0.034, 0.012);
  pr.position.set(-0.2095, 0.06, 0);
  pr.rotation.y = -Math.PI / 2;
  g.add(pr);
  return g;
}

// ------------------------------------------------------------------
//  Wheel (deep-dish drift wheel + hard drift tyre + brake caliper)
// ------------------------------------------------------------------
function buildWheel(mats: Record<string, THREE.Material>) {
  const g = new THREE.Group();
  const prof = [
    [0.0245, -0.013],
    [0.03, -0.013],
    [0.0318, -0.0115],
    [0.0325, -0.009],
    [0.0325, 0.009],
    [0.0318, 0.0115],
    [0.03, 0.013],
    [0.0245, 0.013],
  ].map(([r, h]) => new THREE.Vector2(r, h));
  const tg = new THREE.LatheGeometry(prof, 40);
  tg.rotateX(Math.PI / 2);
  g.add(mesh(tg, mats.tire));
  const barrel = new THREE.CylinderGeometry(0.0243, 0.0243, 0.025, 28, 1, true);
  barrel.rotateX(Math.PI / 2);
  g.add(mesh(barrel, mats.rimInner));
  const lip = new THREE.Mesh(new THREE.TorusGeometry(0.0238, 0.0016, 8, 32), mats.chrome);
  lip.position.z = 0.0115;
  g.add(lip);
  const back = new THREE.Mesh(new THREE.CircleGeometry(0.0236, 24), mats.rimInner);
  back.position.z = -0.006;
  back.rotation.y = Math.PI;
  g.add(back);
  const back2 = new THREE.Mesh(new THREE.CircleGeometry(0.0236, 24), mats.rimInner);
  back2.position.z = -0.0061;
  g.add(back2);
  const disc = cylZ(0.0165, 0.0018, mats.disc, 0, 0, -0.003, 24);
  g.add(disc);
  const spokeGeo = new THREE.BoxGeometry(0.0034, 0.019, 0.0026);
  for (let i = 0; i < 6; i++) {
    for (const off of [-0.11, 0.11]) {
      const a = (i / 6) * Math.PI * 2 + off;
      const sp = new THREE.Mesh(spokeGeo, mats.rim);
      sp.position.set(Math.cos(a + Math.PI / 2) * 0.0135, Math.sin(a + Math.PI / 2) * 0.0135, 0.0065);
      sp.rotation.z = a;
      g.add(sp);
    }
  }
  const hub = cylZ(0.0065, 0.004, mats.rim, 0, 0, 0.0075, 6);
  g.add(hub);
  g.add(cylZ(0.0028, 0.006, mats.chrome, 0, 0, 0.009, 6));
  return g;
}

// ------------------------------------------------------------------
//  Chassis (RMX 2.5 style RWD drift chassis)
// ------------------------------------------------------------------
function buildChassis(mats: Record<string, THREE.Material>, out: Partial<CarVisual>, xr: number, xf: number) {
  const g = new THREE.Group();
  // main plate
  const s = new THREE.Shape();
  s.moveTo(-0.17, -0.045);
  s.lineTo(0.12, -0.045);
  s.lineTo(0.17, -0.028);
  s.lineTo(0.17, 0.028);
  s.lineTo(0.12, 0.045);
  s.lineTo(-0.17, 0.045);
  s.lineTo(-0.17, -0.045);
  const pg = new THREE.ExtrudeGeometry(s, { depth: 0.003, bevelEnabled: false });
  pg.rotateX(-Math.PI / 2);
  g.add(mesh(pg, mats.carbon, 0, 0.006, 0));
  // upper deck
  g.add(box(0.14, 0.0028, 0.05, mats.carbon, 0.03, 0.047, 0));
  // bulkheads / gearbox / towers
  g.add(box(0.03, 0.022, 0.06, mats.gunmetal, xf, 0.02, 0));
  g.add(box(0.036, 0.034, 0.052, mats.blackPlastic, xr, 0.032, 0));
  g.add(box(0.005, 0.052, 0.12, mats.carbon, xf - 0.008, 0.047, 0));
  g.add(box(0.005, 0.058, 0.12, mats.carbon, xr - 0.012, 0.05, 0));
  // standoffs / body posts
  for (const side of [-1, 1]) {
    const p1 = new THREE.Mesh(new THREE.CylinderGeometry(0.0018, 0.0018, 0.07, 8), mats.alu);
    p1.position.set(xf + 0.012, 0.052, side * 0.028);
    g.add(p1);
    const p2 = p1.clone();
    p2.position.set(xr - 0.022, 0.058, side * 0.028);
    g.add(p2);
  }
  for (const [sx, sz] of [
    [-0.035, 0],
    [0.08, 0.012],
  ]) {
    const st = new THREE.Mesh(new THREE.CylinderGeometry(0.0022, 0.0022, 0.04, 8), mats.red);
    st.position.set(sx, 0.027, sz);
    g.add(st);
  }
  // shocks (coilovers) + springs
  const springGeo = new THREE.TubeGeometry(new Helix(0.0066, 0.024, 7), 160, 0.0011, 5, false);
  const springs: { mesh: THREE.Object3D; wheel: number }[] = [];
  const wheelX = [xf, xf, xr, xr];
  for (let i = 0; i < 4; i++) {
    const side = i % 2 === 0 ? -1 : 1;
    const top = new THREE.Vector3(wheelX[i] + (i < 2 ? -0.01 : -0.014), 0.071, side * 0.045);
    const bot = new THREE.Vector3(wheelX[i] + (i < 2 ? -0.004 : -0.006), 0.022, side * 0.07);
    const dir = new THREE.Vector3().subVectors(top, bot);
    const len = dir.length();
    const sg = new THREE.Group();
    sg.position.copy(bot).addScaledVector(dir, 0.5);
    sg.quaternion.setFromUnitVectors(new THREE.Vector3(0, 1, 0), dir.clone().normalize());
    const body = new THREE.Mesh(new THREE.CylinderGeometry(0.0046, 0.0046, len * 0.55, 12), mats.gold);
    body.position.y = len * 0.18;
    sg.add(body);
    const cap = new THREE.Mesh(new THREE.CylinderGeometry(0.0056, 0.0056, 0.004, 12), mats.red);
    cap.position.y = len * 0.47;
    sg.add(cap);
    const shaft = new THREE.Mesh(new THREE.CylinderGeometry(0.0015, 0.0015, len * 0.5, 8), mats.chrome);
    shaft.position.y = -len * 0.22;
    sg.add(shaft);
    const spr = new THREE.Mesh(springGeo, mats.springRed);
    spr.position.y = -len * 0.02;
    sg.add(spr);
    springs.push({ mesh: spr, wheel: i });
    g.add(sg);
  }
  out.springs = springs;

  // steering servo + linkage
  g.add(box(0.02, 0.02, 0.04, mats.blackPlastic, xf - 0.04, 0.02, 0));
  const servoLbl = new THREE.Mesh(
    new THREE.PlaneGeometry(0.036, 0.016),
    new THREE.MeshStandardMaterial({ map: makeLabelTexture(['MST', 'SC-0352'], '#c9141c', '#fff'), roughness: 0.5 }),
  );
  servoLbl.rotation.x = -Math.PI / 2;
  servoLbl.rotation.z = Math.PI / 2;
  servoLbl.position.set(xf - 0.04, 0.0302, 0);
  g.add(servoLbl);
  for (const side of [-1, 1]) {
    const rod = new THREE.Mesh(new THREE.CylinderGeometry(0.0012, 0.0012, 0.07, 6), mats.chrome);
    rod.rotation.x = Math.PI / 2;
    rod.position.set(xf - 0.012, 0.03, side * 0.04);
    g.add(rod);
  }

  // motor (XBL 2500Kv) + spur/pinion
  const motorTex = makeLabelTexture(['XBL', '2500KV  BRUSHLESS'], '#1d4fd8', '#ffffff', 512, 128);
  const can = new THREE.Mesh(new THREE.CylinderGeometry(0.0175, 0.0175, 0.05, 28), [
    new THREE.MeshStandardMaterial({ map: motorTex, metalness: 0.7, roughness: 0.3 }),
    mats.alu,
    mats.alu,
  ]);
  can.rotation.x = Math.PI / 2;
  can.position.set(-0.07, 0.033, -0.004);
  can.castShadow = true;
  g.add(can);
  for (const z of [-0.027, 0.02]) g.add(cylZ(0.0186, 0.004, mats.gunmetal, -0.07, 0.033, z, 24));
  const spur = mesh(gearGeometry(0.028, 64, 0.0018, 0.003), mats.whitePlastic, -0.105, 0.033, 0.042);
  g.add(spur);
  const pinion = mesh(gearGeometry(0.007, 18, 0.0014, 0.005), mats.steel, -0.07, 0.033, 0.042);
  g.add(pinion);
  out.spur = spur;
  out.pinion = pinion;

  // ESC (XBL50) with fan
  g.add(box(0.034, 0.016, 0.03, mats.blackPlastic, -0.025, 0.018, 0.035));
  const escLbl = new THREE.Mesh(
    new THREE.PlaneGeometry(0.03, 0.026),
    new THREE.MeshStandardMaterial({ map: makeLabelTexture(['XBL50', 'ESC'], '#111', '#ff2b2b'), roughness: 0.6 }),
  );
  escLbl.rotation.x = -Math.PI / 2;
  escLbl.position.set(-0.025, 0.0262, 0.035);
  g.add(escLbl);
  const fan = new THREE.Group();
  fan.position.set(-0.025, 0.0275, 0.035);
  for (let i = 0; i < 5; i++) {
    const b = box(0.009, 0.001, 0.003, mats.gunmetal, 0, 0, 0, false);
    b.position.set(Math.cos((i / 5) * Math.PI * 2) * 0.005, 0, Math.sin((i / 5) * Math.PI * 2) * 0.005);
    b.rotation.y = -(i / 5) * Math.PI * 2;
    fan.add(b);
  }
  g.add(fan);
  out.fan = fan;

  // receiver (XTR-03) + gyro (MGX)
  g.add(box(0.026, 0.012, 0.02, mats.blackPlastic, 0.03, 0.016, 0.035));
  const rxLbl = new THREE.Mesh(
    new THREE.PlaneGeometry(0.024, 0.018),
    new THREE.MeshStandardMaterial({ map: makeLabelTexture(['XTR-03', '2.4GHz'], '#222', '#fff'), roughness: 0.6 }),
  );
  rxLbl.rotation.x = -Math.PI / 2;
  rxLbl.position.set(0.03, 0.0222, 0.035);
  g.add(rxLbl);
  const ant = new THREE.Mesh(new THREE.CylinderGeometry(0.0012, 0.0012, 0.05, 6), mats.blackPlastic);
  ant.position.set(0.04, 0.045, 0.042);
  g.add(ant);
  g.add(box(0.02, 0.01, 0.02, mats.blackPlastic, 0.076, 0.0145, -0.022));
  const gyLbl = new THREE.Mesh(
    new THREE.PlaneGeometry(0.019, 0.019),
    new THREE.MeshStandardMaterial({ map: makeLabelTexture(['MGX', 'GYRO'], '#1554ff', '#fff'), roughness: 0.5 }),
  );
  gyLbl.rotation.x = -Math.PI / 2;
  gyLbl.position.set(0.076, 0.0197, -0.022);
  g.add(gyLbl);
  const gyroLed = new THREE.MeshStandardMaterial({ color: 0x113366, emissive: 0x3388ff, emissiveIntensity: 3 });
  const led = new THREE.Mesh(new THREE.SphereGeometry(0.0018, 10, 8), gyroLed);
  led.position.set(0.084, 0.0205, -0.014);
  g.add(led);
  out.gyroLed = gyroLed;

  // LiPo shorty battery (96 x 47 x 25.5 mm)
  const batTex = makeLabelTexture(['LiPo 2S', '7.4V  4200mAh  SHORTY'], '#151515', '#ffcc00', 512, 256);
  const batMats = [mats.blackPlastic, mats.blackPlastic, new THREE.MeshStandardMaterial({ map: batTex, roughness: 0.5 }), mats.blackPlastic, mats.blackPlastic, mats.blackPlastic];
  g.add(box(0.096, 0.0255, 0.047, batMats, 0.005, 0.0218, -0.032));
  const strap = box(0.008, 0.027, 0.05, mats.blueStrap, 0.005, 0.022, -0.032, false);
  g.add(strap);
  return g;
}

function buildSuspensionArms(mats: Record<string, THREE.Material>, xr: number, xf: number) {
  const g = new THREE.Group();
  for (const ax of [xf, xr])
    for (const side of [-1, 1]) {
      g.add(box(0.02, 0.004, 0.05, mats.blackPlastic, ax, 0.016, side * 0.055));
      const link = new THREE.Mesh(new THREE.CylinderGeometry(0.0014, 0.0014, 0.05, 6), mats.alu);
      link.rotation.x = Math.PI / 2;
      link.position.set(ax, 0.047, side * 0.055);
      g.add(link);
      if (ax === xr) {
        const shaft = new THREE.Mesh(new THREE.CylinderGeometry(0.0022, 0.0022, 0.06, 8), mats.steel);
        shaft.rotation.x = Math.PI / 2;
        shaft.position.set(ax, R_WHEEL, side * 0.054);
        g.add(shaft);
      }
    }
  return g;
}

export function buildCar(color: string): CarVisual {
  const carbon = makeCarbonTexture();
  carbon.repeat.set(6, 6);
  const mats: Record<string, THREE.Material> = {
    glass: new THREE.MeshPhysicalMaterial({ color: 0x0b1016, metalness: 0.2, roughness: 0.04, clearcoat: 1, clearcoatRoughness: 0.02 }),
    black: new THREE.MeshStandardMaterial({ color: 0x0d0d0f, roughness: 0.45, metalness: 0.2 }),
    blackPlastic: new THREE.MeshStandardMaterial({ color: 0x141416, roughness: 0.65, metalness: 0.05 }),
    whitePlastic: new THREE.MeshStandardMaterial({ color: 0xeeeeee, roughness: 0.5 }),
    carbon: new THREE.MeshStandardMaterial({ map: carbon, roughness: 0.32, metalness: 0.4 }),
    chrome: new THREE.MeshStandardMaterial({ color: 0xe8e8ec, metalness: 1, roughness: 0.12 }),
    steel: new THREE.MeshStandardMaterial({ color: 0x9a9ea6, metalness: 0.9, roughness: 0.3 }),
    alu: new THREE.MeshStandardMaterial({ color: 0x9aa2ad, metalness: 0.85, roughness: 0.28 }),
    gunmetal: new THREE.MeshStandardMaterial({ color: 0x3b3f46, metalness: 0.8, roughness: 0.35 }),
    gold: new THREE.MeshStandardMaterial({ color: 0xd8a43a, metalness: 0.9, roughness: 0.25 }),
    red: new THREE.MeshStandardMaterial({ color: 0xd11f2a, metalness: 0.75, roughness: 0.3 }),
    springRed: new THREE.MeshStandardMaterial({ color: 0xe0222d, metalness: 0.4, roughness: 0.35 }),
    blueStrap: new THREE.MeshStandardMaterial({ color: 0x1a4fd0, roughness: 0.8 }),
    tire: new THREE.MeshStandardMaterial({ color: 0x1c1c1f, roughness: 0.42, metalness: 0.05 }),
    rim: new THREE.MeshStandardMaterial({ color: 0x9c7a35, metalness: 0.9, roughness: 0.25 }),
    rimInner: new THREE.MeshStandardMaterial({ color: 0x2a2a2e, metalness: 0.7, roughness: 0.4, side: THREE.DoubleSide }),
    disc: new THREE.MeshStandardMaterial({ color: 0x777b82, metalness: 0.9, roughness: 0.35 }),
    caliper: new THREE.MeshStandardMaterial({ color: 0xe0151f, metalness: 0.3, roughness: 0.35 }),
    head: new THREE.MeshStandardMaterial({ color: 0xffffff, emissive: 0xfff4d8, emissiveIntensity: 2.4, roughness: 0.1 }),
    tail: new THREE.MeshStandardMaterial({ color: 0x550000, emissive: 0xff1a1a, emissiveIntensity: 1.2, roughness: 0.2 }),
  };
  const paint = new THREE.MeshPhysicalMaterial({
    color: new THREE.Color(color),
    metalness: 0.35,
    roughness: 0.3,
    clearcoat: 1,
    clearcoatRoughness: 0.05,
  });

  const xf = 0.139;
  const xr = -0.118;
  const hCG = 0.032;
  const root = new THREE.Group();
  const sprung = new THREE.Group();
  sprung.position.y = hCG;
  root.add(sprung);
  const inner = new THREE.Group();
  inner.position.y = -hCG;
  sprung.add(inner);

  const out: Partial<CarVisual> = {};
  const chassis = buildChassis(mats, out, xr, xf);
  inner.add(chassis);
  const bodyShell = buildBody(paint, mats, xr, xf);
  inner.add(bodyShell);
  root.add(buildSuspensionArms(mats, xr, xf));

  const wheels: WheelVisual[] = [];
  const pos = [
    [xf, -1],
    [xf, 1],
    [xr, -1],
    [xr, 1],
  ];
  for (let i = 0; i < 4; i++) {
    const [x, side] = pos[i];
    const corner = new THREE.Group();
    corner.position.set(x, R_WHEEL, side * 0.087);
    const steer = new THREE.Group();
    const camber = new THREE.Group();
    const spin = new THREE.Group();
    corner.add(steer);
    steer.add(camber);
    camber.add(spin);
    const w = buildWheel(mats);
    if (side < 0) w.rotation.y = Math.PI; // face outward on left side
    spin.add(w);
    // caliper & knuckle (do not spin)
    const cal = box(0.009, 0.014, 0.006, mats.caliper, 0.011, 0.01, side * -0.0035);
    camber.add(cal);
    const knuckle = box(0.012, 0.022, 0.008, mats.blackPlastic, 0, 0, side * -0.017);
    camber.add(knuckle);
    root.add(corner);
    wheels.push({ corner, steer, camber, spin, left: side < 0, front: i < 2 });
  }

  return {
    root,
    sprung,
    bodyShell,
    chassis,
    paint,
    wheels,
    tailMat: mats.tail as THREE.MeshStandardMaterial,
    headMat: mats.head as THREE.MeshStandardMaterial,
    gyroLed: out.gyroLed!,
    spur: out.spur!,
    pinion: out.pinion!,
    fan: out.fan!,
    springs: out.springs!,
    hCG,
  };
}

export function updateCarVisual(v: CarVisual, car: CarPhysics, s: Settings, time: number, dt: number, handbrake: boolean) {
  v.root.position.set(car.x, 0, -car.y);
  v.root.rotation.y = car.heading;
  const rideOffset = (s.rideHeight - 6) * 0.001;
  v.sprung.position.y = v.hCG + rideOffset;
  v.sprung.rotation.set(car.roll, 0, car.pitch);
  for (let i = 0; i < 4; i++) {
    const w = car.wheels[i];
    const wv = v.wheels[i];
    wv.corner.position.set(w.x, R_WHEEL, -w.y);
    wv.steer.rotation.y = w.steer;
    const c = w.camber * DEG;
    wv.camber.rotation.x = wv.left ? -c : c;
    wv.spin.rotation.z = -w.spin;
  }
  for (const sp of v.springs) {
    const comp = car.wheels[sp.wheel].compression;
    sp.mesh.scale.y = 1 - comp * 28;
  }
  const rearSpin = car.wheels[2].spin;
  v.spur.rotation.z = -rearSpin * 2.1;
  v.pinion.rotation.z = rearSpin * 2.1 * 4;
  v.fan.rotation.y += dt * 90;
  v.tailMat.emissiveIntensity = car.braking || handbrake ? 5 : car.reversing ? 3 : 1.2;
  if (s.gyroOn) {
    v.gyroLed.emissive.setHex(0x3388ff);
    v.gyroLed.emissiveIntensity = Math.sin(time * 18) > 0 ? 4 : 1.2;
  } else {
    v.gyroLed.emissive.setHex(0xff2222);
    v.gyroLed.emissiveIntensity = 2.5;
  }
}
