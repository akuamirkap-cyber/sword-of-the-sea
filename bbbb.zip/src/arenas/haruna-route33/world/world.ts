import * as THREE from "three";
import { mergeGeometries } from "three/examples/jsm/utils/BufferGeometryUtils.js";
import {
  buildTrack,
  sampleAt,
  type Corner,
  type Sample,
} from "./track";

export type World = {
  group: THREE.Group;
  samples: Sample[];
  corners: Corner[];
  startDist: number;
  length: number;
  hash: Map<string, number[]>;
  heightAt: (x: number, z: number) => number;
  hairpin: { x: number; y: number; z: number };
  windowMat: THREE.MeshStandardMaterial;
  lanternMat: THREE.MeshStandardMaterial;
  clouds: THREE.Group;
};

const X0 = -3480;
const X1 = 3000;
const Z0 = -2480;
const Z1 = 2920;
const CELL = 18;

const COL = {
  asphalt: new THREE.Color("#5c6772"),
  asphaltB: new THREE.Color("#4e5864"),
  line: new THREE.Color("#f7f8f6"),
  yellow: new THREE.Color("#f0c43a"),
  gravel: new THREE.Color("#c6b48f"),
  gutter: new THREE.Color("#8a8378"),
  rail: new THREE.Color("#e6e0d4"),
  post: new THREE.Color("#c9c2b4"),
  cedar: new THREE.Color("#1e5c3c"),
  cedarB: new THREE.Color("#2f7a4c"),
  autumn: new THREE.Color("#e07a32"),
  autumnB: new THREE.Color("#c44b2c"),
  gold: new THREE.Color("#e6a23c"),
  sakura: new THREE.Color("#f0a0b8"),
  sakuraB: new THREE.Color("#e4789a"),
  grass: new THREE.Color("#3fbf58"),
  grassD: new THREE.Color("#2f9a46"),
  dry: new THREE.Color("#7ed56a"),
  rock: new THREE.Color("#a89880"),
  rockD: new THREE.Color("#7c6d5c"),
  water: new THREE.Color("#3c8eaa"),
  sand: new THREE.Color("#d9c7a4"),
  wall: new THREE.Color("#f3e6d2"),
  roof: new THREE.Color("#c45c3e"),
  roofD: new THREE.Color("#4a3d36"),
  torii: new THREE.Color("#d64532"),
  concrete: new THREE.Color("#cfc8bc"),
  cream: new THREE.Color("#f4efe6"),
  ink: new THREE.Color("#1c1915"),
};

function lambert(color: THREE.Color | string, opts?: { vertex?: boolean }) {
  return new THREE.MeshLambertMaterial({
    color,
    flatShading: true,
    vertexColors: opts?.vertex ?? false,
  });
}

function hash(n: number, k = 0) {
  const x = Math.sin(n * 127.1 + k * 311.7) * 43758.5453;
  return x - Math.floor(x);
}

function smooth(t: number) {
  const x = Math.max(0, Math.min(1, t));
  return x * x * (3 - 2 * x);
}

function scenic(x: number, z: number) {
  const axis = (x * 0.52 + z * 0.85) / 2300;
  let h = axis < 0 ? axis * 28 : -430 * Math.min(axis, 1.15);
  if (axis > 1) h = -430 - (axis - 1) * 70;
  h += Math.sin(x * 0.0048) * Math.cos(z * 0.0036) * 16;
  h += Math.sin(x * 0.012 + z * 0.008) * 6;
  return h;
}

const LAKE = { x: -2655, z: -742, y: -86 };

function lakeMask(x: number, z: number) {
  const e = Math.hypot((x - LAKE.x) / 760, (z - LAKE.z) / 500);
  if (e > 1.08) return 0;
  return 1 - smooth((e - 0.78) / 0.3);
}

export function createWorld(): World {
  const track = buildTrack();
  const { samples, corners, startDist, length, hash } = track;
  const group = new THREE.Group();
  group.name = "haruna";

  const nx = Math.ceil((X1 - X0) / CELL) + 1;
  const nz = Math.ceil((Z1 - Z0) / CELL) + 1;
  const heights = new Float32Array(nx * nz);

  const HCELL = 36;
  const nearest = (x: number, z: number) => {
    const cx = Math.floor(x / HCELL);
    const cz = Math.floor(z / HCELL);
    let bestI = 0;
    let best = Infinity;
    for (let ring = 0; ring <= 9; ring++) {
      for (let ix = cx - ring; ix <= cx + ring; ix++) {
        for (let iz = cz - ring; iz <= cz + ring; iz++) {
          if (ring && Math.abs(ix - cx) < ring && Math.abs(iz - cz) < ring) continue;
          const arr = hash.get(`${ix},${iz}`);
          if (!arr) continue;
          for (const i of arr) {
            const s = samples[i];
            const d = (s.x - x) ** 2 + (s.z - z) ** 2;
            if (d < best) {
              best = d;
              bestI = i;
            }
          }
        }
      }
      if (best < (ring * HCELL) ** 2) break;
    }
    return { i: bestI, d: Math.sqrt(best) };
  };

  const idw = (x: number, z: number) => {
    const cx = Math.floor(x / HCELL);
    const cz = Math.floor(z / HCELL);
    let wsum = 0;
    let hsum = 0;
    for (let ix = cx - 2; ix <= cx + 2; ix++) {
      for (let iz = cz - 2; iz <= cz + 2; iz++) {
        const arr = hash.get(`${ix},${iz}`);
        if (!arr) continue;
        for (const i of arr) {
          const s = samples[i];
          const dd = Math.hypot(s.x - x, s.z - z);
          if (dd > 78) continue;
          const w = 1 / (dd + 3) ** 2;
          wsum += w;
          hsum += w * s.y;
        }
      }
    }
    return wsum > 0 ? hsum / wsum : null;
  };

  function heightRaw(x: number, z: number) {
    const sc = scenic(x, z);
    const lm = lakeMask(x, z);
    const inCorridor = x > -480 && x < 1980 && z > -560 && z < 2520;
    if (!inCorridor) {
      let h = sc;
      if (lm > 0) h = h * (1 - lm) + LAKE.y * lm;
      return Math.round(h / 3.2) * 3.2;
    }
    const n = nearest(x, z);
    if (n.d > 250) {
      let h = sc;
      if (lm > 0) h = h * (1 - lm) + LAKE.y * lm;
      return Math.round(h / 3) * 3;
    }
    const road = samples[n.i].y;
    const blended = idw(x, z) ?? road;
    let h: number;
    if (n.d < 9) h = road - 0.42;
    else if (n.d < 42) {
      const t = (n.d - 9) / 33;
      h = road - 0.2 + (blended - road) * t + t * t * 3.2;
    } else {
      const t = Math.min(1, (n.d - 42) / 150);
      h = blended * (1 - t) + sc * t;
      h += Math.sin(x * 0.02 + z * 0.017) * 5 * smooth((n.d - 40) / 80);
    }
    if (n.d > 70 && lm > 0) h = h * (1 - lm) + LAKE.y * lm;
    if (n.d > 34) h = Math.round(h / 2.6) * 2.6;
    return h;
  }

  for (let iz = 0; iz < nz; iz++) {
    for (let ix = 0; ix < nx; ix++) {
      const x = X0 + ix * CELL;
      const z = Z0 + iz * CELL;
      heights[iz * nx + ix] = heightRaw(x, z);
    }
  }

  function heightAt(x: number, z: number) {
    const fx = (x - X0) / CELL;
    const fz = (z - Z0) / CELL;
    if (fx < 0 || fz < 0 || fx > nx - 1 || fz > nz - 1) return scenic(x, z);
    const ix = Math.floor(fx);
    const iz = Math.floor(fz);
    const tx = fx - ix;
    const tz = fz - iz;
    const i00 = iz * nx + ix;
    const h00 = heights[i00];
    const h10 = heights[i00 + 1];
    const h01 = heights[i00 + nx];
    const h11 = heights[i00 + nx + 1];
    return (
      h00 * (1 - tx) * (1 - tz) +
      h10 * tx * (1 - tz) +
      h01 * (1 - tx) * tz +
      h11 * tx * tz
    );
  }

  group.add(buildTerrain(heights, nx, nz));
  group.add(buildRoad(samples));
  addRails(group, samples);
  addMarkings(group, samples, corners);
  addProps(group, samples, corners, startDist, length, heightAt);

  const windowMat = new THREE.MeshStandardMaterial({
    color: "#f0d7a8",
    emissive: "#ffb15a",
    emissiveIntensity: 0.18,
    roughness: 0.45,
    flatShading: true,
  });
  const lanternMat = new THREE.MeshStandardMaterial({
    color: "#e23b2b",
    emissive: "#ff4a2a",
    emissiveIntensity: 0.55,
    roughness: 0.4,
    flatShading: true,
  });

  addForest(group, samples, heightAt, nearest);
  addLake(group);
  addPeaks(group);
  addTown(group, samples, length, startDist, windowMat, lanternMat, heightAt);
  const clouds = addClouds(group);

  let hx = 0;
  let hy = 0;
  let hz = 0;
  let hn = 0;
  for (const s of samples) {
    if (s.fromStart > 5050 && s.fromStart < 5900) {
      hx += s.x;
      hy += s.y;
      hz += s.z;
      hn++;
    }
  }
  const hairpin = hn
    ? { x: hx / hn, y: hy / hn, z: hz / hn }
    : { x: 820, y: -320, z: 1820 };

  return {
    group,
    samples,
    corners,
    startDist,
    length,
    hash,
    heightAt,
    hairpin,
    windowMat,
    lanternMat,
    clouds,
  };
}

function buildTerrain(heights: Float32Array, nx: number, nz: number) {
  const geo = new THREE.BufferGeometry();
  const pos = new Float32Array(nx * nz * 3);
  const col = new Float32Array(nx * nz * 3);
  const c = new THREE.Color();
  for (let iz = 0; iz < nz; iz++) {
    for (let ix = 0; ix < nx; ix++) {
      const i = iz * nx + ix;
      const x = X0 + ix * CELL;
      const z = Z0 + iz * CELL;
      const y = heights[i];
      pos[i * 3] = x;
      pos[i * 3 + 1] = y;
      pos[i * 3 + 2] = z;
      const slope = slopeAt(heights, nx, nz, ix, iz);
      terrainColor(c, y, slope, x, z);
      col[i * 3] = c.r;
      col[i * 3 + 1] = c.g;
      col[i * 3 + 2] = c.b;
    }
  }
  const idx: number[] = [];
  for (let iz = 0; iz < nz - 1; iz++) {
    for (let ix = 0; ix < nx - 1; ix++) {
      const a = iz * nx + ix;
      idx.push(a, a + 1, a + nx, a + 1, a + nx + 1, a + nx);
    }
  }
  geo.setAttribute("position", new THREE.BufferAttribute(pos, 3));
  geo.setAttribute("color", new THREE.BufferAttribute(col, 3));
  geo.setIndex(idx);
  geo.computeVertexNormals();
  const mesh = new THREE.Mesh(
    geo,
    new THREE.MeshLambertMaterial({ vertexColors: true, flatShading: true, side: THREE.DoubleSide }),
  );
  mesh.receiveShadow = true;
  mesh.name = "terrain";
  return mesh;
}

function slopeAt(h: Float32Array, nx: number, nz: number, ix: number, iz: number) {
  const i = iz * nx + ix;
  const y = h[i];
  const dx = ix < nx - 1 ? Math.abs(h[i + 1] - y) : 0;
  const dz = iz < nz - 1 ? Math.abs(h[i + nx] - y) : 0;
  return Math.hypot(dx, dz) / CELL;
}

function terrainColor(c: THREE.Color, y: number, slope: number, x: number, z: number) {
  if (slope > 0.78) c.copy(COL.rock);
  else if (y > -30) c.copy(COL.grassD);
  else c.copy(COL.grass);
  if (slope > 0.5) c.lerp(COL.rock, Math.min(0.7, (slope - 0.5) * 1.2));
  const n = hash(Math.floor(x / 18) + Math.floor(z / 18) * 13);
  c.lerp(n > 0.55 ? new THREE.Color("#67d36e") : COL.grassD, 0.22);
  if (x > 620 && x < 1080 && z > 1580 && z < 2080) c.lerp(COL.gold, 0.28);
  if (lakeMask(x, z) > 0.2) c.copy(COL.water);
  else if (lakeMask(x, z) > 0) c.lerp(COL.sand, 0.5);
}

function buildRoad(samples: Sample[]) {
  const g = new THREE.Group();
  g.name = "road";
  const n = 8;
  const positions: number[] = [];
  const colors: number[] = [];
  const indices: number[] = [];
  const c = new THREE.Color();
  for (let i = 0; i < samples.length; i++) {
    const s = samples[i];
    const w = s.halfW;
    const lats = [-w - 1.2, -w + 0.16, -w + 0.4, -0.1, 0.1, w - 0.4, w - 0.16, w + 1.2];
    const tight = Math.abs(s.curv) > 0.03;
    const dash = Math.floor(s.dist / 7) % 2 === 0;
    for (let k = 0; k < n; k++) {
      const lat = lats[k];
      positions.push(s.x + s.rx * lat, s.y + Math.sin(s.bank) * lat, s.z + s.rz * lat);
      if (k === 3 || k === 4) c.copy(tight ? COL.yellow : dash ? COL.line : COL.asphalt);
      else if (k === 1 || k === 6) c.copy(COL.line);
      else if (k === 0 || k === 7) c.copy(COL.gravel);
      else c.copy(COL.asphalt);
      colors.push(c.r, c.g, c.b);
    }
  }
  for (let i = 0; i < samples.length - 1; i++) {
    for (let k = 0; k < n - 1; k++) {
      const a = i * n + k;
      indices.push(a, a + n, a + 1, a + 1, a + n, a + n + 1);
    }
  }
  const geo = new THREE.BufferGeometry();
  geo.setAttribute("position", new THREE.Float32BufferAttribute(positions, 3));
  geo.setAttribute("color", new THREE.Float32BufferAttribute(colors, 3));
  geo.setIndex(indices);
  const normals = new Float32Array(positions.length);
  for (let i = 1; i < normals.length; i += 3) normals[i] = 1;
  geo.setAttribute("normal", new THREE.BufferAttribute(normals, 3));
  const mesh = new THREE.Mesh(
    geo,
    new THREE.MeshLambertMaterial({ vertexColors: true, side: THREE.DoubleSide }),
  );
  mesh.receiveShadow = true;
  g.add(mesh);
  return g;
}

function addRails(group: THREE.Group, samples: Sample[]) {
  const postGeo = new THREE.BoxGeometry(0.13, 0.78, 0.12);
  const railGeo = new THREE.BoxGeometry(1, 0.14, 0.09);
  const postMat = lambert(COL.post);
  const railMat = lambert(COL.rail);
  const postM: THREE.Matrix4[] = [];
  const railM: THREE.Matrix4[] = [];
  const q = new THREE.Quaternion();
  const up = new THREE.Vector3(0, 1, 0);
  const tmp = new THREE.Vector3();
  const side = (s: Sample, sign: number) => {
    const lat = sign * (s.halfW + 0.62);
    return {
      x: s.x + s.rx * lat,
      y: s.y + Math.sin(s.bank) * lat,
      z: s.z + s.rz * lat,
    };
  };
  type RailPt = { x: number; y: number; z: number; s: Sample };
  const lastL: Array<RailPt | null> = [null];
  const lastR: Array<RailPt | null> = [null];
  for (const s of samples) {
    if (s.fromStart < -20) continue;
    q.setFromAxisAngle(up, s.heading);
    if (s.railL) {
      const p = side(s, -1);
      tmp.set(p.x, p.y + 0.36, p.z);
      postM.push(new THREE.Matrix4().compose(tmp, q, new THREE.Vector3(1, 1, 1)));
      const prev = lastL[0];
      if (prev && s.dist - prev.s.dist < 7.5) addRail(railM, prev, p, s);
      lastL[0] = { ...p, s };
    } else lastL[0] = null;
    if (s.railR) {
      const p = side(s, 1);
      tmp.set(p.x, p.y + 0.36, p.z);
      postM.push(new THREE.Matrix4().compose(tmp, q, new THREE.Vector3(1, 1, 1)));
      const prev = lastR[0];
      if (prev && s.dist - prev.s.dist < 7.5) addRail(railM, prev, p, s);
      lastR[0] = { ...p, s };
    } else lastR[0] = null;
  }
  const posts = new THREE.InstancedMesh(postGeo, postMat, postM.length);
  postM.forEach((m, i) => posts.setMatrixAt(i, m));
  posts.castShadow = true;
  posts.receiveShadow = true;
  group.add(posts);
  const rails = new THREE.InstancedMesh(railGeo, railMat, railM.length);
  railM.forEach((m, i) => rails.setMatrixAt(i, m));
  rails.castShadow = true;
  rails.receiveShadow = true;
  group.add(rails);
}

function addRail(
  out: THREE.Matrix4[],
  a: { x: number; y: number; z: number },
  b: { x: number; y: number; z: number },
  s: Sample,
) {
  const mx = (a.x + b.x) / 2;
  const my = (a.y + b.y) / 2 + 0.58;
  const mz = (a.z + b.z) / 2;
  const len = Math.hypot(b.x - a.x, b.z - a.z);
  const basis = new THREE.Matrix4().makeBasis(
    new THREE.Vector3(s.tx, 0, s.tz),
    new THREE.Vector3(0, 1, 0),
    new THREE.Vector3(s.rx, 0, s.rz),
  );
  const q = new THREE.Quaternion().setFromRotationMatrix(basis);
  out.push(
    new THREE.Matrix4().compose(
      new THREE.Vector3(mx, my, mz),
      q,
      new THREE.Vector3(len, 1, 1),
    ),
  );
}

function addMarkings(group: THREE.Group, samples: Sample[], corners: Corner[]) {
  const cream = lambert(COL.cream);
  const yellow = lambert(COL.yellow);
  const ink = lambert(COL.ink);
  const dummy = new THREE.Object3D();
  const plateMats: THREE.Matrix4[] = [];
  const chevMats: THREE.Matrix4[] = [];
  const straight = findStraight(samples, 4550, 5080);
  if (straight) paintWord(group, straight, cream);

  const firstPin = corners.find((c) => c.hairpin) ?? corners.find((c) => c.fromStart > 4900);
  if (firstPin) {
    const s = sampleAt(samples, firstPin.dist - 70);
    for (let i = 0; i < 5; i++) {
      addArrow(group, sampleAt(samples, s.dist - i * 7), yellow, i % 2 ? -1.3 : 1.3);
    }
  }

  for (const c of corners) {
    const s = sampleAt(samples, c.dist - 32);
    const lat = -(s.halfW + 1.15);
    const x = s.x + s.rx * lat;
    const z = s.z + s.rz * lat;
    const y = s.y + 1.35;
    const post = new THREE.Mesh(new THREE.BoxGeometry(0.08, 1.7, 0.08), ink);
    post.position.set(x, s.y + 0.85, z);
    group.add(post);
    const tex = numberTex(c.number);
    const board = new THREE.Mesh(
      new THREE.PlaneGeometry(0.66, 0.66),
      new THREE.MeshBasicMaterial({ map: tex, side: THREE.DoubleSide }),
    );
    board.position.set(x, y, z);
    board.lookAt(x - s.tx * 4, y, z - s.tz * 4);
    group.add(board);

    if (c.angle > 42) {
      const outside = c.dir === "L" ? 1 : -1;
      for (let k = 0; k < 4; k++) {
        const cs = sampleAt(samples, c.dist - 6 + k * 7);
        const latC = outside * (cs.halfW + 0.95);
        const cx = cs.x + cs.rx * latC;
        const cz = cs.z + cs.rz * latC;
        const boardY = cs.y + 0.85;
        dummy.position.set(cx, boardY, cz);
        dummy.rotation.set(0, 0, 0);
        dummy.lookAt(cs.x, boardY, cs.z);
        dummy.updateMatrix();
        plateMats.push(dummy.matrix.clone());
        dummy.translateZ(0.05);
        dummy.rotateZ(0.55);
        dummy.updateMatrix();
        chevMats.push(dummy.matrix.clone());
        dummy.rotateZ(-1.1);
        dummy.updateMatrix();
        chevMats.push(dummy.matrix.clone());
      }
    }
  }

  if (plateMats.length) {
    const plates = new THREE.InstancedMesh(new THREE.BoxGeometry(0.92, 0.62, 0.06), yellow, plateMats.length);
    plateMats.forEach((m, i) => plates.setMatrixAt(i, m));
    group.add(plates);
  }
  if (chevMats.length) {
    const chevs = new THREE.InstancedMesh(new THREE.BoxGeometry(0.46, 0.1, 0.08), ink, chevMats.length);
    chevMats.forEach((m, i) => chevs.setMatrixAt(i, m));
    group.add(chevs);
  }

  for (let km = 1; km <= 7; km++) {
    const s = sampleAt(samples, samples[0].dist + (samples.find((p) => p.fromStart >= 0)?.dist ?? 0) - samples[0].dist + km * 1000);
    if (s.fromStart < 200 || s.fromStart > 7000) continue;
    const lat = -(s.halfW + 1.4);
    const post = new THREE.Mesh(new THREE.BoxGeometry(0.08, 1.1, 0.08), ink);
    post.position.set(s.x + s.rx * lat, s.y + 0.55, s.z + s.rz * lat);
    group.add(post);
    const tex = numberTex(km);
    const board = new THREE.Mesh(
      new THREE.PlaneGeometry(0.42, 0.42),
      new THREE.MeshBasicMaterial({ map: tex, side: THREE.DoubleSide }),
    );
    board.position.set(s.x + s.rx * lat, s.y + 1.15, s.z + s.rz * lat);
    board.lookAt(s.x + s.rx * lat - s.tx, s.y + 1.15, s.z + s.rz * lat - s.tz);
    group.add(board);
  }
}

function findStraight(samples: Sample[], a: number, b: number) {
  let best = Infinity;
  let bestI = -1;
  for (let i = 0; i < samples.length; i++) {
    const s = samples[i];
    if (s.fromStart < a || s.fromStart > b) continue;
    let sum = 0;
    let n = 0;
    for (let j = i; j < samples.length && samples[j].dist - s.dist < 28; j++) {
      sum += Math.abs(samples[j].curv);
      n++;
    }
    if (n > 3 && sum / n < best) {
      best = sum / n;
      bestI = i;
    }
  }
  return bestI >= 0 ? samples[bestI] : null;
}

const FONT: Record<string, string[]> = {
  A: ["01110", "10001", "10001", "11111", "10001", "10001", "10001"],
  K: ["10001", "10010", "10100", "11000", "10100", "10010", "10001"],
  I: ["11111", "00100", "00100", "00100", "00100", "00100", "11111"],
  N: ["10001", "11001", "10101", "10011", "10001", "10001", "10001"],
};

function paintWord(group: THREE.Group, s: Sample, mat: THREE.Material) {
  const pix = 0.72;
  const word = "AKINA";
  let along0 = 0;
  for (const ch of word) {
    const rows = FONT[ch];
    if (!rows) continue;
    rows.forEach((row, ry) => {
      for (let rx = 0; rx < row.length; rx++) {
        if (row[rx] !== "1") continue;
        const along = along0 + (6 - ry) * pix;
        const across = (rx - 2) * pix;
        const mesh = new THREE.Mesh(new THREE.BoxGeometry(pix * 0.82, 0.07, pix * 0.82), mat);
        mesh.position.set(
          s.x + s.tx * along + s.rx * across,
          s.y + 0.11 + Math.sin(s.bank) * across,
          s.z + s.tz * along + s.rz * across,
        );
        mesh.rotation.y = s.heading;
        mesh.castShadow = true;
        group.add(mesh);
      }
    });
    along0 += 6.4 * pix;
  }
  for (let i = 0; i < 3; i++) addArrow(group, s, mat, 0, -4.2 - i * 2.6);
}

function addArrow(
  group: THREE.Group,
  s: Sample,
  mat: THREE.Material,
  across = 0,
  along = 0,
) {
  const geo = new THREE.BufferGeometry();
  const h = 1.7;
  const w = 0.85;
  const y = s.y + 0.1;
  const tip = [s.x + s.tx * (along + h) + s.rx * across, y, s.z + s.tz * (along + h) + s.rz * across];
  const a = [s.x + s.tx * along + s.rx * (across + w), y, s.z + s.tz * along + s.rz * (across + w)];
  const b = [s.x + s.tx * along + s.rx * (across - w), y, s.z + s.tz * along + s.rz * (across - w)];
  geo.setAttribute("position", new THREE.Float32BufferAttribute([...tip, ...a, ...b], 3));
  geo.computeVertexNormals();
  const mesh = new THREE.Mesh(geo, mat);
  group.add(mesh);
}

function numberTex(n: number) {
  const c = document.createElement("canvas");
  c.width = 128;
  c.height = 128;
  const g = c.getContext("2d");
  if (!g) return new THREE.CanvasTexture(c);
  g.fillStyle = "#f4efe6";
  g.fillRect(0, 0, 128, 128);
  g.strokeStyle = "#1c1915";
  g.lineWidth = 8;
  g.strokeRect(7, 7, 114, 114);
  g.fillStyle = "#e2b43a";
  g.fillRect(7, 7, 114, 16);
  g.fillStyle = "#1c1915";
  g.font = "700 68px Arial, sans-serif";
  g.textAlign = "center";
  g.textBaseline = "middle";
  g.fillText(String(n), 64, 74);
  const t = new THREE.CanvasTexture(c);
  t.colorSpace = THREE.SRGBColorSpace;
  return t;
}

function bannerTex(title: string, sub: string) {
  const c = document.createElement("canvas");
  c.width = 1024;
  c.height = 256;
  const g = c.getContext("2d");
  if (!g) return new THREE.CanvasTexture(c);
  g.fillStyle = "#16130f";
  g.fillRect(0, 0, 1024, 256);
  g.fillStyle = "#e23d2b";
  g.fillRect(0, 0, 1024, 12);
  g.fillRect(0, 244, 1024, 12);
  g.fillStyle = "#f4efe6";
  g.font = "800 108px Arial, sans-serif";
  g.textAlign = "center";
  g.textBaseline = "middle";
  g.fillText(title, 512, 104);
  g.font = "500 36px Arial, sans-serif";
  g.fillStyle = "#e7c27a";
  g.fillText(sub, 512, 186);
  const t = new THREE.CanvasTexture(c);
  t.colorSpace = THREE.SRGBColorSpace;
  return t;
}

function addProps(
  group: THREE.Group,
  samples: Sample[],
  corners: Corner[],
  startDist: number,
  length: number,
  heightAt: (x: number, z: number) => number,
) {
  const start = sampleAt(samples, startDist);
  const concrete = lambert(COL.concrete);
  const ink = lambert(COL.ink);
  const cream = lambert(COL.cream);
  const gravel = lambert(COL.gravel);

  for (const sign of [-1, 1]) {
    const lat = sign * (start.halfW + 6);
    const pad = new THREE.Mesh(new THREE.BoxGeometry(16, 0.08, 28), gravel);
    pad.position.set(
      start.x + start.rx * lat - start.tx * 8,
      start.y + 0.02,
      start.z + start.rz * lat - start.tz * 8,
    );
    pad.rotation.y = start.heading;
    pad.receiveShadow = true;
    group.add(pad);
  }

  const towerX = start.x - start.rx * 18 - start.tx * 6;
  const towerZ = start.z - start.rz * 18 - start.tz * 6;
  const towerY = heightAt(towerX, towerZ);
  const leg = new THREE.BoxGeometry(0.28, 11, 0.28);
  for (const [ox, oz] of [[-1.3, -1.3], [1.3, -1.3], [-1.3, 1.3], [1.3, 1.3]] as const) {
    const m = new THREE.Mesh(leg, concrete);
    m.position.set(towerX + ox, towerY + 5.5, towerZ + oz);
    m.castShadow = true;
    group.add(m);
  }
  const tank = new THREE.Mesh(new THREE.CylinderGeometry(2.4, 2.4, 3.2, 8), concrete);
  tank.position.set(towerX, towerY + 12.2, towerZ);
  tank.castShadow = true;
  group.add(tank);
  const cap = new THREE.Mesh(new THREE.CylinderGeometry(2.6, 2.4, 0.35, 8), ink);
  cap.position.set(towerX, towerY + 13.9, towerZ);
  group.add(cap);
  const house = new THREE.Mesh(new THREE.BoxGeometry(4.2, 2.4, 3.2), concrete);
  house.position.set(towerX + 5.5, towerY + 1.2, towerZ);
  house.castShadow = true;
  group.add(house);

  gantry(group, start, bannerTex("AKINA", "DOWNHILL  ·  START"), 5.4);

  const colors = ["#f4f1ea", "#c44536", "#2f5f9a", "#1c1c1c", "#d7d2c8"];
  colors.forEach((color, i) => {
    const side = i < 3 ? -1 : 1;
    const along = -12 - (i % 3) * 6.5;
    const lat = side * (start.halfW + 5.5);
    const s = sampleAt(samples, startDist + along);
    parkCar(
      group,
      s.x + s.rx * lat,
      s.y + 0.02,
      s.z + s.rz * lat,
      s.heading + (i % 2 ? 0.15 : -0.1),
      color,
    );
  });

  const goal = sampleAt(samples, startDist + length - 18);
  gantry(group, goal, bannerTex("GOAL", "IKAHO  ·  7.1 KM"), 5.1);
  const finish = new THREE.Mesh(
    new THREE.BoxGeometry(goal.halfW * 2.1, 0.04, 0.45),
    cream,
  );
  finish.position.set(goal.x, goal.y + 0.08, goal.z);
  finish.rotation.y = goal.heading;
  group.add(finish);

  const takane = corners.find((c) => c.fromStart > 1650 && c.fromStart < 2300) ?? corners[4];
  if (takane) {
    const s = sampleAt(samples, takane.dist);
    const toX = 820 - s.x;
    const toZ = 1800 - s.z;
    const side = Math.sign(toX * s.rx + toZ * s.rz) || 1;
    const lat = side * (s.halfW + 7);
    const x = s.x + s.rx * lat;
    const z = s.z + s.rz * lat;
    const y = s.y + 0.35;
    const deck = new THREE.Mesh(new THREE.BoxGeometry(8.5, 0.18, 5.5), concrete);
    deck.position.set(x, y, z);
    deck.rotation.y = s.heading;
    deck.receiveShadow = true;
    group.add(deck);
    for (const [ox, oz] of [[-3.6, -2.2], [3.6, -2.2], [-3.6, 2.2], [3.6, 2.2]] as const) {
      const p = new THREE.Mesh(new THREE.BoxGeometry(0.16, 2.5, 0.16), ink);
      const wx = x + s.rx * ox + s.tx * oz;
      const wz = z + s.rz * ox + s.tz * oz;
      p.position.set(wx, y + 1.25, wz);
      group.add(p);
    }
    const roof = new THREE.Mesh(new THREE.BoxGeometry(9.2, 0.16, 6.2), new THREE.MeshLambertMaterial({ color: COL.roofD, flatShading: true }));
    roof.position.set(x, y + 2.55, z);
    roof.rotation.y = s.heading;
    group.add(roof);
    const sign = new THREE.Mesh(
      new THREE.PlaneGeometry(2.4, 0.48),
      new THREE.MeshBasicMaterial({ map: bannerTex("TAKANE", "LOOKOUT"), side: THREE.DoubleSide }),
    );
    sign.position.set(x, y + 2.1, z);
    sign.lookAt(s.x, y + 2.1, s.z);
    group.add(sign);
  }

  const shrine = sampleAt(samples, startDist + 2480);
  const sx = shrine.x - shrine.rx * (shrine.halfW + 8);
  const sz = shrine.z - shrine.rz * (shrine.halfW + 8);
  const sy = heightAt(sx, sz);
  torii(group, sx, sy, sz, shrine.heading);
  const hokora = new THREE.Mesh(new THREE.BoxGeometry(1.6, 1.5, 1.3), cream);
  hokora.position.set(sx - shrine.rx * 2.2, sy + 0.75, sz - shrine.rz * 2.2);
  group.add(hokora);
  const hRoof = new THREE.Mesh(new THREE.BoxGeometry(2.1, 0.16, 1.7), new THREE.MeshLambertMaterial({ color: COL.roof, flatShading: true }));
  hRoof.position.set(sx - shrine.rx * 2.2, sy + 1.6, sz - shrine.rz * 2.2);
  group.add(hRoof);
}

function gantry(group: THREE.Group, s: Sample, tex: THREE.Texture, y: number) {
  const span = s.halfW + 1.4;
  const ink = lambert(COL.ink);
  for (const sign of [-1, 1]) {
    const post = new THREE.Mesh(new THREE.BoxGeometry(0.18, y + 0.4, 0.18), ink);
    post.position.set(s.x + s.rx * sign * span, s.y + y / 2, s.z + s.rz * sign * span);
    post.castShadow = true;
    group.add(post);
  }
  const beam = new THREE.Mesh(new THREE.BoxGeometry(span * 2 + 0.4, 0.16, 0.16), ink);
  beam.position.set(s.x, s.y + y, s.z);
  beam.rotation.y = s.heading;
  group.add(beam);
  const banner = new THREE.Mesh(
    new THREE.PlaneGeometry(span * 1.7, 1.28),
    new THREE.MeshBasicMaterial({ map: tex, side: THREE.DoubleSide }),
  );
  banner.position.set(s.x, s.y + y - 0.85, s.z);
  banner.lookAt(s.x - s.tx * 6, s.y + y - 0.85, s.z - s.tz * 6);
  group.add(banner);
}

function parkCar(group: THREE.Group, x: number, y: number, z: number, heading: number, color: string) {
  const g = new THREE.Group();
  const paint = new THREE.MeshLambertMaterial({ color, flatShading: true });
  const black = lambert("#1b1d20");
  const body = new THREE.Mesh(new THREE.BoxGeometry(1.55, 0.48, 3.3), paint);
  body.position.y = 0.55;
  g.add(body);
  const cab = new THREE.Mesh(new THREE.BoxGeometry(1.35, 0.38, 1.4), black);
  cab.position.set(0, 0.95, -0.15);
  g.add(cab);
  g.position.set(x, y, z);
  g.rotation.y = heading;
  group.add(g);
}

function torii(group: THREE.Group, x: number, y: number, z: number, heading: number) {
  const mat = new THREE.MeshLambertMaterial({ color: COL.torii, flatShading: true });
  const g = new THREE.Group();
  for (const ox of [-1.15, 1.15]) {
    const p = new THREE.Mesh(new THREE.BoxGeometry(0.18, 2.7, 0.18), mat);
    p.position.set(ox, 1.35, 0);
    g.add(p);
  }
  const top = new THREE.Mesh(new THREE.BoxGeometry(3.1, 0.18, 0.28), mat);
  top.position.y = 2.55;
  g.add(top);
  const kasagi = new THREE.Mesh(new THREE.BoxGeometry(3.4, 0.12, 0.42), mat);
  kasagi.position.y = 2.72;
  g.add(kasagi);
  const nuki = new THREE.Mesh(new THREE.BoxGeometry(2.5, 0.12, 0.16), mat);
  nuki.position.y = 2.05;
  g.add(nuki);
  g.position.set(x, y, z);
  g.rotation.y = heading;
  group.add(g);
}

function addForest(
  group: THREE.Group,
  samples: Sample[],
  heightAt: (x: number, z: number) => number,
  nearest: (x: number, z: number) => { i: number; d: number },
) {
  const cedarGeo = treeGeo("cedar");
  const cedarWide = treeGeo("cedarWide");
  const autumnGeo = treeGeo("autumn");
  const sakuraGeo = treeGeo("sakura");
  const bushGeo = treeGeo("bush");
  const treeMat = lambert("#ffffff", { vertex: true });

  const cedar: THREE.Matrix4[] = [];
  const cedarC: THREE.Color[] = [];
  const wide: THREE.Matrix4[] = [];
  const wideC: THREE.Color[] = [];
  const autumn: THREE.Matrix4[] = [];
  const autumnC: THREE.Color[] = [];
  const sakura: THREE.Matrix4[] = [];
  const sakuraC: THREE.Color[] = [];
  const bush: THREE.Matrix4[] = [];
  const bushC: THREE.Color[] = [];
  const q = new THREE.Quaternion();
  const up = new THREE.Vector3(0, 1, 0);

  const push = (
    list: THREE.Matrix4[],
    cols: THREE.Color[],
    x: number,
    y: number,
    z: number,
    h: number,
    r: number,
    color: THREE.Color,
    yaw: number,
  ) => {
    q.setFromAxisAngle(up, yaw);
    list.push(new THREE.Matrix4().compose(new THREE.Vector3(x, y, z), q, new THREE.Vector3(r, h, r)));
    cols.push(color);
  };

  for (let i = 0; i < samples.length; i += 2) {
    const s = samples[i];
    if (s.fromStart < -30) continue;
    const stack = s.fromStart > 5000 && s.fromStart < 6000;
    const tries = stack ? 4 : 8;
    for (let k = 0; k < tries; k++) {
      const side = hash(i, k) < 0.5 ? -1 : 1;
      const lat = side * (10.5 + hash(i, k + 3) * (stack ? 18 : 32));
      const along = (hash(i, k + 5) - 0.5) * 9;
      const x = s.x + s.rx * lat + s.tx * along;
      const z = s.z + s.rz * lat + s.tz * along;
      if (nearest(x, z).d < 9.2) continue;
      if (lakeMask(x, z) > 0.15) continue;
      if (x > 1480 && z > 1880 && x < 2400) continue;
      const y = heightAt(x, z);
      const n = hash(i, k + 9);
      const yaw = hash(i, k + 1) * Math.PI * 2;
      const shade = new THREE.Color().setScalar(0.9 + hash(i, k + 8) * 0.18);
      if (stack && n > 0.72) continue;
      if (n < 0.42) {
        const sH = 12 + hash(i, k) * 6;
        push(cedar, cedarC, x, y, z, sH, sH * 0.34, shade, yaw);
      } else if (n < 0.62) {
        const sH = 9 + hash(i, k) * 4;
        push(wide, wideC, x, y, z, sH, sH * 0.42, shade, yaw);
      } else if (n < 0.86) {
        const sH = 7 + hash(i, k) * 3.5;
        push(autumn, autumnC, x, y, z, sH, sH * 0.72, shade, yaw);
      } else if (n < 0.94) {
        push(sakura, sakuraC, x, y, z, 6.5, 5.2, shade, yaw);
      } else {
        const sH = 8 + hash(i, k) * 3;
        push(wide, wideC, x, y, z, sH, sH * 0.4, shade, yaw);
      }
    }
    if (hash(i, 20) > 0.35) {
      const side = hash(i, 21) < 0.5 ? -1 : 1;
      const lat = side * (9.4 + hash(i, 22) * 2.2);
      const x = s.x + s.rx * lat;
      const z = s.z + s.rz * lat;
      if (nearest(x, z).d > 8.4) {
        push(bush, bushC, x, heightAt(x, z), z, 1.1 + hash(i, 23) * 0.5, 1, new THREE.Color().setScalar(0.95), hash(i, 24) * 6);
      }
    }
  }

  for (let i = 0; i < 220; i++) {
    const a = (i / 220) * Math.PI * 2;
    const e = 0.86 + hash(i, 2) * 0.18;
    const x = LAKE.x + Math.cos(a) * 760 * e;
    const z = LAKE.z + Math.sin(a) * 500 * e;
    if (nearest(x, z).d < 8) continue;
    const y = heightAt(x, z);
    const shade = new THREE.Color().setScalar(0.94 + hash(i, 6) * 0.1);
    if (hash(i, 3) > 0.45) {
      push(sakura, sakuraC, x, y, z, 6 + hash(i, 4) * 2, 1.1, shade, a);
    } else {
      push(cedar, cedarC, x, y, z, 10 + hash(i, 5) * 3, 1, shade, a);
    }
  }

  const addInst = (
    geo: THREE.BufferGeometry,
    list: THREE.Matrix4[],
    cols: THREE.Color[],
    mat: THREE.Material = treeMat,
  ) => {
    if (!list.length) return;
    const mesh = new THREE.InstancedMesh(geo, mat, list.length);
    list.forEach((m, i) => mesh.setMatrixAt(i, m));
    const arr = new Float32Array(list.length * 3);
    cols.forEach((c, i) => {
      arr[i * 3] = c.r;
      arr[i * 3 + 1] = c.g;
      arr[i * 3 + 2] = c.b;
    });
    mesh.instanceColor = new THREE.InstancedBufferAttribute(arr, 3);
    mesh.receiveShadow = true;
    group.add(mesh);
  };
  addInst(cedarGeo, cedar, cedarC);
  addInst(cedarWide, wide, wideC);
  addInst(autumnGeo, autumn, autumnC);
  addInst(sakuraGeo, sakura, sakuraC);
  addInst(bushGeo, bush, bushC);
  addRocks(group, samples, heightAt, nearest, push);
}

function bare(g: THREE.BufferGeometry) {
  return g.index ? g.toNonIndexed() : g;
}

function treeGeo(kind: "cedar" | "cedarWide" | "autumn" | "sakura" | "bush") {
  const trunk = paint(bare(new THREE.CylinderGeometry(0.035, 0.055, 0.16, 6)), new THREE.Color("#8a6848"));
  trunk.translate(0, 0.08, 0);
  if (kind === "bush") {
    const a = paint(bare(new THREE.ConeGeometry(0.42, 0.46, 6)), new THREE.Color("#3d7a48"), new THREE.Color("#b7d48a"));
    a.translate(0, 0.28, 0);
    const b = paint(bare(new THREE.ConeGeometry(0.26, 0.32, 6)), new THREE.Color("#4e8d55"), new THREE.Color("#d5e7a4"));
    b.translate(0, 0.52, 0);
    return mergeGeometries([a, b]) ?? a;
  }
  if (kind === "sakura") {
    const parts = [trunk];
    const spots: [number, number, number, number][] = [
      [0, 0.42, 0, 0.34],
      [-0.16, 0.5, 0.08, 0.22],
      [0.16, 0.48, -0.06, 0.2],
      [0, 0.66, 0, 0.16],
    ];
    for (const [x, y, z, r] of spots) {
      const blob = paint(
        bare(new THREE.IcosahedronGeometry(r, 0)),
        new THREE.Color("#e58aaa"),
        new THREE.Color("#fff0f4"),
      );
      blob.scale(1, 0.72, 1);
      blob.translate(x, y, z);
      parts.push(blob);
    }
    return mergeGeometries(parts) ?? trunk;
  }
  if (kind === "autumn") return leafTree();
  return pineTree(kind === "cedarWide");
}

function pineTree(wide: boolean) {
  const trunk = paint(bare(new THREE.CylinderGeometry(0.055, 0.075, 0.22, 6)), new THREE.Color("#8a552e"));
  trunk.translate(0, 0.11, 0);
  const layers: [number, number, number][] = wide
    ? [
        [0.42, 0.3, 0.26],
        [0.34, 0.26, 0.4],
        [0.26, 0.24, 0.54],
        [0.18, 0.2, 0.68],
        [0.1, 0.16, 0.82],
      ]
    : [
        [0.32, 0.24, 0.24],
        [0.27, 0.22, 0.36],
        [0.22, 0.2, 0.48],
        [0.17, 0.18, 0.6],
        [0.12, 0.16, 0.72],
        [0.07, 0.14, 0.84],
        [0.035, 0.12, 0.94],
      ];
  const parts = [trunk];
  const base = new THREE.Color(wide ? "#1e8f48" : "#167a3c");
  const tip = new THREE.Color(wide ? "#6ee08a" : "#4ecf72");
  for (const [radius, height, y] of layers) {
    const cone = paint(bare(new THREE.ConeGeometry(radius, height, 5)), base, tip);
    cone.translate(0, y, 0);
    parts.push(cone);
  }
  return mergeGeometries(parts) ?? trunk;
}

function leafTree() {
  const trunk = paint(bare(new THREE.CylinderGeometry(0.07, 0.09, 0.36, 6)), new THREE.Color("#8a552e"));
  trunk.translate(0, 0.18, 0);
  const canopy = paint(bare(new THREE.IcosahedronGeometry(0.4, 0)), new THREE.Color("#2eae4c"), new THREE.Color("#8ae88a"));
  canopy.translate(0, 0.58, 0);
  const side = paint(bare(new THREE.IcosahedronGeometry(0.24, 0)), new THREE.Color("#249a42"), new THREE.Color("#b6f09a"));
  side.translate(0.16, 0.5, 0.08);
  return mergeGeometries([trunk, canopy, side]) ?? canopy;
}

function paint(geo: THREE.BufferGeometry, base: THREE.Color, tip?: THREE.Color) {
  const pos = geo.attributes.position;
  const cols = new Float32Array(pos.count * 3);
  const c = new THREE.Color();
  let minY = Infinity;
  let maxY = -Infinity;
  for (let i = 0; i < pos.count; i++) {
    const y = pos.getY(i);
    minY = Math.min(minY, y);
    maxY = Math.max(maxY, y);
  }
  for (let i = 0; i < pos.count; i++) {
    const t = tip ? (pos.getY(i) - minY) / (maxY - minY || 1) : 0;
    c.copy(base);
    if (tip) c.lerp(tip, t * t);
    cols[i * 3] = c.r;
    cols[i * 3 + 1] = c.g;
    cols[i * 3 + 2] = c.b;
  }
  geo.setAttribute("color", new THREE.BufferAttribute(cols, 3));
  return geo;
}

function addRocks(
  group: THREE.Group,
  samples: Sample[],
  heightAt: (x: number, z: number) => number,
  nearest: (x: number, z: number) => { i: number; d: number },
  push: (
    list: THREE.Matrix4[],
    cols: THREE.Color[],
    x: number,
    y: number,
    z: number,
    h: number,
    r: number,
    color: THREE.Color,
    yaw: number,
  ) => void,
) {
  const rocks: THREE.Matrix4[] = [];
  const cols: THREE.Color[] = [];
  const shade = new THREE.Color("#ffffff");
  for (let i = 12; i < samples.length; i += 18) {
    const s = samples[i];
    if (Math.abs(s.curv) < 0.035) continue;
    const side = s.curv >= 0 ? 1 : -1;
    for (let k = 0; k < 2; k++) {
      const lat = side * (s.halfW + 2.8 + k * 1.7);
      const along = (k - 0.5) * 2.2;
      const x = s.x + s.rx * lat + s.tx * along;
      const z = s.z + s.rz * lat + s.tz * along;
      if (nearest(x, z).d < 7.2) continue;
      const sc = k === 0 ? 0.85 : 0.55;
      const ground = heightAt(x, z);
      push(rocks, cols, x, ground + 0.16 * sc, z, sc * 0.62, sc, shade, s.heading + k * 0.4);
    }
  }
  addRockMesh(group, rocks, cols);
}

function addRockMesh(group: THREE.Group, list: THREE.Matrix4[], cols: THREE.Color[]) {
  if (!list.length) return;
  const geo = neatRock();
  const mesh = new THREE.InstancedMesh(geo, lambert("#ffffff", { vertex: true }), list.length);
  list.forEach((m, i) => mesh.setMatrixAt(i, m));
  const arr = new Float32Array(list.length * 3);
  cols.forEach((c, i) => {
    arr[i * 3] = c.r;
    arr[i * 3 + 1] = c.g;
    arr[i * 3 + 2] = c.b;
  });
  mesh.instanceColor = new THREE.InstancedBufferAttribute(arr, 3);
  mesh.receiveShadow = true;
  group.add(mesh);
}

function neatRock() {
  const geo = bare(new THREE.CylinderGeometry(0.72, 1, 0.7, 6));
  const pos = geo.attributes.position;
  for (let i = 0; i < pos.count; i++) {
    const y = pos.getY(i);
    pos.setY(i, y < 0 ? -0.28 : y * 0.85);
    pos.setX(i, pos.getX(i) * 1.08);
    pos.setZ(i, pos.getZ(i) * 0.92);
  }
  geo.computeVertexNormals();
  return paint(geo, new THREE.Color("#8d7d6c"), new THREE.Color("#e4d8c8"));
}

function addLake(group: THREE.Group) {
  const water = new THREE.Mesh(
    new THREE.CircleGeometry(1, 7),
    new THREE.MeshLambertMaterial({ color: COL.water, flatShading: true }),
  );
  water.scale.set(760, 500, 1);
  water.rotation.x = -Math.PI / 2;
  water.position.set(LAKE.x, LAKE.y + 0.4, LAKE.z);
  group.add(water);
  const shore = new THREE.Mesh(
    new THREE.RingGeometry(0.98, 1.08, 7),
    new THREE.MeshLambertMaterial({ color: COL.sand, flatShading: true, side: THREE.DoubleSide }),
  );
  shore.scale.set(760, 500, 1);
  shore.rotation.x = -Math.PI / 2;
  shore.position.set(LAKE.x, LAKE.y + 0.2, LAKE.z);
  group.add(shore);
  const pier = new THREE.Mesh(
    new THREE.BoxGeometry(2.2, 0.16, 14),
    lambert(COL.concrete),
  );
  pier.position.set(LAKE.x + 420, LAKE.y + 0.7, LAKE.z + 40);
  group.add(pier);
  const boat = new THREE.Mesh(new THREE.BoxGeometry(1.4, 0.28, 3.2), lambert("#f4efe6"));
  boat.position.set(LAKE.x + 250, LAKE.y + 0.7, LAKE.z - 80);
  boat.rotation.y = 0.4;
  group.add(boat);
  const boat2 = new THREE.Mesh(new THREE.BoxGeometry(1.1, 0.24, 2.6), lambert("#c45c3e"));
  boat2.position.set(LAKE.x - 180, LAKE.y + 0.7, LAKE.z + 120);
  boat2.rotation.y = -0.8;
  group.add(boat2);
}

function addPeaks(group: THREE.Group) {
  const make = (
    x: number,
    z: number,
    base: number,
    height: number,
    radius: number,
    sides: number,
    top: THREE.Color,
    bottom: THREE.Color,
  ) => {
    const geo = new THREE.ConeGeometry(radius, height, sides);
    geo.translate(0, height / 2, 0);
    const pos = geo.attributes.position;
    const cols = new Float32Array(pos.count * 3);
    const c = new THREE.Color();
    for (let i = 0; i < pos.count; i++) {
      const t = pos.getY(i) / height;
      c.copy(bottom).lerp(top, Math.min(1, t * 1.15));
      cols[i * 3] = c.r;
      cols[i * 3 + 1] = c.g;
      cols[i * 3 + 2] = c.b;
    }
    geo.setAttribute("color", new THREE.BufferAttribute(cols, 3));
    const mesh = new THREE.Mesh(
      geo,
      new THREE.MeshLambertMaterial({ vertexColors: true, flatShading: true }),
    );
    mesh.position.set(x, base, z);
    group.add(mesh);
    return mesh;
  };
  make(-2480, -1320, -50, 300, 460, 9, new THREE.Color("#d9cfc2"), new THREE.Color("#6f8f62"));
  make(-1680, -2100, -30, 340, 620, 8, new THREE.Color("#c9bfb2"), new THREE.Color("#7ea06a"));
  make(-3100, -80, -20, 180, 700, 8, new THREE.Color("#b7c6d4"), new THREE.Color("#6f8f62"));
  make(3900, 640, -220, 680, 1500, 8, new THREE.Color("#c5d4e2"), new THREE.Color("#8aa4b8"));
  make(2100, -900, -80, 260, 540, 8, new THREE.Color("#d4cbbf"), new THREE.Color("#7ea06a"));
}

function addTown(
  group: THREE.Group,
  samples: Sample[],
  length: number,
  startDist: number,
  windowMat: THREE.MeshStandardMaterial,
  lanternMat: THREE.MeshStandardMaterial,
  heightAt: (x: number, z: number) => number,
) {
  const goal = sampleAt(samples, startDist + length - 8);
  const baseY = goal.y - 2;
  const wall = lambert(COL.wall);
  const roof = lambert(COL.roof);
  const roofD = lambert(COL.roofD);
  const stone = lambert("#cbbba6");

  for (let i = 0; i < 40; i++) {
    const t = i / 39;
    const x = goal.x + 70 + t * 210;
    const z = goal.z + 40 + t * 150;
    const y = baseY + t * 8;
    const step = new THREE.Mesh(new THREE.BoxGeometry(5.4, 0.22, 1.35), stone);
    step.position.set(x, y, z);
    step.rotation.y = Math.atan2(150, 210);
    step.receiveShadow = true;
    group.add(step);
    if (i % 4 === 0) {
      const side = i % 8 === 0 ? -1 : 1;
      const bx = x + side * 6.5;
      const bz = z + side * 2;
      const h = 3.2 + hash(i, 1) * 2.2;
      const b = new THREE.Mesh(new THREE.BoxGeometry(4.2, h, 3.6), wall);
      b.position.set(bx, y + h / 2, bz);
      b.castShadow = true;
      group.add(b);
      const rf = new THREE.Mesh(new THREE.BoxGeometry(4.8, 0.28, 4.2), i % 8 === 0 ? roof : roofD);
      rf.position.set(bx, y + h + 0.1, bz);
      group.add(rf);
      const win = new THREE.Mesh(new THREE.PlaneGeometry(0.7, 0.9), windowMat);
      win.position.set(bx - side * 2.12, y + h * 0.55, bz);
      win.lookAt(bx - side * 4, y + h * 0.55, bz);
      group.add(win);
      const lantern = new THREE.Mesh(new THREE.SphereGeometry(0.18, 6, 5), lanternMat);
      lantern.position.set(bx - side * 2.3, y + 2.1, bz + 1.2);
      group.add(lantern);
    }
  }

  const plots = [
    [1750, 2140, 16, 8, 11],
    [1880, 2060, 10, 12, 7],
    [1620, 1980, 9, 8, 6],
    [1980, 2200, 12, 9, 8],
    [1540, 2140, 8, 7, 5],
    [2100, 2080, 11, 10, 9],
    [1760, 2280, 14, 8, 6],
    [1920, 2320, 8, 8, 10],
  ];
  for (const [x, z, w, d, h] of plots) {
    const y = heightAt(x, z);
    const b = new THREE.Mesh(new THREE.BoxGeometry(w, h, d), wall);
    b.position.set(x, y + h / 2, z);
    b.castShadow = true;
    b.receiveShadow = true;
    group.add(b);
    const rf = new THREE.Mesh(new THREE.BoxGeometry(w + 0.8, 0.4, d + 0.8), hash(x, z) > 0.5 ? roof : roofD);
    rf.position.set(x, y + h + 0.15, z);
    group.add(rf);
    for (let k = 0; k < 3; k++) {
      const win = new THREE.Mesh(new THREE.PlaneGeometry(0.8, 1.05), windowMat);
      win.position.set(x - w / 2 - 0.02, y + 1.6 + k * 0.05, z - d / 3 + k * (d / 3));
      win.rotation.y = -Math.PI / 2;
      group.add(win);
    }
  }

  torii(group, goal.x + 48, baseY, goal.z + 18, 0.6);

  for (let i = 0; i < 5; i++) {
    const puff = new THREE.Mesh(
      new THREE.IcosahedronGeometry(1.1 + hash(i, 1), 0),
      new THREE.MeshLambertMaterial({ color: "#f7f3ee", flatShading: true }),
    );
    puff.position.set(1780 + i * 18, baseY + 8 + hash(i, 2) * 3, 2160 + (i % 2) * 10);
    puff.name = "steam";
    group.add(puff);
  }
}

function addClouds(group: THREE.Group) {
  const clouds = new THREE.Group();
  clouds.name = "clouds";
  const puff = new THREE.IcosahedronGeometry(1, 0);
  const mats = [
    new THREE.MeshLambertMaterial({ color: "#ffffff", flatShading: true }),
    new THREE.MeshLambertMaterial({ color: "#f3f7fb", flatShading: true }),
    new THREE.MeshLambertMaterial({ color: "#ffffff", flatShading: true }),
  ];
  const spots: [number, number, number, number][] = [
    [-600, 520, 200, 90],
    [200, 580, 700, 120],
    [900, 500, -200, 80],
    [1600, 640, 900, 140],
    [-1600, 560, 600, 100],
    [400, 700, 1600, 110],
    [-200, 480, 1400, 70],
    [2200, 540, 400, 95],
    [-2400, 620, -200, 130],
    [800, 760, 2200, 150],
  ];
  for (const [x, y, z, s] of spots) {
    const cluster = new THREE.Group();
    for (let i = 0; i < 3; i++) {
      const c = new THREE.Mesh(puff, mats[i]);
      c.scale.set(s * (0.55 + i * 0.22), s * 0.28, s * (0.48 + i * 0.12));
      c.position.set((i - 1) * s * 0.38, i * 8, (i % 2) * s * 0.2);
      cluster.add(c);
    }
    cluster.position.set(x, y, z);
    clouds.add(cluster);
  }
  group.add(clouds);
  return clouds;
}
