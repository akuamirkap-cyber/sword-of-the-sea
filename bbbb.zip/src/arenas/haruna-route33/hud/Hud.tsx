import { useEffect, useRef, useSyncExternalStore } from "react";
import { live, subscribe, touch, ui } from "../world/live";

function formatTime(t: number) {
  if (!t || t < 0) return "0:00.0";
  const m = Math.floor(t / 60);
  const s = t - m * 60;
  return `${m}:${s.toFixed(1).padStart(4, "0")}`;
}

export default function Hud({ onExit }: { onExit: () => void }) {
  const snap = useSyncExternalStore(subscribe, () => live.tick);
  void snap;
  const mapRef = useRef<HTMLCanvasElement>(null);

  useEffect(() => {
    let frame = 0;
    const draw = () => {
      const canvas = mapRef.current;
      if (canvas) paintMap(canvas);
      frame = requestAnimationFrame(draw);
    };
    frame = requestAnimationFrame(draw);
    return () => cancelAnimationFrame(frame);
  }, []);

  const phase = live.phase;
  const showDrive = phase === "drive" || phase === "drone" || phase === "finish";

  return (
    <div className={`hud ${live.night ? "is-night" : ""}`}>
      <div className="vignette" />

      <header className="brand">
        <span className="brand-kicker">Gunma · Route 33</span>
        <strong>HARUNA</strong>
        <em>Touge Drift</em>
      </header>

      <div className="top-actions">
        {showDrive && (
          <>
            <button type="button" onClick={ui.toggleNight}>
              {live.night ? "Siang" : "Malam"}
            </button>
            <button type="button" onClick={ui.cycleCam}>
              {live.cam}
            </button>
            <button type="button" onClick={ui.toggleMute}>
              {live.muted ? "Suara" : "Senyap"}
            </button>
            <button type="button" onClick={ui.reset}>
              Ulang
            </button>
          </>
        )}
        <button type="button" onClick={onExit}>
          Menu
        </button>
      </div>

      {phase === "loading" && (
        <section className="intro">
          <span className="brand-kicker">Menyusun peta</span>
          <h1>
            HARUNA
            <span>TOUGE</span>
          </h1>
          <p>Jalan gunung sedang dipahat — menara air, lima hairpin, sampai Ikaho.</p>
        </section>
      )}

      {phase === "intro" && (
        <section className="intro">
          <span className="brand-kicker">秋名 · Mount Haruna</span>
          <h1>
            HARUNA
            <span>TOUGE</span>
          </h1>
          <p>
            Rekonstruksi low-poly turunan Akina dari bentuk asli Prefektur Route 33.
            Menara air Yaseone, observatorium Takane, lima hairpin, selokan tikungan,
            sampai parkir gol Ikaho.
          </p>
          <ul className="facts">
            <li>
              <b>7,1 km</b>
              <span>turunan</span>
            </li>
            <li>
              <b>−420 m</b>
              <span>elevasi</span>
            </li>
            <li>
              <b>30</b>
              <span>tikungan</span>
            </li>
          </ul>
          <div className="intro-actions">
            <button type="button" className="primary" onClick={ui.startDrive}>
              Masuk ke mobil
            </button>
            <button type="button" onClick={ui.startDrone}>
              Terbang di atas peta
            </button>
            <button type="button" onClick={onExit}>
              Menu Arena
            </button>
          </div>
          <p className="keys">
            W gas · A/D tahan untuk drift · lepas untuk lurus · Spasi kick
            <br />
            C kamera · N malam · F terbang · R ulang · M senyap
          </p>
        </section>
      )}

      {showDrive && (
        <>
          <div className="section">
            <span>{live.sectionJp}</span>
            <strong>{live.section}</strong>
          </div>

          {live.corner && (
            <div className="callout">
              <b>{live.corner}</b>
              <span>{live.cornerSub}</span>
            </div>
          )}

          <div className="speed">
            <b>{Math.round(live.speed)}</b>
            <span>km/j</span>
            <div className="gear">
              <i className={live.gear === 0 ? "on" : ""}>R</i>
              {[1, 2, 3, 4, 5].map((g) => (
                <i key={g} className={live.gear === g ? "on" : ""}>
                  {g}
                </i>
              ))}
            </div>
            <div className="drift">
              <em style={{ width: `${Math.round(live.drift * 100)}%` }} />
            </div>
            <small>{live.drift > 0.42 ? "DRIFT" : "grip"}</small>
          </div>

          <div className="map-card">
            <canvas ref={mapRef} width={220} height={260} />
            <div className="map-meta">
              <span>{live.gap >= 0 ? `FD +${Math.round(live.gap)} m` : `FD ${Math.round(live.gap)} m`}</span>
              <span>{formatTime(live.time)}</span>
            </div>
          </div>

          <div className="progress" aria-hidden>
            <i style={{ width: `${live.progress * 100}%` }} />
          </div>

          {phase === "drone" && (
            <div className="drone-hint">
              <b>Terbang</b>
              <span>WASD gerak · seret untuk melihat · Shift cepat · Spasi naik · Ctrl turun</span>
              <button type="button" onClick={ui.backToCar}>
                Kembali ke mobil
              </button>
            </div>
          )}

          {live.finished !== null && phase !== "drone" && (
            <div className="finish">
              <span>Turunan selesai</span>
              <b>{formatTime(live.finished)}</b>
              <small>{live.best ? `rekor ${formatTime(live.best)}` : "tekan R untuk ulang"}</small>
            </div>
          )}
        </>
      )}

      <div className="touch">
        <div
          className="steer-pad"
          onPointerDown={(e) => steerFrom(e)}
          onPointerMove={(e) => {
            if (e.buttons) steerFrom(e);
          }}
          onPointerUp={() => {
            touch.steer = 0;
          }}
          onPointerLeave={() => {
            touch.steer = 0;
          }}
        />
        <div className="pedals">
          <button
            type="button"
            onPointerDown={() => {
              touch.handbrake = true;
            }}
            onPointerUp={() => {
              touch.handbrake = false;
            }}
            onPointerLeave={() => {
              touch.handbrake = false;
            }}
          >
            HB
          </button>
          <button
            type="button"
            className="gas"
            onPointerDown={() => {
              touch.throttle = 1;
            }}
            onPointerUp={() => {
              touch.throttle = 0;
            }}
            onPointerLeave={() => {
              touch.throttle = 0;
            }}
          >
            GAS
          </button>
          <button
            type="button"
            onPointerDown={() => {
              touch.brake = 1;
            }}
            onPointerUp={() => {
              touch.brake = 0;
            }}
            onPointerLeave={() => {
              touch.brake = 0;
            }}
          >
            REM
          </button>
        </div>
      </div>
    </div>
  );
}

function steerFrom(e: React.PointerEvent<HTMLDivElement>) {
  const rect = e.currentTarget.getBoundingClientRect();
  const x = (e.clientX - rect.left) / rect.width;
  touch.steer = Math.max(-1, Math.min(1, (x - 0.5) * 2));
}

function paintMap(canvas: HTMLCanvasElement) {
  const ctx = canvas.getContext("2d");
  if (!ctx || live.path.length < 2) return;
  const w = canvas.width;
  const h = canvas.height;
  ctx.clearRect(0, 0, w, h);
  let minX = Infinity;
  let maxX = -Infinity;
  let minZ = Infinity;
  let maxZ = -Infinity;
  for (const p of live.path) {
    minX = Math.min(minX, p.x);
    maxX = Math.max(maxX, p.x);
    minZ = Math.min(minZ, p.z);
    maxZ = Math.max(maxZ, p.z);
  }
  const pad = 16;
  const sx = (maxX - minX) || 1;
  const sz = (maxZ - minZ) || 1;
  const scale = Math.min((w - pad * 2) / sx, (h - pad * 2) / sz);
  const ox = (w - sx * scale) / 2;
  const oy = (h - sz * scale) / 2;
  const px = (x: number) => ox + (x - minX) * scale;
  const py = (z: number) => oy + (maxZ - z) * scale;

  ctx.strokeStyle = "rgba(244,239,230,0.28)";
  ctx.lineWidth = 5;
  ctx.lineJoin = "round";
  ctx.beginPath();
  live.path.forEach((p, i) => {
    const x = px(p.x);
    const y = py(p.z);
    if (i === 0) ctx.moveTo(x, y);
    else ctx.lineTo(x, y);
  });
  ctx.stroke();

  ctx.strokeStyle = "#f4efe6";
  ctx.lineWidth = 1.6;
  ctx.stroke();

  if (live.hairpin.length) {
    ctx.strokeStyle = "#e23d2b";
    ctx.lineWidth = 2.4;
    ctx.beginPath();
    live.hairpin.forEach((p, i) => {
      const x = px(p.x);
      const y = py(p.z);
      if (i === 0) ctx.moveTo(x, y);
      else ctx.lineTo(x, y);
    });
    ctx.stroke();
  }

  const rx = px(live.rx);
  const ry = py(live.rz);
  ctx.fillStyle = "#f0c431";
  ctx.beginPath();
  ctx.arc(rx, ry, 3.2, 0, Math.PI * 2);
  ctx.fill();

  const cx = px(live.x);
  const cy = py(live.z);
  ctx.save();
  ctx.translate(cx, cy);
  ctx.rotate(live.heading);
  ctx.fillStyle = "#f4efe6";
  ctx.beginPath();
  ctx.moveTo(0, -6);
  ctx.lineTo(4, 5);
  ctx.lineTo(-4, 5);
  ctx.closePath();
  ctx.fill();
  ctx.restore();
}
