import { useEffect, useRef, useState } from 'react';
import * as THREE from 'three';

interface TrickDef {
  id: string;
  name: string;
  points: number;
  desc: string;
  color: string;
  badgeBg: string;
}

interface TrickProg {
  unlocked: boolean;
  count: number;
  totalScore: number;
  lastTriggeredAt: number;
}

const TRICKS: TrickDef[] = [
  {
    id: 'power_over',
    name: 'Power Over / Basic Drift',
    points: 250,
    desc: 'Drift stabil saat menikung kecepatan tinggi',
    color: 'text-cyan-300',
    badgeBg: 'from-cyan-500/90 to-blue-600/90',
  },
  {
    id: 'ebrake',
    name: 'E-Brake Drift (Handbrake)',
    points: 350,
    desc: 'Picu oversteer dengan Spasi sebelum/saat tikungan',
    color: 'text-amber-300',
    badgeBg: 'from-amber-500/90 to-orange-600/90',
  },
  {
    id: 'feint',
    name: 'Feint Drift (Scandinavian Flick)',
    points: 500,
    desc: 'Banting setir berlawanan arah (A↔D cepat) sebelum masuk drift',
    color: 'text-fuchsia-300',
    badgeBg: 'from-fuchsia-500/90 to-purple-600/90',
  },
  {
    id: 'manji',
    name: 'Manji Drift',
    points: 650,
    desc: 'Drift zig-zag kiri-kanan beruntun di jalan lurus',
    color: 'text-emerald-300',
    badgeBg: 'from-emerald-500/90 to-teal-600/90',
  },
  {
    id: 'spin360',
    name: '360° Entry / Spin Drift',
    points: 850,
    desc: 'Putar mobil 360° saat melaju lalu lanjutkan drift mulus',
    color: 'text-rose-300',
    badgeBg: 'from-rose-500/90 to-red-600/90',
  },
  {
    id: 'donut',
    name: 'Donut',
    points: 600,
    desc: 'Drift memutar penuh mengitari salah satu tiang arena',
    color: 'text-yellow-300',
    badgeBg: 'from-yellow-500/90 to-amber-600/90',
  },
  {
    id: 'figure8',
    name: 'Figure-8 (Angka 8)',
    points: 1500,
    desc: 'Dua lingkaran drift menyambung mengitari kedua tiang',
    color: 'text-indigo-300',
    badgeBg: 'from-indigo-500/90 to-violet-600/90',
  },
  {
    id: 'wall_tap',
    name: 'Near Miss / Wall Tap',
    points: 750,
    desc: 'Sapu tipis pembatas dinding dengan buritan tanpa menabrak',
    color: 'text-lime-300',
    badgeBg: 'from-lime-500/90 to-emerald-600/90',
  },
];

const ARENA = { minX: -140, maxX: 140, minZ: -110, maxZ: 110 };

const PILLARS = [
  { id: 'A' as const, x: -65, z: 32, radius: 1.6, color: 0xf59e0b },
  { id: 'B' as const, x: -23, z: 32, radius: 1.6, color: 0x06b6d4 },
];

const WALLS = [
  { x1: -140, z1: -110, x2: 140, z2: -110, isClippingZone: true },
  { x1: 140, z1: -110, x2: 140, z2: 110, isClippingZone: true },
  { x1: 140, z1: 110, x2: -140, z2: 110, isClippingZone: true },
  { x1: -140, z1: 110, x2: -140, z2: -110, isClippingZone: true },
  { x1: -95, z1: -56, x2: 75, z2: -56, isClippingZone: true },
  { x1: 75, z1: -56, x2: 75, z2: -28, isClippingZone: false },
  { x1: -95, z1: -56, x2: -95, z2: -28, isClippingZone: false },
  { x1: 55, z1: 12, x2: 102, z2: 12, isClippingZone: true },
  { x1: 55, z1: 12, x2: 55, z2: 65, isClippingZone: true },
  { x1: 95, z1: 55, x2: 140, z2: 55, isClippingZone: true },
];

const CAM_MODES = ['Chase', 'Wide Drift', 'Kap Mesin'] as const;

export default function DriftSimGame({ onExit }: { onExit: () => void }) {
  const mountRef = useRef<HTMLDivElement>(null);
  const minimapRef = useRef<HTMLCanvasElement>(null);
  const trickListRef = useRef<HTMLDivElement>(null);
  const popupRef = useRef<HTMLDivElement>(null);
  const recentLogRef = useRef<HTMLDivElement>(null);
  const startHintRef = useRef<HTMLDivElement>(null);

  const [camLabel, setCamLabel] = useState<string>('Chase');
  const [soundOn, setSoundOn] = useState(false);

  const apiRef = useRef<{
    resetCar: () => void;
    cycleCamera: () => void;
    toggleSound: () => boolean;
  } | null>(null);

  useEffect(() => {
    const container = mountRef.current;
    if (!container) return;

    const trickProgress: Record<string, TrickProg> = {};
    TRICKS.forEach((t) => {
      trickProgress[t.id] = { unlocked: false, count: 0, totalScore: 0, lastTriggeredAt: -999 };
    });

    const scene = new THREE.Scene();
    scene.background = new THREE.Color(0x0b101b);
    scene.fog = new THREE.FogExp2(0x0b101b, 0.0028);

    const camera = new THREE.PerspectiveCamera(62, window.innerWidth / window.innerHeight, 0.2, 650);
    const renderer = new THREE.WebGLRenderer({ antialias: true, powerPreference: 'high-performance' });
    renderer.setSize(window.innerWidth, window.innerHeight);
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    renderer.shadowMap.enabled = true;
    renderer.shadowMap.type = THREE.PCFSoftShadowMap;
    renderer.toneMapping = THREE.ACESFilmicToneMapping;
    renderer.toneMappingExposure = 1.1;
    container.appendChild(renderer.domElement);

    const hemiLight = new THREE.HemisphereLight(0x93c5fd, 0x1e293b, 0.85);
    scene.add(hemiLight);

    const dirLight = new THREE.DirectionalLight(0xfff1e0, 1.8);
    dirLight.position.set(80, 130, 60);
    dirLight.castShadow = true;
    dirLight.shadow.mapSize.width = 2048;
    dirLight.shadow.mapSize.height = 2048;
    dirLight.shadow.camera.near = 10;
    dirLight.shadow.camera.far = 360;
    const d = 175;
    dirLight.shadow.camera.left = -d;
    dirLight.shadow.camera.right = d;
    dirLight.shadow.camera.top = d;
    dirLight.shadow.camera.bottom = -d;
    dirLight.shadow.bias = -0.0005;
    scene.add(dirLight);

    function createAsphaltTexture() {
      const c = document.createElement('canvas');
      c.width = 512;
      c.height = 512;
      const ctx = c.getContext('2d')!;
      ctx.fillStyle = '#242933';
      ctx.fillRect(0, 0, 512, 512);
      for (let i = 0; i < 18000; i++) {
        const x = Math.random() * 512;
        const y = Math.random() * 512;
        const v = 28 + Math.random() * 26;
        ctx.fillStyle = `rgb(${v},${v + 2},${v + 6})`;
        ctx.fillRect(x, y, 2, 2);
      }
      const tex = new THREE.CanvasTexture(c);
      tex.wrapS = THREE.RepeatWrapping;
      tex.wrapT = THREE.RepeatWrapping;
      tex.repeat.set(36, 36);
      tex.colorSpace = THREE.SRGBColorSpace;
      return tex;
    }

    function createCurbTexture() {
      const c = document.createElement('canvas');
      c.width = 128;
      c.height = 64;
      const ctx = c.getContext('2d')!;
      ctx.fillStyle = '#ef4444';
      ctx.fillRect(0, 0, 64, 64);
      ctx.fillStyle = '#f8fafc';
      ctx.fillRect(64, 0, 64, 64);
      const tex = new THREE.CanvasTexture(c);
      tex.wrapS = THREE.RepeatWrapping;
      tex.wrapT = THREE.RepeatWrapping;
      tex.colorSpace = THREE.SRGBColorSpace;
      return tex;
    }

    const asphaltTex = createAsphaltTexture();
    const ground = new THREE.Mesh(
      new THREE.PlaneGeometry(340, 280),
      new THREE.MeshStandardMaterial({ map: asphaltTex, roughness: 0.85, metalness: 0.08 }),
    );
    ground.rotation.x = -Math.PI / 2;
    ground.receiveShadow = true;
    scene.add(ground);

    function addGroundLine(x1: number, z1: number, x2: number, z2: number, width = 0.4, color = 0xe2e8f0, opacity = 0.55) {
      const dx = x2 - x1;
      const dz = z2 - z1;
      const len = Math.hypot(dx, dz);
      const mesh = new THREE.Mesh(
        new THREE.PlaneGeometry(len, width),
        new THREE.MeshBasicMaterial({ color, transparent: true, opacity }),
      );
      mesh.rotation.order = 'YXZ';
      mesh.rotation.x = -Math.PI / 2;
      mesh.rotation.y = -Math.atan2(dz, dx);
      mesh.position.set((x1 + x2) / 2, 0.02, (z1 + z2) / 2);
      scene.add(mesh);
    }

    for (let x = -105; x <= 105; x += 14) {
      addGroundLine(x, -83, x + 7, -83, 0.45, 0xfbbf24, 0.6);
    }
    addGroundLine(-60, -108, -60, -58, 1.4, 0xffffff, 0.75);

    const curbTex = createCurbTexture();
    WALLS.forEach((w) => {
      const dx = w.x2 - w.x1;
      const dz = w.z2 - w.z1;
      const len = Math.hypot(dx, dz);
      const angle = Math.atan2(dz, dx);
      const height = 2.0;
      const thickness = 1.6;
      const wallMesh = new THREE.Mesh(
        new THREE.BoxGeometry(len, height, thickness),
        new THREE.MeshStandardMaterial({
          color: w.isClippingZone ? 0x334155 : 0x1e293b,
          roughness: 0.7,
          metalness: 0.2,
        }),
      );
      wallMesh.position.set((w.x1 + w.x2) / 2, height / 2, (w.z1 + w.z2) / 2);
      wallMesh.rotation.y = -angle;
      wallMesh.castShadow = true;
      wallMesh.receiveShadow = true;
      scene.add(wallMesh);

      const stripe = new THREE.Mesh(
        new THREE.BoxGeometry(len, 0.22, thickness + 0.08),
        new THREE.MeshBasicMaterial({ color: w.isClippingZone ? 0x22d3ee : 0xef4444 }),
      );
      stripe.position.set((w.x1 + w.x2) / 2, height - 0.25, (w.z1 + w.z2) / 2);
      stripe.rotation.y = -angle;
      scene.add(stripe);

      if (w.isClippingZone) {
        const apronTex = curbTex.clone();
        apronTex.repeat.set(Math.max(1, Math.round(len / 4)), 1);
        apronTex.needsUpdate = true;
        const apron = new THREE.Mesh(
          new THREE.PlaneGeometry(len, 2.6),
          new THREE.MeshStandardMaterial({ map: apronTex, roughness: 0.8 }),
        );
        apron.rotation.order = 'YXZ';
        apron.rotation.x = -Math.PI / 2;
        apron.rotation.y = -angle;
        apron.position.set((w.x1 + w.x2) / 2, 0.015, (w.z1 + w.z2) / 2);
        scene.add(apron);
      }
    });

    PILLARS.forEach((p) => {
      const cyl = new THREE.Mesh(
        new THREE.CylinderGeometry(p.radius, p.radius * 1.12, 8, 24),
        new THREE.MeshStandardMaterial({ color: 0x1e293b, roughness: 0.5, metalness: 0.3 }),
      );
      cyl.position.set(p.x, 4, p.z);
      cyl.castShadow = true;
      cyl.receiveShadow = true;
      scene.add(cyl);

      const ring = new THREE.Mesh(
        new THREE.CylinderGeometry(p.radius + 0.12, p.radius + 0.12, 1.0, 24),
        new THREE.MeshBasicMaterial({ color: p.color }),
      );
      ring.position.set(p.x, 2.2, p.z);
      scene.add(ring);

      const topBeacon = new THREE.Mesh(
        new THREE.SphereGeometry(p.radius * 0.7, 16, 16),
        new THREE.MeshBasicMaterial({ color: p.color }),
      );
      topBeacon.position.set(p.x, 8.3, p.z);
      scene.add(topBeacon);

      const guideRing = new THREE.Mesh(
        new THREE.RingGeometry(8.5, 9.2, 48),
        new THREE.MeshBasicMaterial({ color: p.color, side: THREE.DoubleSide, transparent: true, opacity: 0.42 }),
      );
      guideRing.rotation.x = -Math.PI / 2;
      guideRing.position.set(p.x, 0.025, p.z);
      scene.add(guideRing);

      const outerRing = new THREE.Mesh(
        new THREE.RingGeometry(15.2, 15.5, 48),
        new THREE.MeshBasicMaterial({ color: 0xffffff, side: THREE.DoubleSide, transparent: true, opacity: 0.15 }),
      );
      outerRing.rotation.x = -Math.PI / 2;
      outerRing.position.set(p.x, 0.025, p.z);
      scene.add(outerRing);

      const pLight = new THREE.PointLight(p.color, 25, 38);
      pLight.position.set(p.x, 5.5, p.z);
      scene.add(pLight);
    });

    const towerCoords: [number, number][] = [
      [-130, -100],
      [130, -100],
      [-130, 100],
      [130, 100],
      [0, -56],
      [55, 12],
    ];
    towerCoords.forEach(([tx, tz]) => {
      const pole = new THREE.Mesh(
        new THREE.CylinderGeometry(0.3, 0.4, 16, 8),
        new THREE.MeshStandardMaterial({ color: 0x475569 }),
      );
      pole.position.set(tx, 8, tz);
      scene.add(pole);
      const lamp = new THREE.Mesh(new THREE.BoxGeometry(2.6, 0.8, 0.8), new THREE.MeshBasicMaterial({ color: 0xe0f2fe }));
      lamp.position.set(tx, 16.2, tz);
      scene.add(lamp);
    });

    // 3D Drift Car
    const carGroup = new THREE.Group();
    scene.add(carGroup);
    const chassisGroup = new THREE.Group();
    carGroup.add(chassisGroup);

    const bodyPaint = new THREE.MeshStandardMaterial({ color: 0xe11d48, metalness: 0.6, roughness: 0.22 });
    const darkTrim = new THREE.MeshStandardMaterial({ color: 0x0f172a, roughness: 0.5, metalness: 0.3 });
    const lowerChassis = new THREE.Mesh(new THREE.BoxGeometry(1.96, 0.58, 4.45), bodyPaint);
    lowerChassis.position.set(0, 0.58, 0);
    lowerChassis.castShadow = true;
    chassisGroup.add(lowerChassis);

    const splitter = new THREE.Mesh(new THREE.BoxGeometry(2.04, 0.1, 0.45), darkTrim);
    splitter.position.set(0, 0.28, 2.15);
    chassisGroup.add(splitter);
    const diffuser = new THREE.Mesh(new THREE.BoxGeometry(1.92, 0.14, 0.35), darkTrim);
    diffuser.position.set(0, 0.3, -2.18);
    chassisGroup.add(diffuser);

    const cabin = new THREE.Mesh(
      new THREE.BoxGeometry(1.62, 0.48, 2.1),
      new THREE.MeshStandardMaterial({ color: 0x111827, metalness: 0.85, roughness: 0.1 }),
    );
    cabin.position.set(0, 1.06, -0.18);
    cabin.castShadow = true;
    chassisGroup.add(cabin);

    const roof = new THREE.Mesh(new THREE.BoxGeometry(1.56, 0.08, 1.55), bodyPaint);
    roof.position.set(0, 1.31, -0.2);
    chassisGroup.add(roof);

    const wingBlade = new THREE.Mesh(new THREE.BoxGeometry(2.02, 0.07, 0.34), darkTrim);
    wingBlade.position.set(0, 1.24, -2.02);
    wingBlade.rotation.x = 0.14;
    wingBlade.castShadow = true;
    chassisGroup.add(wingBlade);

    [-0.65, 0.65].forEach((sx) => {
      const strut = new THREE.Mesh(new THREE.BoxGeometry(0.06, 0.36, 0.22), darkTrim);
      strut.position.set(sx, 1.04, -2.0);
      chassisGroup.add(strut);
    });

    const headlightMat = new THREE.MeshBasicMaterial({ color: 0xe0f2fe });
    [-0.68, 0.68].forEach((hx) => {
      const hl = new THREE.Mesh(new THREE.BoxGeometry(0.36, 0.12, 0.08), headlightMat);
      hl.position.set(hx, 0.62, 2.23);
      chassisGroup.add(hl);
    });

    const tailLightMat = new THREE.MeshBasicMaterial({ color: 0x7f1d1d });
    [-0.68, 0.68].forEach((tx) => {
      const tl = new THREE.Mesh(new THREE.BoxGeometry(0.42, 0.13, 0.08), tailLightMat);
      tl.position.set(tx, 0.66, -2.23);
      chassisGroup.add(tl);
    });

    const underglow = new THREE.Mesh(
      new THREE.PlaneGeometry(2.2, 4.6),
      new THREE.MeshBasicMaterial({ color: 0x000000, transparent: true, opacity: 0.45 }),
    );
    underglow.rotation.x = -Math.PI / 2;
    underglow.position.y = 0.03;
    carGroup.add(underglow);

    const wheels: THREE.Group[] = [];
    const frontWheelPivots: THREE.Group[] = [];
    const wheelGeo = new THREE.CylinderGeometry(0.36, 0.36, 0.28, 20);
    wheelGeo.rotateZ(Math.PI / 2);
    const tireMat = new THREE.MeshStandardMaterial({ color: 0x111111, roughness: 0.85 });
    const rimMat = new THREE.MeshStandardMaterial({ color: 0xd4d4d8, metalness: 0.8, roughness: 0.2 });

    function makeWheel(x: number, z: number, isFront: boolean) {
      const pivot = new THREE.Group();
      pivot.position.set(x, 0.36, z);
      const spinGroup = new THREE.Group();
      const tire = new THREE.Mesh(wheelGeo, tireMat);
      tire.castShadow = true;
      spinGroup.add(tire);
      const rim = new THREE.Mesh(new THREE.CylinderGeometry(0.22, 0.22, 0.3, 12), rimMat);
      rim.rotation.z = Math.PI / 2;
      spinGroup.add(rim);
      pivot.add(spinGroup);
      carGroup.add(pivot);
      wheels.push(spinGroup);
      if (isFront) frontWheelPivots.push(pivot);
    }

    makeWheel(-0.98, 1.42, true);
    makeWheel(0.98, 1.42, true);
    makeWheel(-0.98, -1.42, false);
    makeWheel(0.98, -1.42, false);

    // Skidmarks
    const MAX_SKIDS = 1800;
    const skidMeshes: THREE.Mesh[] = [];
    const skidGeo = new THREE.PlaneGeometry(0.34, 1.0);
    const skidMat = new THREE.MeshBasicMaterial({
      color: 0x09090b,
      transparent: true,
      opacity: 0.58,
      depthWrite: false,
    });
    let skidIndex = 0;
    for (let i = 0; i < MAX_SKIDS; i++) {
      const m = new THREE.Mesh(skidGeo, skidMat);
      m.rotation.x = -Math.PI / 2;
      m.visible = false;
      scene.add(m);
      skidMeshes.push(m);
    }
    let lastRearLeft: { x: number; z: number } | null = null;
    let lastRearRight: { x: number; z: number } | null = null;

    function stampSkid(p1: { x: number; z: number } | null, p2: { x: number; z: number } | null) {
      if (!p1 || !p2) return;
      const dx = p2.x - p1.x;
      const dz = p2.z - p1.z;
      const dist = Math.hypot(dx, dz);
      if (dist < 0.18 || dist > 6) return;
      const mesh = skidMeshes[skidIndex];
      skidIndex = (skidIndex + 1) % MAX_SKIDS;
      mesh.visible = true;
      mesh.position.set((p1.x + p2.x) / 2, 0.022, (p1.z + p2.z) / 2);
      mesh.scale.set(1, dist * 1.15, 1);
      mesh.rotation.order = 'YXZ';
      mesh.rotation.set(-Math.PI / 2, Math.atan2(dx, dz), 0);
    }

    // Smoke Particles
    const MAX_SMOKE = 240;
    const smokeParticles: {
      mesh: THREE.Mesh;
      mat: THREE.MeshBasicMaterial;
      vx: number;
      vy: number;
      vz: number;
      life: number;
      maxLife: number;
      active: boolean;
    }[] = [];
    const smokeGeo = new THREE.SphereGeometry(0.45, 7, 7);
    for (let i = 0; i < MAX_SMOKE; i++) {
      const mat = new THREE.MeshBasicMaterial({
        color: 0xf1f5f9,
        transparent: true,
        opacity: 0,
        depthWrite: false,
      });
      const mesh = new THREE.Mesh(smokeGeo, mat);
      mesh.visible = false;
      scene.add(mesh);
      smokeParticles.push({ mesh, mat, vx: 0, vy: 0, vz: 0, life: 0, maxLife: 1, active: false });
    }
    let smokeCursor = 0;

    function spawnSmoke(x: number, z: number, vx: number, vz: number, intensity: number) {
      const p = smokeParticles[smokeCursor];
      smokeCursor = (smokeCursor + 1) % MAX_SMOKE;
      p.active = true;
      p.life = 0;
      p.maxLife = 0.55 + Math.random() * 0.45;
      p.mesh.visible = true;
      p.mesh.position.set(x + (Math.random() - 0.5) * 0.3, 0.25, z + (Math.random() - 0.5) * 0.3);
      p.mesh.scale.setScalar(0.55 + intensity * 0.55);
      p.vx = vx * 0.25 + (Math.random() - 0.5) * 2.2;
      p.vy = 1.4 + Math.random() * 1.6;
      p.vz = vz * 0.25 + (Math.random() - 0.5) * 2.2;
      p.mat.opacity = Math.min(0.48, 0.18 + intensity * 0.3);
    }

    function updateSmoke(dt: number) {
      for (let i = 0; i < MAX_SMOKE; i++) {
        const p = smokeParticles[i];
        if (!p.active) continue;
        p.life += dt;
        if (p.life >= p.maxLife) {
          p.active = false;
          p.mesh.visible = false;
          continue;
        }
        const t = p.life / p.maxLife;
        p.mesh.position.x += p.vx * dt;
        p.mesh.position.y += p.vy * dt;
        p.mesh.position.z += p.vz * dt;
        p.vx *= 0.96;
        p.vz *= 0.96;
        p.mesh.scale.setScalar(0.7 + t * 2.8);
        p.mat.opacity = (1 - t) * 0.36;
      }
    }

    // Audio
    let audioCtx: AudioContext | null = null;
    let audioEnabled = false;
    let engineOsc: OscillatorNode | null = null;
    let engineGain: GainNode | null = null;
    let screechGain: GainNode | null = null;
    let screechFilter: BiquadFilterNode | null = null;

    function initAudio() {
      if (audioCtx) return;
      const Ctx = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
      if (!Ctx) return;
      audioCtx = new Ctx();
      engineOsc = audioCtx.createOscillator();
      engineOsc.type = 'sawtooth';
      engineOsc.frequency.value = 65;
      const engineFilter = audioCtx.createBiquadFilter();
      engineFilter.type = 'lowpass';
      engineFilter.frequency.value = 340;
      engineGain = audioCtx.createGain();
      engineGain.gain.value = 0;
      engineOsc.connect(engineFilter);
      engineFilter.connect(engineGain);
      engineGain.connect(audioCtx.destination);
      engineOsc.start();

      const bufSize = audioCtx.sampleRate * 2;
      const noiseBuf = audioCtx.createBuffer(1, bufSize, audioCtx.sampleRate);
      const data = noiseBuf.getChannelData(0);
      for (let i = 0; i < bufSize; i++) data[i] = Math.random() * 2 - 1;
      const noiseSrc = audioCtx.createBufferSource();
      noiseSrc.buffer = noiseBuf;
      noiseSrc.loop = true;
      screechFilter = audioCtx.createBiquadFilter();
      screechFilter.type = 'bandpass';
      screechFilter.frequency.value = 1350;
      screechFilter.Q.value = 4.5;
      screechGain = audioCtx.createGain();
      screechGain.gain.value = 0;
      noiseSrc.connect(screechFilter);
      screechFilter.connect(screechGain);
      screechGain.connect(audioCtx.destination);
      noiseSrc.start();
    }

    function toggleAudio() {
      initAudio();
      if (!audioCtx) return false;
      if (audioCtx.state === 'suspended') void audioCtx.resume();
      audioEnabled = !audioEnabled;
      if (!audioEnabled && engineGain && screechGain) {
        engineGain.gain.setTargetAtTime(0, audioCtx.currentTime, 0.05);
        screechGain.gain.setTargetAtTime(0, audioCtx.currentTime, 0.05);
      }
      setSoundOn(audioEnabled);
      return audioEnabled;
    }

    function updateAudio(speed: number, slipIntensity: number, throttle: number) {
      if (!audioEnabled || !audioCtx || !engineOsc || !engineGain || !screechGain || !screechFilter) return;
      const now = audioCtx.currentTime;
      const rpmFreq = 58 + speed * 2.9 + (throttle > 0 ? 22 : 0) + slipIntensity * 35;
      engineOsc.frequency.setTargetAtTime(Math.min(260, rpmFreq), now, 0.06);
      engineGain.gain.setTargetAtTime(0.055 + Math.min(0.05, speed * 0.0012), now, 0.08);
      const screechVol = slipIntensity > 0.15 && speed > 4 ? Math.min(0.11, slipIntensity * 0.12) : 0;
      screechGain.gain.setTargetAtTime(screechVol, now, 0.05);
      screechFilter.frequency.setTargetAtTime(1150 + slipIntensity * 520, now, 0.08);
    }

    // Input & Physics
    const keys: Record<string, boolean> = {};
    let hintDismissed = false;

    const car = {
      x: -75,
      z: -83,
      vx: 0,
      vz: 0,
      heading: Math.PI / 2,
      angularVel: 0,
      steerAngle: 0,
      wheelSpin: 0,
      roll: 0,
      pitch: 0,
      speed: 0,
      vLong: 0,
      vLat: 0,
      slipAngleDeg: 0,
      isHandbrake: false,
      collidedRecently: 0,
    };

    let totalScore = 0;
    let comboMult = 1.0;
    let liveDriftPoints = 0;
    let gameTime = 0;

    const detector = {
      isDrifting: false,
      driftDuration: 0,
      driftGapTimer: 0,
      driftSign: 0,
      driftSignChanges: 0,
      lastSignChangeTime: -99,
      steerHistory: [] as { t: number; val: number }[],
      ebrakeRecentTime: -99,
      powerOverFiredInSession: false,
      ebrakeFiredInSession: false,
      feintFiredInSession: false,
      spinAccum: 0,
      spinStartTime: 0,
      spinReadyForCatch: false,
      spinCatchWindow: 0,
      lastPillarAngles: { A: null as number | null, B: null as number | null },
      pillarSweeps: { A: 0, B: 0 },
      lastCompletedOrb: null as { id: 'A' | 'B'; dir: number; time: number } | null,
      wallTapCooldown: 0,
    };

    const recentItems: string[] = [];

    function showPopup(title: string, points: number, gradientClass = 'from-cyan-500/90 to-blue-600/90', isAlert = false) {
      const popupContainer = popupRef.current;
      if (!popupContainer) return;
      const el = document.createElement('div');
      el.className = `trick-popup px-6 py-2.5 rounded-xl bg-gradient-to-r ${gradientClass} shadow-2xl border border-white/25 flex items-center gap-3`;
      el.innerHTML = `
        <span class="font-racing text-lg md:text-xl font-bold tracking-wider text-white drop-shadow">${title}</span>
        ${!isAlert && points > 0 ? `<span class="font-racing text-lg md:text-xl font-bold text-amber-200 bg-black/25 px-2.5 py-0.5 rounded-lg">+${points}</span>` : ''}
      `;
      popupContainer.appendChild(el);
      window.setTimeout(() => el.remove(), 2250);
    }

    function addRecentLog(name: string, pts: number) {
      const recentLogEl = recentLogRef.current;
      if (!recentLogEl) return;
      recentItems.unshift(`<div class="flex justify-between"><span>✓ ${name}</span><span class="text-emerald-400">+${pts}</span></div>`);
      if (recentItems.length > 2) recentItems.pop();
      recentLogEl.innerHTML = recentItems.join('');
    }

    function renderTrickList() {
      const trickListEl = trickListRef.current;
      if (!trickListEl) return;
      let unlockedCount = 0;
      trickListEl.innerHTML = '';
      TRICKS.forEach((t) => {
        const p = trickProgress[t.id];
        if (p.unlocked) unlockedCount++;
        const card = document.createElement('div');
        card.className = `rounded-lg px-3 py-2 border transition-all ${
          p.unlocked ? 'bg-emerald-500/12 border-emerald-400/45' : 'bg-slate-900/55 border-white/8 opacity-80'
        }`;
        card.innerHTML = `
          <div class="flex items-start justify-between gap-2">
            <div class="flex items-start gap-2">
              <div class="mt-0.5 w-4 h-4 rounded flex items-center justify-center text-[11px] font-bold ${
                p.unlocked ? 'bg-emerald-400 text-slate-950' : 'bg-slate-800 border border-white/15 text-slate-500'
              }">${p.unlocked ? '✓' : ''}</div>
              <div>
                <div class="font-racing text-xs font-bold leading-tight ${p.unlocked ? 'text-white' : 'text-slate-300'}">${t.name}</div>
                <div class="text-[10px] text-slate-400 leading-snug mt-0.5">${t.desc}</div>
              </div>
            </div>
            <div class="text-right shrink-0">
              <div class="font-racing text-xs font-bold ${p.unlocked ? 'text-emerald-300' : t.color}">
                ${p.unlocked ? `+${p.totalScore}` : `+${t.points}`}
              </div>
              ${p.count > 0 ? `<div class="text-[10px] text-slate-400">${p.count}x</div>` : ''}
            </div>
          </div>
        `;
        trickListEl.appendChild(card);
      });
      const pt = document.getElementById('ds-trick-progress-text');
      const pb = document.getElementById('ds-trick-progress-bar');
      if (pt) pt.textContent = `${unlockedCount}/${TRICKS.length}`;
      if (pb) pb.style.width = `${(unlockedCount / TRICKS.length) * 100}%`;
    }

    function resetDriftSession(bankPoints = true) {
      if (bankPoints && liveDriftPoints > 0) {
        totalScore += Math.round(liveDriftPoints * comboMult);
      }
      liveDriftPoints = 0;
      comboMult = 1.0;
      detector.isDrifting = false;
      detector.driftDuration = 0;
      detector.driftSign = 0;
      detector.driftSignChanges = 0;
      detector.powerOverFiredInSession = false;
      detector.ebrakeFiredInSession = false;
      detector.feintFiredInSession = false;
    }

    function onCrash() {
      if (liveDriftPoints > 50) {
        showPopup('TABRAKAN! POIN HANGUS', 0, 'from-slate-700/90 to-slate-800/90', true);
      }
      resetDriftSession(false);
    }

    function awardTrick(trickId: string, customBonus = 0) {
      const def = TRICKS.find((t) => t.id === trickId);
      const prog = trickProgress[trickId];
      if (!def || !prog) return;
      const cooldown = trickId === 'manji' ? 3.5 : trickId === 'wall_tap' ? 2.5 : 3.0;
      if (gameTime - prog.lastTriggeredAt < cooldown) return;
      prog.lastTriggeredAt = gameTime;
      prog.unlocked = true;
      prog.count += 1;
      const pts = Math.round((def.points + customBonus) * comboMult);
      prog.totalScore += pts;
      totalScore += pts;
      comboMult = Math.min(5.0, +(comboMult + 0.25).toFixed(2));
      showPopup(`${def.name.toUpperCase()}!`, pts, def.badgeBg);
      addRecentLog(def.name, pts);
      renderTrickList();
    }

    function resetCar() {
      car.x = -75;
      car.z = -83;
      car.vx = 0;
      car.vz = 0;
      car.heading = Math.PI / 2;
      car.angularVel = 0;
      car.steerAngle = 0;
      lastRearLeft = null;
      lastRearRight = null;
      resetDriftSession(false);
    }

    function closestPointOnSegment(px: number, pz: number, x1: number, z1: number, x2: number, z2: number) {
      const dx = x2 - x1;
      const dz = z2 - z1;
      const lenSq = dx * dx + dz * dz;
      if (lenSq === 0) return { x: x1, z: z1, dist: Math.hypot(px - x1, pz - z1) };
      let t = ((px - x1) * dx + (pz - z1) * dz) / lenSq;
      t = Math.max(0, Math.min(1, t));
      const cx = x1 + t * dx;
      const cz = z1 + t * dz;
      return { x: cx, z: cz, dist: Math.hypot(px - cx, pz - cz) };
    }

    function handleCollisions() {
      const carRadius = 1.65;
      for (const w of WALLS) {
        const hit = closestPointOnSegment(car.x, car.z, w.x1, w.z1, w.x2, w.z2);
        const minDist = carRadius + 0.8;
        if (hit.dist < minDist) {
          const nx = (car.x - hit.x) / (hit.dist || 0.001);
          const nz = (car.z - hit.z) / (hit.dist || 0.001);
          const overlap = minDist - hit.dist;
          car.x += nx * overlap;
          car.z += nz * overlap;
          const vn = car.vx * nx + car.vz * nz;
          if (vn < 0) {
            car.vx -= 1.35 * vn * nx;
            car.vz -= 1.35 * vn * nz;
            car.vx *= 0.72;
            car.vz *= 0.72;
            if (Math.abs(vn) > 4.5) {
              car.collidedRecently = 1.2;
              onCrash();
            }
          }
        }
      }

      for (const p of PILLARS) {
        const dx = car.x - p.x;
        const dz = car.z - p.z;
        const dist = Math.hypot(dx, dz);
        const minDist = carRadius + p.radius;
        if (dist < minDist) {
          const nx = dx / (dist || 0.001);
          const nz = dz / (dist || 0.001);
          car.x = p.x + nx * minDist;
          car.z = p.z + nz * minDist;
          const vn = car.vx * nx + car.vz * nz;
          if (vn < 0) {
            car.vx -= 1.3 * vn * nx;
            car.vz -= 1.3 * vn * nz;
            car.vx *= 0.75;
            car.vz *= 0.75;
            if (Math.abs(vn) > 4.0) {
              car.collidedRecently = 1.2;
              onCrash();
            }
          }
        }
      }
    }

    function updateCarPhysics(dt: number) {
      const throttle = keys['KeyW'] || keys['ArrowUp'] ? 1 : 0;
      const brake = keys['KeyS'] || keys['ArrowDown'] ? 1 : 0;
      const steerLeft = keys['KeyA'] || keys['ArrowLeft'] ? 1 : 0;
      const steerRight = keys['KeyD'] || keys['ArrowRight'] ? 1 : 0;
      const handbrake = !!keys['Space'];
      car.isHandbrake = handbrake;

      const fx = Math.sin(car.heading);
      const fz = Math.cos(car.heading);
      const rx = Math.cos(car.heading);
      const rz = -Math.sin(car.heading);

      const vLong = car.vx * fx + car.vz * fz;
      const vLat = car.vx * rx + car.vz * rz;
      const speed = Math.hypot(car.vx, car.vz);
      car.speed = speed;
      car.vLong = vLong;
      car.vLat = vLat;

      const targetSteer = steerLeft - steerRight;
      const steerSpeed = targetSteer !== 0 ? 7.5 : 9.5;
      car.steerAngle += (targetSteer - car.steerAngle) * Math.min(1, steerSpeed * dt);

      let slipAngle = 0;
      if (speed > 1.8) {
        slipAngle = Math.atan2(vLat, Math.max(0.5, Math.abs(vLong)));
      }
      car.slipAngleDeg = THREE.MathUtils.radToDeg(slipAngle);

      let longAccel = 0;
      if (throttle > 0) {
        const speedRatio = Math.min(1, Math.max(0, vLong) / 47);
        longAccel += 33.0 * (1 - 0.55 * speedRatio);
      }
      if (brake > 0) {
        longAccel -= vLong > 1.5 ? 38.0 : 18.0;
      }
      if (handbrake && speed > 1.0) {
        longAccel -= Math.sign(vLong) * 7.5;
      }
      const drag = 0.011 * speed * speed + 0.55 * Math.abs(vLong);
      longAccel -= Math.sign(vLong) * drag * 0.45;

      const absSlip = Math.abs(slipAngle);
      let lateralGrip = handbrake ? 1.55 : absSlip > 0.28 ? 3.25 : 6.4;
      if (throttle > 0 && Math.abs(car.steerAngle) > 0.25 && speed > 9) {
        lateralGrip *= 0.84;
      }
      const lateralForce = -Math.tanh(vLat * 0.28) * lateralGrip * 4.4 - vLat * (handbrake ? 0.35 : 0.95);

      const ax = fx * longAccel + rx * lateralForce;
      const az = fz * longAccel + rz * lateralForce;
      car.vx += ax * dt;
      car.vz += az * dt;

      if (!throttle && !brake && Math.hypot(car.vx, car.vz) < 0.25) {
        car.vx = 0;
        car.vz = 0;
      }

      const steerFactor = Math.min(1, speed / 5.5);
      const directionSign = vLong >= -0.5 ? 1 : -1;
      const yawStrength = handbrake ? 7.6 : 5.4;
      let yawTorque = car.steerAngle * yawStrength * steerFactor * directionSign;

      const intentionalHardSpin = handbrake && Math.abs(car.steerAngle) > 0.85;
      if (speed > 5.0 && absSlip > 0.14 && !intentionalHardSpin) {
        yawTorque += Math.sin(slipAngle) * 2.55;
      }

      const angularDamping = handbrake ? 2.4 : 4.2;
      car.angularVel += (yawTorque - car.angularVel * angularDamping) * dt;
      car.heading += car.angularVel * dt;

      car.x += car.vx * dt;
      car.z += car.vz * dt;
      handleCollisions();

      carGroup.position.set(car.x, 0, car.z);
      carGroup.rotation.y = car.heading;

      const targetRoll = THREE.MathUtils.clamp(-vLat * 0.012 + car.angularVel * 0.035, -0.11, 0.11);
      const targetPitch = THREE.MathUtils.clamp(throttle * -0.025 + brake * 0.035, -0.05, 0.05);
      car.roll += (targetRoll - car.roll) * Math.min(1, 10 * dt);
      car.pitch += (targetPitch - car.pitch) * Math.min(1, 10 * dt);
      chassisGroup.rotation.z = car.roll;
      chassisGroup.rotation.x = car.pitch;

      const visualSteer = car.steerAngle * 0.48;
      frontWheelPivots.forEach((p) => {
        p.rotation.y = visualSteer;
      });
      car.wheelSpin += (vLong / 0.36) * dt;
      wheels.forEach((w) => {
        w.rotation.x = car.wheelSpin;
      });
      tailLightMat.color.setHex(brake || handbrake ? 0xff1e42 : 0x7f1d1d);

      const lateralIntensity = THREE.MathUtils.clamp((Math.abs(vLat) - 2.2) / 14 + (handbrake && speed > 4 ? 0.55 : 0), 0, 1);
      if (lateralIntensity > 0.12 && speed > 3.5) {
        const rearOffset = -1.42;
        const halfTrack = 0.98;
        const rl = { x: car.x + fx * rearOffset - rx * halfTrack, z: car.z + fz * rearOffset - rz * halfTrack };
        const rr = { x: car.x + fx * rearOffset + rx * halfTrack, z: car.z + fz * rearOffset + rz * halfTrack };
        stampSkid(lastRearLeft, rl);
        stampSkid(lastRearRight, rr);
        lastRearLeft = rl;
        lastRearRight = rr;
        if (Math.random() < 0.6 + lateralIntensity * 0.4) {
          spawnSmoke(rl.x, rl.z, car.vx, car.vz, lateralIntensity);
          spawnSmoke(rr.x, rr.z, car.vx, car.vz, lateralIntensity);
        }
      } else {
        lastRearLeft = null;
        lastRearRight = null;
      }

      updateAudio(speed, lateralIntensity, throttle);
      if (car.collidedRecently > 0) car.collidedRecently -= dt;
    }

    function updateDriftDetection(dt: number) {
      gameTime += dt;
      if (detector.wallTapCooldown > 0) detector.wallTapCooldown -= dt;
      const absSlip = Math.abs(car.slipAngleDeg);
      const speed = car.speed;

      detector.steerHistory.push({ t: gameTime, val: car.steerAngle });
      while (detector.steerHistory.length && gameTime - detector.steerHistory[0].t > 1.2) {
        detector.steerHistory.shift();
      }
      if (car.isHandbrake && speed > 7) {
        detector.ebrakeRecentTime = gameTime;
      }

      const currentlySliding = speed > 7.5 && absSlip > 14 && absSlip < 85 && car.collidedRecently <= 0;
      const currentSign = car.slipAngleDeg >= 0 ? 1 : -1;

      if (currentlySliding) {
        if (!detector.isDrifting) {
          detector.isDrifting = true;
          detector.driftDuration = 0;
          detector.driftSign = currentSign;
          if (gameTime - detector.ebrakeRecentTime < 1.1 && !detector.ebrakeFiredInSession) {
            detector.ebrakeFiredInSession = true;
            awardTrick('ebrake');
          }
          let minSteer = 0;
          let maxSteer = 0;
          let minTime = 0;
          let maxTime = 0;
          for (const h of detector.steerHistory) {
            if (h.val < minSteer) {
              minSteer = h.val;
              minTime = h.t;
            }
            if (h.val > maxSteer) {
              maxSteer = h.val;
              maxTime = h.t;
            }
          }
          if (minSteer < -0.4 && maxSteer > 0.4 && Math.abs(maxTime - minTime) < 1.15 && !detector.feintFiredInSession) {
            detector.feintFiredInSession = true;
            awardTrick('feint');
          }
        }
        detector.driftGapTimer = 0;
        detector.driftDuration += dt;
        liveDriftPoints += (absSlip * 1.4 + speed * 2.2) * dt;

        if (currentSign !== detector.driftSign && absSlip > 15) {
          detector.driftSign = currentSign;
          if (gameTime - detector.lastSignChangeTime < 2.8) {
            detector.driftSignChanges += 1;
          } else {
            detector.driftSignChanges = 1;
          }
          detector.lastSignChangeTime = gameTime;
          if (detector.driftSignChanges >= 2) {
            detector.driftSignChanges = 0;
            awardTrick('manji');
          }
        }

        if (detector.driftDuration > 0.75 && speed > 12.5 && !detector.powerOverFiredInSession && !detector.ebrakeFiredInSession) {
          detector.powerOverFiredInSession = true;
          awardTrick('power_over');
        }
      } else if (detector.isDrifting) {
        detector.driftGapTimer += dt;
        if (detector.driftGapTimer > 0.95) {
          resetDriftSession(true);
        }
      }

      if (speed > 8.5 && Math.abs(car.angularVel) > 1.8) {
        if (Math.abs(detector.spinAccum) < 0.1) detector.spinStartTime = gameTime;
        detector.spinAccum += car.angularVel * dt;
        if (Math.abs(detector.spinAccum) >= THREE.MathUtils.degToRad(315) && gameTime - detector.spinStartTime < 3.2) {
          detector.spinReadyForCatch = true;
          detector.spinCatchWindow = 1.8;
          detector.spinAccum = 0;
        }
      } else if (Math.abs(car.angularVel) < 1.0) {
        detector.spinAccum *= 0.92;
      }

      if (detector.spinReadyForCatch) {
        detector.spinCatchWindow -= dt;
        if (currentlySliding && Math.abs(car.angularVel) < 2.4 && car.vLong > 5.0) {
          detector.spinReadyForCatch = false;
          awardTrick('spin360');
        } else if (detector.spinCatchWindow <= 0) {
          detector.spinReadyForCatch = false;
        }
      }

      for (const p of PILLARS) {
        const dx = car.x - p.x;
        const dz = car.z - p.z;
        const dist = Math.hypot(dx, dz);
        if (dist < 18.5 && speed > 4.5 && absSlip > 12) {
          const ang = Math.atan2(dz, dx);
          const prev = detector.lastPillarAngles[p.id];
          if (prev !== null) {
            let dAng = ang - prev;
            if (dAng > Math.PI) dAng -= Math.PI * 2;
            if (dAng < -Math.PI) dAng += Math.PI * 2;
            if (Math.sign(dAng) !== Math.sign(detector.pillarSweeps[p.id]) && Math.abs(dAng) > 0.05) {
              detector.pillarSweeps[p.id] *= 0.5;
            }
            detector.pillarSweeps[p.id] += dAng;
            const absSweep = Math.abs(detector.pillarSweeps[p.id]);
            const sweepDir = Math.sign(detector.pillarSweeps[p.id]);
            if (absSweep >= THREE.MathUtils.degToRad(330)) {
              detector.pillarSweeps[p.id] = 0;
              awardTrick('donut');
            }
            if (absSweep >= THREE.MathUtils.degToRad(220)) {
              const last = detector.lastCompletedOrb;
              if (last && last.id !== p.id && last.dir !== sweepDir && gameTime - last.time < 14.0) {
                detector.lastCompletedOrb = null;
                detector.pillarSweeps[p.id] = 0;
                awardTrick('figure8');
              } else if (!last || last.id !== p.id || gameTime - last.time > 14.0) {
                detector.lastCompletedOrb = { id: p.id, dir: sweepDir, time: gameTime };
              }
            }
          }
          detector.lastPillarAngles[p.id] = ang;
        } else {
          detector.lastPillarAngles[p.id] = null;
          detector.pillarSweeps[p.id] *= 0.96;
        }
      }

      if (currentlySliding && speed > 10 && absSlip > 18 && detector.wallTapCooldown <= 0 && car.collidedRecently <= 0) {
        const fx = Math.sin(car.heading);
        const fz = Math.cos(car.heading);
        const rearX = car.x - fx * 2.15;
        const rearZ = car.z - fz * 2.15;
        for (const w of WALLS) {
          const hit = closestPointOnSegment(rearX, rearZ, w.x1, w.z1, w.x2, w.z2);
          if (hit.dist > 0.85 && hit.dist < 2.45) {
            detector.wallTapCooldown = 2.6;
            awardTrick('wall_tap');
            break;
          }
        }
      }
    }

    let camModeIdx = 0;
    const camPos = new THREE.Vector3(-85, 6, -83);
    const camLook = new THREE.Vector3(-75, 1, -83);

    function cycleCamera() {
      camModeIdx = (camModeIdx + 1) % CAM_MODES.length;
      setCamLabel(CAM_MODES[camModeIdx]);
    }

    function updateCamera(dt: number) {
      const fx = Math.sin(car.heading);
      const fz = Math.cos(car.heading);
      if (camModeIdx === 2) {
        camera.position.set(car.x + fx * 0.4, 1.55, car.z + fz * 0.4);
        camera.lookAt(car.x + fx * 18, 1.1, car.z + fz * 18);
        camera.fov = 72;
        camera.updateProjectionMatrix();
        return;
      }
      let dirX = fx;
      let dirZ = fz;
      if (car.speed > 4) {
        const vxNorm = car.vx / car.speed;
        const vzNorm = car.vz / car.speed;
        const blend = camModeIdx === 1 ? 0.55 : 0.38;
        dirX = fx * (1 - blend) + vxNorm * blend;
        dirZ = fz * (1 - blend) + vzNorm * blend;
        const len = Math.hypot(dirX, dirZ) || 1;
        dirX /= len;
        dirZ /= len;
      }
      const distBack = camModeIdx === 1 ? 11.2 : 8.4;
      const heightUp = camModeIdx === 1 ? 4.4 : 3.35;
      camPos.lerp(new THREE.Vector3(car.x - dirX * distBack, heightUp, car.z - dirZ * distBack), Math.min(1, 7.5 * dt));
      camLook.lerp(new THREE.Vector3(car.x + fx * 3.5, 1.25, car.z + fz * 3.5), Math.min(1, 11.0 * dt));
      camera.position.copy(camPos);
      camera.lookAt(camLook);
      const targetFov = (camModeIdx === 1 ? 66 : 60) + Math.min(13, car.speed * 0.28);
      camera.fov += (targetFov - camera.fov) * Math.min(1, 5 * dt);
      camera.updateProjectionMatrix();
    }

    function updateHUD() {
      const kmh = Math.round(car.speed * 3.6);
      const absAngle = Math.round(Math.abs(car.slipAngleDeg));
      const speedEl = document.getElementById('ds-speed-val');
      const angleEl = document.getElementById('ds-angle-val');
      const scoreEl = document.getElementById('ds-total-score');
      const comboEl = document.getElementById('ds-combo-badge');
      if (speedEl) speedEl.textContent = String(kmh);
      if (angleEl) angleEl.textContent = `${absAngle}°`;
      if (scoreEl) scoreEl.textContent = totalScore.toLocaleString('id-ID');
      if (comboEl) comboEl.textContent = `x${comboMult.toFixed(1)}`;

      const ebrakeEl = document.getElementById('ds-ebrake-indicator');
      if (ebrakeEl) {
        ebrakeEl.className = car.isHandbrake
          ? 'px-2 py-0.5 rounded text-[10px] font-racing font-bold tracking-wider bg-amber-500 text-slate-950 border border-amber-300 text-center'
          : 'px-2 py-0.5 rounded text-[10px] font-racing font-bold tracking-wider bg-slate-800 text-slate-500 border border-white/5 text-center';
      }

      const liveBox = document.getElementById('ds-live-drift-box');
      const driftLabel = document.getElementById('ds-drift-state-label');
      const livePtsEl = document.getElementById('ds-live-points');
      const angleBar = document.getElementById('ds-drift-angle-bar');
      if (liveBox && driftLabel && livePtsEl && angleBar) {
        if (detector.isDrifting) {
          liveBox.classList.remove('opacity-40');
          driftLabel.textContent = detector.driftSignChanges > 0 ? 'MANJI CHAIN!' : 'DRIFTING!';
          livePtsEl.textContent = `+${Math.round(liveDriftPoints * comboMult)}`;
          angleBar.style.width = `${Math.min(100, (absAngle / 65) * 100)}%`;
        } else {
          liveBox.classList.add('opacity-40');
          driftLabel.textContent = 'SIAP DRIFT';
          livePtsEl.textContent = '+0';
          angleBar.style.width = '0%';
        }
      }

      const ticker = document.getElementById('ds-chain-ticker');
      const tickerText = document.getElementById('ds-chain-text');
      if (ticker && tickerText) {
        let cue = '';
        if (detector.spinReadyForCatch) {
          cue = '360° TERCAPAI — TAHAN DRIFT SEKARANG!';
        } else if (detector.lastCompletedOrb && gameTime - detector.lastCompletedOrb.time < 14.0) {
          const nextPillar = detector.lastCompletedOrb.id === 'A' ? 'B (Cyan)' : 'A (Amber)';
          cue = `FIGURE-8: LANJUTKAN MUTARI TIANG ${nextPillar} ARAH SEBALIKNYA!`;
        } else if (Math.max(Math.abs(detector.pillarSweeps.A), Math.abs(detector.pillarSweeps.B)) > 1.2) {
          const pct = Math.min(99, Math.round((Math.max(Math.abs(detector.pillarSweeps.A), Math.abs(detector.pillarSweeps.B)) / THREE.MathUtils.degToRad(330)) * 100));
          cue = `DONUT PROGRES: ${pct}%`;
        } else if (detector.driftSignChanges === 1 && gameTime - detector.lastSignChangeTime < 2.6) {
          cue = 'MANJI x1 — BANTING BALIK UNTUK MANJI DRIFT!';
        }
        if (cue) {
          ticker.classList.remove('hidden');
          tickerText.textContent = cue;
        } else {
          ticker.classList.add('hidden');
        }
      }

      const zoneLabel = document.getElementById('ds-zone-label');
      if (zoneLabel) {
        let zoneName = 'Arena Tengah';
        if (car.z < -56) zoneName = 'Lurus Manji';
        else if (car.x < 10 && car.z > -15) zoneName = 'Area Donut & 8';
        else if (car.x > 50) zoneName = 'Tikungan Teknis';
        zoneLabel.textContent = zoneName;
      }

      const mmCanvas = minimapRef.current;
      const mmCtx = mmCanvas?.getContext('2d');
      if (mmCtx) {
        mmCtx.clearRect(0, 0, 160, 120);
        const mapX = (x: number) => ((x - ARENA.minX) / (ARENA.maxX - ARENA.minX)) * 150 + 5;
        const mapZ = (z: number) => ((z - ARENA.minZ) / (ARENA.maxZ - ARENA.minZ)) * 110 + 5;
        mmCtx.lineWidth = 2;
        WALLS.forEach((w) => {
          mmCtx.strokeStyle = w.isClippingZone ? '#22d3ee' : '#64748b';
          mmCtx.beginPath();
          mmCtx.moveTo(mapX(w.x1), mapZ(w.z1));
          mmCtx.lineTo(mapX(w.x2), mapZ(w.z2));
          mmCtx.stroke();
        });
        PILLARS.forEach((p) => {
          mmCtx.fillStyle = p.id === 'A' ? '#f59e0b' : '#06b6d4';
          mmCtx.beginPath();
          mmCtx.arc(mapX(p.x), mapZ(p.z), 3.5, 0, Math.PI * 2);
          mmCtx.fill();
        });
        const cx = mapX(car.x);
        const cz = mapZ(car.z);
        mmCtx.fillStyle = '#f43f5e';
        mmCtx.beginPath();
        mmCtx.arc(cx, cz, 4, 0, Math.PI * 2);
        mmCtx.fill();
        mmCtx.strokeStyle = '#ffffff';
        mmCtx.lineWidth = 1.6;
        mmCtx.beginPath();
        mmCtx.moveTo(cx, cz);
        mmCtx.lineTo(cx + Math.sin(car.heading) * 9, cz + Math.cos(car.heading) * 9);
        mmCtx.stroke();
      }
    }

    const onKeyDown = (e: KeyboardEvent) => {
      const code = e.code;
      if (['Space', 'ArrowUp', 'ArrowDown', 'ArrowLeft', 'ArrowRight'].includes(code)) {
        e.preventDefault();
      }
      keys[code] = true;
      if (!hintDismissed && ['KeyW', 'KeyA', 'KeyS', 'KeyD', 'Space', 'ArrowUp'].includes(code)) {
        hintDismissed = true;
        if (startHintRef.current) startHintRef.current.style.opacity = '0';
      }
      if (code === 'KeyR') resetCar();
      if (code === 'KeyC') cycleCamera();
    };
    const onKeyUp = (e: KeyboardEvent) => {
      keys[e.code] = false;
    };
    const onResize = () => {
      camera.aspect = window.innerWidth / window.innerHeight;
      camera.updateProjectionMatrix();
      renderer.setSize(window.innerWidth, window.innerHeight);
    };

    window.addEventListener('keydown', onKeyDown);
    window.addEventListener('keyup', onKeyUp);
    window.addEventListener('resize', onResize);

    apiRef.current = { resetCar, cycleCamera, toggleSound: toggleAudio };
    renderTrickList();
    resetCar();

    let rafId = 0;
    let lastTime = performance.now();
    const animate = (now: number) => {
      rafId = requestAnimationFrame(animate);
      const dt = Math.min(0.04, (now - lastTime) / 1000);
      lastTime = now;
      updateCarPhysics(dt);
      updateDriftDetection(dt);
      updateSmoke(dt);
      updateCamera(dt);
      updateHUD();
      renderer.render(scene, camera);
    };
    rafId = requestAnimationFrame(animate);

    return () => {
      cancelAnimationFrame(rafId);
      window.removeEventListener('keydown', onKeyDown);
      window.removeEventListener('keyup', onKeyUp);
      window.removeEventListener('resize', onResize);
      if (audioCtx) {
        void audioCtx.close().catch(() => {});
      }
      scene.traverse((obj) => {
        const mesh = obj as THREE.Mesh;
        mesh.geometry?.dispose();
        if (Array.isArray(mesh.material)) mesh.material.forEach((m) => m.dispose());
        else mesh.material?.dispose();
      });
      asphaltTex.dispose();
      curbTex.dispose();
      renderer.dispose();
      renderer.domElement.remove();
    };
  }, []);

  return (
    <div className="fixed inset-0 overflow-hidden bg-[#0a0d14] text-slate-50 select-none">
      <div ref={mountRef} className="fixed inset-0 z-0" />

      {/* TOP LEFT: SCORE & MINIMAP */}
      <div className="fixed top-4 left-4 z-20 flex flex-col gap-2.5 pointer-events-none">
        <div className="rounded-xl px-4 py-3 min-w-[260px] bg-[#0a0e17]/80 border border-white/10">
          <div className="flex items-center justify-between gap-4">
            <div>
              <div className="text-[11px] uppercase tracking-widest text-slate-400 font-semibold">Total Skor Drift</div>
              <div id="ds-total-score" className="font-racing text-3xl font-bold text-white tracking-wide tabular-nums">
                0
              </div>
            </div>
            <div className="text-right">
              <div className="text-[11px] uppercase tracking-widest text-slate-400 font-semibold">Combo</div>
              <div id="ds-combo-badge" className="font-racing text-2xl font-bold text-amber-400 tabular-nums">
                x1.0
              </div>
            </div>
          </div>
          <div id="ds-live-drift-box" className="mt-2.5 pt-2.5 border-t border-white/10 transition-opacity duration-200 opacity-40">
            <div className="flex items-center justify-between text-xs mb-1">
              <span id="ds-drift-state-label" className="font-racing uppercase tracking-wider text-cyan-300">
                SIAP DRIFT
              </span>
              <span id="ds-live-points" className="font-racing font-bold text-amber-300 text-sm tabular-nums">
                +0
              </span>
            </div>
            <div className="w-full h-1.5 bg-slate-800 rounded-full overflow-hidden">
              <div
                id="ds-drift-angle-bar"
                className="h-full bg-gradient-to-r from-cyan-400 via-amber-400 to-rose-500 transition-all duration-75"
                style={{ width: '0%' }}
              />
            </div>
          </div>
        </div>

        <div className="rounded-xl p-2.5 w-[180px] bg-[#0a0e17]/80 border border-white/10">
          <div className="flex items-center justify-between text-[10px] uppercase tracking-wider text-slate-400 mb-1.5 px-1">
            <span>Peta Sirkuit</span>
            <span id="ds-zone-label" className="text-cyan-300 font-semibold">
              Start
            </span>
          </div>
          <canvas
            ref={minimapRef}
            width={160}
            height={120}
            className="w-full h-auto rounded-lg bg-slate-950/70 border border-white/5"
          />
        </div>
      </div>

      {/* TOP CENTER: POPUPS & CHAIN TICKER */}
      <div ref={popupRef} className="fixed top-6 left-1/2 z-30 pointer-events-none flex flex-col items-center gap-2" />
      <div id="ds-chain-ticker" className="fixed top-24 left-1/2 -translate-x-1/2 z-20 pointer-events-none hidden">
        <div className="px-4 py-1.5 rounded-md text-xs font-racing tracking-wider text-amber-300 bg-[#0a0e17]/85 border border-amber-400/30">
          <span id="ds-chain-text">DRIFTING...</span>
        </div>
      </div>

      {/* RIGHT: TRICK LIST */}
      <div className="fixed top-4 right-4 z-20 w-[320px] max-h-[calc(100vh-140px)] hidden md:flex flex-col bg-[#0a0e17]/80 border border-white/10 rounded-xl overflow-hidden">
        <div className="px-4 py-3 border-b border-white/10 bg-slate-900/60 flex items-center justify-between">
          <div>
            <h2 className="font-racing text-sm font-bold uppercase tracking-wider text-white">Daftar Manuver Drift</h2>
            <p className="text-[11px] text-slate-400 mt-0.5">Eksekusi semua 8 teknik drift di arena</p>
          </div>
          <div className="text-right">
            <span id="ds-trick-progress-text" className="font-racing text-lg font-bold text-emerald-400 tabular-nums">
              0/8
            </span>
          </div>
        </div>
        <div className="px-3 pt-2 pb-1">
          <div className="w-full h-1.5 bg-slate-800 rounded-full overflow-hidden">
            <div
              id="ds-trick-progress-bar"
              className="h-full bg-gradient-to-r from-emerald-500 to-cyan-400 transition-all duration-300"
              style={{ width: '0%' }}
            />
          </div>
        </div>
        <div ref={trickListRef} className="p-3 space-y-2 overflow-y-auto" />
        <div className="px-3 py-2 border-t border-white/10 bg-slate-950/50">
          <div className="text-[10px] uppercase tracking-wider text-slate-400 mb-1">Log Terakhir</div>
          <div ref={recentLogRef} className="text-xs text-slate-300 space-y-0.5 min-h-[36px] font-racing">
            <div className="text-slate-500 italic">Mulai mengemudi &amp; drift untuk mencatat manuver...</div>
          </div>
        </div>
      </div>

      {/* BOTTOM LEFT: TELEMETRY */}
      <div className="fixed bottom-4 left-4 z-20 pointer-events-none">
        <div className="bg-[#0a0e17]/80 border border-white/10 rounded-xl px-4 py-3 flex items-center gap-5">
          <div>
            <div className="text-[10px] uppercase tracking-widest text-slate-400">Kecepatan</div>
            <div className="flex items-baseline gap-1">
              <span id="ds-speed-val" className="font-racing text-4xl font-bold text-white leading-none tabular-nums">
                0
              </span>
              <span className="text-xs font-racing text-slate-400">KM/H</span>
            </div>
          </div>
          <div className="h-10 w-px bg-white/10" />
          <div>
            <div className="text-[10px] uppercase tracking-widest text-slate-400">Sudut Slip</div>
            <div className="flex items-baseline gap-1">
              <span id="ds-angle-val" className="font-racing text-2xl font-bold text-cyan-400 leading-none tabular-nums">
                0°
              </span>
            </div>
          </div>
          <div className="h-10 w-px bg-white/10" />
          <div className="flex flex-col gap-1">
            <div
              id="ds-ebrake-indicator"
              className="px-2 py-0.5 rounded text-[10px] font-racing font-bold tracking-wider bg-slate-800 text-slate-500 border border-white/5 text-center"
            >
              E-BRAKE
            </div>
            <div className="px-2 py-0.5 rounded text-[10px] font-racing font-bold tracking-wider bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 text-center">
              ASSIST ON
            </div>
          </div>
        </div>
      </div>

      {/* BOTTOM RIGHT: CONTROLS & UTILITY */}
      <div className="fixed bottom-4 right-4 z-20 flex flex-col items-end gap-2">
        <div className="flex items-center gap-2 flex-wrap justify-end">
          <button
            type="button"
            onClick={() => apiRef.current?.toggleSound()}
            className="bg-[#0a0e17]/85 hover:bg-white/10 border border-white/15 px-3 py-1.5 rounded-lg text-xs font-medium text-slate-200 transition cursor-pointer whitespace-nowrap"
          >
            {soundOn ? 'Suara: On' : 'Suara: Off'}
          </button>
          <button
            type="button"
            onClick={() => apiRef.current?.cycleCamera()}
            className="bg-[#0a0e17]/85 hover:bg-white/10 border border-white/15 px-3 py-1.5 rounded-lg text-xs font-medium text-slate-200 transition cursor-pointer whitespace-nowrap"
          >
            Kamera: {camLabel}
          </button>
          <button
            type="button"
            onClick={() => apiRef.current?.resetCar()}
            className="bg-[#0a0e17]/85 hover:bg-rose-500/20 border border-white/15 hover:border-rose-400/40 px-3 py-1.5 rounded-lg text-xs font-medium text-slate-200 transition cursor-pointer whitespace-nowrap"
          >
            Reset (R)
          </button>
          <button
            type="button"
            onClick={onExit}
            className="bg-amber-500/90 hover:bg-amber-400 px-3 py-1.5 rounded-lg text-xs font-bold text-slate-950 transition cursor-pointer whitespace-nowrap"
          >
            Menu Arena (Esc)
          </button>
        </div>
        <div className="bg-[#0a0e17]/80 border border-white/10 rounded-xl px-3.5 py-2 text-[11px] text-slate-300 flex flex-wrap items-center gap-x-3 gap-y-1">
          <span>
            <kbd className="px-1.5 py-0.5 bg-slate-800 border border-white/15 rounded font-racing text-white">W</kbd> Gas
          </span>
          <span>
            <kbd className="px-1.5 py-0.5 bg-slate-800 border border-white/15 rounded font-racing text-white">S</kbd> Rem/Mundur
          </span>
          <span>
            <kbd className="px-1.5 py-0.5 bg-slate-800 border border-white/15 rounded font-racing text-white">A/D</kbd> Setir
          </span>
          <span>
            <kbd className="px-1.5 py-0.5 bg-amber-500/20 border border-amber-400/40 rounded font-racing text-amber-300">SPASI</kbd> Handbrake
          </span>
          <span>
            <kbd className="px-1.5 py-0.5 bg-slate-800 border border-white/15 rounded font-racing text-white">C</kbd> Kamera
          </span>
        </div>
      </div>

      {/* INTRO HINT */}
      <div
        ref={startHintRef}
        className="fixed bottom-24 left-1/2 -translate-x-1/2 z-20 pointer-events-none transition-opacity duration-500"
      >
        <div className="bg-[#0a0e17]/85 px-5 py-2.5 rounded-lg border border-cyan-400/30 text-sm text-cyan-200 font-medium shadow-lg">
          Tekan <strong className="text-white font-racing">W / A / S / D</strong> &amp;{' '}
          <strong className="text-amber-300 font-racing">SPASI</strong> untuk mulai nge-drift!
        </div>
      </div>
    </div>
  );
}
