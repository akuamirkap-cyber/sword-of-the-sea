import * as THREE from 'three';
import { buildTrack, type Track } from './trackLayout';
import {
  OX,
  OZ,
  RoadField,
  baseHeight,
  buildFarTerrain,
  buildLake,
  buildNearTerrain,
  type NearBounds,
  type Platform,
} from './terrain';
import { buildRoad, roadFrame, type RoadBuild } from './roadMesh';
import { buildScenery } from './scenery';
import { buildCar, PANDA, type CarRig } from './car';
import { CarSim, type CarInput } from './physics';
import { PRESETS, Sky } from './sky';
import { Petals, Skids, Smoke } from './effects';
import { GameAudio } from './audio';
import { installFog } from './fog';
import { clamp, lerp } from './noise';

export type Mode = 'loading' | 'menu' | 'countdown' | 'running' | 'finished';

export interface Hud {
  mode: Mode;
  speed: number;
  rpm: number;
  gear: number;
  time: number;
  penalty: number;
  score: number;
  chain: number;
  mult: number;
  drifting: boolean;
  angle: number;
  progress: number;
  section: string;
  sectionAt: number;
  countdown: number;
  topSpeed: number;
  bestChain: number;
  cam: string;
  preset: string;
  paused: boolean;
  muted: boolean;
  wallAt: number;
  assist: boolean;
  fps: number;
  s: number;
  total: number;
}

const CAM_NAMES = ['CHASE', 'HIGH', 'HOOD', 'TV'];

const angDiff = (a: number, b: number) => Math.atan2(Math.sin(a - b), Math.cos(a - b));

export class Game {
  renderer!: THREE.WebGLRenderer;
  scene = new THREE.Scene();
  camera = new THREE.PerspectiveCamera(62, 1, 0.8, 9500);
  sky!: Sky;
  track!: Track;
  field!: RoadField;
  road!: RoadBuild;
  rig!: CarRig;
  sim = new CarSim();
  smoke!: Smoke;
  skids!: Skids;
  petals!: Petals;
  audio = new GameAudio();
  petalsOn = 1;

  mode: Mode = 'loading';
  paused = false;
  camMode = 0;
  presetIdx = 0;
  keys = new Set<string>();
  touch = { left: false, right: false, gas: false, brake: false, hb: false };
  input: CarInput = { throttle: 0, brake: 0, steer: 0, handbrake: false, clutch: false };
  hud: Hud = {
    mode: 'loading',
    speed: 0,
    rpm: 0,
    gear: 1,
    time: 0,
    penalty: 0,
    score: 0,
    chain: 0,
    mult: 1,
    drifting: false,
    angle: 0,
    progress: 0,
    section: '',
    sectionAt: 0,
    countdown: 0,
    topSpeed: 0,
    bestChain: 0,
    cam: CAM_NAMES[0],
    preset: PRESETS[0].label,
    paused: false,
    muted: false,
    wallAt: 0,
    assist: true,
    fps: 60,
    s: 0,
    total: 0,
  };

  // interpolated render pose of the car (physics runs at a fixed 120 Hz)
  pose = { x: 0, y: 0, z: 0, psi: 0 };
  private prev = { x: 0, y: 0, z: 0, psi: 0 };

  // run state
  private raf = 0;
  private last = 0;
  private acc = 0;
  private runTime = 0;
  private penalty = 0;
  private cdTimer = 0;
  private lastCd = 4;
  private score = 0;
  private chain = 0;
  private chainTime = 0;
  private graceT = 0;
  private mult = 1;
  private topSpeed = 0;
  private bestChain = 0;
  private curSection = -1;
  private wheelAngle = 0;
  private smokeAcc = 0;
  private shake = 0;
  private fpsAcc = 0;
  private fpsN = 0;
  private time = 0;
  private hudT = 0;

  // camera state
  private camAng = 0;
  private camPos = new THREE.Vector3();
  private tvPos = new THREE.Vector3();
  private tvS = -999;
  private tvSide = 1;
  private fovCur = 62;
  debugCam: { pos: THREE.Vector3; look: THREE.Vector3; fov: number } | null = null;

  // showcase (menu)
  private sc = { s: 330, v: 14, slip: 0, lat: 1.5 };

  mapPts: [number, number][] = [];
  mapBounds = { x0: 0, x1: 1, z0: 0, z1: 1 };

  constructor(public container: HTMLElement) {}

  /* -------------------------------------------------------------- */
  async init(onProgress: (p: number, label: string) => void) {
    const tick = () => new Promise<void>((r) => setTimeout(r, 20));
    const canvas = document.createElement('canvas');
    canvas.style.cssText = 'position:absolute;inset:0;width:100%;height:100%;display:block;filter:saturate(1.26) contrast(1.08) brightness(1.02)';
    this.container.appendChild(canvas);
    this.renderer = new THREE.WebGLRenderer({ canvas, antialias: true, powerPreference: 'high-performance', preserveDrawingBuffer: location.search.includes('debug') });
    this.renderer.setPixelRatio(Math.min(window.devicePixelRatio, 1.75));
    this.renderer.shadowMap.enabled = true;
    this.renderer.shadowMap.type = THREE.PCFSoftShadowMap;
    this.renderer.toneMapping = THREE.NeutralToneMapping;
    installFog();
    this.scene.fog = new THREE.FogExp2(0xd0e6f6, 0.00027);
    this.sky = new Sky(this.scene);
    this.sky.apply(PRESETS[0], this.renderer);
    this.resize();

    onProgress(0.05, 'Carving Mt. Haruna…');
    await tick();
    // 1. layout
    this.track = buildTrack(baseHeight, OX, OZ);
    const tr = this.track;
    const sF = Math.floor(tr.startS);
    const lotC = roadFrame(tr, sF - 36, 31);
    const startLot: Platform = { x: lotC.x, z: lotC.z, r: 22, y: tr.y[sF - 36] };
    const endI = tr.n - 1;
    const endF = roadFrame(tr, endI, 0);
    const finishPlaza: Platform = {
      x: endF.x + endF.f.x * 44,
      z: endF.z + endF.f.z * 44,
      r: 46,
      y: tr.y[endI] - 0.2,
    };
    this.field = new RoadField(tr, [startLot, finishPlaza], 3);
    let minX = 1e9;
    let maxX = -1e9;
    let minZ = 1e9;
    let maxZ = -1e9;
    for (let i = 0; i < tr.n; i++) {
      minX = Math.min(minX, tr.x[i]);
      maxX = Math.max(maxX, tr.x[i]);
      minZ = Math.min(minZ, tr.z[i]);
      maxZ = Math.max(maxZ, tr.z[i]);
    }
    const g = 4;
    const margin = 185;
    const near: NearBounds = {
      x0: Math.floor((minX - margin) / g) * g,
      x1: Math.ceil((maxX + margin) / g) * g,
      z0: Math.floor((minZ - margin - 40) / g) * g,
      z1: Math.ceil((maxZ + margin + 60) / g) * g,
    };
    this.mapBounds = { x0: minX, x1: maxX, z0: minZ, z1: maxZ };
    for (let i = 0; i < tr.n; i += 8) this.mapPts.push([tr.x[i], tr.z[i]]);

    onProgress(0.15, 'Sculpting the mountain…');
    await tick();
    const nearMesh = buildNearTerrain(this.field, near, g);
    this.scene.add(nearMesh);

    onProgress(0.45, 'Painting distant ranges…');
    await tick();
    this.scene.add(buildFarTerrain(near));
    this.scene.add(buildLake());

    onProgress(0.58, 'Laying asphalt, guardrails & gutters…');
    await tick();
    this.road = buildRoad(tr, this.field);
    this.scene.add(this.road.group);

    onProgress(0.7, 'Planting cedars & cherry blossoms…');
    await tick();
    const sc = buildScenery({ field: this.field, track: tr, road: this.road, near, startLot, finishPlaza });
    this.scene.add(sc.group);

    onProgress(0.9, 'Warming up the Hachiroku…');
    await tick();
    this.rig = buildCar(PANDA);
    this.scene.add(this.rig.root);
    this.smoke = new Smoke(this.scene);
    this.skids = new Skids(this.scene);
    this.petals = new Petals(this.scene);
    this.resize();
    this.sim.reset(tr, this.sc.s);
    this.syncPrev();

    window.addEventListener('keydown', this.onKeyDown);
    window.addEventListener('keyup', this.onKeyUp);
    window.addEventListener('resize', this.resize);
    document.addEventListener('visibilitychange', this.onVis);

    // pre-compile shaders
    this.renderer.compile(this.scene, this.camera);
    onProgress(1, 'Ready');
    this.mode = 'menu';
    this.hud.mode = 'menu';
    this.hud.total = tr.length;
    this.last = performance.now();
    this.raf = requestAnimationFrame(this.frame);
  }

  dispose() {
    cancelAnimationFrame(this.raf);
    window.removeEventListener('keydown', this.onKeyDown);
    window.removeEventListener('keyup', this.onKeyUp);
    window.removeEventListener('resize', this.resize);
    document.removeEventListener('visibilitychange', this.onVis);
    this.renderer?.dispose();
    this.renderer?.domElement.remove();
  }

  /* -------------------------------------------------------------- */
  private onVis = () => {
    this.last = performance.now();
  };

  resize = () => {
    if (!this.renderer) return;
    const w = this.container.clientWidth || window.innerWidth;
    const h = this.container.clientHeight || window.innerHeight;
    this.renderer.setSize(w, h, false);
    this.camera.aspect = w / h;
    this.camera.updateProjectionMatrix();
    this.petals?.setScale(h * this.renderer.getPixelRatio());
  };

  private onKeyDown = (e: KeyboardEvent) => {
    const k = e.key.toLowerCase();
    if (['arrowup', 'arrowdown', 'arrowleft', 'arrowright', ' '].includes(k)) e.preventDefault();
    if (e.repeat) return;
    this.keys.add(k);
    if (k === 'shift') this.sim.kick = 0.5;
    if (k === 'c') this.cycleCamera();
    if (k === 't') this.cyclePreset();
    if (k === 'm') this.toggleMute();
    if (k === 'r') this.respawn();
    if (k === 'p' || k === 'escape') this.togglePause();
    if (k === 'enter' && this.mode === 'menu') this.startRun();
    if (k === 'enter' && this.mode === 'finished') this.toMenu();
    if (k === 'g') {
      this.sim.assist = this.sim.assist > 0 ? 0 : 0.75;
      this.hud.assist = this.sim.assist > 0;
    }
  };
  private onKeyUp = (e: KeyboardEvent) => {
    this.keys.delete(e.key.toLowerCase());
  };

  cycleCamera() {
    this.camMode = (this.camMode + 1) % CAM_NAMES.length;
    this.hud.cam = CAM_NAMES[this.camMode];
    this.camera.near = this.camMode === 2 ? 0.15 : 0.8;
    this.camera.updateProjectionMatrix();
  }
  cyclePreset() {
    this.presetIdx = (this.presetIdx + 1) % PRESETS.length;
    this.sky.apply(PRESETS[this.presetIdx], this.renderer);
    this.hud.preset = PRESETS[this.presetIdx].label;
  }
  toggleMute() {
    this.hud.muted = !this.hud.muted;
    this.audio.setMuted(this.hud.muted);
  }
  togglePause() {
    if (this.mode !== 'running' && this.mode !== 'countdown') return;
    this.paused = !this.paused;
    this.hud.paused = this.paused;
  }
  toggleAssist() {
    this.sim.assist = this.sim.assist > 0 ? 0 : 0.75;
    this.hud.assist = this.sim.assist > 0;
  }

  respawn() {
    if (this.mode !== 'running') return;
    const s = Math.max(this.track.startS - 10, this.sim.idx - 6);
    this.sim.reset(this.track, s, 0);
    this.syncPrev();
    this.penalty += 5;
    this.chain = 0;
    this.mult = 1;
    this.skids.clear();
    this.smoke.clear();
  }

  startRun() {
    if (this.mode === 'loading') return;
    this.audio.start();
    this.sim.reset(this.track, this.track.startS - 22, 1.6);
    this.sim.kick = 0;
    this.syncPrev();
    this.mode = 'countdown';
    this.hud.mode = 'countdown';
    this.cdTimer = 3.2;
    this.lastCd = 4;
    this.runTime = 0;
    this.penalty = 0;
    this.score = 0;
    this.chain = 0;
    this.mult = 1;
    this.topSpeed = 0;
    this.bestChain = 0;
    this.curSection = -1;
    this.paused = false;
    this.hud.paused = false;
    this.skids.clear();
    this.smoke.clear();
    this.camMode = this.camMode === 3 ? 0 : this.camMode;
    this.hud.cam = CAM_NAMES[this.camMode];
    this.camAng = this.sim.psi;
    this.snapCamera = true;
  }
  private snapCamera = true;

  toMenu() {
    this.mode = 'menu';
    this.hud.mode = 'menu';
    this.sc.s = 330;
    this.sc.v = 14;
    this.tvS = -999;
    this.skids.clear();
    this.smoke.clear();
  }

  private syncPrev() {
    const s = this.sim;
    this.prev.x = s.x;
    this.prev.y = s.y;
    this.prev.z = s.z;
    this.prev.psi = s.psi;
    this.acc = 0;
  }

  /** debug helpers used by automated screenshots */
  stop() {
    cancelAnimationFrame(this.raf);
  }
  renderOnce(dt = 0.016, steps = 1) {
    for (let i = 0; i < steps; i++) {
      this.update(dt);
      this.updateCamera(dt);
    }
    this.sky.update(dt, this.camera.position);
    this.sky.followSun(this.rig.root.position);
    this.renderer.render(this.scene, this.camera);
  }
  showcaseAt(s: number) {
    this.sc.s = s;
    this.sc.v = 16;
  }
  /** debug helper used by automated screenshots */
  teleport(s: number, lat = 0) {
    this.sim.reset(this.track, s, lat);
    this.syncPrev();
  }

  /* -------------------------------------------------------------- */
  private frame = (now: number) => {
    this.raf = requestAnimationFrame(this.frame);
    const dt = Math.min(0.05, (now - this.last) / 1000);
    this.last = now;
    this.fpsAcc += dt;
    this.fpsN++;
    if (this.fpsAcc > 0.5) {
      this.hud.fps = Math.round(this.fpsN / this.fpsAcc);
      this.fpsAcc = 0;
      this.fpsN = 0;
    }
    if (!this.paused) this.update(dt);
    this.updateCamera(dt);
    this.sky.update(dt, this.camera.position);
    this.sky.followSun(this.rig.root.position);
    this.renderer.render(this.scene, this.camera);
  };

  private readInput() {
    const k = this.keys;
    const t = this.touch;
    const left = k.has('arrowleft') || k.has('a') || t.left;
    const right = k.has('arrowright') || k.has('d') || t.right;
    this.input.throttle = k.has('arrowup') || k.has('w') || t.gas ? 1 : 0;
    this.input.brake = k.has('arrowdown') || k.has('s') || t.brake ? 1 : 0;
    this.input.steer = (left ? 1 : 0) - (right ? 1 : 0);
    this.input.handbrake = k.has(' ') || t.hb;
  }

  private update(dt: number) {
    this.time += dt;
    const sim = this.sim;
    const tr = this.track;

    if (this.mode === 'menu') {
      this.updateShowcase(dt);
    } else {
      this.readInput();
      if (this.mode === 'countdown') {
        this.cdTimer -= dt;
        const c = Math.ceil(this.cdTimer);
        if (c !== this.lastCd) {
          this.lastCd = c;
          if (c > 0) this.audio.beep(520, 0.15);
          else if (c <= 0) this.audio.beep(1040, 0.5);
        }
        this.hud.countdown = Math.max(0, c);
        this.stepPhysics(dt, true);
        if (this.cdTimer <= 0) {
          this.mode = 'running';
          this.hud.mode = 'running';
          this.hud.sectionAt = performance.now();
          this.hud.section = 'SUMMIT PARKING';
        }
      } else if (this.mode === 'running') {
        this.runTime += dt;
        this.stepPhysics(dt, false);
        this.scoreStep(dt);
        // section announcements
        const secs = tr.sections;
        for (let k = secs.length - 1; k >= 0; k--) {
          if (sim.idx >= secs[k].s0 - 8) {
            if (k !== this.curSection) {
              this.curSection = k;
              this.hud.section = secs[k].name;
              this.hud.sectionAt = performance.now();
            }
            break;
          }
        }
        if (sim.idx >= tr.finishS) this.finish();
      } else if (this.mode === 'finished') {
        this.stepPhysics(dt, false, true);
      }
    }
    this.syncCar(dt);
    this.updateEffects(dt);
    this.updateHud(dt);
  }

  private stepPhysics(dt: number, locked: boolean, autoBrake = false) {
    this.acc += dt;
    const h = 1 / 120;
    let n = 0;
    const sim = this.sim;
    let hit = 0;
    while (this.acc >= h && n < 8) {
      this.prev.x = sim.x;
      this.prev.y = sim.y;
      this.prev.z = sim.z;
      this.prev.psi = sim.psi;
      if (autoBrake) {
        const inp: CarInput = { throttle: 0, brake: 1, steer: 0, handbrake: false, clutch: false };
        sim.step(h, inp, this.track, false);
      } else {
        sim.step(h, this.input, this.track, locked);
      }
      hit = Math.max(hit, sim.wallHit);
      this.acc -= h;
      n++;
    }
    if (n === 8) this.acc = 0;
    if (hit > 1.2) {
      this.shake = Math.min(1, this.shake + hit * 0.06);
      this.audio.thump(hit);
      if (this.mode === 'running') {
        this.chain = 0;
        this.mult = 1;
        this.graceT = 0;
        this.hud.wallAt = performance.now();
      }
      // dust burst
      const p = this.rig.root.position;
      for (let i = 0; i < 6; i++) {
        this.smoke.emit(p.x + (Math.random() - 0.5) * 2, p.y + 0.6, p.z + (Math.random() - 0.5) * 2, (Math.random() - 0.5) * 3, 1 + Math.random() * 2, (Math.random() - 0.5) * 3, 0.8 + Math.random() * 0.8, 0.9);
      }
    }
    this.topSpeed = Math.max(this.topSpeed, sim.speedKmh);
  }

  private scoreStep(dt: number) {
    const sim = this.sim;
    const slipDeg = Math.abs(sim.slip) * 57.3;
    const drifting = slipDeg > 13 && sim.speedKmh > 28 && !sim.onWall && sim.u > 0;
    if (drifting) {
      this.graceT = 0.9;
      this.chainTime += dt;
      this.mult = clamp(1 + Math.floor(this.chainTime / 2.0), 1, 8);
      this.chain += slipDeg * sim.speedKmh * 0.045 * this.mult * dt;
      this.bestChain = Math.max(this.bestChain, this.chain);
    } else if (this.graceT > 0) {
      this.graceT -= dt;
    } else if (this.chain > 0) {
      this.score += this.chain;
      this.chain = 0;
      this.chainTime = 0;
      this.mult = 1;
    } else {
      this.chainTime = 0;
      this.mult = 1;
    }
    this.hud.drifting = drifting;
  }

  private finish() {
    this.mode = 'finished';
    this.hud.mode = 'finished';
    this.score += this.chain;
    this.chain = 0;
    this.tvS = -999;
    this.camMode = 3;
    this.hud.cam = 'TV';
    this.camera.near = 0.8;
    this.camera.updateProjectionMatrix();
    this.audio.beep(880, 0.35);
  }

  /** kinematic "TV broadcast" drift car for the title screen */
  private updateShowcase(dt: number) {
    const tr = this.track;
    const sc = this.sc;
    const i = Math.floor(sc.s);
    let kmax = 0;
    for (let j = 0; j < 80; j += 4) kmax = Math.max(kmax, Math.abs(tr.kappa[Math.min(tr.n - 2, i + j)]) * (1 - j / 200));
    const vt = clamp(Math.sqrt(8.5 / Math.max(kmax, 1e-4)), 13, 27);
    sc.v += clamp(vt - sc.v, -9 * dt, 6 * dt);
    sc.s += sc.v * dt;
    if (sc.s > tr.finishS - 10) {
      sc.s = 130;
      this.skids.clear();
    }
    const i0 = Math.floor(sc.s);
    const f = sc.s - i0;
    const k0 = tr.kappa[i0];
    const kSm = lerp(tr.kappa[Math.max(0, i0 - 8)], tr.kappa[Math.min(tr.n - 1, i0 + 8)], 0.5) * 0.5 + k0 * 0.5;
    const slipT = clamp(kSm * 17, -0.78, 0.78);
    sc.slip += (slipT - sc.slip) * Math.min(1, dt * 3.2);
    const latT = clamp(kSm * 70, -2.6, 2.6) + 1.2;
    sc.lat += (latT - sc.lat) * Math.min(1, dt * 2);
    const x = lerp(tr.x[i0], tr.x[i0 + 1], f);
    const z = lerp(tr.z[i0], tr.z[i0 + 1], f);
    const ps = tr.psi[i0] + angDiff(tr.psi[i0 + 1], tr.psi[i0]) * f;
    const y = lerp(tr.y[i0], tr.y[i0 + 1], f);
    const sim = this.sim;
    sim.x = x + sc.lat * Math.cos(ps);
    sim.z = z - sc.lat * Math.sin(ps);
    sim.y = y;
    sim.psi = ps + sc.slip;
    sim.idx = i0;
    sim.u = sc.v * Math.cos(sc.slip);
    sim.v = -sc.v * Math.sin(sc.slip) * 1.0;
    // velocity direction follows the road, nose points into the corner
    sim.delta = -sc.slip * 0.9 + kSm * 4;
    sim.rearSpin = clamp(Math.abs(sc.slip) / 0.3, 0, 1.3);
    sim.frontSlip = 0;
    sim.speedKmh = sc.v * 3.6;
    sim.thr = Math.abs(sc.slip) > 0.15 ? 0.9 : 0.5;
    sim.rpm = 3500 + sc.v * 160 + sim.thr * 600;
    sim.gear = sc.v > 20 ? 3 : 2;
    sim.grade = (tr.y[i0] - tr.y[i0 + 1]);
    sim.pitch = 0;
    sim.slip = -sc.slip;
    sim.w = kSm * sc.v;
    sim.ax = 0;
  }

  private syncCar(dt: number) {
    const sim = this.sim;
    const rig = this.rig;
    const P = this.pose;
    if (this.mode === 'menu') {
      P.x = sim.x;
      P.y = sim.y;
      P.z = sim.z;
      P.psi = sim.psi;
    } else {
      const a = clamp(this.acc / (1 / 120), 0, 1);
      P.x = lerp(this.prev.x, sim.x, a);
      P.y = lerp(this.prev.y, sim.y, a);
      P.z = lerp(this.prev.z, sim.z, a);
      P.psi = this.prev.psi + angDiff(sim.psi, this.prev.psi) * a;
    }
    rig.root.position.set(P.x, P.y + 0.02, P.z);
    rig.root.rotation.y = P.psi;
    const dpsi = angDiff(sim.psi, this.track.psi[sim.idx]);
    const pitch = clamp(Math.atan(sim.grade * Math.cos(dpsi)) * 0.9 - sim.ax * 0.0035, -0.25, 0.25);
    rig.body.rotation.x = pitch;
    rig.body.rotation.z = clamp(sim.u * sim.w * 0.0042, -0.09, 0.09);
    rig.body.position.y = 0.0;
    this.wheelAngle += (sim.u / 0.31) * dt;
    rig.wheelSpin.forEach((w) => (w.rotation.x = this.wheelAngle));
    rig.frontPivots.forEach((p) => (p.rotation.y = sim.delta));
    // brake lights
    const braking = this.mode !== 'menu' && (this.input.brake > 0 || this.mode === 'finished');
    rig.tailMat.color.setHex(braking ? 0xff2a2a : 0x9e1b22);
  }

  private wheelWorld(lx: number, lz: number, out: THREE.Vector3) {
    const s = this.pose;
    const c = Math.cos(s.psi);
    const si = Math.sin(s.psi);
    out.set(s.x + lx * c + lz * si, s.y, s.z - lx * si + lz * c);
    return out;
  }

  private _w = new THREE.Vector3();

  private updateEffects(dt: number) {
    const sim = this.sim;
    const c = Math.cos(this.pose.psi);
    const si = Math.sin(this.pose.psi);
    const spd = sim.speedKmh;
    const rearSliding = sim.rearSpin > 0.38 && spd > 8 && this.mode !== 'finished';
    const frontSliding = Math.abs(sim.frontSlip) > 0.26 && spd > 12;
    const wheels: [number, number, boolean, number][] = [
      [0.76, 1.25, true, 0],
      [-0.76, 1.25, true, 1],
      [0.76, -1.2, false, 2],
      [-0.76, -1.2, false, 3],
    ];
    for (const [lx, lz, front, wi] of wheels) {
      this.wheelWorld(lx, lz, this._w);
      const on = front ? frontSliding : rearSliding;
      this.skids.add(wi, this._w, c, -si, on, front ? 0.55 : clamp(sim.rearSpin * 0.9, 0.3, 1), 0.12);
    }
    // smoke from the rear tyres (and a little from the fronts when plowing)
    if (rearSliding) {
      this.smokeAcc += dt * (12 + sim.rearSpin * 34 + spd * 0.25);
      const vx = sim.vxw;
      const vz = sim.vzw;
      while (this.smokeAcc >= 1) {
        this.smokeAcc -= 1;
        const side = Math.random() < 0.5 ? 0.76 : -0.76;
        this.wheelWorld(side + (Math.random() - 0.5) * 0.3, -1.3 + (Math.random() - 0.5) * 0.3, this._w);
        const big = 0.85 + Math.random() * 1.0 + sim.rearSpin * 0.55;
        this.smoke.emit(
          this._w.x,
          this._w.y + 0.25,
          this._w.z,
          vx * 0.28 + (Math.random() - 0.5) * 2.4,
          0.7 + Math.random() * 1.4,
          vz * 0.28 + (Math.random() - 0.5) * 2.4,
          big,
          1.2 + Math.random() * 1.1
        );
      }
    } else {
      this.smokeAcc = 0;
    }
    if (frontSliding && Math.random() < 0.4) {
      this.wheelWorld(0.76 * (Math.random() < 0.5 ? 1 : -1), 1.25, this._w);
      this.smoke.emit(this._w.x, this._w.y + 0.2, this._w.z, sim.vxw * 0.15, 0.5, sim.vzw * 0.15, 0.7, 1.0);
    }
    this.smoke.update(dt, this.camera.position);
    this.petals.update(dt, this.camera.position, this.time, this.petalsOn);

    // audio
    const sq = clamp(Math.max(sim.rearSpin * 0.9, Math.abs(sim.frontSlip) * 2.2), 0, 1) * (spd > 8 ? 1 : 0);
    this.audio.update(sim.rpm, sim.thr, Math.abs(sim.u), sq, this.mode === 'running' || this.mode === 'countdown' || this.mode === 'finished');
  }

  private updateHud(dt: number) {
    this.hudT += dt;
    const h = this.hud;
    const sim = this.sim;
    h.speed = sim.speedKmh;
    h.rpm = sim.rpm;
    h.gear = sim.gear;
    h.time = this.runTime + this.penalty;
    h.penalty = this.penalty;
    h.score = this.score;
    h.chain = this.chain;
    h.mult = this.mult;
    h.angle = Math.abs(sim.slip) * 57.3;
    h.progress = clamp((sim.idx - this.track.startS) / (this.track.finishS - this.track.startS), 0, 1);
    h.topSpeed = this.topSpeed;
    h.bestChain = this.bestChain;
    h.s = sim.idx;
    if (this.mode !== 'running') h.drifting = false;
  }

  /* -------------------------------------------------------------- */
  private updateCamera(dt: number) {
    const cam = this.camera;
    const sim = this.sim;
    if (this.debugCam) {
      cam.position.copy(this.debugCam.pos);
      cam.lookAt(this.debugCam.look);
      if (cam.fov !== this.debugCam.fov) {
        cam.fov = this.debugCam.fov;
        cam.updateProjectionMatrix();
      }
      return;
    }
    const menuLike = this.mode === 'menu' || this.mode === 'finished';
    const mode = menuLike ? 3 : this.camMode;
    const speed = Math.hypot(sim.u, sim.v);
    const P = this.pose;
    const carP = new THREE.Vector3(P.x, P.y, P.z);
    let fovT = 62;
    const desired = new THREE.Vector3();
    const look = new THREE.Vector3();

    if (mode === 3) {
      // roadside TV-camera: pick a vantage point ahead of the car, track it as it passes
      const tr = this.track;
      const s = sim.idx;
      if (this.tvS < 0 || s > this.tvIdx + 14 || s < this.tvIdx - 170) {
        this.tvSide = this.tvSide * -1;
        const ahead = this.mode === 'menu' ? 42 + Math.random() * 30 : 45 + Math.random() * 25;
        const si = clamp(Math.floor(s + ahead), 2, tr.n - 2);
        // prefer the open (drop-off) side so the view across the valley is not blocked by a cut slope
        const k = tr.kappa[si];
        const cl = this.road.cutL[si] === 1;
        const cr = this.road.cutR[si] === 1;
        let lat: number;
        if (!cl && !cr) lat = (k > 0 ? -1 : 1) * (6.9 + Math.random() * 1.1);
        else if (!cl) lat = 6.9 + Math.random() * 1.1;
        else if (!cr) lat = -(6.9 + Math.random() * 1.1);
        else lat = (Math.random() - 0.5) * 3;
        const fr = roadFrame(tr, si, lat);
        const hh = this.field.height(fr.x, fr.z);
        this.tvPos.set(fr.x, Math.max(hh, tr.y[si] - 0.7) + 1.7 + Math.random() * 2.2, fr.z);
        this.tvS = s;
        this.tvIdx = si;
      }
      desired.copy(this.tvPos);
      look.copy(carP);
      look.y += 0.9;
      fovT = clamp((2 * Math.atan(6.5 / Math.max(8, desired.distanceTo(carP))) * 180) / Math.PI, 20, 62);
      this.camPos.lerp(desired, this.snapCamera ? 1 : 1 - Math.exp(-dt * 30));
    } else if (mode === 2) {
      const f = new THREE.Vector3(Math.sin(P.psi), 0, Math.cos(P.psi));
      desired.set(P.x + f.x * 0.25, P.y + 1.18, P.z + f.z * 0.25);
      const ang = P.psi + clamp(sim.slip * 0.0, -1, 1);
      look.set(P.x + Math.sin(ang) * 20, P.y + 1.0, P.z + Math.cos(ang) * 20);
      this.camPos.copy(desired);
      fovT = 74 + speed * 0.12;
    } else {
      const velAng = speed > 5 ? Math.atan2(sim.vxw, sim.vzw) : P.psi;
      const target = P.psi + angDiff(velAng, P.psi) * 0.5;
      this.camAng += angDiff(target, this.camAng) * (1 - Math.exp(-dt * (this.snapCamera ? 40 : 3.8)));
      const dist = mode === 1 ? 17 + speed * 0.07 : 6.4 + speed * 0.03;
      const hgt = mode === 1 ? 12.5 : 2.3 + speed * 0.008;
      desired.set(P.x - Math.sin(this.camAng) * dist, P.y + hgt, P.z - Math.cos(this.camAng) * dist);
      look.set(P.x + Math.sin(this.camAng) * (mode === 1 ? 6 : 4.5), P.y + (mode === 1 ? 0.5 : 1.35), P.z + Math.cos(this.camAng) * (mode === 1 ? 6 : 4.5));
      this.camPos.lerp(desired, this.snapCamera ? 1 : 1 - Math.exp(-dt * 10));
      fovT = (mode === 1 ? 48 : 61) + clamp(speed * 0.22, 0, 14);
    }
    this.snapCamera = false;

    // keep the camera out of the ground
    const gh = this.field.height(this.camPos.x, this.camPos.z);
    if (this.camGround === 0 || this.snapCamera) this.camGround = gh;
    this.camGround += (gh - this.camGround) * (1 - Math.exp(-dt * 10));
    if (this.camPos.y < this.camGround + 1.1) this.camPos.y = this.camGround + 1.1;

    cam.position.copy(this.camPos);
    if (this.shake > 0.001) {
      cam.position.x += (Math.random() - 0.5) * this.shake * 0.7;
      cam.position.y += (Math.random() - 0.5) * this.shake * 0.5;
      cam.position.z += (Math.random() - 0.5) * this.shake * 0.7;
      this.shake *= Math.exp(-dt * 6);
    }
    cam.lookAt(look);
    this.fovCur += (fovT - this.fovCur) * Math.min(1, dt * 4);
    if (Math.abs(cam.fov - this.fovCur) > 0.02) {
      cam.fov = this.fovCur;
      cam.updateProjectionMatrix();
    }
  }
  private tvIdx = 0;
  private camGround = 0;
}

