import { clamp } from './noise';

/**
 * MT. HARUNA / "AKINA" TOUGE DOWNHILL — layout.
 * The centreline is defined as a sequence of [mark, length(m), turn(deg, + = left)].
 * Heading psi: 0 = south (downhill), +90 = east. Direction = (sin psi, cos psi) on (x, z).
 */
type Seg = [string | null, number, number];

const START_PSI = 72;

const SEGS: Seg[] = [
  ['SUMMIT PARKING', 120, 0],
  ['LAKESIDE SWEEPERS', 100, -34],
  [null, 16, 0],
  [null, 110, 36],
  [null, 24, 0],
  ['LAKE BEND', 112, -150],
  [null, 50, 0],
  [null, 70, 26],
  [null, 80, -26],
  [null, 24, 0],
  ['FIRST HAIRPIN', 58, 150],
  [null, 96, 0],
  ['SECOND HAIRPIN', 58, -150],
  [null, 82, 0],
  ['FIVE CONSECUTIVE HAIRPINS', 57, 150],
  [null, 52, 0],
  [null, 57, -150],
  [null, 52, 0],
  [null, 57, 150],
  [null, 52, 0],
  [null, 57, -150],
  [null, 52, 0],
  [null, 57, 150],
  [null, 40, 0],
  ['SAKURA SWEEPERS', 100, -20],
  [null, 20, 0],
  [null, 110, 24],
  [null, 20, 0],
  ['SAKURA BEND', 92, -152],
  [null, 30, 0],
  [null, 80, 24],
  [null, 90, -26],
  [null, 20, 0],
  ['BLIND CORNER', 88, 148],
  [null, 70, 0],
  [null, 70, -22],
  [null, 50, 22],
  [null, 20, 0],
  ['GUTTER HAIRPIN', 58, -150],
  [null, 90, 0],
  ['LONG DOWNHILL', 180, 137],
  [null, 120, 0],
  [null, 60, -60],
  ['AKINA FOOT', 100, 0],
  [null, 80, 0],
];

export interface Section {
  name: string;
  s0: number;
  s1: number;
}

export interface Track {
  n: number;
  ds: number;
  length: number;
  x: Float32Array;
  y: Float32Array;
  z: Float32Array;
  psi: Float32Array;
  kappa: Float32Array;
  /** +1 if the uphill side of the road is on the left, -1 if on the right */
  uphill: Float32Array;
  sections: Section[];
  startS: number;
  finishS: number;
}

export function buildCenterline(ds = 1) {
  // 1. curvature profile
  const total = SEGS.reduce((a, s) => a + s[1], 0);
  const n = Math.floor(total / ds) + 1;
  const kap = new Float32Array(n);
  const sections: Section[] = [];
  let acc = 0;
  for (const [mark, len, turn] of SEGS) {
    const k = ((turn * Math.PI) / 180) / len;
    if (mark) {
      if (sections.length) sections[sections.length - 1].s1 = acc;
      sections.push({ name: mark, s0: acc, s1: total });
    }
    const i0 = Math.floor(acc / ds);
    const i1 = Math.floor((acc + len) / ds);
    for (let i = i0; i < i1 && i < n; i++) kap[i] = k;
    acc += len;
  }
  // 2. smooth curvature (two box passes) for natural entry / exit
  const smooth = (src: Float32Array, w: number) => {
    const out = new Float32Array(src.length);
    for (let i = 0; i < src.length; i++) {
      let sum = 0;
      let c = 0;
      for (let j = -w; j <= w; j++) {
        const q = i + j;
        if (q >= 0 && q < src.length) {
          sum += src[q];
          c++;
        }
      }
      out[i] = sum / c;
    }
    return out;
  };
  const kap2 = smooth(smooth(kap, 7), 7);
  // 3. integrate
  const x = new Float32Array(n);
  const z = new Float32Array(n);
  const psi = new Float32Array(n);
  let p = (START_PSI * Math.PI) / 180;
  let px = 0;
  let pz = 0;
  for (let i = 0; i < n; i++) {
    x[i] = px;
    z[i] = pz;
    psi[i] = p;
    p += kap2[i] * ds;
    px += Math.sin(p) * ds;
    pz += Math.cos(p) * ds;
  }
  return { n, ds, length: (n - 1) * ds, x, z, psi, kappa: kap2, sections };
}

/**
 * Builds the final track: centreline + elevation.
 * `base` is the natural mountain height; the road elevation follows it, heavily smoothed,
 * so grades stay realistic (hairpins get benches / cuts instead of crazy slopes).
 */
export function buildTrack(base: (x: number, z: number) => number, ox: number, oz: number): Track {
  const c = buildCenterline(1);
  const n = c.n;
  const x = new Float32Array(n);
  const z = new Float32Array(n);
  for (let i = 0; i < n; i++) {
    x[i] = c.x[i] + ox;
    z[i] = c.z[i] + oz;
  }
  // raw elevation from natural terrain
  let y: Float64Array = new Float64Array(n);
  for (let i = 0; i < n; i++) y[i] = base(x[i], z[i]);
  // gaussian-ish smoothing, wide window
  const blur = (src: Float64Array, w: number, passes: number) => {
    let a = src;
    for (let k = 0; k < passes; k++) {
      const out = new Float64Array(n);
      // prefix sums for speed
      const pre = new Float64Array(n + 1);
      for (let i = 0; i < n; i++) pre[i + 1] = pre[i] + a[i];
      for (let i = 0; i < n; i++) {
        const lo = Math.max(0, i - w);
        const hi = Math.min(n - 1, i + w);
        out[i] = (pre[hi + 1] - pre[lo]) / (hi - lo + 1);
      }
      a = out;
    }
    return a;
  };
  y = blur(y, 38, 3);
  // never climb: monotonic descent with a tiny minimum fall
  for (let i = 1; i < n; i++) if (y[i] > y[i - 1] - 0.004) y[i] = y[i - 1] - 0.004;
  y = blur(y, 10, 2);

  // uphill side detection
  const uphill = new Float32Array(n);
  for (let i = 0; i < n; i++) {
    const ps = c.psi[i];
    const lx = Math.cos(ps);
    const lz = -Math.sin(ps);
    const hl = base(x[i] + lx * 22, z[i] + lz * 22);
    const hr = base(x[i] - lx * 22, z[i] - lz * 22);
    uphill[i] = hl >= hr ? 1 : -1;
  }
  // smooth the sign so it does not flicker on flat bits
  const sm = new Float32Array(n);
  for (let i = 0; i < n; i++) {
    let s = 0;
    for (let j = -25; j <= 25; j++) s += uphill[clamp(i + j, 0, n - 1)];
    sm[i] = s >= 0 ? 1 : -1;
  }

  const startS = 105;
  const finishS = c.length - 36;
  return {
    n,
    ds: 1,
    length: c.length,
    x,
    y: Float32Array.from(y),
    z,
    psi: c.psi,
    kappa: c.kappa,
    uphill: sm,
    sections: c.sections,
    startS,
    finishS,
  };
}
