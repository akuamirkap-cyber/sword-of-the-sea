import * as THREE from 'three';
import { mergeGeometries } from 'three/examples/jsm/utils/BufferGeometryUtils.js';
import type { Track } from './trackLayout';
import { LAKE, RoadField, autumnMask, baseHeight, blossomMask, meadowMask, type NearBounds, type Platform } from './terrain';
import { buildCar, PANDA, STYLE_BLUE, STYLE_RED, STYLE_SILVER, STYLE_YELLOW } from './car';
import type { CarStyle } from './car';
import { canvasTex, roadFrame, type RoadBuild } from './roadMesh';
import { clamp, fbm, lerp, mulberry32, smoothstep } from './noise';

const C = (h: number) => new THREE.Color(h);

/* ------------------------------------------------------------------ */
/* Geometry baking (per-face colours = faceted low-poly look)           */
/* ------------------------------------------------------------------ */
function bake(geo: THREE.BufferGeometry, colorFn: (cy: number, face: number) => THREE.Color) {
  const g = geo.index ? geo.toNonIndexed() : geo.clone();
  g.deleteAttribute('uv');
  const pos = g.attributes.position;
  const tris = pos.count / 3;
  const col = new Float32Array(pos.count * 3);
  for (let t = 0; t < tris; t++) {
    const cy = (pos.getY(t * 3) + pos.getY(t * 3 + 1) + pos.getY(t * 3 + 2)) / 3;
    const c = colorFn(cy, t);
    for (let k = 0; k < 3; k++) {
      col[(t * 3 + k) * 3] = c.r;
      col[(t * 3 + k) * 3 + 1] = c.g;
      col[(t * 3 + k) * 3 + 2] = c.b;
    }
  }
  g.setAttribute('color', new THREE.BufferAttribute(col, 3));
  return g;
}

const faceRnd = (face: number, salt = 0) => {
  const s = Math.sin(face * 78.233 + salt * 12.9898) * 43758.5453;
  return s - Math.floor(s);
};

function jitterColor(c: THREE.Color, face: number, amt = 0.1) {
  const j = 1 + (faceRnd(face) - 0.5) * amt * 2;
  return new THREE.Color(clamp(c.r * j, 0, 1), clamp(c.g * j, 0, 1), clamp(c.b * j, 0, 1));
}

function xf(g: THREE.BufferGeometry, x = 0, y = 0, z = 0, sx = 1, sy = 1, sz = 1, ry = 0) {
  const m = new THREE.Matrix4().compose(
    new THREE.Vector3(x, y, z),
    new THREE.Quaternion().setFromEuler(new THREE.Euler(0, ry, 0)),
    new THREE.Vector3(sx, sy, sz)
  );
  g.applyMatrix4(m);
  return g;
}

/* ------------------------------------------------------------------ */
/* Faceted trees & rocks                                                 */
/* ------------------------------------------------------------------ */
const h3 = (x: number, y: number, z: number) => {
  const q = Math.sin(x * 127.1 + y * 311.7 + z * 74.7) * 43758.5453;
  return q - Math.floor(q);
};

const HI_WARM = C(0xfff0a8);
const SH_COOL = C(0x1f3d55);

class GB {
  pos: number[] = [];
  col: number[] = [];
  shadow: THREE.Color = SH_COOL;
  private n = 0;
  /** adds a triangle, flipped so it faces away from `ref`; colour is lit-shaded by its normal */
  tri(a: number[], b: number[], c: number[], base: THREE.Color, ref?: number[], warm = 0.16, cool = 0.4, jit = 0.07) {
    let p = a;
    let q = b;
    let r = c;
    let ux = q[0] - p[0];
    let uy = q[1] - p[1];
    let uz = q[2] - p[2];
    let vx = r[0] - p[0];
    let vy = r[1] - p[1];
    let vz = r[2] - p[2];
    let nx = uy * vz - uz * vy;
    let ny = uz * vx - ux * vz;
    let nz = ux * vy - uy * vx;
    if (ref) {
      const cx = (p[0] + q[0] + r[0]) / 3 - ref[0];
      const cy = (p[1] + q[1] + r[1]) / 3 - ref[1];
      const cz = (p[2] + q[2] + r[2]) / 3 - ref[2];
      if (nx * cx + ny * cy + nz * cz < 0) {
        [q, r] = [r, q];
        ux = q[0] - p[0];
        uy = q[1] - p[1];
        uz = q[2] - p[2];
        vx = r[0] - p[0];
        vy = r[1] - p[1];
        vz = r[2] - p[2];
        nx = uy * vz - uz * vy;
        ny = uz * vx - ux * vz;
        nz = ux * vy - uy * vx;
      }
    }
    const len = Math.hypot(nx, ny, nz) || 1;
    const Y = ny / len;
    const col = base.clone();
    const light = 0.72 + 0.36 * clamp(Y * 0.5 + 0.5, 0, 1) + 0.1 * clamp(Y, 0, 1);
    col.multiplyScalar(light);
    if (Y > 0.35) col.lerp(HI_WARM, warm * (Y - 0.35) / 0.65);
    if (Y < -0.1) col.lerp(this.shadow, cool * clamp(-Y, 0, 1));
    const j = 1 + (h3(this.n * 1.7, p[1] + q[1], p[0] - r[2]) - 0.5) * 2 * jit;
    col.multiplyScalar(j);
    this.n++;
    this.pos.push(p[0], p[1], p[2], q[0], q[1], q[2], r[0], r[1], r[2]);
    for (let k = 0; k < 3; k++) this.col.push(col.r, col.g, col.b);
  }
  geometry() {
    const g = new THREE.BufferGeometry();
    g.setAttribute('position', new THREE.Float32BufferAttribute(this.pos, 3));
    g.setAttribute('color', new THREE.Float32BufferAttribute(this.col, 3));
    g.computeVertexNormals();
    return g;
  }
}

/** tapered N-sided prism (trunk / branch) */
function prism(g: GB, x0: number, y0: number, z0: number, x1: number, y1: number, z1: number, r0: number, r1: number, sides: number, colA: THREE.Color, colB: THREE.Color) {
  const ring = (x: number, y: number, z: number, r: number, off: number) =>
    Array.from({ length: sides }, (_, i) => {
      const a = (i / sides) * Math.PI * 2 + off;
      return [x + Math.cos(a) * r, y, z + Math.sin(a) * r];
    });
  const A = ring(x0, y0, z0, r0, 0.3);
  const B = ring(x1, y1, z1, r1, 0.3);
  const mid = [(x0 + x1) / 2, (y0 + y1) / 2, (z0 + z1) / 2];
  for (let i = 0; i < sides; i++) {
    const j = (i + 1) % sides;
    const c = i % 2 ? colB : colA;
    g.tri(A[i], A[j], B[j], c, mid, 0.05, 0.2, 0.05);
    g.tri(A[i], B[j], B[i], c, mid, 0.05, 0.2, 0.05);
  }
}

/** displaced icosphere used as a leafy clump */
function blob(
  g: GB,
  cx: number, cy: number, cz: number,
  r: number, sy: number,
  detail: number,
  colorOf: (ny: number, yRel: number, face: number) => THREE.Color,
  seed: number,
  rough = 0.26
) {
  const ico = new THREE.IcosahedronGeometry(1, detail).toNonIndexed();
  const p = ico.attributes.position;
  const V: number[][] = [];
  for (let i = 0; i < p.count; i++) {
    let x = p.getX(i);
    let y = p.getY(i);
    let z = p.getZ(i);
    const k = 1 + (h3(x * 3.1 + seed, y * 2.7, z * 3.9 - seed) - 0.5) * rough;
    x *= k;
    y *= k;
    z *= k;
    if (y < -0.45) y = -0.45 + (y + 0.45) * 0.3; // flattened underside
    V.push([cx + x * r, cy + y * r * sy, cz + z * r]);
  }
  const ref = [cx, cy, cz];
  for (let t = 0; t < V.length; t += 3) {
    const a = V[t];
    const b = V[t + 1];
    const c = V[t + 2];
    const yRel = ((a[1] + b[1] + c[1]) / 3 - cy) / (r * sy);
    g.tri(a, b, c, colorOf(0, yRel, t / 3 + seed * 7), ref, 0.14, 0.3, 0.08);
  }
}

/** Spruce / Japanese cedar: slim layered branches, two rows of facets per tier, ragged hem, teal -> lime */
function coniferGeo(hi: boolean, dark: THREE.Color, light: THREE.Color, slender: number, seed: number) {
  const g = new GB();
  g.shadow = dark.clone().multiplyScalar(0.5).lerp(C(0x2a3c7a), 0.3);
  const segs = hi ? 9 : 6;
  const tiers = hi ? 7 : 5;
  const total = 15.5;
  const trunkH = 2.1;
  prism(g, 0, -0.4, 0, 0, total - 3.4, 0, 0.44, 0.14, hi ? 6 : 5, C(0x84604a), C(0x6e4d3a));
  for (let k = 0; k < tiers; k++) {
    const t = k / (tiers - 1);
    const rs = lerp(2.7, 0.75, Math.pow(t, 0.85)) * (1 - 0.34 * slender);
    const hgt = lerp(4.5, 3.1, t);
    const y0 = trunkH + t * (total - trunkH - 4.3);
    const lx = (h3(k, seed, 3) - 0.5) * 0.3;
    const lz = (h3(k, seed, 5) - 0.5) * 0.3;
    const apex = [lx * 0.6, y0 + hgt, lz * 0.6];
    const axis = [lx * 0.3, y0 + hgt * 0.35, lz * 0.3];
    const centre = [lx * 0.3, y0 + 0.15, lz * 0.3];
    const hem: number[][] = [];
    const mid: number[][] = [];
    for (let i = 0; i < segs; i++) {
      const a = (i / segs) * Math.PI * 2 + k * 0.7 + seed;
      const odd = i % 2;
      const rr = rs * (odd ? 0.7 : 1.0) * (0.86 + 0.28 * h3(i, k, seed));
      hem.push([Math.cos(a) * rr + lx * 0.3, y0 - (odd ? 0.6 : 0.05) - 0.15 * h3(i, k, 1), Math.sin(a) * rr + lz * 0.3]);
      const rm = rs * 0.56 * (0.9 + 0.2 * h3(i, k, seed + 2));
      mid.push([Math.cos(a + 0.2) * rm, y0 + hgt * 0.5, Math.sin(a + 0.2) * rm]);
    }
    const base = dark.clone().lerp(light, Math.pow(t, 0.75));
    base.multiplyScalar(k % 2 ? 1.07 : 0.97);
    const under = base.clone().multiplyScalar(0.5);
    for (let i = 0; i < segs; i++) {
      const j = (i + 1) % segs;
      const alt = i % 2 ? 1.1 : 0.92;
      if (hi) {
        g.tri(apex, mid[i], mid[j], base.clone().multiplyScalar(alt * 1.04), axis, 0.34, 0.4, 0.07);
        g.tri(mid[i], hem[i], hem[j], base.clone().multiplyScalar(alt * 0.94), axis, 0.26, 0.4, 0.07);
        g.tri(mid[i], hem[j], mid[j], base.clone().multiplyScalar(alt * 0.98), axis, 0.26, 0.4, 0.07);
      } else {
        g.tri(apex, hem[i], hem[j], base.clone().multiplyScalar(alt), axis, 0.32, 0.4, 0.08);
      }
      g.tri(centre, hem[j], hem[i], under, [apex[0], y0 + hgt, apex[2]], 0.0, 0.2, 0.04);
    }
  }
  return g.geometry();
}

/** round-crowned deciduous tree (maple, zelkova, sakura …) */
function crownGeo(hi: boolean, palette: THREE.Color[], opt: { trunk: number; big: number; blobs: number; height?: number; accent?: THREE.Color; spread?: number }, seed: number) {
  const g = new GB();
  const avg = new THREE.Color(0, 0, 0);
  palette.forEach((c) => avg.add(c));
  avg.multiplyScalar(1 / palette.length);
  g.shadow = avg.clone().multiplyScalar(0.64).lerp(C(0x7a5aa0), 0.2);
  const H = opt.height ?? 4.9;
  const trunkA = C(opt.trunk);
  const trunkB = trunkA.clone().multiplyScalar(0.84);
  prism(g, 0, -0.4, 0, 0, H - 0.8, 0, 0.56, 0.3, hi ? 6 : 5, trunkA, trunkB);
  const pick = (_ny: number, yRel: number, f: number) => {
    const idx = Math.floor(h3(f, seed, 1.3) * palette.length) % palette.length;
    const c = palette[idx].clone();
    // yellower on top, cooler & darker below
    c.lerp(HI_WARM, clamp(yRel, 0, 1) * 0.09);
    c.multiplyScalar(0.9 + clamp(yRel + 0.5, 0, 1.2) * 0.16);
    if (opt.accent && h3(f, seed, 9.1) > 0.9) c.lerp(opt.accent, 0.7);
    return c;
  };
  const spread = opt.spread ?? 1;
  blob(g, 0, H + opt.big * 0.42, 0, opt.big * 1.08, 0.88, hi ? 1 : 0, pick, seed);
  const n = Math.max(1, opt.blobs - 1);
  for (let i = 0; i < n; i++) {
    const a = i * 2.39996 + seed;
    const rad = opt.big * (0.7 + 0.2 * h3(i, seed, 2)) * spread;
    const r = opt.big * (0.64 + 0.22 * h3(i, seed, 3));
    const y = H + opt.big * (0.1 + 0.5 * h3(i, seed, 4));
    blob(g, Math.cos(a) * rad, y, Math.sin(a) * rad, r, 0.88, 0, pick, seed + i + 1);
    if (hi && i < 2) {
      // visible branch towards the clump
      prism(g, 0, H - 1.6 + i * 0.6, 0, Math.cos(a) * rad * 0.55, y - r * 0.3, Math.sin(a) * rad * 0.55, 0.16, 0.07, 4, trunkA, trunkB);
    }
  }
  return g.geometry();
}

/** silver birch (shirakaba) - white trunk with dark bands, airy yellow-green crown */
function birchGeo(hi: boolean) {
  const g = new GB();
  const white = C(0xe9e6dc);
  const dark = C(0x4a4640);
  const H = 10.5;
  const seg = 7;
  for (let k = 0; k < seg; k++) {
    const y0 = -0.4 + (k / seg) * (H + 0.4);
    const y1 = -0.4 + ((k + 1) / seg) * (H + 0.4);
    const r0 = lerp(0.3, 0.14, k / seg);
    const r1 = lerp(0.3, 0.14, (k + 1) / seg);
    prism(g, 0, y0, 0, 0.0, y1, 0.0, r0, r1, 5, k % 3 === 1 ? dark : white, white);
  }
  const pal = [C(0xb7d65a), C(0xa5cc4f), C(0xcbe06a), C(0x8fc24a)];
  const pick = (_n: number, yRel: number, f: number) => {
    const c = pal[Math.floor(h3(f, 4.4, 1) * pal.length) % pal.length].clone();
    c.multiplyScalar(0.86 + clamp(yRel + 0.5, 0, 1) * 0.22);
    return c;
  };
  blob(g, 0, H + 0.6, 0, 2.2, 1.25, hi ? 1 : 0, pick, 5);
  blob(g, 0.9, H - 1.8, 0.5, 1.7, 1.1, 0, pick, 6);
  blob(g, -0.8, H - 3.4, -0.4, 1.5, 1.0, 0, pick, 7);
  return g.geometry();
}

function bushGeo(palette: THREE.Color[], seed: number) {
  const g = new GB();
  const pick = (_n: number, yRel: number, f: number) => {
    const c = palette[Math.floor(h3(f, seed, 6.6) * palette.length) % palette.length].clone();
    return c.multiplyScalar(0.88 + clamp(yRel + 0.5, 0, 1) * 0.22);
  };
  blob(g, 0, 0.55, 0, 1.15, 0.8, 0, pick, seed, 0.3);
  blob(g, 0.85, 0.4, 0.35, 0.8, 0.8, 0, pick, seed + 1, 0.3);
  blob(g, -0.6, 0.38, -0.5, 0.7, 0.8, 0, pick, seed + 2, 0.3);
  return g.geometry();
}

/** tidy faceted boulders: weathered warm-grey, lit by normal, mossy on top */
function rockGeo(kind: 'A' | 'B' | 'C') {
  const src =
    kind === 'C' ? new THREE.DodecahedronGeometry(1, 0) : new THREE.IcosahedronGeometry(1, 1);
  const ng = src.toNonIndexed();
  const p = ng.attributes.position;
  const sx = kind === 'B' ? 1.55 : kind === 'C' ? 1.1 : 1.15;
  const sy = kind === 'B' ? 0.62 : kind === 'C' ? 0.95 : 0.8;
  const sz = kind === 'B' ? 1.05 : 1.0;
  const V: number[][] = [];
  for (let i = 0; i < p.count; i++) {
    const x = p.getX(i);
    const y = p.getY(i);
    const z = p.getZ(i);
    const k = 1 + (h3(x * 5.3, y * 4.1, z * 6.7) - 0.5) * (kind === 'C' ? 0.22 : 0.34);
    let yy = y * k * sy;
    if (yy < -0.4 * sy) yy = -0.4 * sy + (yy + 0.4 * sy) * 0.25; // flat bed
    V.push([x * k * sx, yy, z * k * sz]);
  }
  const g = new GB();
  const pal = [C(0xb3ada0), C(0x9f9a8f), C(0xa8a296), C(0x918d86)];
  const moss = C(0x7fa356);
  const ref = [0, 0, 0];
  for (let t = 0; t < V.length; t += 3) {
    const base = pal[Math.floor(h3(t, 2.2, 7.7) * pal.length) % pal.length].clone();
    const a = V[t];
    const b = V[t + 1];
    const c = V[t + 2];
    // probe the face normal to decide on moss
    const ux = b[0] - a[0];
    const uy = b[1] - a[1];
    const uz = b[2] - a[2];
    const vx = c[0] - a[0];
    const vy = c[1] - a[1];
    const vz = c[2] - a[2];
    const nx = uy * vz - uz * vy;
    const ny = uz * vx - ux * vz;
    const nz = ux * vy - uy * vx;
    const l = Math.hypot(nx, ny, nz) || 1;
    const cy = (a[1] + b[1] + c[1]) / 3;
    const up = (cy > 0 ? ny / l : -ny / l) * (cy > 0 ? 1 : 1);
    const ref2 = ref;
    if (Math.abs(up) > 0.62 && cy > -0.1) base.lerp(moss, 0.42);
    g.tri(a, b, c, base, ref2, 0.12, 0.35, 0.08);
  }
  return g.geometry();
}

/* ------------------------------------------------------------------ */
/* Chunked instancing                                                     */
/* ------------------------------------------------------------------ */
class Chunker {
  cell: number;
  map = new Map<string, { mats: THREE.Matrix4[]; cols: THREE.Color[] }>();
  constructor(cell: number) {
    this.cell = cell;
  }
  add(x: number, z: number, m: THREE.Matrix4, c: THREE.Color) {
    const key = `${Math.floor(x / this.cell)}|${Math.floor(z / this.cell)}`;
    let e = this.map.get(key);
    if (!e) {
      e = { mats: [], cols: [] };
      this.map.set(key, e);
    }
    e.mats.push(m);
    e.cols.push(c);
  }
  build(geo: THREE.BufferGeometry, mat: THREE.Material, parent: THREE.Group, shadow = true, receive = true) {
    this.map.forEach((e) => {
      const im = new THREE.InstancedMesh(geo, mat, e.mats.length);
      for (let i = 0; i < e.mats.length; i++) {
        im.setMatrixAt(i, e.mats[i]);
        im.setColorAt(i, e.cols[i]);
      }
      im.instanceMatrix.needsUpdate = true;
      if (im.instanceColor) im.instanceColor.needsUpdate = true;
      im.castShadow = shadow;
      im.receiveShadow = receive;
      im.computeBoundingSphere();
      parent.add(im);
    });
  }
}

const _m = new THREE.Matrix4();
const _q = new THREE.Quaternion();
const _e = new THREE.Euler();
const _p = new THREE.Vector3();
const _s = new THREE.Vector3();
function mat(x: number, y: number, z: number, sx: number, sy: number, sz: number, ry: number, tilt = 0) {
  _e.set(tilt * Math.sin(ry * 3), ry, tilt * Math.cos(ry * 3));
  _q.setFromEuler(_e);
  _p.set(x, y, z);
  _s.set(sx, sy, sz);
  return new THREE.Matrix4().compose(_p, _q, _s);
}
void _m;

/* ------------------------------------------------------------------ */
export interface SceneryOpts {
  field: RoadField;
  track: Track;
  road: RoadBuild;
  near: NearBounds;
  startLot: Platform;
  finishPlaza: Platform;
}

export function buildScenery(o: SceneryOpts) {
  const group = new THREE.Group();
  const { field, track } = o;
  const rnd = mulberry32(31337);

  const treeMat = new THREE.MeshLambertMaterial({ vertexColors: true, flatShading: true });
  const greenPal = [C(0x4fa142), C(0x5eb049), C(0x428f3d), C(0x6bbd4d)];
  const limePal = [C(0x83be52), C(0x92cb58), C(0x72ac47), C(0x9fd35e)];
  const orangePal = [C(0xe5802d), C(0xdc6e25), C(0xf09a3a), C(0xcd5d1f)];
  const yellowPal = [C(0xf3c632), C(0xe9b724), C(0xf8d850), C(0xdeac1f)];
  const redPal = [C(0xcf3a2e), C(0xdf4a30), C(0xb92e2b), C(0xe66532)];
  const sakuraPal = [C(0xf8b8cf), C(0xf193b4), C(0xfdd6e3), C(0xf5a6c0), C(0xffe8ef)];
  const geos = {
    cedarD: coniferGeo(false, C(0x1d6552), C(0x6fc45e), 0.5, 1),
    cedarL: coniferGeo(false, C(0x3a8d4c), C(0xa3d95c), 0.28, 2),
    cedarDH: coniferGeo(true, C(0x1d6552), C(0x6fc45e), 0.5, 1),
    cedarLH: coniferGeo(true, C(0x3a8d4c), C(0xa3d95c), 0.28, 2),
    green: crownGeo(false, greenPal, { trunk: 0x7c5a43, big: 3.4, blobs: 4 }, 3),
    greenH: crownGeo(true, greenPal, { trunk: 0x7c5a43, big: 3.4, blobs: 5 }, 3),
    lime: crownGeo(false, limePal, { trunk: 0x86644a, big: 3.2, blobs: 4 }, 4),
    limeH: crownGeo(true, limePal, { trunk: 0x86644a, big: 3.2, blobs: 5 }, 4),
    orange: crownGeo(false, orangePal, { trunk: 0x6f4f3a, big: 3.5, blobs: 4 }, 5),
    orangeH: crownGeo(true, orangePal, { trunk: 0x6f4f3a, big: 3.5, blobs: 5 }, 5),
    yellow: crownGeo(false, yellowPal, { trunk: 0x74543d, big: 3.4, blobs: 4 }, 6),
    yellowH: crownGeo(true, yellowPal, { trunk: 0x74543d, big: 3.4, blobs: 5 }, 6),
    red: crownGeo(false, redPal, { trunk: 0x6a4a38, big: 3.3, blobs: 4 }, 7),
    redH: crownGeo(true, redPal, { trunk: 0x6a4a38, big: 3.3, blobs: 5 }, 7),
    sakura: crownGeo(false, sakuraPal, { trunk: 0x57392c, big: 4.0, blobs: 5, height: 4.4, spread: 1.15 }, 8),
    sakuraH: crownGeo(true, sakuraPal, { trunk: 0x57392c, big: 4.0, blobs: 6, height: 4.4, spread: 1.2 }, 8),
    birch: birchGeo(false),
    birchH: birchGeo(true),
    bush: bushGeo([C(0x4f9d44), C(0x63b04c), C(0x428a3d)], 11),
    bushA: bushGeo([C(0xdc742c), C(0xeb9b3a), C(0xc6562a)], 12),
    rockA: rockGeo('A'),
    rockB: rockGeo('B'),
    rockC: rockGeo('C'),
  };
  const HI = new Set(['cedarD', 'cedarL', 'green', 'lime', 'orange', 'yellow', 'red', 'sakura', 'birch']);
  type Key = keyof typeof geos;
  const chunks: Record<Key, Chunker> = {} as Record<Key, Chunker>;
  (Object.keys(geos) as Key[]).forEach((k) => (chunks[k] = new Chunker(340)));

  const treeRows = new Set<number>();
  const sak = track.sections.filter((s) => s.name.startsWith('SAKURA'));
  const inSakura = (i: number) => sak.some((s) => i >= s.s0 - 20 && i <= s.s1 + 20);
  void treeRows;

  // colour variety: every tree gets a warm (yellow-olive) or cool (teal) lean on top of its palette
  const tint = (v = 0.1) => {
    const k = 1 - v + rnd() * v * 2;
    const t = rnd() * 2 - 1;
    return new THREE.Color(k * (1 + 0.1 * t), k * (1 + 0.03 * t), k * (1 - 0.18 * t));
  };

  const sink = (h: number) => h - 0.35;
  const slopeAt = (x: number, z: number, h: number) => {
    const hx = field.height(x + 3, z);
    const hz = field.height(x, z + 3);
    return Math.hypot(hx - h, hz - h) / 3;
  };

  const nearB = o.near;
  const step = 8.2;
  for (let z = nearB.z0 + 6; z < nearB.z1 - 6; z += step) {
    for (let x = nearB.x0 + 6; x < nearB.x1 - 6; x += step) {
      const px = x + (rnd() - 0.5) * step * 0.95;
      const pz = z + (rnd() - 0.5) * step * 0.95;
      const nr = field.nearest(px, pz, 120);
      const d = nr.d;
      if (d < 10.5) continue;
      if (field.platformDist(px, pz) < 6) continue;
      const lr = Math.hypot(px - LAKE.x, pz - LAKE.z);
      if (lr < LAKE.r + 24) continue;
      const h = field.height(px, pz);
      // treeline + steepness
      const tl = 500 + fbm(px / 90, pz / 90, 2) * 50;
      if (h > tl) continue;
      const sl = slopeAt(px, pz, h);
      if (sl > 1.05) continue;
      // density
      const dens = d < 32 ? 0.98 : d < 90 ? 0.8 : d < 200 ? 0.62 : 0.5;
      const mead = meadowMask(px, pz);
      let p = dens * (1 - mead * 0.7);
      p *= 1 - smoothstep(0.7, 1.05, sl) * 0.8;
      // plain/foothills near the bottom: sparser
      p *= 1 - smoothstep(1650, 1850, pz) * 0.55;
      if (rnd() > p) continue;
      const aut = autumnMask(px, pz);
      const blos = blossomMask(px, pz);
      const r = rnd();
      let key: Key;
      if (blos > 0.55 && r < 0.55) key = 'sakura';
      else if (aut > 0.45 && r < aut * 0.95) key = r < 0.3 ? 'orange' : r < 0.55 ? 'yellow' : r < 0.7 ? 'red' : r < 0.85 ? 'orange' : 'cedarL';
      else if (lr < LAKE.r + 190 && r < 0.34) key = 'birch';
      else if (r < 0.5) key = rnd() < 0.5 ? 'cedarD' : 'cedarL';
      else if (r < 0.78) key = 'green';
      else if (r < 0.88) key = 'lime';
      else key = rnd() < 0.5 ? 'bush' : 'bushA';
      if (key === 'bushA' && aut < 0.3) key = 'bush';
      const isCedar = key.startsWith('cedar');
      const isBush = key.startsWith('bush');
      const s = isBush ? 0.8 + rnd() * 1.2 : isCedar ? 0.85 + rnd() * 0.55 : 0.85 + rnd() * 0.65;
      const sy = isCedar ? s * (1.0 + rnd() * 0.55) : s;
      const kk = (d < 56 && HI.has(key) ? `${key}H` : key) as Key;
      chunks[kk].add(px, pz, mat(px, sink(h), pz, s, sy, s, rnd() * 6.28, 0.04), tint(0.1));
    }
  }

  // sakura avenue along the "SAKURA SWEEPERS" (pink canopy hugging the road like the reference photo)
  for (let i = 0; i < track.n; i += 9) {
    if (!inSakura(i)) continue;
    for (const side of [1, -1]) {
      if (rnd() < 0.18) continue;
      const lat = side * (10.5 + rnd() * 7);
      const fr = roadFrame(track, i, lat);
      const px = fr.x + (rnd() - 0.5) * 3;
      const pz = fr.z + (rnd() - 0.5) * 3;
      const nr = field.nearest(px, pz, 30);
      if (nr.d < 9.5) continue;
      const h = field.height(px, pz);
      if (slopeAt(px, pz, h) > 1.1) continue;
      const s = 0.95 + rnd() * 0.55;
      chunks.sakuraH.add(px, pz, mat(px, sink(h), pz, s, s * (0.9 + rnd() * 0.3), s, rnd() * 6.28, 0.03), tint(0.06));
    }
  }
  // a few special trees close to the road everywhere (the reference shows overhanging green)
  for (let i = 120; i < track.n - 100; i += 17) {
    const side = rnd() < 0.5 ? 1 : -1;
    const lat = side * (9.5 + rnd() * 4);
    const fr = roadFrame(track, i, lat);
    const nr = field.nearest(fr.x, fr.z, 20);
    if (nr.d < 9.2) continue;
    const h = field.height(fr.x, fr.z);
    if (slopeAt(fr.x, fr.z, h) > 1.2) continue;
    const aut = autumnMask(fr.x, fr.z);
    const key: Key = aut > 0.45 ? (rnd() < 0.5 ? 'orange' : 'yellow') : rnd() < 0.6 ? 'cedarD' : 'green';
    const s = 0.95 + rnd() * 0.4;
    chunks[`${key}H` as Key].add(fr.x, fr.z, mat(fr.x, sink(h), fr.z, s, s * 1.1, s, rnd() * 6.28, 0.03), tint(0.08));
  }

  // rocks: tidy clusters (one boulder + a few smaller ones), half-buried, never in the lane
  const rockKinds: Key[] = ['rockA', 'rockB', 'rockC', 'rockA'];
  const rockCluster = (cx: number, cz: number, scale: number) => {
    const n = 1 + Math.floor(rnd() * 3);
    for (let i = 0; i < n; i++) {
      const a = rnd() * 6.28;
      const off = i === 0 ? 0 : scale * (0.9 + rnd() * 0.9);
      const x = cx + Math.cos(a) * off;
      const z = cz + Math.sin(a) * off;
      const nr = field.nearest(x, z, 14);
      if (nr.d < 8.6) continue;
      const h = field.height(x, z);
      const s0 = i === 0 ? scale : scale * (0.32 + rnd() * 0.32);
      const key = rockKinds[Math.floor(rnd() * rockKinds.length)];
      chunks[key].add(x, z, mat(x, h + s0 * 0.02, z, s0, s0, s0 * (0.85 + rnd() * 0.3), rnd() * 6.28, 0.1), tint(0.07));
    }
  };
  // along the cut slopes: small, regular, tucked against the foot of the bank
  for (let i = 10; i < track.n - 10; i += 19) {
    for (const side of [1, -1]) {
      const isCut = (side === 1 ? o.road.cutL[i] : o.road.cutR[i]) === 1;
      if (!isCut || rnd() < 0.45) continue;
      const fr = roadFrame(track, i + Math.floor(rnd() * 8), side * (9.3 + rnd() * 3.4));
      rockCluster(fr.x, fr.z, 0.55 + rnd() * 0.9);
    }
  }
  // a few bigger outcrops on steep mountain faces
  for (let k = 0; k < 240; k++) {
    const px = nearB.x0 + rnd() * (nearB.x1 - nearB.x0);
    const pz = nearB.z0 + rnd() * (nearB.z1 - nearB.z0);
    const nr = field.nearest(px, pz, 60);
    if (nr.d < 15) continue;
    const h = field.height(px, pz);
    if (slopeAt(px, pz, h) < 0.55) continue;
    if (Math.hypot(px - LAKE.x, pz - LAKE.z) < LAKE.r + 10 && h < LAKE.y + 2) continue;
    rockCluster(px, pz, 1.4 + Math.pow(rnd(), 2) * 2.6);
  }

  // far forest (cheap cones) beyond the detailed region
  const farGeo = (() => {
    const parts: THREE.BufferGeometry[] = [];
    parts.push(bake(xf(new THREE.ConeGeometry(4.2, 12, 5, 1, true), 0, 6, 0), (cy, f) => new THREE.Color(0.7 + cy / 12 * 0.35, 0.7 + cy / 12 * 0.35, 0.7 + cy / 12 * 0.35).multiplyScalar(0.9 + faceRnd(f) * 0.2)));
    parts.push(bake(xf(new THREE.ConeGeometry(2.6, 8, 5, 1, true), 0, 12, 0), (cy, f) => new THREE.Color(0.85 + (cy - 8) / 12 * 0.2, 0.85 + (cy - 8) / 12 * 0.2, 0.85).multiplyScalar(0.9 + faceRnd(f, 2) * 0.2)));
    return mergeGeometries(parts)!;
  })();
  const farChunks = new Chunker(900);
  {
    const fs = 17;
    const fr = mulberry32(555);
    for (let z = -1500; z < 3100; z += fs) {
      for (let x = -1500; x < 1500; x += fs) {
        const px = x + (fr() - 0.5) * fs;
        const pz = z + (fr() - 0.5) * fs;
        if (px > nearB.x0 - 4 && px < nearB.x1 + 4 && pz > nearB.z0 - 4 && pz < nearB.z1 + 4) continue;
        const h = baseHeight(px, pz);
        const tl = 520 + fbm(px / 120, pz / 120, 2) * 70;
        if (h > tl) continue;
        const hx = baseHeight(px + 12, pz);
        const hz = baseHeight(px, pz + 12);
        const sl = Math.hypot(hx - h, hz - h) / 12;
        if (sl > 1.15) continue;
        if (Math.hypot(px - LAKE.x, pz - LAKE.z) < LAKE.r + 40) continue;
        if (pz > 2300 && fbm(px / 400, pz / 400, 2) < 0.15) continue; // fields on the plain
        const mead = meadowMask(px, pz);
        if (fr() < mead * 0.65) continue;
        const aut = autumnMask(px, pz);
        const blos = blossomMask(px, pz);
        const col = new THREE.Color();
        const r = fr();
        if (aut > 0.45 && r < aut) col.setHex(r < 0.4 ? 0xd9782c : r < 0.7 ? 0xe2b23a : 0xc9402a);
        else if (blos > 0.6 && r < 0.45) col.setHex(0xf3a9c3);
        else col.setHex(r < 0.55 ? 0x2d6a42 : r < 0.8 ? 0x3d8a4b : 0x5aa04c);
        const s = 1.3 + fr() * 1.2;
        farChunks.add(px, pz, mat(px, h - 0.8, pz, s, s * (0.9 + fr() * 0.7), s, fr() * 6), col);
      }
    }
  }

  (Object.keys(chunks) as Key[]).forEach((k) => chunks[k].build(geos[k], treeMat, group, k !== 'bush' && k !== 'bushA', false));
  farChunks.build(farGeo, treeMat, group, false, false);

  /* ----- banners / flags along the road ----- */
  const flagTexts: [string, string, string][] = [
    ['榛名山', 'HARUNA', '#d62828'],
    ['峠最速', 'TOUGE', '#1d3557'],
    ['DRIFT', 'KING', '#f77f00'],
    ['走り屋', 'RACING', '#2a9d8f'],
    ['秋名', 'AKINA', '#7b2cbf'],
  ];
  const flagTex = flagTexts.map(([a, b, bg]) =>
    canvasTex(128, 384, (ctx, w, h) => {
      ctx.fillStyle = bg;
      ctx.fillRect(0, 0, w, h);
      ctx.fillStyle = 'rgba(255,255,255,0.95)';
      ctx.fillRect(8, 8, w - 16, 6);
      ctx.fillRect(8, h - 14, w - 16, 6);
      ctx.textAlign = 'center';
      ctx.fillStyle = '#fff';
      ctx.font = '900 66px "Hiragino Kaku Gothic Pro","Yu Gothic","Noto Sans CJK JP","Arial Black",sans-serif';
      const chars = Array.from(a);
      chars.forEach((c, k) => ctx.fillText(c, w / 2, 90 + k * 76));
      ctx.font = '800 26px Arial, sans-serif';
      ctx.fillStyle = '#ffe9a8';
      ctx.fillText(b, w / 2, h - 28);
    })
  );
  const flagGeo = new THREE.PlaneGeometry(0.95, 2.6);
  const poleGeo = new THREE.BoxGeometry(0.07, 3.6, 0.07);
  const poleMat = new THREE.MeshLambertMaterial({ color: 0x777c84, flatShading: true });
  const flagMeshes: THREE.InstancedMesh[] = [];
  const flagLists: THREE.Matrix4[][] = flagTex.map(() => []);
  const poleList: THREE.Matrix4[] = [];
  const placeFlag = (i: number, lat: number, k: number) => {
    const fr = roadFrame(track, i, lat);
    const up = new THREE.Vector3(0, 1, 0);
    const back = fr.f.clone().negate();
    const m = new THREE.Matrix4().makeBasis(fr.r, up, back);
    m.setPosition(fr.x - fr.r.x * 0.5 * Math.sign(lat), fr.y + 2.2, fr.z - fr.r.z * 0.5 * Math.sign(lat));
    flagLists[k % flagTex.length].push(m);
    const pm = new THREE.Matrix4().makeBasis(fr.r, up, back);
    pm.setPosition(fr.x, fr.y + 1.4, fr.z);
    poleList.push(pm);
  };
  const five = track.sections.find((s) => s.name.startsWith('FIVE'))!;
  let fk = 0;
  for (let i = Math.floor(five.s0) + 10; i < Math.floor(five.s1) - 60; i += 34) placeFlag(i, 6.0 * (rnd() < 0.5 ? 1 : -1) * 1, fk++);
  for (let i = Math.floor(track.startS) - 30; i < track.startS + 200; i += 26) {
    placeFlag(i, 6.0, fk++);
    placeFlag(i + 13, -6.0, fk++);
  }
  for (let i = Math.floor(track.finishS) - 120; i < track.finishS + 4; i += 28) {
    placeFlag(i, 6.0, fk++);
    placeFlag(i + 14, -6.0, fk++);
  }
  flagTex.forEach((t, k) => {
    const im = new THREE.InstancedMesh(flagGeo, new THREE.MeshLambertMaterial({ map: t, side: THREE.DoubleSide }), flagLists[k].length);
    flagLists[k].forEach((m, q) => im.setMatrixAt(q, m));
    im.castShadow = true;
    group.add(im);
    flagMeshes.push(im);
  });
  const poles = new THREE.InstancedMesh(poleGeo, poleMat, poleList.length);
  poleList.forEach((m, q) => poles.setMatrixAt(q, m));
  poles.castShadow = true;
  group.add(poles);

  /* ----- start parking lot ----- */
  const lot = o.startLot;
  {
    const asphalt = new THREE.Mesh(
      new THREE.CylinderGeometry(lot.r - 0.2, lot.r - 0.2, 0.8, 28, 1),
      new THREE.MeshLambertMaterial({ color: 0x6b6f79, flatShading: true })
    );
    asphalt.position.set(lot.x, lot.y - 0.4, lot.z);
    asphalt.receiveShadow = true;
    group.add(asphalt);
    const ring = new THREE.Mesh(
      new THREE.CylinderGeometry(lot.r, lot.r, 0.8, 28, 1, true),
      new THREE.MeshLambertMaterial({ color: 0xb9bdc0, flatShading: true, side: THREE.DoubleSide })
    );
    ring.position.set(lot.x, lot.y - 0.42, lot.z);
    group.add(ring);
    // slot lines
    const lineMat = new THREE.MeshBasicMaterial({ color: 0xf1efe6 });
    const sd = track.psi[Math.floor(track.startS) - 40];
    for (let k = -3; k <= 3; k++) {
      const l = new THREE.Mesh(new THREE.BoxGeometry(0.14, 0.02, 5), lineMat);
      l.position.set(lot.x + Math.cos(sd) * k * 2.9 - Math.sin(sd) * 0, lot.y + 0.015, lot.z - Math.sin(sd) * k * 2.9);
      l.rotation.y = sd;
      // move the row toward the lot edge opposite to the road
      l.position.x += Math.sin(sd) * 7;
      l.position.z += Math.cos(sd) * 7;
      group.add(l);
    }
    // parked cars
    const styles: CarStyle[] = [STYLE_BLUE, STYLE_YELLOW, STYLE_RED, STYLE_SILVER, PANDA];
    const base = sd;
    styles.forEach((st, k) => {
      const c = buildCar(st);
      const off = (k - 2) * 2.9;
      c.root.position.set(
        lot.x + Math.cos(base) * off + Math.sin(base) * 7.2 + (rnd() - 0.5) * 0.3,
        lot.y + 0.01,
        lot.z - Math.sin(base) * off + Math.cos(base) * 7.2
      );
      c.root.rotation.y = base + Math.PI + (rnd() - 0.5) * 0.12;
      group.add(c.root);
    });
    // vending machines + shelter
    const vm = (x: number, z: number, col: number, ry: number) => {
      const b = new THREE.Mesh(new THREE.BoxGeometry(0.9, 1.9, 0.8), new THREE.MeshLambertMaterial({ color: col, flatShading: true }));
      b.position.set(x, lot.y + 0.95, z);
      b.rotation.y = ry;
      b.castShadow = true;
      group.add(b);
      const glow = new THREE.Mesh(new THREE.PlaneGeometry(0.7, 0.9), new THREE.MeshBasicMaterial({ color: 0xcfeeff }));
      glow.position.set(x + Math.sin(ry) * 0.41, lot.y + 1.15, z + Math.cos(ry) * 0.41);
      glow.rotation.y = ry;
      group.add(glow);
    };
    const ox = Math.cos(base);
    const oz = -Math.sin(base);
    const fx = Math.sin(base);
    const fz = Math.cos(base);
    vm(lot.x + ox * 14 - fx * 4, lot.z + oz * 14 - fz * 4, 0xd62828, base + Math.PI / 2 + 0.2);
    vm(lot.x + ox * 14 - fx * 5.2, lot.z + oz * 14 - fz * 5.2, 0x1d6fd6, base + Math.PI / 2 + 0.2);
    // red torii gate (Haruna shrine vibe) at the lot edge facing the lake
    const torii = new THREE.Group();
    const red = new THREE.MeshLambertMaterial({ color: 0xc8341f, flatShading: true });
    const blk = new THREE.MeshLambertMaterial({ color: 0x1b1a1d, flatShading: true });
    for (const s of [-1, 1]) {
      const p = new THREE.Mesh(new THREE.CylinderGeometry(0.28, 0.34, 5.4, 7), red);
      p.position.set(s * 2.1, 2.7, 0);
      p.castShadow = true;
      torii.add(p);
    }
    const nuki = new THREE.Mesh(new THREE.BoxGeometry(5.4, 0.3, 0.32), red);
    nuki.position.y = 4.1;
    const kasa = new THREE.Mesh(new THREE.BoxGeometry(6.6, 0.32, 0.6), blk);
    kasa.position.y = 5.55;
    const kasa2 = new THREE.Mesh(new THREE.BoxGeometry(6.0, 0.26, 0.5), red);
    kasa2.position.y = 5.28;
    torii.add(nuki, kasa, kasa2);
    const tx = lot.x - ox * 13 + fx * 6;
    const tz = lot.z - oz * 13 + fz * 6;
    torii.position.set(tx, lot.y - 0.0, tz);
    torii.rotation.y = base + Math.PI / 2 + 0.4;
    group.add(torii);
  }

  /* ----- finish plaza: gas station + cars ----- */
  const pl = o.finishPlaza;
  {
    const asphalt = new THREE.Mesh(
      new THREE.CylinderGeometry(pl.r - 0.2, pl.r - 0.2, 0.8, 32, 1),
      new THREE.MeshLambertMaterial({ color: 0x666a73, flatShading: true })
    );
    asphalt.position.set(pl.x, pl.y - 0.4, pl.z);
    asphalt.receiveShadow = true;
    group.add(asphalt);
    const ring = new THREE.Mesh(
      new THREE.CylinderGeometry(pl.r, pl.r, 0.8, 32, 1, true),
      new THREE.MeshLambertMaterial({ color: 0xb9bdc0, flatShading: true, side: THREE.DoubleSide })
    );
    ring.position.set(pl.x, pl.y - 0.42, pl.z);
    group.add(ring);
    const ps = track.psi[track.n - 1];
    const fx = Math.sin(ps);
    const fz = Math.cos(ps);
    const lx = Math.cos(ps);
    const lz = -Math.sin(ps);
    // canopy
    const cx = pl.x + lx * 22 + fx * 6;
    const cz = pl.z + lz * 22 + fz * 6;
    const canopy = new THREE.Group();
    const roof = new THREE.Mesh(new THREE.BoxGeometry(14, 0.5, 8), new THREE.MeshLambertMaterial({ color: 0xf0f0ee, flatShading: true }));
    roof.position.y = 5.2;
    roof.castShadow = true;
    const stripe = new THREE.Mesh(new THREE.BoxGeometry(14.1, 0.35, 8.1), new THREE.MeshLambertMaterial({ color: 0xe03a2e, flatShading: true }));
    stripe.position.y = 4.95;
    canopy.add(roof, stripe);
    for (const sx of [-5.5, 5.5]) {
      for (const sz of [-2.8, 2.8]) {
        const p = new THREE.Mesh(new THREE.BoxGeometry(0.35, 5, 0.35), new THREE.MeshLambertMaterial({ color: 0xd5d8dc, flatShading: true }));
        p.position.set(sx, 2.5, sz);
        canopy.add(p);
      }
    }
    for (const sx of [-2.5, 2.5]) {
      const pump = new THREE.Mesh(new THREE.BoxGeometry(0.7, 1.5, 0.5), new THREE.MeshLambertMaterial({ color: sx < 0 ? 0xe03a2e : 0x2a6fd6, flatShading: true }));
      pump.position.set(sx, 0.75, 0);
      canopy.add(pump);
    }
    canopy.position.set(cx, pl.y, cz);
    canopy.rotation.y = ps + Math.PI / 2;
    group.add(canopy);
    const shop = new THREE.Mesh(new THREE.BoxGeometry(12, 4.2, 7), new THREE.MeshLambertMaterial({ color: 0xe8e2d2, flatShading: true }));
    shop.position.set(cx + lx * 10, pl.y + 2.1, cz + lz * 10);
    shop.rotation.y = ps + Math.PI / 2;
    shop.castShadow = true;
    group.add(shop);
    const shopRoof = new THREE.Mesh(new THREE.BoxGeometry(12.8, 0.4, 7.8), new THREE.MeshLambertMaterial({ color: 0xc23a2c, flatShading: true }));
    shopRoof.position.set(shop.position.x, pl.y + 4.4, shop.position.z);
    shopRoof.rotation.y = ps + Math.PI / 2;
    group.add(shopRoof);
    [STYLE_RED, STYLE_SILVER, STYLE_YELLOW].forEach((st, k) => {
      const c = buildCar(st);
      c.root.position.set(pl.x - lx * (10 + k * 3.2) + fx * (14 + k * 2), pl.y + 0.01, pl.z - lz * (10 + k * 3.2) + fz * (14 + k * 2));
      c.root.rotation.y = ps + 0.5 + k * 0.7;
      group.add(c.root);
    });
  }

  /* ----- village near the foot + far city on the plain ----- */
  const houseParts: THREE.BufferGeometry[] = [];
  const roofCols = [0xb5412d, 0x2f5d8a, 0x4a6b4a, 0x7a3a2a, 0x555b66];
  const wallCols = [0xf0ebe0, 0xe6dcc8, 0xd8d4c8, 0xf4f1ea, 0xcfc7b4];
  const addHouse = (x: number, y: number, z: number, w: number, h: number, d: number, ry: number, kk: number) => {
    const wallC = C(wallCols[kk % wallCols.length]);
    const roofC = C(roofCols[(kk * 7) % roofCols.length]);
    const b = bake(xf(new THREE.BoxGeometry(w, h, d), 0, h / 2, 0), (_cy, f) => jitterColor(wallC, f, 0.04));
    const r = bake(
      xf(new THREE.ConeGeometry(Math.max(w, d) * 0.78, h * 0.55, 4, 1), 0, h + h * 0.27, 0, 1, 1, 1, Math.PI / 4),
      (_cy, f) => jitterColor(roofC, f, 0.08)
    );
    r.scale(w >= d ? 1 : d / w, 1, w >= d ? d / w : 1);
    for (const g of [b, r]) {
      g.rotateY(ry);
      g.translate(x, y, z);
      houseParts.push(g);
    }
  };
  {
    const vr = mulberry32(2024);
    const tail = track.n - 1;
    const bx = track.x[tail];
    const bz = track.z[tail];
    for (let k = 0; k < 130; k++) {
      const px = bx - 460 + vr() * 920;
      const pz = bz + 160 + vr() * 520;
      const h = baseHeight(px, pz);
      const hx = baseHeight(px + 6, pz);
      const hz = baseHeight(px, pz + 6);
      if (Math.hypot(hx - h, hz - h) / 6 > 0.22) continue;
      if (Math.hypot(px - bx, pz - bz) < 90) continue;
      addHouse(px, h - 0.2, pz, 8 + vr() * 6, 4.5 + vr() * 3, 8 + vr() * 5, Math.floor(vr() * 4) * 0.4 + 0.1, k);
    }
  }
  if (houseParts.length) {
    const hg = mergeGeometries(houseParts)!;
    const hm = new THREE.Mesh(hg, new THREE.MeshLambertMaterial({ vertexColors: true, flatShading: true }));
    hm.castShadow = false;
    hm.receiveShadow = false;
    group.add(hm);
  }
  {
    const cr = mulberry32(88);
    const parts: THREE.BufferGeometry[] = [];
    const cols = [0xdfe3e8, 0xc9d0d8, 0xe9e4da, 0xb8c2cf, 0xf1f1ee, 0xa7b6c8];
    for (let k = 0; k < 900; k++) {
      const px = -1500 + cr() * 3000;
      const pz = 2500 + cr() * 1400;
      const dcen = Math.hypot(px - 150, pz - 3100) / 900;
      const hgt = (8 + Math.pow(cr(), 2.4) * 80) * (1.4 - clamp(dcen, 0, 1.2));
      if (hgt < 6) continue;
      const w = 14 + cr() * 38;
      const d = 14 + cr() * 38;
      const y = baseHeight(px, pz);
      const c = C(cols[Math.floor(cr() * cols.length)]);
      const g = bake(xf(new THREE.BoxGeometry(w, hgt, d), px, y + hgt / 2 - 0.5, pz), (cy, f) => jitterColor(c, f, 0.05).multiplyScalar(0.92 + clamp((cy - y) / 100, 0, 0.12)));
      parts.push(g);
    }
    const cg = mergeGeometries(parts)!;
    group.add(new THREE.Mesh(cg, new THREE.MeshLambertMaterial({ vertexColors: true, flatShading: true })));
  }
  void lerp;
  return { group };
}
